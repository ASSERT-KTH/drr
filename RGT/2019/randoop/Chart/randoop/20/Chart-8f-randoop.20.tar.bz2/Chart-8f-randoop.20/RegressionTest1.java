import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
        java.lang.Throwable throwable16 = null;
        try {
            timePeriodFormatException7.addSuppressed(throwable16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        java.util.Date date13 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date5, timeZone19);
        long long23 = week22.getFirstMillisecond();
        int int24 = week22.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61729228800000L) + "'", long23 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 53);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 6, 53" + "'", str3.equals("Week 6, 53"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 47);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 12);
//        int int7 = week5.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.Date date11 = week10.getStart();
//        int int12 = week0.compareTo((java.lang.Object) date11);
//        int int13 = week0.getWeek();
//        long long14 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        long long9 = week7.getMiddleMillisecond();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.previous();
//        java.lang.String str14 = week11.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 12);
//        int int21 = week19.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week19.next();
//        java.util.Date date23 = week19.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.lang.String str25 = week24.toString();
//        long long26 = week24.getFirstMillisecond();
//        org.jfree.data.time.Year year27 = week24.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week24.next();
//        java.util.Date date29 = week24.getEnd();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date29, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date23, timeZone32);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date16, timeZone32);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(100, 12);
//        int int41 = week39.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass42 = week39.getClass();
//        java.util.Date date43 = week39.getStart();
//        java.lang.Class class44 = null;
//        java.util.Date date45 = null;
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
//        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date16, timeZone46);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date10, timeZone46);
//        int int52 = week51.getYearValue();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1545249599999L + "'", long9 == 1545249599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 24, 2019" + "'", str25.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2018 + "'", int52 == 2018);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        int int10 = week7.getWeek();
        try {
            org.jfree.data.time.Year year11 = week7.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47 + "'", int8 == 47);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 100, 12" + "'", str7.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        long long6 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
//        java.util.Date date8 = week2.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.lang.String str21 = week20.toString();
//        long long22 = week20.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = week20.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week20.next();
//        java.util.Date date25 = week20.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
//        java.util.Date date30 = regularTimePeriod29.getStart();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date30, timeZone33);
//        java.lang.Class<?> wildcardClass36 = date30.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(100, 12);
//        int int41 = week39.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass42 = week39.getClass();
//        java.util.Date date43 = week39.getStart();
//        java.lang.Class class44 = null;
//        java.util.Date date45 = null;
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
//        java.util.Date date53 = regularTimePeriod52.getStart();
//        java.lang.Class class54 = null;
//        java.util.Date date55 = null;
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date53, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone56);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
//        java.util.Date date64 = regularTimePeriod63.getStart();
//        java.lang.Class class65 = null;
//        java.util.Date date66 = null;
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date64, timeZone67);
//        java.lang.Class<?> wildcardClass70 = date64.getClass();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(100, 12);
//        int int75 = week73.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass76 = week73.getClass();
//        java.util.Date date77 = week73.getStart();
//        java.lang.Class class78 = null;
//        java.util.Date date79 = null;
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date79, timeZone80);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date77, timeZone80);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = week85.previous();
//        java.util.Date date87 = regularTimePeriod86.getStart();
//        java.lang.Class class88 = null;
//        java.util.Date date89 = null;
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class88, date89, timeZone90);
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date87, timeZone90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date77, timeZone90);
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date43, timeZone90);
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date25, timeZone90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date18, timeZone90);
//        java.lang.Class class97 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNull(regularTimePeriod96);
//        org.junit.Assert.assertNotNull(class97);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        java.util.Date date7 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        int int10 = week2.compareTo((java.lang.Object) 0);
        int int12 = week2.compareTo((java.lang.Object) 53);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 12" + "'", str5.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.lang.String str9 = week2.toString();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
        int int14 = week12.compareTo((java.lang.Object) false);
        long long15 = week12.getMiddleMillisecond();
        long long16 = week12.getLastMillisecond();
        java.util.Date date17 = week12.getEnd();
        int int19 = week12.compareTo((java.lang.Object) 8);
        int int20 = week2.compareTo((java.lang.Object) int19);
        long long21 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61728926400001L) + "'", long15 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61728624000001L) + "'", long16 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61728624000001L) + "'", long21 == (-61728624000001L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        int int10 = week7.getWeek();
        java.lang.String str11 = week7.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week7.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47 + "'", int8 == 47);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 47, 13" + "'", str11.equals("Week 47, 13"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559761199999L + "'", long7 == 1559761199999L);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str10 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(2, (int) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
        java.lang.Class<?> wildcardClass24 = timePeriodFormatException21.getClass();
        java.lang.String str25 = timePeriodFormatException21.toString();
        java.lang.String str26 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException21.getSuppressed();
        java.lang.String str29 = timePeriodFormatException21.toString();
        boolean boolean30 = week16.equals((java.lang.Object) timePeriodFormatException21);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 8);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        long long9 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = week0.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        int int8 = week0.compareTo((java.lang.Object) "");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.String str11 = timePeriodFormatException10.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException16.getSuppressed();
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException16.getClass();
//        java.lang.String str20 = timePeriodFormatException16.toString();
//        java.lang.String str21 = timePeriodFormatException16.toString();
//        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
//        java.lang.Throwable[] throwableArray30 = timePeriodFormatException28.getSuppressed();
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException28.getClass();
//        java.lang.String str32 = timePeriodFormatException28.toString();
//        java.lang.String str33 = timePeriodFormatException28.toString();
//        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
//        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
//        boolean boolean36 = week0.equals((java.lang.Object) timePeriodFormatException13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertNotNull(throwableArray17);
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 47, 13");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week -1, 3" + "'", str3.equals("Week -1, 3"));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException14.getClass();
        java.lang.String str18 = timePeriodFormatException14.toString();
        java.lang.String str19 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str23 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException11.getSuppressed();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException11.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        java.util.Date date6 = week3.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        java.util.Date date9 = week7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        long long13 = week12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.previous();
//        java.lang.String str15 = week12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week12.next();
//        java.util.Date date17 = regularTimePeriod16.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 12);
//        int int22 = week20.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week20.next();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.lang.String str26 = week25.toString();
//        long long27 = week25.getFirstMillisecond();
//        org.jfree.data.time.Year year28 = week25.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week25.next();
//        java.util.Date date30 = week25.getEnd();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date30, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date24, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date17, timeZone33);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(100, 12);
//        int int42 = week40.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        java.util.Date date44 = week40.getStart();
//        java.lang.Class class45 = null;
//        java.util.Date date46 = null;
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date44, timeZone47);
//        java.lang.Class<?> wildcardClass50 = timeZone47.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date17, timeZone47);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date9, timeZone47);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date6, timeZone47);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
//        int int15 = week13.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        java.util.Date date17 = week13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
//        java.lang.Class<?> wildcardClass23 = date17.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(100, 12);
//        int int28 = week26.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass29 = week26.getClass();
//        java.util.Date date30 = week26.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
//        java.util.Date date32 = week31.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(100, 12);
//        int int36 = week35.getWeek();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(100, 12);
//        int int41 = week39.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass42 = week39.getClass();
//        java.util.Date date43 = week39.getStart();
//        java.lang.Class class44 = null;
//        java.util.Date date45 = null;
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
//        int int49 = week35.compareTo((java.lang.Object) timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date32, timeZone46);
//        java.util.Locale locale51 = null;
//        try {
//            org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date5, timeZone46, locale51);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        java.util.Date date4 = week3.getStart();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        int int9 = week7.getYearValue();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
//        int int14 = week12.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.next();
//        java.util.Date date16 = week12.getStart();
//        int int17 = week12.getWeek();
//        java.lang.Object obj18 = null;
//        int int19 = week12.compareTo(obj18);
//        boolean boolean20 = week7.equals((java.lang.Object) week12);
//        int int21 = week12.getWeek();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        boolean boolean4 = week1.equals((java.lang.Object) 0.0d);
//        long long5 = week1.getMiddleMillisecond();
//        long long6 = week1.getSerialIndex();
//        java.util.Date date7 = week1.getStart();
//        org.jfree.data.time.Year year8 = week1.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
//        java.util.Calendar calendar10 = null;
//        try {
//            week9.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        java.lang.Class<?> wildcardClass22 = timePeriodFormatException19.getClass();
        java.lang.String str23 = timePeriodFormatException19.toString();
        java.lang.String str24 = timePeriodFormatException19.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        java.lang.Class<?> wildcardClass30 = timePeriodFormatException28.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException32.getSuppressed();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException32.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException19.getSuppressed();
        java.lang.Throwable[] throwableArray38 = timePeriodFormatException19.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray38);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 47, 13");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getFirstMillisecond();
        java.lang.String str10 = week2.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 100, 12" + "'", str10.equals("Week 100, 12"));
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getSerialIndex();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int8 = week5.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        long long6 = week3.getMiddleMillisecond();
//        long long7 = week3.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException20.getSuppressed();
        java.lang.Class<?> wildcardClass23 = timePeriodFormatException20.getClass();
        java.lang.String str24 = timePeriodFormatException20.toString();
        java.lang.String str25 = timePeriodFormatException20.toString();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        java.lang.Class<?> wildcardClass32 = timePeriodFormatException30.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException39.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
        java.lang.Class<?> wildcardClass45 = timePeriodFormatException43.getClass();
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(throwableArray47);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year8);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        long long16 = week2.getFirstMillisecond();
//        long long17 = week2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 11);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61813598400001L) + "'", long3 == (-61813598400001L));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        org.jfree.data.time.Year year16 = week5.getYear();
//        long long17 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107007L + "'", long17 == 107007L);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
//        java.lang.String str31 = week28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week28.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = week41.getEnd();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date40, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        java.util.Date date56 = week55.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date56);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str22 = timePeriodFormatException16.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(3, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year4);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.lang.Class<?> wildcardClass5 = date3.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getSerialIndex();
//        int int5 = week3.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 24);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.lang.String str30 = week29.toString();
//        long long31 = week29.getFirstMillisecond();
//        org.jfree.data.time.Year year32 = week29.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week29.next();
//        java.util.Date date34 = week29.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.lang.String str36 = week35.toString();
//        long long37 = week35.getFirstMillisecond();
//        org.jfree.data.time.Year year38 = week35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week35.next();
//        java.util.Date date40 = week35.getStart();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(100, 12);
//        int int45 = week43.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass46 = week43.getClass();
//        java.util.Date date47 = week43.getStart();
//        java.lang.Class class48 = null;
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date47, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date40, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date34, timeZone50);
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 24, 2019" + "'", str30.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560063600000L + "'", long31 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560063600000L + "'", long37 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(class55);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 4);
//        long long3 = week2.getLastMillisecond();
//        java.lang.String str4 = week2.toString();
//        java.util.Date date5 = week2.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.lang.String str14 = week13.toString();
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.Year year16 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week13.next();
//        java.util.Date date18 = week13.getEnd();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5, timeZone26);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62039491200001L) + "'", long3 == (-62039491200001L));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 3, 4" + "'", str4.equals("Week 3, 4"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        java.util.Date date17 = week0.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 12);
//        int int22 = week20.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week20.next();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getLastMillisecond();
//        boolean boolean28 = week25.equals((java.lang.Object) 0.0d);
//        long long29 = week25.getMiddleMillisecond();
//        int int30 = week25.getWeek();
//        java.lang.String str31 = week25.toString();
//        java.lang.Class<?> wildcardClass32 = week25.getClass();
//        java.util.Date date33 = null;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        java.util.Date date39 = week36.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
//        java.lang.Class<?> wildcardClass43 = timePeriodFormatException41.getClass();
//        java.util.Date date44 = null;
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
//        java.util.Date date47 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
//        java.lang.Class<?> wildcardClass51 = timePeriodFormatException49.getClass();
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone53);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date39, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone53);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date24, timeZone53);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date17, timeZone53);
//        java.util.Calendar calendar60 = null;
//        try {
//            long long61 = week59.getLastMillisecond(calendar60);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(throwableArray50);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 0");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException9.getClass();
        java.lang.String str13 = timePeriodFormatException9.toString();
        java.lang.String str14 = timePeriodFormatException9.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
        java.lang.Class<?> wildcardClass24 = timePeriodFormatException21.getClass();
        java.lang.String str25 = timePeriodFormatException21.toString();
        java.lang.String str26 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str30 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, 0" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, 0"));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
//        java.lang.String str6 = week3.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        boolean boolean10 = week7.equals((java.lang.Object) 0.0d);
//        long long11 = week7.getMiddleMillisecond();
//        int int12 = week7.getWeek();
//        java.lang.String str13 = week7.toString();
//        java.lang.Class<?> wildcardClass14 = week7.getClass();
//        java.util.Date date15 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        java.util.Date date21 = week18.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
//        java.util.Date date29 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException31.getClass();
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date21, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date6, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.lang.Class<?> wildcardClass8 = week2.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (short) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.String str10 = timePeriodFormatException8.toString();
        boolean boolean11 = week2.equals((java.lang.Object) str10);
        long long12 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        java.util.Date date14 = week2.getEnd();
        long long15 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 736L + "'", long12 == 736L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61728624000001L) + "'", long15 == (-61728624000001L));
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException6.getClass();
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.util.Date date18 = week15.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean25 = week3.equals((java.lang.Object) wildcardClass9);
//        int int26 = week3.getWeek();
//        long long27 = week3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        long long6 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
//        java.util.Date date8 = week2.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.util.Date date12 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        java.util.Date date19 = week15.getStart();
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date19, timeZone22);
//        java.lang.Class<?> wildcardClass25 = timeZone22.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone22);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, 12);
//        int int31 = week29.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass32 = week29.getClass();
//        java.util.Date date33 = week29.getStart();
//        java.lang.String str34 = week29.toString();
//        java.util.Date date35 = week29.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.lang.String str37 = week36.toString();
//        java.util.Date date38 = week36.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        long long42 = week41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week41.previous();
//        java.lang.String str44 = week41.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = regularTimePeriod45.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, 12);
//        int int51 = week49.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week49.next();
//        java.util.Date date53 = week49.getStart();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.lang.String str55 = week54.toString();
//        long long56 = week54.getFirstMillisecond();
//        org.jfree.data.time.Year year57 = week54.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week54.next();
//        java.util.Date date59 = week54.getEnd();
//        java.lang.Class class60 = null;
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date59, timeZone62);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date53, timeZone62);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date46, timeZone62);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(100, 12);
//        int int71 = week69.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass72 = week69.getClass();
//        java.util.Date date73 = week69.getStart();
//        java.lang.Class class74 = null;
//        java.util.Date date75 = null;
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date73, timeZone76);
//        java.lang.Class<?> wildcardClass79 = timeZone76.getClass();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date46, timeZone76);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date38, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date35, timeZone76);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 100, 12" + "'", str34.equals("Week 100, 12"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 24, 2019" + "'", str37.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 24, 2019" + "'", str55.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560063600000L + "'", long56 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(wildcardClass79);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 0);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        java.util.Date date30 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone36);
        int int40 = week39.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week39.next();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167708800001L) + "'", long10 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 52 + "'", int40 == 52);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(2019, year4);
//        java.util.Calendar calendar6 = null;
//        try {
//            week5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year3);
        long long6 = week5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1567018799999L + "'", long6 == 1567018799999L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, (int) (short) 100);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        java.lang.String str20 = timePeriodFormatException18.toString();
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.String str22 = timePeriodFormatException18.toString();
//        boolean boolean23 = week0.equals((java.lang.Object) str22);
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = week0.getLastMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        long long10 = week2.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61729228800000L) + "'", long10 == (-61729228800000L));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week3.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getSerialIndex();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int8 = week5.getWeek();
//        int int9 = week5.getWeek();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getSerialIndex();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 736L + "'", long6 == 736L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61728624000001L) + "'", long7 == (-61728624000001L));
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        java.util.Date date6 = week4.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(4, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) 'a', year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(8, year8);
//        java.lang.Class<?> wildcardClass13 = week12.getClass();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
        java.util.Date date38 = regularTimePeriod37.getStart();
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date38, timeZone41);
        java.lang.Class<?> wildcardClass44 = date38.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(100, 12);
        int int49 = week47.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass50 = week47.getClass();
        java.util.Date date51 = week47.getStart();
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date51, timeZone54);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        java.util.Date date61 = regularTimePeriod60.getStart();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date51, timeZone64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date17, timeZone64);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(100, 12);
        int int73 = week71.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass74 = week71.getClass();
        java.util.Date date75 = week71.getStart();
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date75, timeZone78);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date17, timeZone78);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getFirstMillisecond();
        int int7 = week2.getYearValue();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61729228800000L) + "'", long6 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728926400001L) + "'", long8 == (-61728926400001L));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        long long6 = week2.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        java.lang.String str10 = timePeriodFormatException8.toString();
//        boolean boolean11 = week2.equals((java.lang.Object) str10);
//        long long12 = week2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getFirstMillisecond();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
//        java.lang.Class<?> wildcardClass21 = timePeriodFormatException19.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
//        java.lang.String str25 = timePeriodFormatException19.toString();
//        int int26 = week16.compareTo((java.lang.Object) str25);
//        int int27 = week16.getYearValue();
//        java.lang.String str28 = week16.toString();
//        boolean boolean29 = week14.equals((java.lang.Object) week16);
//        java.lang.Class<?> wildcardClass30 = week14.getClass();
//        boolean boolean31 = week2.equals((java.lang.Object) wildcardClass30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 736L + "'", long12 == 736L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(throwableArray20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(class32);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        boolean boolean7 = week2.equals((java.lang.Object) 0);
//        java.lang.String str8 = week2.toString();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.lang.String str10 = week9.toString();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.Date date13 = week12.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        java.util.Date date15 = week14.getStart();
//        int int16 = week2.compareTo((java.lang.Object) date15);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        long long12 = week9.getMiddleMillisecond();
//        boolean boolean14 = week9.equals((java.lang.Object) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week9.next();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.lang.String str17 = week16.toString();
//        long long18 = week16.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass19 = week16.getClass();
//        int int20 = week9.compareTo((java.lang.Object) wildcardClass19);
//        java.util.Date date21 = week9.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
//        int int30 = week28.compareTo((java.lang.Object) false);
//        java.util.Date date31 = week28.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray34 = timePeriodFormatException33.getSuppressed();
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException33.getClass();
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
//        java.util.Date date39 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
//        java.lang.Class<?> wildcardClass43 = timePeriodFormatException41.getClass();
//        java.util.Date date44 = null;
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date31, timeZone45);
//        long long49 = week48.getFirstMillisecond();
//        java.util.Date date50 = week48.getStart();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(100, 12);
//        int int55 = week53.compareTo((java.lang.Object) false);
//        java.util.Date date56 = week53.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray59 = timePeriodFormatException58.getSuppressed();
//        java.lang.Class<?> wildcardClass60 = timePeriodFormatException58.getClass();
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date61, timeZone62);
//        java.util.Date date64 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray67 = timePeriodFormatException66.getSuppressed();
//        java.lang.Class<?> wildcardClass68 = timePeriodFormatException66.getClass();
//        java.util.Date date69 = null;
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date69, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date64, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date56, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date50, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date21, timeZone70);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61728926400001L) + "'", long12 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-61729228800000L) + "'", long49 == (-61729228800000L));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(throwableArray59);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(throwableArray67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getLastMillisecond();
//        boolean boolean19 = week16.equals((java.lang.Object) 0.0d);
//        long long20 = week16.getMiddleMillisecond();
//        int int21 = week16.getWeek();
//        java.lang.String str22 = week16.toString();
//        java.lang.Class<?> wildcardClass23 = week16.getClass();
//        java.util.Date date24 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(100, 12);
//        int int29 = week27.compareTo((java.lang.Object) false);
//        java.util.Date date30 = week27.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        java.util.Date date38 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
//        java.util.Date date43 = null;
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date30, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone44);
//        java.util.Locale locale49 = null;
//        try {
//            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date13, timeZone44, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560365999999L + "'", long20 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 24, 2019" + "'", str22.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 3, 4");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.String str10 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(2, (int) (byte) -1);
//        java.lang.String str19 = week18.toString();
//        boolean boolean20 = week5.equals((java.lang.Object) str19);
//        long long21 = week5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 2, -1" + "'", str19.equals("Week 2, -1"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1545552000000L + "'", long21 == 1545552000000L);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.String str10 = timePeriodFormatException8.toString();
        boolean boolean11 = week2.equals((java.lang.Object) str10);
        long long12 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        java.util.Date date14 = week2.getEnd();
        java.util.Date date15 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 736L + "'", long12 == 736L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str18 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        java.lang.Class<?> wildcardClass24 = timePeriodFormatException22.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException26.getSuppressed();
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException26.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException34.getSuppressed();
        java.lang.Class<?> wildcardClass37 = timePeriodFormatException34.getClass();
        java.lang.String str38 = timePeriodFormatException34.toString();
        java.lang.String str39 = timePeriodFormatException34.toString();
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException44.getSuppressed();
        java.lang.Class<?> wildcardClass46 = timePeriodFormatException44.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getEnd();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        java.util.Date date17 = week0.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
        java.lang.String str17 = timePeriodFormatException13.toString();
        java.lang.String str18 = timePeriodFormatException13.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str34 = timePeriodFormatException33.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException36.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException39.getSuppressed();
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException39.getClass();
        java.lang.String str43 = timePeriodFormatException39.toString();
        java.lang.String str44 = timePeriodFormatException39.toString();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException36.getSuppressed();
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException36.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
        java.lang.Class<?> wildcardClass53 = timePeriodFormatException51.getClass();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        java.lang.Class<?> wildcardClass55 = timePeriodFormatException51.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        java.lang.String str13 = timePeriodFormatException7.toString();
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
//        long long16 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        int int6 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(class29);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int9 = week2.compareTo((java.lang.Object) class8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.lang.Object obj8 = null;
        int int9 = week2.compareTo(obj8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week -1, 3");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(4, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (-2007));
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, -2007" + "'", str3.equals("Week 1, -2007"));
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        boolean boolean14 = week9.equals((java.lang.Object) 0);
//        java.lang.String str15 = week9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week9.previous();
//        long long17 = week9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week9.next();
//        try {
//            int int19 = week0.compareTo((java.lang.Object) week9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 100, 12" + "'", str15.equals("Week 100, 12"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61729228800000L) + "'", long17 == (-61729228800000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        java.util.Calendar calendar7 = null;
//        try {
//            week5.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        long long5 = week2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException7.getSuppressed();
        java.lang.String str15 = timePeriodFormatException7.toString();
        boolean boolean16 = week2.equals((java.lang.Object) timePeriodFormatException7);
        long long17 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62166499200001L) + "'", long17 == (-62166499200001L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (-2007));
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-125472124800001L) + "'", long3 == (-125472124800001L));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int3 = week2.getWeek();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(4, year9);
//        int int11 = week2.compareTo((java.lang.Object) week10);
//        java.lang.String str12 = week10.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-2007) + "'", int11 == (-2007));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 4, 2019" + "'", str12.equals("Week 4, 2019"));
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        java.lang.String str8 = week0.toString();
//        org.jfree.data.time.Year year9 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = week0.getSerialIndex();
//        long long9 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        java.lang.Class<?> wildcardClass16 = week0.getClass();
//        int int17 = week0.getWeek();
//        java.util.Date date18 = week0.getStart();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week0.getMiddleMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        java.util.Date date9 = week7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.Date date11 = week10.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
//        int int24 = week22.compareTo((java.lang.Object) false);
//        java.util.Date date25 = week22.getStart();
//        java.lang.Class class26 = null;
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone28);
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        boolean boolean32 = week10.equals((java.lang.Object) wildcardClass16);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        java.util.Date date37 = regularTimePeriod36.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        long long40 = week39.getLastMillisecond();
//        boolean boolean42 = week39.equals((java.lang.Object) 0.0d);
//        long long43 = week39.getMiddleMillisecond();
//        int int44 = week39.getWeek();
//        java.lang.String str45 = week39.toString();
//        java.lang.Class<?> wildcardClass46 = week39.getClass();
//        java.util.Date date47 = null;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(100, 12);
//        int int52 = week50.compareTo((java.lang.Object) false);
//        java.util.Date date53 = week50.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray56 = timePeriodFormatException55.getSuppressed();
//        java.lang.Class<?> wildcardClass57 = timePeriodFormatException55.getClass();
//        java.util.Date date58 = null;
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
//        java.util.Date date61 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray64 = timePeriodFormatException63.getSuppressed();
//        java.lang.Class<?> wildcardClass65 = timePeriodFormatException63.getClass();
//        java.util.Date date66 = null;
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date66, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date61, timeZone67);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date53, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date37, timeZone67);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date6, timeZone67);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560668399999L + "'", long40 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560365999999L + "'", long43 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24 + "'", int44 == 24);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 24, 2019" + "'", str45.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(throwableArray56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(throwableArray64);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date17);
        long long35 = week34.getFirstMillisecond();
        long long36 = week34.getSerialIndex();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = week34.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61729228800000L) + "'", long35 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 736L + "'", long36 == 736L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        java.lang.Class<?> wildcardClass9 = date8.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str18 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException12.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, 0);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str15 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getWeek();
        java.util.Date date9 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week0.next();
//        java.lang.String str18 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = date9.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
        int int20 = week18.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        java.util.Date date22 = week18.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        java.util.Date date43 = regularTimePeriod42.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
        java.lang.Class<?> wildcardClass49 = date43.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(100, 12);
        int int54 = week52.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        java.util.Date date56 = week52.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.util.Date date66 = regularTimePeriod65.getStart();
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date66, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date56, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date22, timeZone69);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date4, timeZone69);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date4);
        long long76 = week75.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = week75.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-62073057600001L) + "'", long76 == (-62073057600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        long long6 = week2.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        java.lang.String str10 = timePeriodFormatException8.toString();
//        boolean boolean11 = week2.equals((java.lang.Object) str10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.previous();
//        java.lang.String str16 = week13.toString();
//        int int17 = week13.getYearValue();
//        org.jfree.data.time.Year year18 = week13.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(6, year18);
//        long long20 = week19.getLastMillisecond();
//        boolean boolean21 = week2.equals((java.lang.Object) week19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week19.previous();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week19.getFirstMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1549785599999L + "'", long20 == 1549785599999L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.lang.Class<?> wildcardClass6 = week5.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) '4');
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
        int int10 = week8.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        java.util.Date date12 = week8.getStart();
        boolean boolean13 = week2.equals((java.lang.Object) date12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(100, 12);
        int int18 = week16.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass19 = week16.getClass();
        java.util.Date date20 = week16.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone23);
        java.lang.Class<?> wildcardClass26 = date20.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, 12);
        int int31 = week29.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass32 = week29.getClass();
        java.util.Date date33 = week29.getStart();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        java.util.Date date35 = week34.getStart();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(100, 12);
        int int39 = week38.getWeek();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(100, 12);
        int int44 = week42.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass45 = week42.getClass();
        java.util.Date date46 = week42.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
        int int52 = week38.compareTo((java.lang.Object) timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date35, timeZone49);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date12, timeZone49);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNull(regularTimePeriod53);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        org.jfree.data.time.Year year16 = week5.getYear();
//        long long17 = week5.getFirstMillisecond();
//        java.util.Date date18 = week5.getStart();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1545552000000L + "'", long17 == 1545552000000L);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        long long9 = week7.getFirstMillisecond();
//        int int10 = week7.getYearValue();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week7.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1544947200000L + "'", long9 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
        java.lang.String str17 = timePeriodFormatException13.toString();
        java.lang.String str18 = timePeriodFormatException13.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str32 = timePeriodFormatException5.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        int int9 = week2.compareTo((java.lang.Object) "Week 100, 12");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 100, 12" + "'", str7.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date13);
        java.lang.Object obj20 = null;
        int int21 = week19.compareTo(obj20);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date6);
        long long14 = week13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61729228800000L) + "'", long14 == (-61729228800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(3, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year4);
        long long8 = week7.getLastMillisecond();
        int int9 = week7.getWeek();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1528613999999L + "'", long8 == 1528613999999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-29) + "'", int9 == (-29));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        int int16 = week14.getYearValue();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week14.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(5, year6);
//        java.lang.Class<?> wildcardClass9 = year6.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 0");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, 0" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, 0"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 6);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 13);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 24);
//        java.util.Date date3 = week2.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException5.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.previous();
//        java.lang.String str13 = week10.toString();
//        int int14 = week10.getYearValue();
//        org.jfree.data.time.Year year15 = week10.getYear();
//        java.lang.Class<?> wildcardClass16 = week10.getClass();
//        int int17 = week10.getWeek();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        long long19 = week18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week18.previous();
//        java.lang.String str21 = week18.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week18.next();
//        java.util.Date date23 = regularTimePeriod22.getEnd();
//        int int24 = week10.compareTo((java.lang.Object) date23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(100, 12);
//        int int29 = week27.compareTo((java.lang.Object) false);
//        java.util.Date date30 = week27.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        java.util.Date date38 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
//        java.util.Date date43 = null;
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date30, timeZone44);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(100, 12);
//        int int52 = week50.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass53 = week50.getClass();
//        java.util.Date date54 = week50.getStart();
//        java.lang.Class class55 = null;
//        java.util.Date date56 = null;
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
//        java.lang.Class<?> wildcardClass60 = timeZone57.getClass();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date30, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date23, timeZone57);
//        boolean boolean63 = week2.equals((java.lang.Object) wildcardClass8);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        java.lang.String str7 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        int int7 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date5, timeZone11);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        java.util.Date date26 = regularTimePeriod25.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        long long9 = week7.getFirstMillisecond();
//        int int10 = week7.getYearValue();
//        java.util.Date date11 = week7.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1544947200000L + "'", long9 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        int int8 = week0.getYearValue();
//        org.jfree.data.time.Year year9 = week0.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.lang.String str11 = week10.toString();
//        java.util.Date date12 = week10.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        java.lang.Class<?> wildcardClass15 = week13.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        java.util.Date date21 = week18.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(100, 12);
//        int int26 = week24.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass27 = week24.getClass();
//        java.util.Date date28 = week24.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date28, timeZone31);
//        java.lang.Class<?> wildcardClass34 = timeZone31.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone31);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date21);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date21);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        long long39 = week38.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week38.previous();
//        java.lang.String str41 = week38.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week38.next();
//        java.util.Date date43 = regularTimePeriod42.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(100, 12);
//        int int48 = week46.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week46.next();
//        java.util.Date date50 = week46.getStart();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.lang.String str52 = week51.toString();
//        long long53 = week51.getFirstMillisecond();
//        org.jfree.data.time.Year year54 = week51.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week51.next();
//        java.util.Date date56 = week51.getEnd();
//        java.lang.Class class57 = null;
//        java.util.Date date58 = null;
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date50, timeZone59);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date43, timeZone59);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date21, timeZone59);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date21);
//        int int66 = week0.compareTo((java.lang.Object) date21);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 24, 2019" + "'", str41.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Week 24, 2019" + "'", str52.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560063600000L + "'", long53 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getWeek();
        java.util.Date date5 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Date date8 = week7.getEnd();
        java.util.Date date9 = week7.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.util.Date date10 = week8.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        int int12 = week11.getWeek();
//        java.util.Date date13 = week11.getStart();
//        boolean boolean14 = week7.equals((java.lang.Object) week11);
//        java.lang.String str15 = week11.toString();
//        long long16 = week11.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week27.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        long long10 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61728926400001L) + "'", long10 == (-61728926400001L));
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getFirstMillisecond();
        java.lang.String str10 = week2.toString();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        boolean boolean18 = week13.equals((java.lang.Object) 0);
        java.lang.String str19 = week13.toString();
        long long20 = week13.getLastMillisecond();
        java.util.Date date21 = week13.getStart();
        boolean boolean22 = week2.equals((java.lang.Object) week13);
        long long23 = week2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year24 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 100, 12" + "'", str10.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 100, 12" + "'", str19.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61728624000001L) + "'", long20 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61728926400001L) + "'", long23 == (-61728926400001L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        int int24 = week22.getYearValue();
        long long25 = week22.getFirstMillisecond();
        boolean boolean26 = week19.equals((java.lang.Object) week22);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61729228800000L) + "'", long25 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        int int7 = week3.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.lang.String str9 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        java.lang.String str11 = week2.toString();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week2.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 100, 12" + "'", str11.equals("Week 100, 12"));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        boolean boolean4 = week1.equals((java.lang.Object) 0.0d);
//        long long5 = week1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week1.previous();
//        java.lang.Object obj7 = null;
//        int int8 = week1.compareTo(obj7);
//        org.jfree.data.time.Year year9 = week1.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 100, year9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException9.getClass();
        java.lang.String str13 = timePeriodFormatException9.toString();
        java.lang.String str14 = timePeriodFormatException9.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        java.util.Calendar calendar5 = null;
//        try {
//            week4.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        boolean boolean4 = week1.equals((java.lang.Object) 0.0d);
//        long long5 = week1.getMiddleMillisecond();
//        long long6 = week1.getSerialIndex();
//        java.util.Date date7 = week1.getStart();
//        org.jfree.data.time.Year year8 = week1.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
//        int int10 = week9.getYearValue();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException14.getClass();
        java.lang.String str18 = timePeriodFormatException14.toString();
        java.lang.String str19 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable throwable23 = null;
        try {
            timePeriodFormatException5.addSuppressed(throwable23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 53");
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = regularTimePeriod4.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = week8.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.lang.String str14 = week13.toString();
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.Year year16 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week13.next();
//        java.util.Date date18 = week13.getEnd();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date12, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5, timeZone21);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
//        int int30 = week28.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        java.util.Date date32 = week28.getStart();
//        java.lang.Class class33 = null;
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
//        java.lang.Class<?> wildcardClass38 = timeZone35.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date5, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getSerialIndex();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
//        java.lang.String str11 = timePeriodFormatException9.toString();
//        java.lang.String str12 = timePeriodFormatException9.toString();
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException9.getSuppressed();
//        boolean boolean14 = week5.equals((java.lang.Object) throwableArray13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
//        java.lang.String str31 = week28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week28.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = week41.getEnd();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date40, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        java.lang.Class<?> wildcardClass56 = date11.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.lang.Object obj8 = null;
        int int9 = week2.compareTo(obj8);
        int int10 = week2.getWeek();
        java.util.Date date11 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.String str18 = timePeriodFormatException16.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str23 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException25.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException29.getSuppressed();
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException29.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray38 = timePeriodFormatException37.getSuppressed();
        java.lang.Throwable[] throwableArray39 = timePeriodFormatException37.getSuppressed();
        java.lang.Class<?> wildcardClass40 = timePeriodFormatException37.getClass();
        java.lang.String str41 = timePeriodFormatException37.toString();
        java.lang.String str42 = timePeriodFormatException37.toString();
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
        java.lang.Class<?> wildcardClass49 = timePeriodFormatException47.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.String str57 = timePeriodFormatException29.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str42.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str57.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        java.lang.String str7 = week0.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 7);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61886779200001L) + "'", long3 == (-61886779200001L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        int int9 = week2.compareTo((java.lang.Object) "");
        java.util.Date date10 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2007), 3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        int int10 = week2.compareTo((java.lang.Object) 0);
        long long11 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 12" + "'", str5.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61728624000001L) + "'", long11 == (-61728624000001L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (byte) -1);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.lang.Class<?> wildcardClass8 = week2.getClass();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 2, -1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        int int8 = week7.getYearValue();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
//        int int21 = week7.compareTo((java.lang.Object) timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week7.next();
//        java.util.Date date23 = week7.getStart();
//        java.lang.Class<?> wildcardClass24 = date23.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 6, 53");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.Date date17 = week16.getStart();
//        int int18 = week6.compareTo((java.lang.Object) date17);
//        boolean boolean19 = week2.equals((java.lang.Object) week6);
//        int int20 = week2.getWeek();
//        int int21 = week2.getYearValue();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
        java.lang.String str17 = timePeriodFormatException13.toString();
        java.lang.String str18 = timePeriodFormatException13.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str34 = timePeriodFormatException33.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException36.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException39.getSuppressed();
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException39.getClass();
        java.lang.String str43 = timePeriodFormatException39.toString();
        java.lang.String str44 = timePeriodFormatException39.toString();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException36.getSuppressed();
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException36.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
        java.lang.Class<?> wildcardClass53 = timePeriodFormatException51.getClass();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException51.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str34.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int3 = week2.getWeek();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 12);
        int int8 = week6.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        java.util.Date date10 = week6.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
        int int16 = week2.compareTo((java.lang.Object) timeZone13);
        long long17 = week2.getMiddleMillisecond();
        int int18 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61728926400001L) + "'", long17 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, 12);
//        int int5 = week3.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        java.util.Date date7 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getLastMillisecond();
//        boolean boolean11 = week8.equals((java.lang.Object) 0.0d);
//        long long12 = week8.getMiddleMillisecond();
//        int int13 = week8.getWeek();
//        java.lang.String str14 = week8.toString();
//        java.lang.Class<?> wildcardClass15 = week8.getClass();
//        java.util.Date date16 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 12);
//        int int21 = week19.compareTo((java.lang.Object) false);
//        java.util.Date date22 = week19.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
//        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
//        java.util.Date date30 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date22, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone36);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date7, timeZone36);
//        java.util.Locale locale42 = null;
//        try {
//            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date0, timeZone36, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(throwableArray25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (-1));
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62185248000000L) + "'", long3 == (-62185248000000L));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
//        java.lang.Class<?> wildcardClass6 = year4.getClass();
//        long long7 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.lang.String str10 = week9.toString();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Year year14 = week13.getYear();
//        boolean boolean15 = week8.equals((java.lang.Object) year14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(6, year14);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.lang.String str4 = week3.toString();
//        int int5 = week3.getYearValue();
//        int int6 = week3.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.String str18 = timePeriodFormatException16.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str23 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException28.getSuppressed();
        java.lang.Class<?> wildcardClass31 = timePeriodFormatException28.getClass();
        java.lang.String str32 = timePeriodFormatException28.toString();
        java.lang.String str33 = timePeriodFormatException28.toString();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException28.getSuppressed();
        java.lang.String str36 = timePeriodFormatException28.toString();
        java.lang.String str37 = timePeriodFormatException28.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
        java.lang.String str42 = timePeriodFormatException40.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException44.getSuppressed();
        java.lang.Class<?> wildcardClass46 = timePeriodFormatException44.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        java.lang.String str50 = timePeriodFormatException44.toString();
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException44.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray56 = timePeriodFormatException55.getSuppressed();
        java.lang.Class<?> wildcardClass57 = timePeriodFormatException55.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException55.addSuppressed((java.lang.Throwable) timePeriodFormatException59);
        java.lang.String str61 = timePeriodFormatException55.toString();
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str42.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str50.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str61.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        java.lang.Class<?> wildcardClass16 = week0.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 12);
//        int int21 = week19.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass22 = week19.getClass();
//        java.util.Date date23 = week19.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
//        java.util.Date date25 = week24.getStart();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone26);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
//        java.lang.Class<?> wildcardClass10 = date4.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
//        int int15 = week13.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        java.util.Date date17 = week13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
//        java.util.Date date27 = regularTimePeriod26.getStart();
//        java.lang.Class class28 = null;
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date17);
//        long long35 = week34.getFirstMillisecond();
//        long long36 = week34.getSerialIndex();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.lang.String str38 = week37.toString();
//        java.util.Date date39 = week37.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
//        long long42 = regularTimePeriod41.getMiddleMillisecond();
//        boolean boolean43 = week34.equals((java.lang.Object) long42);
//        long long44 = week34.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61729228800000L) + "'", long35 == (-61729228800000L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 736L + "'", long36 == 736L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 24, 2019" + "'", str38.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560970799999L + "'", long42 == 1560970799999L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61728926400001L) + "'", long44 == (-61728926400001L));
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        long long7 = week6.getMiddleMillisecond();
//        int int8 = week6.getWeek();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) -1, year9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1545854399999L + "'", long7 == 1545854399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        long long9 = week7.getMiddleMillisecond();
//        java.util.Date date10 = week7.getStart();
//        boolean boolean12 = week7.equals((java.lang.Object) 10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.lang.String str15 = week14.toString();
//        long long16 = week14.getFirstMillisecond();
//        org.jfree.data.time.Year year17 = week14.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(0, year17);
//        long long19 = week18.getSerialIndex();
//        boolean boolean20 = week7.equals((java.lang.Object) long19);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1545249599999L + "'", long9 == 1545249599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107007L + "'", long19 == 107007L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 12" + "'", str6.equals("Week 100, 12"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(6, year6);
//        boolean boolean9 = week7.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.lang.String str12 = week11.toString();
//        long long13 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year14 = week11.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(0, year14);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week7.equals((java.lang.Object) long16);
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week7.getLastMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107007L + "'", long16 == 107007L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
//        int int12 = week10.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.next();
//        java.util.Date date14 = week10.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.lang.String str16 = week15.toString();
//        long long17 = week15.getFirstMillisecond();
//        org.jfree.data.time.Year year18 = week15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week15.next();
//        java.util.Date date20 = week15.getEnd();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date14, timeZone23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date7, timeZone23);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
//        int int32 = week30.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass33 = week30.getClass();
//        java.util.Date date34 = week30.getStart();
//        java.lang.Class class35 = null;
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34, timeZone37);
//        java.lang.Class<?> wildcardClass40 = timeZone37.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date7, timeZone37);
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (byte) -1, year42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(13, year42);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(year42);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week3.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(10, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year4);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.previous();
//        java.lang.String str10 = week7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week15.next();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.lang.String str21 = week20.toString();
//        long long22 = week20.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = week20.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week20.next();
//        java.util.Date date25 = week20.getEnd();
//        java.lang.Class class26 = null;
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date25, timeZone28);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date19, timeZone28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date12, timeZone28);
//        java.util.Date date33 = week32.getEnd();
//        int int34 = week0.compareTo((java.lang.Object) week32);
//        java.util.Calendar calendar35 = null;
//        try {
//            long long36 = week32.getMiddleMillisecond(calendar35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException6.getClass();
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.util.Date date18 = week15.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean25 = week3.equals((java.lang.Object) wildcardClass9);
//        int int26 = week3.getWeek();
//        org.jfree.data.time.Year year27 = week3.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertNotNull(year27);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(6, year6);
//        boolean boolean9 = week7.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.lang.String str12 = week11.toString();
//        long long13 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year14 = week11.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(0, year14);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week7.equals((java.lang.Object) long16);
//        java.util.Date date18 = week7.getStart();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107007L + "'", long16 == 107007L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        int int8 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.String str18 = timePeriodFormatException16.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str23 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException25.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException32.getSuppressed();
        java.lang.Class<?> wildcardClass35 = timePeriodFormatException32.getClass();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.String str37 = timePeriodFormatException25.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.Throwable[] throwableArray39 = timePeriodFormatException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException9.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        java.lang.String str19 = timePeriodFormatException17.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException17.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.String str23 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        java.lang.Class<?> wildcardClass22 = timePeriodFormatException19.getClass();
        java.lang.String str23 = timePeriodFormatException19.toString();
        java.lang.String str24 = timePeriodFormatException19.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException4.getSuppressed();
        java.lang.String str28 = timePeriodFormatException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 1);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        java.lang.String str20 = timePeriodFormatException18.toString();
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.String str22 = timePeriodFormatException18.toString();
//        boolean boolean23 = week0.equals((java.lang.Object) str22);
//        long long24 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        boolean boolean7 = week0.equals((java.lang.Object) date5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
        java.lang.String str8 = timePeriodFormatException4.toString();
        java.lang.String str9 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str11 = timePeriodFormatException4.toString();
        java.lang.String str12 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.util.Date date10 = week8.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        int int12 = week11.getWeek();
//        java.util.Date date13 = week11.getStart();
//        boolean boolean14 = week7.equals((java.lang.Object) week11);
//        java.lang.String str15 = week11.toString();
//        java.lang.String str16 = week11.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (int) (short) -1);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        long long7 = week0.getFirstMillisecond();
//        java.lang.String str8 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 8);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.String str18 = timePeriodFormatException16.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str23 = timePeriodFormatException16.toString();
        java.lang.String str24 = timePeriodFormatException16.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        int int6 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        long long7 = week0.getLastMillisecond();
//        long long8 = week0.getFirstMillisecond();
//        long long9 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
        java.lang.String str17 = timePeriodFormatException13.toString();
        java.lang.String str18 = timePeriodFormatException13.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException13.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week -1, 3");
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        java.lang.String str20 = timePeriodFormatException18.toString();
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.String str22 = timePeriodFormatException18.toString();
//        boolean boolean23 = week0.equals((java.lang.Object) str22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week0.previous();
//        int int25 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(3, year3);
        long long6 = week5.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        long long8 = week5.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1547668799999L + "'", long6 == 1547668799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107010L + "'", long8 == 107010L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 10);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 11, 10" + "'", str3.equals("Week 11, 10"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        long long10 = week9.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            week9.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61729228800001L) + "'", long10 == (-61729228800001L));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.Date date17 = week16.getStart();
//        int int18 = week6.compareTo((java.lang.Object) date17);
//        boolean boolean19 = week2.equals((java.lang.Object) week6);
//        int int20 = week6.getYearValue();
//        long long21 = week6.getFirstMillisecond();
//        java.util.Date date22 = week6.getStart();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week6.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) (short) 10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (short) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(6, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107013L + "'", long9 == 107013L);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        int int8 = week7.getWeek();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        boolean boolean4 = week0.equals((java.lang.Object) 1560365999999L);
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(9, year4);
        java.lang.Class<?> wildcardClass6 = year4.getClass();
        long long7 = year4.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(3, year4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year4);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 12);
//        int int7 = week5.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.Date date11 = week10.getStart();
//        int int12 = week0.compareTo((java.lang.Object) date11);
//        java.lang.Class<?> wildcardClass13 = date11.getClass();
//        java.util.TimeZone timeZone14 = null;
//        java.util.Locale locale15 = null;
//        try {
//            org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date11, timeZone14, locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = date9.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
        int int20 = week18.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        java.util.Date date22 = week18.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        java.util.Date date43 = regularTimePeriod42.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
        java.lang.Class<?> wildcardClass49 = date43.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(100, 12);
        int int54 = week52.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        java.util.Date date56 = week52.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.util.Date date66 = regularTimePeriod65.getStart();
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date66, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date56, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date22, timeZone69);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date4, timeZone69);
        java.util.Date date75 = week74.getStart();
        long long76 = week74.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-62073057600001L) + "'", long76 == (-62073057600001L));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        boolean boolean10 = week7.equals((java.lang.Object) 0.0d);
//        long long11 = week7.getMiddleMillisecond();
//        int int12 = week7.getWeek();
//        java.lang.String str13 = week7.toString();
//        java.lang.Class<?> wildcardClass14 = week7.getClass();
//        java.util.Date date15 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        java.util.Date date21 = week18.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
//        java.util.Date date29 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException31.getClass();
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date21, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date6, timeZone35);
//        long long41 = week40.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61728926400001L) + "'", long41 == (-61728926400001L));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        long long8 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week3.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getFirstMillisecond();
        java.lang.String str10 = week2.toString();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        boolean boolean18 = week13.equals((java.lang.Object) 0);
        java.lang.String str19 = week13.toString();
        long long20 = week13.getLastMillisecond();
        java.util.Date date21 = week13.getStart();
        boolean boolean22 = week2.equals((java.lang.Object) week13);
        int int24 = week13.compareTo((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 100, 12" + "'", str10.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 100, 12" + "'", str19.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61728624000001L) + "'", long20 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException9.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(0, 0);
        long long18 = week17.getLastMillisecond();
        java.util.Date date19 = week17.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.util.Date date24 = regularTimePeriod23.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        java.util.Date date38 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date19, timeZone44);
        java.util.Locale locale48 = null;
        try {
            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date7, timeZone44, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167708800001L) + "'", long18 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 12);
//        int int8 = week6.compareTo((java.lang.Object) false);
//        java.lang.String str9 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, year12);
//        int int14 = week6.compareTo((java.lang.Object) 0);
//        long long15 = week6.getMiddleMillisecond();
//        boolean boolean16 = week0.equals((java.lang.Object) week6);
//        org.jfree.data.time.Year year17 = week0.getYear();
//        java.util.Date date18 = week0.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
//        int int24 = week22.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass25 = week22.getClass();
//        java.util.Date date26 = week22.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week22.next();
//        java.lang.Object obj28 = null;
//        int int29 = week22.compareTo(obj28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week22.next();
//        boolean boolean31 = week19.equals((java.lang.Object) week22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61728926400001L) + "'", long15 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(11, year3);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        org.jfree.data.time.Year year16 = week5.getYear();
//        long long17 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year18 = week5.getYear();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1545552000000L + "'", long17 == 1545552000000L);
//        org.junit.Assert.assertNotNull(year18);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.Date date6 = week5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        int int8 = week7.getYearValue();
//        java.util.Date date9 = week7.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
        int int17 = week15.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        java.util.Date date19 = week15.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(100, 12);
        int int25 = week24.getWeek();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
        int int30 = week28.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass31 = week28.getClass();
        java.util.Date date32 = week28.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        int int38 = week24.compareTo((java.lang.Object) timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date21, timeZone35);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        java.util.Date date44 = regularTimePeriod43.getStart();
        java.lang.Class class45 = null;
        java.util.Date date46 = null;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date44, timeZone47);
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date44, timeZone50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (byte) 0, 24);
        java.util.Date date55 = week54.getStart();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(100, 12);
        int int60 = week58.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass61 = week58.getClass();
        java.util.Date date62 = week58.getStart();
        java.lang.Class class63 = null;
        java.util.Date date64 = null;
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date64, timeZone65);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date62, timeZone65);
        java.lang.Class<?> wildcardClass68 = timeZone65.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date55, timeZone65);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNull(regularTimePeriod69);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(11, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', year5);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        long long8 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        int int8 = week7.getYearValue();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
//        int int21 = week7.compareTo((java.lang.Object) timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week7.next();
//        java.util.Date date23 = week7.getStart();
//        long long24 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1606334399999L + "'", long24 == 1606334399999L);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        java.lang.Class<?> wildcardClass8 = week6.getClass();
//        java.util.Date date9 = week6.getEnd();
//        boolean boolean10 = week0.equals((java.lang.Object) date9);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) 'a', year6);
//        long long8 = week7.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107104L + "'", long8 == 107104L);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        boolean boolean4 = week0.equals((java.lang.Object) 1560365999999L);
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        java.util.Date date12 = week8.getStart();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date5, timeZone15);
//        int int19 = week18.getYearValue();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.lang.String str21 = week20.toString();
//        boolean boolean22 = week18.equals((java.lang.Object) week20);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        int int8 = week4.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        java.util.Date date9 = year7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(10, year7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = week26.getLastMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        int int8 = week7.getYearValue();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        java.lang.String str7 = week0.toString();
//        long long8 = week0.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
        int int17 = week15.compareTo((java.lang.Object) false);
        long long18 = week15.getFirstMillisecond();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(100, 12);
        int int23 = week21.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass24 = week21.getClass();
        java.util.Date date25 = week21.getStart();
        boolean boolean26 = week15.equals((java.lang.Object) date25);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, 12);
        int int31 = week29.compareTo((java.lang.Object) false);
        java.util.Date date32 = week29.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException34.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        java.util.Date date40 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray43 = timePeriodFormatException42.getSuppressed();
        java.lang.Class<?> wildcardClass44 = timePeriodFormatException42.getClass();
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone46);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date32, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date25, timeZone46);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61729228800000L) + "'", long18 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod50);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) 0, 24);
//        boolean boolean6 = week0.equals((java.lang.Object) (byte) 0);
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.String str9 = timePeriodFormatException3.toString();
//        int int10 = week0.compareTo((java.lang.Object) str9);
//        int int11 = week0.getYearValue();
//        long long12 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        java.lang.String str7 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = week7.getEnd();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date6, timeZone15);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
//        java.util.Date date23 = regularTimePeriod22.getStart();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date23, timeZone26);
//        java.lang.Class<?> wildcardClass29 = date23.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(100, 12);
//        int int34 = week32.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass35 = week32.getClass();
//        java.util.Date date36 = week32.getStart();
//        java.lang.Class class37 = null;
//        java.util.Date date38 = null;
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date36, timeZone39);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
//        java.util.Date date46 = regularTimePeriod45.getStart();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date36, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.previous();
//        java.util.Date date57 = regularTimePeriod56.getStart();
//        java.lang.Class class58 = null;
//        java.util.Date date59 = null;
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone60);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date57, timeZone60);
//        java.lang.Class<?> wildcardClass63 = date57.getClass();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(100, 12);
//        int int68 = week66.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass69 = week66.getClass();
//        java.util.Date date70 = week66.getStart();
//        java.lang.Class class71 = null;
//        java.util.Date date72 = null;
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date72, timeZone73);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date70, timeZone73);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.previous();
//        java.util.Date date80 = regularTimePeriod79.getStart();
//        java.lang.Class class81 = null;
//        java.util.Date date82 = null;
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone83);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date80, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date70, timeZone83);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date36, timeZone83);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date6, timeZone83);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = week91.previous();
//        java.util.Date date93 = regularTimePeriod92.getStart();
//        java.lang.Class class94 = null;
//        java.util.Date date95 = null;
//        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class94, date95, timeZone96);
//        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date93, timeZone96);
//        org.jfree.data.time.Week week99 = new org.jfree.data.time.Week(date6, timeZone96);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(timeZone96);
//        org.junit.Assert.assertNull(regularTimePeriod97);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        long long6 = week2.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        java.lang.String str10 = timePeriodFormatException8.toString();
//        boolean boolean11 = week2.equals((java.lang.Object) str10);
//        long long12 = week2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getFirstMillisecond();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
//        java.lang.Class<?> wildcardClass21 = timePeriodFormatException19.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
//        java.lang.String str25 = timePeriodFormatException19.toString();
//        int int26 = week16.compareTo((java.lang.Object) str25);
//        int int27 = week16.getYearValue();
//        java.lang.String str28 = week16.toString();
//        boolean boolean29 = week14.equals((java.lang.Object) week16);
//        java.lang.Class<?> wildcardClass30 = week14.getClass();
//        boolean boolean31 = week2.equals((java.lang.Object) wildcardClass30);
//        try {
//            org.jfree.data.time.Year year32 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 736L + "'", long12 == 736L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(throwableArray20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 100, 0" + "'", str3.equals("Week 100, 0"));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        boolean boolean4 = week1.equals((java.lang.Object) 0.0d);
//        long long5 = week1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week1.previous();
//        java.lang.Object obj7 = null;
//        int int8 = week1.compareTo(obj7);
//        int int9 = week1.getYearValue();
//        org.jfree.data.time.Year year10 = week1.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(2, year10);
//        java.lang.String str12 = week11.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 2, 2019" + "'", str12.equals("Week 2, 2019"));
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.lang.String str4 = week3.toString();
//        int int5 = week3.getYearValue();
//        long long6 = week3.getSerialIndex();
//        java.util.Date date7 = week3.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.Date date10 = week9.getStart();
        java.util.Calendar calendar11 = null;
        try {
            week9.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        boolean boolean10 = week7.equals((java.lang.Object) 0.0d);
//        long long11 = week7.getMiddleMillisecond();
//        int int12 = week7.getWeek();
//        java.lang.String str13 = week7.toString();
//        java.lang.Class<?> wildcardClass14 = week7.getClass();
//        java.util.Date date15 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        java.util.Date date21 = week18.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
//        java.util.Date date29 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException31.getClass();
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date21, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date6, timeZone35);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        long long42 = week41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week41.previous();
//        java.lang.String str44 = week41.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = regularTimePeriod45.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, 12);
//        int int51 = week49.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week49.next();
//        java.util.Date date53 = week49.getStart();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.lang.String str55 = week54.toString();
//        long long56 = week54.getFirstMillisecond();
//        org.jfree.data.time.Year year57 = week54.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week54.next();
//        java.util.Date date59 = week54.getEnd();
//        java.lang.Class class60 = null;
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date59, timeZone62);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date53, timeZone62);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date46, timeZone62);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(100, 12);
//        int int71 = week69.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass72 = week69.getClass();
//        java.util.Date date73 = week69.getStart();
//        java.lang.Class class74 = null;
//        java.util.Date date75 = null;
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date73, timeZone76);
//        java.lang.Class<?> wildcardClass79 = timeZone76.getClass();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date46, timeZone76);
//        boolean boolean81 = week40.equals((java.lang.Object) timeZone76);
//        int int82 = week40.getWeek();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 24, 2019" + "'", str55.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560063600000L + "'", long56 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(wildcardClass79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 47 + "'", int82 == 47);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
        java.lang.String str8 = timePeriodFormatException4.toString();
        java.lang.String str9 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 0");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str21 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException26.getSuppressed();
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException26.getSuppressed();
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException26.getClass();
        java.lang.String str30 = timePeriodFormatException26.toString();
        java.lang.String str31 = timePeriodFormatException26.toString();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray39 = timePeriodFormatException38.getSuppressed();
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException38.getSuppressed();
        java.lang.Class<?> wildcardClass41 = timePeriodFormatException38.getClass();
        java.lang.String str42 = timePeriodFormatException38.toString();
        java.lang.String str43 = timePeriodFormatException38.toString();
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException23.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str42.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray47);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        java.lang.Class<?> wildcardClass16 = week0.getClass();
//        int int17 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week0.previous();
//        long long20 = week0.getSerialIndex();
//        java.util.Date date21 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.previous();
//        java.lang.String str10 = week7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        int int12 = week0.compareTo((java.lang.Object) week7);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
        int int10 = week8.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        java.util.Date date12 = week8.getStart();
        boolean boolean13 = week2.equals((java.lang.Object) date12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        long long10 = week9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        try {
            org.jfree.data.time.Year year12 = week9.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61729228800001L) + "'", long10 == (-61729228800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        java.lang.Class<?> wildcardClass9 = date8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
        int int14 = week12.compareTo((java.lang.Object) false);
        java.util.Date date15 = week12.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException17.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.util.Date date23 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException25.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date15, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date8, timeZone29);
        java.lang.Class<?> wildcardClass34 = date8.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.previous();
//        java.lang.String str8 = week5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        java.util.Date date10 = regularTimePeriod9.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
//        int int15 = week13.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.next();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.lang.String str19 = week18.toString();
//        long long20 = week18.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = week18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week18.next();
//        java.util.Date date23 = week18.getEnd();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date23, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date17, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date10, timeZone26);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        int int35 = week33.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        java.util.Date date37 = week33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date37, timeZone40);
//        java.lang.Class<?> wildcardClass43 = timeZone40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date10, timeZone40);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date2, timeZone40);
//        java.lang.Class<?> wildcardClass46 = date2.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//    }
//}

