import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.removeChangeListener(seriesChangeListener34);
        java.lang.Comparable comparable36 = timeSeries33.getKey();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        java.lang.Number number39 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        java.lang.String str46 = month45.toString();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.lang.String str54 = month53.toString();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) month53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries43.addAndOrUpdate(timeSeries51);
        timeSeries43.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.addAndOrUpdate(timeSeries43);
        java.util.Collection collection60 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        timeSeries3.fireSeriesChanged();
        try {
            timeSeries3.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 0.0d + "'", comparable36.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "June 2019" + "'", str54.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(collection60);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month26);
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) month26);
        java.util.Date date31 = month26.getEnd();
        int int32 = month26.getMonth();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month18);
        int int22 = timeSeries12.getMaximumItemCount();
        boolean boolean23 = timeSeries3.equals((java.lang.Object) timeSeries12);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries12);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(9223372036854775807L);
        long long29 = fixedMillisecond28.getSerialIndex();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond28.getFirstMillisecond(calendar30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.String str28 = timeSeries27.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        java.lang.String str39 = month38.toString();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) month38);
        long long41 = timeSeries40.getMaximumItemAge();
        java.lang.String str42 = timeSeries40.getDescription();
        double double43 = timeSeries40.getMinY();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        java.lang.String str58 = month57.toString();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) month56, (org.jfree.data.time.RegularTimePeriod) month57);
        java.lang.String str60 = month56.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month56, (java.lang.Number) (short) 10);
        int int63 = month49.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1L);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1560668399999L, false);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 12, false);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
        java.lang.String str78 = month77.toString();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries75.createCopy((org.jfree.data.time.RegularTimePeriod) month76, (org.jfree.data.time.RegularTimePeriod) month77);
        java.lang.String str80 = month76.toString();
        int int81 = month76.getYearValue();
        timeSeries27.update((org.jfree.data.time.RegularTimePeriod) month76, (java.lang.Number) 1560185999984L);
        org.jfree.data.time.Year year84 = month76.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year84.next();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "June 2019" + "'", str78.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "June 2019" + "'", str80.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
        org.junit.Assert.assertNotNull(year84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        timeSeries3.removeAgedItems((long) 2, false);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str21 = month17.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.lang.String str31 = month30.toString();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month29, (org.jfree.data.time.RegularTimePeriod) month30);
        long long33 = timeSeries32.getMaximumItemAge();
        java.lang.String str34 = timeSeries32.getDescription();
        int int35 = timeSeriesDataItem23.compareTo((java.lang.Object) str34);
        java.lang.Number number36 = timeSeriesDataItem23.getValue();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.removeChangeListener(seriesChangeListener41);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.lang.String str49 = month48.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) month47, (org.jfree.data.time.RegularTimePeriod) month48);
        java.lang.String str51 = month47.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (short) 10);
        timeSeries40.add(timeSeriesDataItem53, true);
        boolean boolean56 = timeSeriesDataItem23.equals((java.lang.Object) timeSeriesDataItem53);
        java.lang.Number number57 = timeSeriesDataItem23.getValue();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo58 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem23, seriesChangeInfo58);
        timeSeries3.add(timeSeriesDataItem23);
        boolean boolean61 = timeSeriesDataItem23.isSelected();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (short) 10 + "'", number36.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (short) 10 + "'", number57.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12);
        double double14 = timeSeries13.getMinY();
        boolean boolean15 = timeSeries13.isEmpty();
        timeSeries13.setMaximumItemAge(1560193199999L);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.String str32 = month31.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries21.addAndOrUpdate(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries38.removeChangeListener(seriesChangeListener39);
        java.lang.Comparable comparable41 = timeSeries38.getKey();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        java.lang.String str43 = month42.toString();
        java.lang.Number number44 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) month42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month42.previous();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month42.next();
        java.lang.String str49 = regularTimePeriod48.toString();
        java.lang.Number number50 = timeSeries13.getValue(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 0.0d + "'", comparable41.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "July 2019" + "'", str49.equals("July 2019"));
        org.junit.Assert.assertNull(number50);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month5, seriesChangeInfo8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.Object obj28 = timeSeries24.clone();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long33 = timeSeries32.getMaximumItemAge();
        int int34 = timeSeries32.getMaximumItemCount();
        java.util.Collection collection35 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        timeSeries32.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2147483647 + "'", int34 == 2147483647);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        long long20 = timeSeries19.getMaximumItemAge();
        java.lang.String str21 = timeSeries19.getDescription();
        int int22 = timeSeriesDataItem10.compareTo((java.lang.Object) str21);
        java.lang.Number number23 = timeSeriesDataItem10.getValue();
        java.lang.Number number24 = timeSeriesDataItem10.getValue();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) 10 + "'", number24.equals((short) 10));
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener4);
//        java.lang.Comparable comparable6 = timeSeries3.getKey();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.lang.String str8 = month7.toString();
//        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
//        timeSeries3.setMaximumItemCount(5);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.previous();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day12.equals(obj15);
//        java.lang.Number number17 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//        org.junit.Assert.assertNull(number9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(number17);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.String str13 = month12.toString();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) month12);
        long long15 = timeSeries14.getMaximumItemAge();
        java.lang.String str16 = timeSeries14.getDescription();
        double double17 = timeSeries14.getMinY();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        java.lang.Object obj20 = null;
        boolean boolean21 = month18.equals(obj20);
        org.jfree.data.time.Year year22 = month18.getYear();
        int int23 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        boolean boolean24 = year4.equals((java.lang.Object) timeSeries14);
        java.util.Date date25 = year4.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        java.lang.String str35 = month31.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (short) 10);
        int int38 = month24.compareTo((java.lang.Object) timeSeriesDataItem37);
        java.lang.String str39 = month24.toString();
        int int40 = timeSeriesDataItem16.compareTo((java.lang.Object) month24);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.removeChangeListener(seriesChangeListener45);
        java.lang.Comparable comparable47 = timeSeries44.getKey();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.lang.String str49 = month48.toString();
        java.lang.Number number50 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        java.lang.String str57 = month56.toString();
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries54.createCopy((org.jfree.data.time.RegularTimePeriod) month55, (org.jfree.data.time.RegularTimePeriod) month56);
        java.lang.String str59 = month55.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month55, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long66 = timeSeries65.getMaximumItemAge();
        int int67 = timeSeries65.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries44.addAndOrUpdate(timeSeries65);
        java.lang.Object obj69 = timeSeries65.clone();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long74 = timeSeries73.getMaximumItemAge();
        int int75 = timeSeries73.getMaximumItemCount();
        java.util.Collection collection76 = timeSeries65.getTimePeriodsUniqueToOtherSeries(timeSeries73);
        int int77 = timeSeriesDataItem16.compareTo((java.lang.Object) timeSeries73);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 0.0d + "'", comparable47.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
        org.junit.Assert.assertNull(number50);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June 2019" + "'", str57.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "June 2019" + "'", str59.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 9223372036854775807L + "'", long66 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2147483647 + "'", int67 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 9223372036854775807L + "'", long74 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2147483647 + "'", int75 == 2147483647);
        org.junit.Assert.assertNotNull(collection76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (byte) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 10);
        int int34 = month20.compareTo((java.lang.Object) timeSeriesDataItem33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560668399999L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int43 = fixedMillisecond41.compareTo((java.lang.Object) 9);
        long long44 = fixedMillisecond41.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond41.next();
        int int46 = month20.compareTo((java.lang.Object) fixedMillisecond41);
        java.util.Date date47 = fixedMillisecond41.getStart();
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond41.getMiddleMillisecond(calendar48);
        long long50 = fixedMillisecond41.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        java.lang.Object obj0 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass1 = obj0.getClass();
//        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        long long8 = day6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
//        java.util.Date date10 = day6.getEnd();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        java.util.TimeZone timeZone14 = null;
//        try {
//            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str16 = month12.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (short) 10);
        int int19 = month5.compareTo((java.lang.Object) timeSeriesDataItem18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month26, seriesChangeInfo29);
        int int31 = month26.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries35.removeChangeListener(seriesChangeListener36);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        java.lang.String str46 = month42.toString();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) month42);
        java.lang.Class class48 = timeSeries35.getTimePeriodClass();
        boolean boolean49 = timeSeries35.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
        long long54 = fixedMillisecond51.getFirstMillisecond();
        long long55 = fixedMillisecond51.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond51.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond51.previous();
        long long58 = fixedMillisecond51.getSerialIndex();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) (byte) 10, false);
        int int62 = month26.compareTo((java.lang.Object) timeSeries35);
        boolean boolean63 = timeSeriesDataItem18.equals((java.lang.Object) timeSeries35);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNull(class48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12);
        double double14 = timeSeries13.getMinY();
        boolean boolean15 = timeSeries13.isEmpty();
        timeSeries13.setMaximumItemAge(1560193199999L);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 10, (int) (short) 1);
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month20);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 5);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        int int6 = day0.getDayOfMonth();
//        java.lang.String str7 = day0.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, "org.jfree.data.event.SeriesChangeEvent[source=1]", "June 2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month26);
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) month26);
        java.util.Date date31 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month36, (org.jfree.data.time.RegularTimePeriod) month37);
        long long40 = timeSeries39.getMaximumItemAge();
        java.lang.String str41 = timeSeries39.getDescription();
        double double42 = timeSeries39.getMinY();
        timeSeries39.clear();
        int int44 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries39);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month26);
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) month26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond1.previous();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond1.getLastMillisecond(calendar32);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond1.getMiddleMillisecond(calendar34);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month32);
        long long37 = timeSeries36.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        long long46 = timeSeries45.getMaximumItemAge();
        java.lang.String str47 = timeSeries45.getDescription();
        double double48 = timeSeries45.getMinY();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        java.lang.Object obj51 = null;
        boolean boolean52 = month49.equals(obj51);
        org.jfree.data.time.Year year53 = month49.getYear();
        int int54 = timeSeries45.getIndex((org.jfree.data.time.RegularTimePeriod) year53);
        java.util.Date date55 = year53.getStart();
        java.lang.Number number56 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) year53);
        int int57 = year53.getYear();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(number56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        java.lang.Class<?> wildcardClass19 = timeSeriesDataItem16.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.String str22 = month21.toString();
        long long23 = month21.getSerialIndex();
        java.util.Date date24 = month21.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date24);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
        long long31 = fixedMillisecond28.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 11, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.String str23 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str25 = month21.toString();
        int int26 = month21.getYearValue();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month21.previous();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getSerialIndex();
        java.util.Date date3 = month0.getStart();
        java.util.Date date4 = month0.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.lang.String str6 = day5.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "30-June-2019" + "'", str6.equals("30-June-2019"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        int int15 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemCount(12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        long long20 = timeSeries19.getMaximumItemAge();
        java.lang.String str21 = timeSeries19.getDescription();
        int int22 = timeSeriesDataItem10.compareTo((java.lang.Object) str21);
        java.lang.Number number23 = timeSeriesDataItem10.getValue();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries27.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month35);
        java.lang.String str38 = month34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        timeSeries27.add(timeSeriesDataItem40, true);
        boolean boolean43 = timeSeriesDataItem10.equals((java.lang.Object) timeSeriesDataItem40);
        boolean boolean44 = timeSeriesDataItem40.isSelected();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        long long49 = fixedMillisecond46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond46.next();
        int int51 = timeSeriesDataItem40.compareTo((java.lang.Object) regularTimePeriod50);
        java.lang.Object obj52 = timeSeriesDataItem40.clone();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        long long21 = month14.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1, seriesChangeInfo23);
        int int25 = month14.compareTo((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559372400000L + "'", long21 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 10);
        int int34 = month20.compareTo((java.lang.Object) timeSeriesDataItem33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560668399999L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int43 = fixedMillisecond41.compareTo((java.lang.Object) 9);
        long long44 = fixedMillisecond41.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond41.next();
        int int46 = month20.compareTo((java.lang.Object) fixedMillisecond41);
        java.util.Date date47 = fixedMillisecond41.getStart();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.util.TimeZone timeZone49 = null;
        java.util.Locale locale50 = null;
        try {
            org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date47, timeZone49, locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(date47);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 10);
        int int34 = month20.compareTo((java.lang.Object) timeSeriesDataItem33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560668399999L, false);
        try {
            java.lang.Number number41 = timeSeries3.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.List list10 = timeSeries3.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.getDataItem(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        try {
            timeSeries3.update(7, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month32);
        int int37 = month32.getMonth();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries41.removeChangeListener(seriesChangeListener42);
        java.lang.Comparable comparable44 = timeSeries41.getKey();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        java.lang.String str46 = month45.toString();
        java.lang.Number number47 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month45.previous();
        int int49 = month32.compareTo((java.lang.Object) regularTimePeriod48);
        long long50 = month32.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 0.0d + "'", comparable44.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.removeChangeListener(seriesChangeListener34);
        java.lang.Comparable comparable36 = timeSeries33.getKey();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        java.lang.Number number39 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        java.lang.String str46 = month45.toString();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.lang.String str54 = month53.toString();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) month53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries43.addAndOrUpdate(timeSeries51);
        timeSeries43.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.addAndOrUpdate(timeSeries43);
        java.util.Collection collection60 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        timeSeries3.fireSeriesChanged();
        try {
            timeSeries3.delete(7, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 0.0d + "'", comparable36.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "June 2019" + "'", str54.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(collection60);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        double double17 = timeSeries3.getMinY();
        double double18 = timeSeries3.getMaxY();
        boolean boolean19 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Class<?> wildcardClass17 = timeSeries11.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.lang.String str30 = month29.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month29);
        java.lang.String str32 = month28.toString();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.Comparable comparable34 = timeSeries21.getKey();
        boolean boolean35 = timeSeries11.equals((java.lang.Object) timeSeries21);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0.0d + "'", comparable34.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long4 = timeSeries3.getMaximumItemAge();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        timeSeries3.setDescription("");
        java.lang.Class class10 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(class10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        int int6 = year4.getYear();
        long long7 = year4.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            year4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        java.util.Date date9 = month4.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month26);
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) month26);
        java.util.Date date31 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.String str9 = timeSeries7.getDescription();
        double double10 = timeSeries7.getMinY();
        timeSeries7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day3, seriesChangeInfo4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.util.List list28 = timeSeries24.getItems();
        timeSeries24.setNotify(true);
        java.lang.Object obj31 = timeSeries24.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month36, (org.jfree.data.time.RegularTimePeriod) month37);
        java.lang.String str40 = month36.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month49);
        long long52 = timeSeries51.getMaximumItemAge();
        java.lang.String str53 = timeSeries51.getDescription();
        int int54 = timeSeriesDataItem42.compareTo((java.lang.Object) str53);
        java.lang.Number number55 = timeSeriesDataItem42.getValue();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries59.removeChangeListener(seriesChangeListener60);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
        java.lang.String str68 = month67.toString();
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries65.createCopy((org.jfree.data.time.RegularTimePeriod) month66, (org.jfree.data.time.RegularTimePeriod) month67);
        java.lang.String str70 = month66.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (short) 10);
        timeSeries59.add(timeSeriesDataItem72, true);
        boolean boolean75 = timeSeriesDataItem42.equals((java.lang.Object) timeSeriesDataItem72);
        timeSeriesDataItem42.setSelected(false);
        timeSeries24.add(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (short) 10 + "'", number55.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "June 2019" + "'", str68.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "June 2019" + "'", str70.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = seriesException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str11 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str9.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "hi!", "Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        java.lang.String str35 = month31.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (short) 10);
        int int38 = month24.compareTo((java.lang.Object) timeSeriesDataItem37);
        java.lang.String str39 = month24.toString();
        int int40 = timeSeriesDataItem16.compareTo((java.lang.Object) month24);
        timeSeriesDataItem16.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.lang.String str49 = month48.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) month47, (org.jfree.data.time.RegularTimePeriod) month48);
        timeSeries46.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener53);
        timeSeries46.clear();
        timeSeries46.setMaximumItemAge((long) '4');
        timeSeries46.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        java.lang.String str66 = month65.toString();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries63.createCopy((org.jfree.data.time.RegularTimePeriod) month64, (org.jfree.data.time.RegularTimePeriod) month65);
        java.lang.String str68 = month64.toString();
        int int69 = month64.getYearValue();
        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) month64);
        int int71 = timeSeriesDataItem16.compareTo((java.lang.Object) month64);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "June 2019" + "'", str66.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "June 2019" + "'", str68.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month32);
        java.lang.String str37 = month32.toString();
        org.jfree.data.time.Year year38 = month32.getYear();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
        org.junit.Assert.assertNotNull(year38);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getSerialIndex();
        java.util.Date date3 = month0.getStart();
        java.util.Date date4 = month0.getEnd();
        int int5 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getEnd();
//        java.lang.String str5 = day0.toString();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        java.lang.Comparable comparable27 = timeSeries24.getKey();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        java.lang.Number number30 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month28, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        try {
            timeSeries15.update(regularTimePeriod35, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        long long20 = timeSeries19.getMaximumItemAge();
        java.lang.String str21 = timeSeries19.getDescription();
        int int22 = timeSeriesDataItem10.compareTo((java.lang.Object) str21);
        java.lang.Number number23 = timeSeriesDataItem10.getValue();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries27.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month35);
        java.lang.String str38 = month34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        timeSeries27.add(timeSeriesDataItem40, true);
        boolean boolean43 = timeSeriesDataItem10.equals((java.lang.Object) timeSeriesDataItem40);
        org.jfree.data.general.SeriesException seriesException45 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=NaN]");
        boolean boolean46 = timeSeriesDataItem10.equals((java.lang.Object) seriesException45);
        org.jfree.data.general.SeriesException seriesException48 = new org.jfree.data.general.SeriesException("");
        seriesException45.addSuppressed((java.lang.Throwable) seriesException48);
        java.lang.Throwable[] throwableArray50 = seriesException45.getSuppressed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        long long21 = month14.getFirstMillisecond();
        long long22 = month14.getFirstMillisecond();
        int int23 = month14.getMonth();
        java.util.Calendar calendar24 = null;
        try {
            long long25 = month14.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559372400000L + "'", long21 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        int int21 = timeSeries3.getMaximumItemCount();
        boolean boolean22 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.clear();
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        boolean boolean27 = timeSeries3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        java.lang.Comparable comparable34 = timeSeries31.getKey();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        java.lang.Number number37 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        java.lang.String str46 = month42.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, (double) 100);
        timeSeries31.removeAgedItems(0L, false);
        timeSeries31.setNotify(false);
        java.util.Collection collection54 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        timeSeries31.setNotify(true);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        java.lang.String str59 = month58.toString();
        java.lang.Object obj60 = null;
        boolean boolean61 = month58.equals(obj60);
        org.jfree.data.time.Year year62 = month58.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.previous();
        boolean boolean65 = year62.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year62.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year62.previous();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(1, year62);
        java.lang.Number number69 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) month68);
        java.util.Collection collection70 = timeSeries31.getTimePeriods();
        java.lang.String str71 = timeSeries31.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0.0d + "'", comparable34.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "June 2019" + "'", str59.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(number69);
        org.junit.Assert.assertNotNull(collection70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        timeSeries13.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries13);
        boolean boolean30 = timeSeries13.isEmpty();
        java.lang.Comparable comparable31 = timeSeries13.getKey();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.lang.String str42 = month41.toString();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) month40, (org.jfree.data.time.RegularTimePeriod) month41);
        long long44 = timeSeries43.getMaximumItemAge();
        java.lang.String str45 = timeSeries43.getDescription();
        double double46 = timeSeries43.getMinY();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.lang.String str53 = month52.toString();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) month51, (org.jfree.data.time.RegularTimePeriod) month52);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        java.lang.String str61 = month60.toString();
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) month59, (org.jfree.data.time.RegularTimePeriod) month60);
        java.lang.String str63 = month59.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month59, (java.lang.Number) (short) 10);
        int int66 = month52.compareTo((java.lang.Object) timeSeriesDataItem65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) 1L);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) 1560668399999L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int75 = fixedMillisecond73.compareTo((java.lang.Object) 9);
        long long76 = fixedMillisecond73.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond73.next();
        int int78 = month52.compareTo((java.lang.Object) fixedMillisecond73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond73.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 7 + "'", comparable31.equals(7));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June 2019" + "'", str42.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "June 2019" + "'", str61.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "June 2019" + "'", str63.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        java.lang.String str35 = month31.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (short) 10);
        int int38 = month24.compareTo((java.lang.Object) timeSeriesDataItem37);
        java.lang.String str39 = month24.toString();
        int int40 = timeSeriesDataItem16.compareTo((java.lang.Object) month24);
        java.lang.Object obj41 = timeSeriesDataItem16.clone();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-9999), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        timeSeries3.setMaximumItemCount((int) '4');
        int int6 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        try {
            java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        timeSeries5.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener12);
        timeSeries5.clear();
        timeSeries5.setMaximumItemAge((long) '4');
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        java.lang.String str19 = timeSeries5.getDescription();
        java.lang.Comparable comparable20 = timeSeries5.getKey();
        boolean boolean21 = year1.equals((java.lang.Object) comparable20);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 7 + "'", comparable20.equals(7));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = timeSeries7.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener9);
        timeSeries7.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month32);
        long long37 = month32.getFirstMillisecond();
        int int38 = month32.getMonth();
        java.util.Calendar calendar39 = null;
        try {
            month32.peg(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = timeSeries7.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries7.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries7.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        double double17 = timeSeries3.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int21 = fixedMillisecond19.compareTo((java.lang.Object) 9);
        long long22 = fixedMillisecond19.getFirstMillisecond();
        java.lang.Number number23 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries16.add(regularTimePeriod17, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(43626L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        java.lang.String str6 = seriesChangeEvent2.toString();
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1 + "'", obj4.equals(1));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 1 + "'", obj5.equals(1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        long long20 = timeSeries19.getMaximumItemAge();
        java.lang.String str21 = timeSeries19.getDescription();
        int int22 = timeSeriesDataItem10.compareTo((java.lang.Object) str21);
        java.lang.Number number23 = timeSeriesDataItem10.getValue();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries27.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month35);
        java.lang.String str38 = month34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        timeSeries27.add(timeSeriesDataItem40, true);
        boolean boolean43 = timeSeriesDataItem10.equals((java.lang.Object) timeSeriesDataItem40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem10.getPeriod();
        java.lang.Class<?> wildcardClass46 = regularTimePeriod45.getClass();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) Double.NaN, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=NaN]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=NaN]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=NaN]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=NaN]"));
        org.junit.Assert.assertEquals((double) obj7, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        java.lang.Object obj17 = null;
        boolean boolean18 = month15.equals(obj17);
        org.jfree.data.time.Year year19 = month15.getYear();
        int int20 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Class class21 = timeSeries11.getTimePeriodClass();
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.lang.String str31 = month30.toString();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month29, (org.jfree.data.time.RegularTimePeriod) month30);
        java.lang.String str33 = month29.toString();
        java.util.Date date34 = month29.getStart();
        boolean boolean35 = fixedMillisecond24.equals((java.lang.Object) date34);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.lang.String str42 = month41.toString();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) month40, (org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month49);
        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) month49);
        int int53 = fixedMillisecond24.compareTo((java.lang.Object) month49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond24.previous();
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond24.getLastMillisecond(calendar55);
        java.util.Date date57 = fixedMillisecond24.getStart();
        int int58 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June 2019" + "'", str42.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getFirstMillisecond();
//        int int6 = day0.compareTo((java.lang.Object) 24234L);
//        int int7 = day0.getYear();
//        long long8 = day0.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month32);
        java.lang.String str35 = month31.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (short) 10);
        int int38 = month24.compareTo((java.lang.Object) timeSeriesDataItem37);
        java.lang.String str39 = month24.toString();
        int int40 = timeSeriesDataItem16.compareTo((java.lang.Object) month24);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        java.lang.Object obj45 = timeSeries44.clone();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        java.lang.String str52 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) month50, (org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        java.lang.String str60 = month59.toString();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) month58, (org.jfree.data.time.RegularTimePeriod) month59);
        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) month59);
        int int63 = timeSeries53.getMaximumItemCount();
        boolean boolean64 = timeSeries44.equals((java.lang.Object) timeSeries53);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries53);
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries53.removePropertyChangeListener(propertyChangeListener66);
        timeSeries53.setKey((java.lang.Comparable) 100L);
        boolean boolean70 = month24.equals((java.lang.Object) timeSeries53);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "June 2019" + "'", str52.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2147483647 + "'", int63 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 10);
        int int34 = month20.compareTo((java.lang.Object) timeSeriesDataItem33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560668399999L, false);
        int int40 = month20.getYearValue();
        java.util.Calendar calendar41 = null;
        try {
            month20.peg(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        long long9 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month4.previous();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month4.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month13);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(0);
        long long20 = year19.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560150000000L);
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy(6, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62167363200000L) + "'", long20 == (-62167363200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        long long20 = timeSeries19.getMaximumItemAge();
        java.lang.String str21 = timeSeries19.getDescription();
        int int22 = timeSeriesDataItem10.compareTo((java.lang.Object) str21);
        java.lang.Number number23 = timeSeriesDataItem10.getValue();
        timeSeriesDataItem10.setValue((java.lang.Number) 43626L);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        java.lang.Object obj28 = null;
        boolean boolean29 = month26.equals(obj28);
        int int30 = month26.getYearValue();
        int int32 = month26.compareTo((java.lang.Object) 6);
        int int33 = timeSeriesDataItem10.compareTo((java.lang.Object) month26);
        timeSeriesDataItem10.setSelected(false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.String str22 = month21.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) month21);
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (short) 10);
        int int27 = month13.compareTo((java.lang.Object) timeSeriesDataItem26);
        timeSeries7.add(timeSeriesDataItem26, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = null;
        try {
            timeSeries7.update(regularTimePeriod30, (java.lang.Number) 43626L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        boolean boolean4 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = month9.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.String str23 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month22);
        long long25 = timeSeries24.getMaximumItemAge();
        java.lang.String str26 = timeSeries24.getDescription();
        int int27 = timeSeriesDataItem15.compareTo((java.lang.Object) str26);
        java.lang.Number number28 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.removeChangeListener(seriesChangeListener33);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        java.lang.String str41 = month40.toString();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) month39, (org.jfree.data.time.RegularTimePeriod) month40);
        java.lang.String str43 = month39.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (short) 10);
        timeSeries32.add(timeSeriesDataItem45, true);
        boolean boolean48 = timeSeriesDataItem15.equals((java.lang.Object) timeSeriesDataItem45);
        boolean boolean49 = timeSeriesDataItem15.isSelected();
        timeSeries3.add(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "June 2019" + "'", str41.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Number number18 = null;
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month17, number18, false);
        try {
            timeSeries7.update(11, (java.lang.Number) 24234L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 9);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        long long9 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        timeSeries3.setMaximumItemCount(4);
        boolean boolean8 = timeSeries3.isEmpty();
        boolean boolean9 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month18);
        int int22 = timeSeries12.getMaximumItemCount();
        boolean boolean23 = timeSeries3.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.lang.String str30 = month29.toString();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month36, (org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries27.addAndOrUpdate(timeSeries35);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.lang.String str42 = month41.toString();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.lang.String str49 = month48.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) month47, (org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        java.lang.String str57 = month56.toString();
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries54.createCopy((org.jfree.data.time.RegularTimePeriod) month55, (org.jfree.data.time.RegularTimePeriod) month56);
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) month56);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) month41, (org.jfree.data.time.RegularTimePeriod) month56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month56.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries12.getDataItem(regularTimePeriod61);
        boolean boolean63 = timeSeries12.getNotify();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June 2019" + "'", str42.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June 2019" + "'", str57.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries5.getKey();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.lang.String str10 = month9.toString();
//        java.lang.Number number11 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) month9);
//        java.util.List list12 = timeSeries5.getItems();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.lang.String str19 = month18.toString();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.lang.String str27 = month26.toString();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries16.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        java.lang.String str31 = month30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        java.lang.String str38 = month37.toString();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month36, (org.jfree.data.time.RegularTimePeriod) month37);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        java.lang.String str46 = month45.toString();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month45);
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month45);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month45.previous();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        java.lang.String str52 = month51.toString();
//        java.lang.Object obj53 = null;
//        boolean boolean54 = month51.equals(obj53);
//        org.jfree.data.time.Year year55 = month51.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.previous();
//        boolean boolean58 = year55.equals((java.lang.Object) 10L);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries5.createCopy(regularTimePeriod50, (org.jfree.data.time.RegularTimePeriod) year55);
//        timeSeries59.clear();
//        int int61 = day0.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Class<?> wildcardClass62 = day0.getClass();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        java.lang.String str64 = month63.toString();
//        long long65 = month63.getSerialIndex();
//        java.util.Date date66 = month63.getStart();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date66);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo68 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent69 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date66, seriesChangeInfo68);
//        java.util.TimeZone timeZone70 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date66, timeZone70);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0d + "'", comparable8.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "June 2019" + "'", str52.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "June 2019" + "'", str64.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.String str22 = month21.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) month21);
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (short) 10);
        int int27 = month13.compareTo((java.lang.Object) timeSeriesDataItem26);
        timeSeries7.add(timeSeriesDataItem26, true);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        java.lang.String str40 = month39.toString();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month39);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        java.lang.String str48 = month47.toString();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) month46, (org.jfree.data.time.RegularTimePeriod) month47);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries37.addAndOrUpdate(timeSeries45);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries54.removeChangeListener(seriesChangeListener55);
        java.lang.Comparable comparable57 = timeSeries54.getKey();
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        java.lang.String str59 = month58.toString();
        java.lang.Number number60 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) month58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month58.previous();
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) month58, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries33.addAndOrUpdate(timeSeries45);
        int int65 = timeSeries33.getItemCount();
        java.lang.String str66 = timeSeries33.getRangeDescription();
        int int67 = timeSeriesDataItem26.compareTo((java.lang.Object) str66);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "June 2019" + "'", str48.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + 0.0d + "'", comparable57.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "June 2019" + "'", str59.equals("June 2019"));
        org.junit.Assert.assertNull(number60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str66.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        java.lang.Object obj3 = null;
        boolean boolean4 = month1.equals(obj3);
        org.jfree.data.time.Year year5 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        boolean boolean8 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year5.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(1, year5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        long long16 = fixedMillisecond13.getFirstMillisecond();
        long long17 = fixedMillisecond13.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.previous();
        boolean boolean20 = month11.equals((java.lang.Object) fixedMillisecond13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        timeSeries3.setMaximumItemCount(4);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.String str9 = month8.toString();
        long long10 = month8.getSerialIndex();
        java.util.Date date11 = month8.getStart();
        java.util.Date date12 = month8.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 0.0f, true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.String str23 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month22, seriesChangeInfo25);
        int int27 = month22.getYearValue();
        int int28 = month22.getMonth();
        timeSeries3.setKey((java.lang.Comparable) int28);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        timeSeries13.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries13);
        java.util.List list30 = timeSeries13.getItems();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long37 = timeSeries36.getMaximumItemAge();
        int int38 = timeSeries36.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        java.lang.String str45 = month44.toString();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) month44);
        java.lang.String str47 = month43.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
        java.util.Date date51 = regularTimePeriod50.getStart();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) 0, false);
        long long56 = month52.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month52);
        java.lang.Comparable comparable58 = timeSeries13.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond60.getFirstMillisecond(calendar61);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        java.lang.String str69 = month68.toString();
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries66.createCopy((org.jfree.data.time.RegularTimePeriod) month67, (org.jfree.data.time.RegularTimePeriod) month68);
        long long71 = timeSeries70.getMaximumItemAge();
        java.lang.String str72 = timeSeries70.getDescription();
        double double73 = timeSeries70.getMinY();
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
        java.lang.String str75 = month74.toString();
        java.lang.Object obj76 = null;
        boolean boolean77 = month74.equals(obj76);
        org.jfree.data.time.Year year78 = month74.getYear();
        int int79 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) year78);
        java.lang.Class class80 = timeSeries70.getTimePeriodClass();
        int int81 = fixedMillisecond60.compareTo((java.lang.Object) timeSeries70);
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries13.addAndOrUpdate(timeSeries70);
        timeSeries82.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "June 2019" + "'", str47.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1559372400000L + "'", long56 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 7 + "'", comparable58.equals(7));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "June 2019" + "'", str69.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 9223372036854775807L + "'", long71 == 9223372036854775807L);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "June 2019" + "'", str75.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(year78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNull(class80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(timeSeries82);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 9);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.setMaximumItemAge((long) (short) 0);
        timeSeries3.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=NaN]");
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0d + "'", comparable5.equals(0.0d));
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getEnd();
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        java.lang.Object obj12 = null;
        boolean boolean13 = month10.equals(obj12);
        org.jfree.data.time.Year year14 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        timeSeries3.add(regularTimePeriod15, 0.0d);
        double double18 = timeSeries3.getMinY();
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = year4.getFirstMillisecond();
        java.lang.String str6 = year4.toString();
        long long7 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.String str9 = timeSeries7.getDescription();
        double double10 = timeSeries7.getMinY();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.String str17 = month16.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        java.lang.String str27 = month23.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (short) 10);
        int int30 = month16.compareTo((java.lang.Object) timeSeriesDataItem29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 1L);
        long long33 = month16.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1559372400000L + "'", long33 == 1559372400000L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.removeChangeListener(seriesChangeListener23);
        java.lang.Comparable comparable25 = timeSeries22.getKey();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        java.lang.Number number28 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.previous();
        java.lang.Number number30 = timeSeries3.getValue(regularTimePeriod29);
        try {
            java.lang.Class<?> wildcardClass31 = number30.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 0.0d + "'", comparable25.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        java.lang.Comparable comparable27 = timeSeries24.getKey();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        java.lang.Number number30 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month28, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        int int35 = timeSeries3.getItemCount();
        java.lang.String str36 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
        long long41 = fixedMillisecond38.getFirstMillisecond();
        long long42 = fixedMillisecond38.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond38.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond38.previous();
        long long45 = fixedMillisecond38.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond38);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries3.addAndOrUpdate(timeSeries46);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str36.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(timeSeries47);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
//        boolean boolean5 = day0.equals((java.lang.Object) seriesChangeEvent4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.lang.String str13 = month12.toString();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) month12);
//        java.lang.String str15 = month11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.lang.String str25 = month24.toString();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
//        long long27 = timeSeries26.getMaximumItemAge();
//        java.lang.String str28 = timeSeries26.getDescription();
//        int int29 = timeSeriesDataItem17.compareTo((java.lang.Object) str28);
//        java.lang.Number number30 = timeSeriesDataItem17.getValue();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries34.removeChangeListener(seriesChangeListener35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        java.lang.String str43 = month42.toString();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) month41, (org.jfree.data.time.RegularTimePeriod) month42);
//        java.lang.String str45 = month41.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month41, (java.lang.Number) (short) 10);
//        timeSeries34.add(timeSeriesDataItem47, true);
//        boolean boolean50 = timeSeriesDataItem17.equals((java.lang.Object) timeSeriesDataItem47);
//        boolean boolean51 = timeSeriesDataItem47.isSelected();
//        boolean boolean52 = day0.equals((java.lang.Object) boolean51);
//        org.jfree.data.time.SerialDate serialDate53 = day0.getSerialDate();
//        java.util.Calendar calendar54 = null;
//        try {
//            long long55 = day0.getLastMillisecond(calendar54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 10 + "'", number30.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(serialDate53);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month26);
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) month26);
        java.util.Date date31 = month26.getEnd();
        java.util.Date date32 = month26.getStart();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        int int6 = day0.getDayOfMonth();
//        long long7 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        int int10 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        java.lang.String str6 = month5.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
//        long long8 = timeSeries7.getMaximumItemAge();
//        java.lang.String str9 = timeSeries7.getDescription();
//        double double10 = timeSeries7.getMinY();
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.String str18 = month17.toString();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
//        java.lang.String str20 = month16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (short) 10);
//        timeSeries7.add(timeSeriesDataItem22, true);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.lang.String str28 = month27.toString();
//        java.lang.Object obj29 = null;
//        boolean boolean30 = month27.equals(obj29);
//        org.jfree.data.time.Year year31 = month27.getYear();
//        int int32 = day25.compareTo((java.lang.Object) month27);
//        int int33 = day25.getMonth();
//        java.lang.String str34 = day25.toString();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=NaN]");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.removeChangeListener(seriesChangeListener21);
        java.lang.Comparable comparable23 = timeSeries20.getKey();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        java.lang.Number number26 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.previous();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month24, (double) (byte) 10);
        java.util.Date date30 = month24.getStart();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 0.0d + "'", comparable23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        boolean boolean27 = timeSeries3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries13.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        java.lang.String str40 = month39.toString();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month39);
        long long42 = timeSeries41.getMaximumItemAge();
        java.lang.String str43 = timeSeries41.getDescription();
        double double44 = timeSeries41.getMinY();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        java.lang.String str51 = month50.toString();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) month49, (org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        java.lang.String str59 = month58.toString();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) month57, (org.jfree.data.time.RegularTimePeriod) month58);
        java.lang.String str61 = month57.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) (short) 10);
        int int64 = month50.compareTo((java.lang.Object) timeSeriesDataItem63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1L);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 1560668399999L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int73 = fixedMillisecond71.compareTo((java.lang.Object) 9);
        long long74 = fixedMillisecond71.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond71.next();
        int int76 = month50.compareTo((java.lang.Object) fixedMillisecond71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond71.next();
        timeSeries13.add(regularTimePeriod77, (double) 24229L, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "June 2019" + "'", str59.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "June 2019" + "'", str61.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 10);
        timeSeries3.add(timeSeriesDataItem16, true);
        timeSeries3.update(0, (java.lang.Number) 10.0d);
        int int22 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.Year year4 = month0.getYear();
        int int5 = year4.getYear();
        long long6 = year4.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.String str13 = month12.toString();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) month12);
        long long15 = timeSeries14.getMaximumItemAge();
        java.lang.String str16 = timeSeries14.getDescription();
        double double17 = timeSeries14.getMinY();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        java.lang.Object obj20 = null;
        boolean boolean21 = month18.equals(obj20);
        org.jfree.data.time.Year year22 = month18.getYear();
        int int23 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        boolean boolean24 = year4.equals((java.lang.Object) timeSeries14);
        long long25 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year4.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.Number number18 = null;
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month17, number18, false);
        org.jfree.data.time.Year year21 = month17.getYear();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        boolean boolean26 = timeSeries25.isEmpty();
        timeSeries25.fireSeriesChanged();
        timeSeries25.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month35);
        java.lang.String str38 = month34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) (short) 10);
        int int42 = timeSeriesDataItem40.compareTo((java.lang.Object) 0L);
        timeSeriesDataItem40.setValue((java.lang.Number) 1560150000000L);
        timeSeries25.add(timeSeriesDataItem40);
        int int46 = year21.compareTo((java.lang.Object) timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.List list10 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.String str17 = month16.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries14.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month43.previous();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        java.lang.Object obj51 = null;
        boolean boolean52 = month49.equals(obj51);
        org.jfree.data.time.Year year53 = month49.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.previous();
        boolean boolean56 = year53.equals((java.lang.Object) 10L);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy(regularTimePeriod48, (org.jfree.data.time.RegularTimePeriod) year53);
        boolean boolean58 = timeSeries57.getNotify();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("July 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        timeSeries13.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries13);
        java.util.List list30 = timeSeries13.getItems();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long37 = timeSeries36.getMaximumItemAge();
        int int38 = timeSeries36.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        java.lang.String str45 = month44.toString();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) month44);
        java.lang.String str47 = month43.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
        java.util.Date date51 = regularTimePeriod50.getStart();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) 0, false);
        long long56 = month52.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month52);
        java.lang.Comparable comparable58 = timeSeries13.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond60.getFirstMillisecond(calendar61);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        java.lang.String str69 = month68.toString();
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries66.createCopy((org.jfree.data.time.RegularTimePeriod) month67, (org.jfree.data.time.RegularTimePeriod) month68);
        long long71 = timeSeries70.getMaximumItemAge();
        java.lang.String str72 = timeSeries70.getDescription();
        double double73 = timeSeries70.getMinY();
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
        java.lang.String str75 = month74.toString();
        java.lang.Object obj76 = null;
        boolean boolean77 = month74.equals(obj76);
        org.jfree.data.time.Year year78 = month74.getYear();
        int int79 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) year78);
        java.lang.Class class80 = timeSeries70.getTimePeriodClass();
        int int81 = fixedMillisecond60.compareTo((java.lang.Object) timeSeries70);
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries13.addAndOrUpdate(timeSeries70);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeries13.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "June 2019" + "'", str47.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1559372400000L + "'", long56 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 7 + "'", comparable58.equals(7));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "June 2019" + "'", str69.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 9223372036854775807L + "'", long71 == 9223372036854775807L);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "June 2019" + "'", str75.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(year78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNull(class80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(timeSeries82);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        timeSeries13.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries13);
        java.util.List list30 = timeSeries13.getItems();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long37 = timeSeries36.getMaximumItemAge();
        int int38 = timeSeries36.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        java.lang.String str45 = month44.toString();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) month43, (org.jfree.data.time.RegularTimePeriod) month44);
        java.lang.String str47 = month43.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
        java.util.Date date51 = regularTimePeriod50.getStart();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month52, (java.lang.Number) 0, false);
        long long56 = month52.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month52);
        int int58 = month52.getYearValue();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "June 2019" + "'", str47.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1559372400000L + "'", long56 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        long long4 = timeSeries3.getMaximumItemAge();
//        int int5 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.util.List list8 = timeSeries3.getItems();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        long long11 = day9.getSerialIndex();
//        boolean boolean13 = day9.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day9.previous();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener19);
//        java.lang.Comparable comparable21 = timeSeries18.getKey();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        java.lang.String str23 = month22.toString();
//        java.lang.Number number24 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) month22);
//        java.util.List list25 = timeSeries18.getItems();
//        boolean boolean26 = day9.equals((java.lang.Object) timeSeries18);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries18.addChangeListener(seriesChangeListener27);
//        timeSeries18.fireSeriesChanged();
//        java.util.Collection collection30 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0.0d + "'", comparable21.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(collection30);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long4 = timeSeries3.getMaximumItemAge();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        timeSeries13.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries13);
        boolean boolean30 = timeSeries13.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        long long35 = fixedMillisecond32.getSerialIndex();
        java.util.Date date36 = fixedMillisecond32.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        try {
            timeSeries13.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.removeChangeListener(seriesChangeListener34);
        java.lang.Comparable comparable36 = timeSeries33.getKey();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        java.lang.Number number39 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        java.lang.String str46 = month45.toString();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.lang.String str54 = month53.toString();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) month53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries43.addAndOrUpdate(timeSeries51);
        timeSeries43.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.addAndOrUpdate(timeSeries43);
        java.util.Collection collection60 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        int int61 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int65 = fixedMillisecond63.compareTo((java.lang.Object) 9);
        long long66 = fixedMillisecond63.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond63.previous();
        java.lang.Number number68 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 0.0d + "'", comparable36.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "June 2019" + "'", str54.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2147483647 + "'", int61 == 2147483647);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 100.0d + "'", number68.equals(100.0d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str16 = month12.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (short) 10);
        int int19 = month5.compareTo((java.lang.Object) timeSeriesDataItem18);
        java.lang.String str20 = month5.toString();
        java.lang.String str21 = month5.toString();
        long long22 = month5.getLastMillisecond();
        java.lang.String str23 = month5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getSerialIndex();
        java.util.Date date3 = month0.getStart();
        java.util.Date date4 = month0.getEnd();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries9.getKey();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        java.lang.Number number15 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.List list16 = timeSeries9.getItems();
//        boolean boolean17 = day0.equals((java.lang.Object) timeSeries9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries9.addChangeListener(seriesChangeListener18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries9.addPropertyChangeListener(propertyChangeListener20);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0d + "'", comparable12.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 10);
        int int34 = month20.compareTo((java.lang.Object) timeSeriesDataItem33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560668399999L, false);
        timeSeries3.setMaximumItemCount(1);
        java.lang.Class<?> wildcardClass42 = timeSeries3.getClass();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.String str23 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str25 = month21.toString();
        int int26 = month21.getYearValue();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        java.lang.Comparable comparable34 = timeSeries31.getKey();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        java.lang.Number number37 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        java.lang.String str52 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) month50, (org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries41.addAndOrUpdate(timeSeries49);
        timeSeries41.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries31.addAndOrUpdate(timeSeries41);
        int int58 = month21.compareTo((java.lang.Object) timeSeries41);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        java.lang.String str65 = month64.toString();
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries62.createCopy((org.jfree.data.time.RegularTimePeriod) month63, (org.jfree.data.time.RegularTimePeriod) month64);
        java.lang.String str67 = month63.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month63, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeriesDataItem69.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
        java.lang.String str77 = month76.toString();
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries74.createCopy((org.jfree.data.time.RegularTimePeriod) month75, (org.jfree.data.time.RegularTimePeriod) month76);
        long long79 = timeSeries78.getMaximumItemAge();
        java.lang.String str80 = timeSeries78.getDescription();
        int int81 = timeSeriesDataItem69.compareTo((java.lang.Object) str80);
        java.lang.Number number82 = timeSeriesDataItem69.getValue();
        timeSeriesDataItem69.setSelected(true);
        timeSeries41.add(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0.0d + "'", comparable34.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "June 2019" + "'", str52.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "June 2019" + "'", str65.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "June 2019" + "'", str67.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "June 2019" + "'", str77.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 9223372036854775807L + "'", long79 == 9223372036854775807L);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (short) 10 + "'", number82.equals((short) 10));
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str16 = month12.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (short) 10);
        int int19 = month5.compareTo((java.lang.Object) timeSeriesDataItem18);
        java.lang.String str20 = month5.toString();
        java.lang.String str21 = month5.toString();
        java.util.Date date22 = month5.getStart();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.String str9 = timeSeries7.getDescription();
        double double10 = timeSeries7.getMinY();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        java.lang.Object obj13 = null;
        boolean boolean14 = month11.equals(obj13);
        org.jfree.data.time.Year year15 = month11.getYear();
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        long long17 = year15.getLastMillisecond();
        long long18 = year15.getSerialIndex();
        java.lang.Object obj19 = null;
        int int20 = year15.compareTo(obj19);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        int int28 = timeSeries24.getItemCount();
        timeSeries24.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 9);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        java.lang.String str6 = fixedMillisecond1.toString();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, year1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 10);
        int int34 = month20.compareTo((java.lang.Object) timeSeriesDataItem33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560668399999L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int43 = fixedMillisecond41.compareTo((java.lang.Object) 9);
        long long44 = fixedMillisecond41.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond41.next();
        int int46 = month20.compareTo((java.lang.Object) fixedMillisecond41);
        int int47 = month20.getYearValue();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        java.lang.Comparable comparable27 = timeSeries24.getKey();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        java.lang.Number number30 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month28, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries15);
        int int35 = timeSeries3.getItemCount();
        int int36 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemCount(3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(9223372036854775807L);
        long long41 = fixedMillisecond40.getSerialIndex();
        long long42 = fixedMillisecond40.getLastMillisecond();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 1560186026348L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0d + "'", comparable27.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.next();
        java.lang.Class<?> wildcardClass17 = fixedMillisecond15.getClass();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        java.util.Calendar calendar5 = null;
        try {
            year2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.String str28 = timeSeries27.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        java.lang.String str39 = month38.toString();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) month38);
        long long41 = timeSeries40.getMaximumItemAge();
        java.lang.String str42 = timeSeries40.getDescription();
        double double43 = timeSeries40.getMinY();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        java.lang.String str58 = month57.toString();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) month56, (org.jfree.data.time.RegularTimePeriod) month57);
        java.lang.String str60 = month56.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month56, (java.lang.Number) (short) 10);
        int int63 = month49.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1L);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1560668399999L, false);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 12, false);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
        java.lang.String str78 = month77.toString();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries75.createCopy((org.jfree.data.time.RegularTimePeriod) month76, (org.jfree.data.time.RegularTimePeriod) month77);
        java.lang.String str80 = month76.toString();
        int int81 = month76.getYearValue();
        timeSeries27.update((org.jfree.data.time.RegularTimePeriod) month76, (java.lang.Number) 1560185999984L);
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185999984L);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "June 2019" + "'", str78.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "June 2019" + "'", str80.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.Object obj28 = timeSeries24.clone();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long33 = timeSeries32.getMaximumItemAge();
        int int34 = timeSeries32.getMaximumItemCount();
        java.util.Collection collection35 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        java.lang.String str46 = month42.toString();
        java.util.Date date47 = month42.getStart();
        boolean boolean48 = fixedMillisecond37.equals((java.lang.Object) date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2147483647 + "'", int34 == 2147483647);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 9);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        long long9 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.removeChangeListener(seriesChangeListener34);
        java.lang.Comparable comparable36 = timeSeries33.getKey();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.String str38 = month37.toString();
        java.lang.Number number39 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        java.lang.String str46 = month45.toString();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) month44, (org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.lang.String str54 = month53.toString();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) month53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries43.addAndOrUpdate(timeSeries51);
        timeSeries43.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.addAndOrUpdate(timeSeries43);
        java.util.Collection collection60 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        timeSeries3.fireSeriesChanged();
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 0.0d + "'", comparable36.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "June 2019" + "'", str54.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(collection60);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        java.lang.String str6 = month5.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
//        java.lang.String str8 = month4.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
//        java.lang.Object obj16 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass17 = obj16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        long long24 = day22.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.next();
//        java.util.Date date26 = day22.getEnd();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
//        int int30 = day15.compareTo((java.lang.Object) day29);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-9) + "'", int30 == (-9));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = month10.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.Class class16 = timeSeries3.getTimePeriodClass();
        boolean boolean17 = timeSeries3.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        long long22 = fixedMillisecond19.getFirstMillisecond();
        long long23 = fixedMillisecond19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond19.previous();
        long long26 = fixedMillisecond19.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (byte) 10, false);
        java.util.Calendar calendar30 = null;
        fixedMillisecond19.peg(calendar30);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) calendar30, seriesChangeInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month26);
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) month26);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.lang.String str37 = month36.toString();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries34.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        java.lang.String str47 = month46.toString();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) month45, (org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        java.lang.String str55 = month54.toString();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) month53, (org.jfree.data.time.RegularTimePeriod) month54);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries44.addAndOrUpdate(timeSeries52);
        boolean boolean58 = timeSeries34.equals((java.lang.Object) timeSeries44);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries44.removeChangeListener(seriesChangeListener59);
        boolean boolean61 = month26.equals((java.lang.Object) timeSeries44);
        java.lang.String str62 = timeSeries44.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "June 2019" + "'", str47.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "June 2019" + "'", str55.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.String str28 = timeSeries27.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        java.lang.String str39 = month38.toString();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) month38);
        long long41 = timeSeries40.getMaximumItemAge();
        java.lang.String str42 = timeSeries40.getDescription();
        double double43 = timeSeries40.getMinY();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        java.lang.String str58 = month57.toString();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) month56, (org.jfree.data.time.RegularTimePeriod) month57);
        java.lang.String str60 = month56.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month56, (java.lang.Number) (short) 10);
        int int63 = month49.compareTo((java.lang.Object) timeSeriesDataItem62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1L);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 1560668399999L, false);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 12, false);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
        java.lang.String str78 = month77.toString();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries75.createCopy((org.jfree.data.time.RegularTimePeriod) month76, (org.jfree.data.time.RegularTimePeriod) month77);
        java.lang.String str80 = month76.toString();
        int int81 = month76.getYearValue();
        timeSeries27.update((org.jfree.data.time.RegularTimePeriod) month76, (java.lang.Number) 1560185999984L);
        org.jfree.data.time.Year year84 = month76.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = month76.next();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "June 2019" + "'", str78.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "June 2019" + "'", str80.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
        org.junit.Assert.assertNotNull(year84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.Comparable comparable28 = timeSeries3.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        long long33 = fixedMillisecond30.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 0.0d + "'", comparable28.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        java.lang.String str6 = month5.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
//        timeSeries3.setKey((java.lang.Comparable) 7);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.lang.String str11 = month10.toString();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = month10.equals(obj12);
//        org.jfree.data.time.Year year14 = month10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        timeSeries3.add(regularTimePeriod15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
//        boolean boolean22 = timeSeries21.isEmpty();
//        timeSeries21.fireSeriesChanged();
//        timeSeries21.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.String str32 = month31.toString();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month31);
//        java.lang.String str34 = month30.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (short) 10);
//        int int38 = timeSeriesDataItem36.compareTo((java.lang.Object) 0L);
//        timeSeriesDataItem36.setValue((java.lang.Number) 1560150000000L);
//        timeSeries21.add(timeSeriesDataItem36);
//        java.util.Collection collection42 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries3.getNextTimePeriod();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        long long46 = day44.getSerialIndex();
//        boolean boolean48 = day44.equals((java.lang.Object) 10L);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        java.lang.String str55 = month54.toString();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) month53, (org.jfree.data.time.RegularTimePeriod) month54);
//        long long57 = timeSeries56.getMaximumItemAge();
//        java.lang.String str58 = timeSeries56.getDescription();
//        double double59 = timeSeries56.getMinY();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        java.lang.String str61 = month60.toString();
//        java.lang.Object obj62 = null;
//        boolean boolean63 = month60.equals(obj62);
//        org.jfree.data.time.Year year64 = month60.getYear();
//        int int65 = timeSeries56.getIndex((org.jfree.data.time.RegularTimePeriod) year64);
//        long long66 = year64.getLastMillisecond();
//        long long67 = year64.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year64.next();
//        int int69 = day44.compareTo((java.lang.Object) year64);
//        int int70 = day44.getYear();
//        java.lang.Number number71 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day44);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "June 2019" + "'", str55.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str58);
//        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "June 2019" + "'", str61.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577865599999L + "'", long66 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 0.0d + "'", number71.equals(0.0d));
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries9.getKey();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        java.lang.Number number15 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month13);
//        java.util.List list16 = timeSeries9.getItems();
//        boolean boolean17 = day0.equals((java.lang.Object) timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        java.lang.String str24 = month23.toString();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.String str32 = month31.toString();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month31);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries21.addAndOrUpdate(timeSeries29);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.String str36 = month35.toString();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        java.lang.String str43 = month42.toString();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) month41, (org.jfree.data.time.RegularTimePeriod) month42);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.String str51 = month50.toString();
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) month49, (org.jfree.data.time.RegularTimePeriod) month50);
//        timeSeries44.delete((org.jfree.data.time.RegularTimePeriod) month50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) month50);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries9.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
//        java.lang.String str57 = month56.toString();
//        long long58 = month56.getSerialIndex();
//        java.util.Date date59 = month56.getStart();
//        java.util.Date date60 = month56.getEnd();
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) month56);
//        try {
//            timeSeries9.delete(10, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0d + "'", comparable12.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June 2019" + "'", str57.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 24234L + "'", long58 == 24234L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = month6.toString();
        java.util.Date date11 = month6.getStart();
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12);
        double double14 = timeSeries13.getMinY();
        timeSeries13.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.List list10 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.String str17 = month16.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.String str25 = month24.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries14.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.lang.String str36 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month43.previous();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        java.lang.Object obj51 = null;
        boolean boolean52 = month49.equals(obj51);
        org.jfree.data.time.Year year53 = month49.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.previous();
        boolean boolean56 = year53.equals((java.lang.Object) 10L);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy(regularTimePeriod48, (org.jfree.data.time.RegularTimePeriod) year53);
        timeSeries57.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries57.addChangeListener(seriesChangeListener59);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560186071008L + "'", long2 == 1560186071008L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560186071008L + "'", long3 == 1560186071008L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) 43626L);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) 1560186019295L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 1 + "'", obj6.equals(1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month6);
        java.lang.String str9 = month5.toString();
        org.jfree.data.time.Year year10 = month5.getYear();
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(2019, year10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        java.lang.Number number9 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long25 = timeSeries24.getMaximumItemAge();
        int int26 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.String str28 = timeSeries27.getDomainDescription();
        timeSeries27.removeAgedItems((long) 7, false);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        java.lang.String str42 = month41.toString();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) month40, (org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries39.addAndOrUpdate(timeSeries47);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries56.removeChangeListener(seriesChangeListener57);
        java.lang.Comparable comparable59 = timeSeries56.getKey();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        java.lang.String str61 = month60.toString();
        java.lang.Number number62 = timeSeries56.getValue((org.jfree.data.time.RegularTimePeriod) month60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month60.previous();
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month60, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries35.addAndOrUpdate(timeSeries47);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo67 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries47, seriesChangeInfo67);
        java.lang.String str69 = timeSeries47.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeries47.getNextTimePeriod();
        timeSeries27.setKey((java.lang.Comparable) regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0d + "'", comparable6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June 2019" + "'", str42.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + 0.0d + "'", comparable59.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "June 2019" + "'", str61.equals("June 2019"));
        org.junit.Assert.assertNull(number62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener10);
        timeSeries3.clear();
        timeSeries3.setMaximumItemAge((long) '4');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=1]");
        boolean boolean17 = timeSeries3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries3.addChangeListener(seriesChangeListener20);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries13.addAndOrUpdate(timeSeries21);
        boolean boolean27 = timeSeries3.equals((java.lang.Object) timeSeries13);
        try {
            timeSeries3.delete(6, 5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getDescription();
        double double14 = timeSeries11.getMinY();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        java.lang.Object obj17 = null;
        boolean boolean18 = month15.equals(obj17);
        org.jfree.data.time.Year year19 = month15.getYear();
        int int20 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Class class21 = timeSeries11.getTimePeriodClass();
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries11);
        timeSeries11.removeAgedItems((long) 10, false);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.String str32 = month31.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month31);
        java.lang.String str34 = month30.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) month42, (org.jfree.data.time.RegularTimePeriod) month43);
        long long46 = timeSeries45.getMaximumItemAge();
        java.lang.String str47 = timeSeries45.getDescription();
        int int48 = timeSeriesDataItem36.compareTo((java.lang.Object) str47);
        java.lang.Number number49 = timeSeriesDataItem36.getValue();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries53.removeChangeListener(seriesChangeListener54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        java.lang.String str62 = month61.toString();
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries59.createCopy((org.jfree.data.time.RegularTimePeriod) month60, (org.jfree.data.time.RegularTimePeriod) month61);
        java.lang.String str64 = month60.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month60, (java.lang.Number) (short) 10);
        timeSeries53.add(timeSeriesDataItem66, true);
        boolean boolean69 = timeSeriesDataItem36.equals((java.lang.Object) timeSeriesDataItem66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeriesDataItem36.getPeriod();
        timeSeries11.add(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (short) 10 + "'", number49.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "June 2019" + "'", str62.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "June 2019" + "'", str64.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.lang.Class<?> wildcardClass6 = fixedMillisecond1.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        boolean boolean4 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries8.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.String str29 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries18.addAndOrUpdate(timeSeries26);
        boolean boolean32 = timeSeries8.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries36.removeChangeListener(seriesChangeListener37);
        java.lang.Comparable comparable39 = timeSeries36.getKey();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        java.lang.String str41 = month40.toString();
        java.lang.Number number42 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.lang.String str49 = month48.toString();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) month47, (org.jfree.data.time.RegularTimePeriod) month48);
        java.lang.String str51 = month47.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, (double) 100);
        timeSeries36.removeAgedItems(0L, false);
        timeSeries36.setNotify(false);
        java.util.Collection collection59 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries3.addAndOrUpdate(timeSeries36);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        java.lang.String str62 = month61.toString();
        java.lang.Object obj63 = null;
        boolean boolean64 = month61.equals(obj63);
        org.jfree.data.time.Year year65 = month61.getYear();
        int int66 = year65.getYear();
        long long67 = year65.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
        java.lang.String str74 = month73.toString();
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) month72, (org.jfree.data.time.RegularTimePeriod) month73);
        long long76 = timeSeries75.getMaximumItemAge();
        java.lang.String str77 = timeSeries75.getDescription();
        double double78 = timeSeries75.getMinY();
        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month();
        java.lang.String str80 = month79.toString();
        java.lang.Object obj81 = null;
        boolean boolean82 = month79.equals(obj81);
        org.jfree.data.time.Year year83 = month79.getYear();
        int int84 = timeSeries75.getIndex((org.jfree.data.time.RegularTimePeriod) year83);
        boolean boolean85 = year65.equals((java.lang.Object) timeSeries75);
        java.lang.Number number86 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year65);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 0.0d + "'", comparable39.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "June 2019" + "'", str41.equals("June 2019"));
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(collection59);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "June 2019" + "'", str62.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(year65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "June 2019" + "'", str74.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 9223372036854775807L + "'", long76 == 9223372036854775807L);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "June 2019" + "'", str80.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(year83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 100.0d + "'", number86.equals(100.0d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) 43626L);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        long long7 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        java.lang.Comparable comparable14 = timeSeries11.getKey();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        java.lang.Number number17 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.String str32 = month31.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries21.addAndOrUpdate(timeSeries29);
        timeSeries21.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries11.addAndOrUpdate(timeSeries21);
        java.util.List list38 = timeSeries21.getItems();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener39);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long45 = timeSeries44.getMaximumItemAge();
        int int46 = timeSeries44.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.lang.String str53 = month52.toString();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) month51, (org.jfree.data.time.RegularTimePeriod) month52);
        java.lang.String str55 = month51.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeriesDataItem57.getPeriod();
        java.util.Date date59 = regularTimePeriod58.getStart();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date59);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) month60, (java.lang.Number) 0, false);
        long long64 = month60.getFirstMillisecond();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) month60);
        int int66 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0d + "'", comparable14.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2147483647 + "'", int46 == 2147483647);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "June 2019" + "'", str55.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1559372400000L + "'", long64 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        try {
            timeSeries3.setMaximumItemAge((-61949116800001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int11 = fixedMillisecond9.compareTo((java.lang.Object) 9);
        long long12 = fixedMillisecond9.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        java.lang.String str15 = seriesException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException17.getSuppressed();
        int int21 = fixedMillisecond9.compareTo((java.lang.Object) timePeriodFormatException17);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond9.getMiddleMillisecond(calendar22);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 6, false);
        long long27 = fixedMillisecond9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str15.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 9);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        java.lang.String str6 = month5.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) month13);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        java.lang.String str23 = month22.toString();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) month22);
//        long long25 = timeSeries24.getMaximumItemAge();
//        java.lang.String str26 = timeSeries24.getDescription();
//        double double27 = timeSeries24.getMinY();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.String str29 = month28.toString();
//        java.lang.Object obj30 = null;
//        boolean boolean31 = month28.equals(obj30);
//        org.jfree.data.time.Year year32 = month28.getYear();
//        int int33 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        long long36 = day34.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.next();
//        timeSeries24.add(regularTimePeriod37, (double) 2019L);
//        int int40 = timeSeries16.getIndex(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43626L + "'", long36 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        java.util.Date date7 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(9223372036854775807L);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9999);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.String str9 = timeSeries7.getDescription();
        double double10 = timeSeries7.getMinY();
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = month16.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (short) 10);
        timeSeries7.add(timeSeriesDataItem22, true);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month4, (org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries3.setKey((java.lang.Comparable) 7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        java.lang.Object obj12 = null;
        boolean boolean13 = month10.equals(obj12);
        org.jfree.data.time.Year year14 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        timeSeries3.add(regularTimePeriod15, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "", "org.jfree.data.general.SeriesException: ");
        boolean boolean22 = timeSeries21.isEmpty();
        timeSeries21.fireSeriesChanged();
        timeSeries21.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.String str32 = month31.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) month31);
        java.lang.String str34 = month30.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (short) 10);
        int int38 = timeSeriesDataItem36.compareTo((java.lang.Object) 0L);
        timeSeriesDataItem36.setValue((java.lang.Number) 1560150000000L);
        timeSeries21.add(timeSeriesDataItem36);
        java.util.Collection collection42 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        java.lang.String str43 = timeSeries3.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0d, "", "");
        long long48 = timeSeries47.getMaximumItemAge();
        java.lang.Comparable comparable49 = timeSeries47.getKey();
        timeSeries47.setMaximumItemCount(4);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.lang.String str53 = month52.toString();
        long long54 = month52.getSerialIndex();
        java.util.Date date55 = month52.getStart();
        java.util.Date date56 = month52.getEnd();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) day57, (java.lang.Number) 0.0f, true);
        java.lang.Number number61 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day57);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 0.0d + "'", comparable49.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 24234L + "'", long54 == 24234L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + 0.0d + "'", number61.equals(0.0d));
    }
}

