import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        java.lang.Class<?> wildcardClass8 = obj7.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues8.getMaxMiddleIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        boolean boolean15 = timePeriodValues8.equals((java.lang.Object) year12);
        boolean boolean16 = timePeriodValues8.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int23 = day21.compareTo((java.lang.Object) 3);
        int int24 = day21.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.next();
        org.jfree.data.time.SerialDate serialDate26 = day21.getSerialDate();
        java.util.Date date27 = day21.getStart();
        timePeriodValues20.setKey((java.lang.Comparable) day21);
        java.lang.String str29 = timePeriodValues20.getDescription();
        boolean boolean30 = timePeriodValues8.equals((java.lang.Object) timePeriodValues20);
        int int31 = timePeriodValues8.getMaxEndIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year32, (double) (short) 100);
        boolean boolean36 = simpleTimePeriod2.equals((java.lang.Object) year32);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 100.0f);
        java.lang.Object obj7 = timePeriodValue6.clone();
        java.lang.Object obj8 = timePeriodValue6.clone();
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriod9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,10.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        int int3 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 9);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) 1.0f);
        int int9 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        boolean boolean12 = timePeriodValue5.equals((java.lang.Object) regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues5.getMaxMiddleIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        boolean boolean12 = timePeriodValues5.equals((java.lang.Object) year9);
        boolean boolean14 = year9.equals((java.lang.Object) (-1L));
        int int15 = year0.compareTo((java.lang.Object) year9);
        java.util.Calendar calendar16 = null;
        try {
            year9.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        int int9 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxEndIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        long long11 = simpleTimePeriod9.getEndMillis();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        boolean boolean14 = simpleTimePeriod9.equals((java.lang.Object) long13);
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod9);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
        int int19 = day16.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day16, 1.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        long long26 = year24.getFirstMillisecond();
        long long27 = year24.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues5.setNotify(true);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 3);
//        int int11 = day8.getYear();
//        int int12 = day8.getYear();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 5);
//        int int15 = timePeriodValues5.getMaxStartIndex();
//        boolean boolean16 = timePeriodValues5.getNotify();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 1.0f);
//        int int20 = day17.getDayOfMonth();
//        int int22 = day17.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) (byte) -1);
//        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue24.getPeriod();
//        java.lang.Number number26 = timePeriodValue24.getValue();
//        java.lang.String str27 = timePeriodValue24.toString();
//        timePeriodValues5.add(timePeriodValue24);
//        boolean boolean29 = year0.equals((java.lang.Object) timePeriodValues5);
//        timePeriodValues5.setNotify(false);
//        try {
//            timePeriodValues5.update((int) (short) -1, (java.lang.Number) (-1.0d));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(timePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0d) + "'", number26.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str27.equals("TimePeriodValue[13-June-2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj6 = timePeriodValues5.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener11);
        java.lang.Object obj13 = timePeriodValues5.clone();
        int int14 = timePeriodValues5.getMaxEndIndex();
        int int15 = timePeriodValues5.getItemCount();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) seriesException17);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray20 = seriesException17.getSuppressed();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        int int4 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setNotify(false);
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        java.lang.Object obj8 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 1.0f);
//        timePeriodValue11.setValue((java.lang.Number) 0);
//        java.lang.Object obj14 = timePeriodValue11.clone();
//        java.lang.String str15 = timePeriodValue11.toString();
//        timePeriodValues3.add(timePeriodValue11);
//        java.lang.Class<?> wildcardClass17 = timePeriodValues3.getClass();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,0]" + "'", str15.equals("TimePeriodValue[13-June-2019,0]"));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getLastMillisecond();
//        java.util.Date date41 = year39.getStart();
//        int int42 = day12.compareTo((java.lang.Object) year39);
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = day12.getLastMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(false);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxEndIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        long long11 = simpleTimePeriod9.getEndMillis();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        boolean boolean14 = simpleTimePeriod9.equals((java.lang.Object) long13);
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod9);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        int int6 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues3.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        timePeriodValues25.setDomainDescription("");
//        java.lang.String str41 = timePeriodValues25.getDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, (double) 1.0f);
//        int int45 = day42.getDayOfMonth();
//        int int47 = day42.compareTo((java.lang.Object) 1L);
//        int int48 = day42.getMonth();
//        timePeriodValues25.setKey((java.lang.Comparable) day42);
//        org.jfree.data.time.TimePeriod timePeriod50 = null;
//        try {
//            timePeriodValues25.add(timePeriod50, 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues9.setNotify(true);
//        int int12 = day0.compareTo((java.lang.Object) true);
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) '4');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (double) 1.0f);
//        timePeriodValue13.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
//        timePeriodValue13.setValue((java.lang.Number) 10.0d);
//        java.lang.String str19 = timePeriodValue13.toString();
//        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue13.getPeriod();
//        timePeriodValues8.add(timePeriodValue13);
//        boolean boolean22 = timePeriodValues8.isEmpty();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        java.util.Date date25 = year23.getStart();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
//        int int29 = day26.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day26.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day26.next();
//        java.util.Date date32 = day26.getEnd();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date25, date32);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) 1577865599999L);
//        java.util.Date date37 = simpleTimePeriod34.getEnd();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, (double) 1.0f);
//        int int41 = day38.getDayOfMonth();
//        int int43 = day38.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int46 = day44.compareTo((java.lang.Object) 3);
//        int int47 = day44.getYear();
//        java.lang.Class<?> wildcardClass48 = day44.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        int int50 = day38.compareTo((java.lang.Object) wildcardClass48);
//        long long51 = day38.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day38.next();
//        java.util.Date date53 = regularTimePeriod52.getEnd();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        long long56 = year55.getFirstMillisecond();
//        java.util.Date date57 = year55.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        long long60 = year59.getLastMillisecond();
//        java.util.Date date61 = year59.getStart();
//        java.lang.Object obj62 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass63 = obj62.getClass();
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day65, (double) 1.0f);
//        java.util.Date date68 = day65.getEnd();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date68, timeZone70);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date61, timeZone70);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date57, timeZone70);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date53, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date37, timeZone70);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date3, timeZone70);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timePeriod16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str19.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 13 + "'", int41 == 13);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560409200000L + "'", long51 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 1.0f);
//        int int8 = day5.getDayOfMonth();
//        int int10 = day5.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) (byte) -1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.String str14 = timePeriodValues3.getDescription();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(str14);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getItemCount();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) seriesException15);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues3.createCopy(0, 2);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int22 = day20.compareTo((java.lang.Object) 3);
        int int23 = day20.getYear();
        java.lang.Class<?> wildcardClass24 = day20.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.Date date30 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date30, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        java.util.Date date41 = year39.getStart();
        java.lang.Object obj42 = new java.lang.Object();
        java.lang.Class<?> wildcardClass43 = obj42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, (double) 1.0f);
        java.util.Date date48 = day45.getEnd();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date41, timeZone50);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date37, timeZone50);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date30, timeZone50);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day54, (double) 1.0f);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues6.setNotify(true);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int11 = day9.compareTo((java.lang.Object) 3);
        int int12 = day9.getYear();
        int int13 = day9.getYear();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date19 = simpleTimePeriod18.getStart();
        long long20 = simpleTimePeriod18.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 100.0f);
        timePeriodValues6.add(timePeriodValue22);
        java.lang.Object obj24 = timePeriodValue22.clone();
        int int25 = year0.compareTo(obj24);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1546329600000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        java.lang.Object obj7 = timePeriodValues6.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        timePeriodValue2.setValue((java.lang.Number) 0);
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue2.getPeriod();
        org.junit.Assert.assertNotNull(timePeriod5);
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(false);
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) 1.0f);
//        int int13 = day10.getDayOfMonth();
//        int int14 = day10.getDayOfMonth();
//        int int15 = year5.compareTo((java.lang.Object) int14);
//        long long16 = year5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year5.previous();
//        java.lang.String str19 = year5.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        java.lang.String str8 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(5, (int) (byte) 0);
        timePeriodValues8.setRangeDescription("31-December-1969");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        java.lang.Object obj5 = null;
        boolean boolean6 = year3.equals(obj5);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 1.0f);
//        int int8 = day5.getDayOfMonth();
//        int int10 = day5.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) (byte) -1);
//        timePeriodValues3.add(timePeriodValue12);
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue12.getPeriod();
//        java.lang.Number number15 = timePeriodValue12.getValue();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.0d) + "'", number15.equals((-1.0d)));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        int int8 = year6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) 0.0f);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int13 = day11.compareTo((java.lang.Object) 3);
        int int14 = day11.getYear();
        int int16 = day11.compareTo((java.lang.Object) "hi!");
        boolean boolean17 = year6.equals((java.lang.Object) int16);
        java.util.Date date18 = year6.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        boolean boolean5 = timePeriodValues3.getNotify();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        boolean boolean11 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int18 = day16.compareTo((java.lang.Object) 3);
        int int19 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.next();
        org.jfree.data.time.SerialDate serialDate21 = day16.getSerialDate();
        java.util.Date date22 = day16.getStart();
        timePeriodValues15.setKey((java.lang.Comparable) day16);
        java.lang.String str24 = timePeriodValues15.getDescription();
        boolean boolean25 = timePeriodValues3.equals((java.lang.Object) timePeriodValues15);
        int int26 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable27 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (byte) 10 + "'", comparable27.equals((byte) 10));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(5, (int) (byte) 0);
        timePeriodValues8.setRangeDescription("31-December-1969");
        timePeriodValues8.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(5, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        boolean boolean15 = simpleTimePeriod11.equals((java.lang.Object) seriesException13);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener22);
        int int24 = timePeriodValues21.getItemCount();
        timePeriodValues21.setNotify(false);
        int int27 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean28 = timePeriodValues21.getNotify();
        int int29 = timePeriodValues21.getItemCount();
        boolean boolean30 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues21);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener31);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.setNotify(true);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        int int10 = day6.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        boolean boolean14 = timePeriodValues3.getNotify();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (double) 1.0f);
//        int int18 = day15.getDayOfMonth();
//        int int20 = day15.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (double) (byte) -1);
//        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue22.getPeriod();
//        java.lang.Number number24 = timePeriodValue22.getValue();
//        java.lang.String str25 = timePeriodValue22.toString();
//        timePeriodValues3.add(timePeriodValue22);
//        timePeriodValue22.setValue((java.lang.Number) 12);
//        java.lang.String str29 = timePeriodValue22.toString();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timePeriod23);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str25.equals("TimePeriodValue[13-June-2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "TimePeriodValue[13-June-2019,12]" + "'", str29.equals("TimePeriodValue[13-June-2019,12]"));
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxEndIndex();
//        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        java.util.Date date11 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getLastMillisecond();
//        long long14 = year12.getFirstMillisecond();
//        long long15 = year12.getLastMillisecond();
//        int int16 = simpleTimePeriod9.compareTo((java.lang.Object) year12);
//        java.lang.Object obj17 = null;
//        int int18 = year12.compareTo(obj17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (double) 1.0f);
//        int int22 = day19.getDayOfMonth();
//        int int23 = day19.getDayOfMonth();
//        int int24 = day19.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.previous();
//        long long26 = day19.getSerialIndex();
//        int int27 = year12.compareTo((java.lang.Object) day19);
//        int int28 = day19.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timePeriodValues32.addPropertyChangeListener(propertyChangeListener33);
//        int int35 = timePeriodValues32.getMaxMiddleIndex();
//        boolean boolean36 = timePeriodValues32.isEmpty();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int39 = day37.compareTo((java.lang.Object) 3);
//        int int40 = day37.getYear();
//        java.lang.Class<?> wildcardClass41 = day37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day37.previous();
//        timePeriodValues32.add((org.jfree.data.time.TimePeriod) regularTimePeriod42, (java.lang.Number) 1560409200000L);
//        boolean boolean45 = day19.equals((java.lang.Object) timePeriodValues32);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getLastMillisecond();
//        java.util.Date date48 = year46.getStart();
//        int int49 = day19.compareTo((java.lang.Object) year46);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (double) (-1.0f));
//        java.util.Calendar calendar52 = null;
//        try {
//            long long53 = day19.getMiddleMillisecond(calendar52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int4, "org.jfree.data.general.SeriesChangeEvent[source=10]", "org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[13-June-2019,-1.0]]");
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) 1.0f);
//        timePeriodValue8.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
//        timePeriodValue8.setValue((java.lang.Number) 10.0d);
//        java.lang.String str14 = timePeriodValue8.toString();
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue8.getPeriod();
//        timePeriodValues3.add(timePeriodValue8);
//        boolean boolean17 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getFirstMillisecond();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (double) 1.0f);
//        int int24 = day21.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.next();
//        java.util.Date date27 = day21.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (double) 1577865599999L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener32);
//        org.junit.Assert.assertNotNull(timePeriod11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str14.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        int int22 = day12.getMonth();
//        java.util.Calendar calendar23 = null;
//        try {
//            day12.peg(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        int int6 = timePeriodValues3.getItemCount();
        java.lang.Number number8 = null;
        try {
            timePeriodValues3.update(0, number8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        java.lang.Class<?> wildcardClass5 = day0.getClass();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        timePeriodValues25.setDomainDescription("");
//        java.lang.String str41 = timePeriodValues25.getDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, (double) 1.0f);
//        int int45 = day42.getDayOfMonth();
//        int int47 = day42.compareTo((java.lang.Object) 1L);
//        int int48 = day42.getMonth();
//        timePeriodValues25.setKey((java.lang.Comparable) day42);
//        timePeriodValues25.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[13-June-2019,-1.0]]");
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Date date6 = day0.getStart();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getLastMillisecond();
//        java.lang.Class<?> wildcardClass9 = day7.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) 1.0f);
//        int int13 = day10.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
//        java.util.Date date16 = day10.getEnd();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 3);
//        int int21 = day18.getYear();
//        java.lang.Class<?> wildcardClass22 = day18.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date27 = simpleTimePeriod26.getStart();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date28, timeZone29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date28, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date16, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getFirstMillisecond();
//        java.util.Date date36 = year34.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getLastMillisecond();
//        java.util.Date date40 = year38.getStart();
//        java.lang.Object obj41 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass42 = obj41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day44, (double) 1.0f);
//        java.util.Date date47 = day44.getEnd();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date47, timeZone49);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date40, timeZone49);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date36, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date16, timeZone49);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date6, timeZone49);
//        long long55 = year54.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        java.lang.Object obj7 = null;
        int int8 = year0.compareTo(obj7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        long long13 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        int int17 = timePeriodValues16.getMinEndIndex();
//        try {
//            timePeriodValues16.update(8, (java.lang.Number) 1560538799999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) (byte) 100);
//        int int6 = day0.getDayOfMonth();
//        java.lang.String str7 = day0.toString();
//        int int8 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) long6);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        boolean boolean5 = year0.equals((java.lang.Object) year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getLastMillisecond();
        java.util.Date date4 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getItemCount();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) seriesException15);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues3.createCopy(0, 2);
        java.lang.String str20 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date7 = simpleTimePeriod6.getStart();
//        java.util.Date date8 = simpleTimePeriod6.getStart();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getLastMillisecond();
//        long long11 = year9.getFirstMillisecond();
//        long long12 = year9.getLastMillisecond();
//        int int13 = simpleTimePeriod6.compareTo((java.lang.Object) year9);
//        java.lang.Object obj14 = null;
//        int int15 = year9.compareTo(obj14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
//        int int19 = day16.getDayOfMonth();
//        int int20 = day16.getDayOfMonth();
//        int int21 = day16.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.previous();
//        long long23 = day16.getSerialIndex();
//        int int24 = year9.compareTo((java.lang.Object) day16);
//        int int25 = day16.getDayOfMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day16, (double) (byte) 0);
//        timePeriodValues1.delete((int) (short) 100, (int) (byte) -1);
//        int int31 = timePeriodValues1.getMaxStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener32);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues8.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int13 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        int int21 = year19.getYear();
        long long22 = year19.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 10.0d);
        long long25 = year19.getFirstMillisecond();
        int int26 = year19.getYear();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        timePeriodValue2.setValue((java.lang.Number) 0);
//        java.lang.Number number5 = timePeriodValue2.getValue();
//        java.lang.String str6 = timePeriodValue2.toString();
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,0]" + "'", str6.equals("TimePeriodValue[13-June-2019,0]"));
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        int int2 = year0.getYear();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
//        int int6 = day3.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
//        java.util.Date date9 = day3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day3.previous();
//        int int11 = year0.compareTo((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int17 = day12.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 3);
//        int int21 = day18.getYear();
//        java.lang.Class<?> wildcardClass22 = day18.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        int int24 = day12.compareTo((java.lang.Object) wildcardClass22);
//        long long25 = day12.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day12.next();
//        boolean boolean27 = year0.equals((java.lang.Object) regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) (byte) 100);
//        int int6 = day0.getDayOfMonth();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 3);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        int int21 = year19.getYear();
//        long long22 = year19.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 10.0d);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getLastMillisecond();
//        java.lang.Class<?> wildcardClass27 = day25.getClass();
//        timePeriodValues3.setKey((java.lang.Comparable) day25);
//        java.util.Calendar calendar29 = null;
//        try {
//            long long30 = day25.getMiddleMillisecond(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6, "TimePeriodValue[13-June-2019,1.560495599999E12]", "org.jfree.data.general.SeriesChangeEvent[source=10]");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
        java.util.Date date6 = day0.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj12 = timePeriodValues11.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener15);
        java.lang.Comparable comparable17 = timePeriodValues11.getKey();
        java.lang.Object obj18 = timePeriodValues11.clone();
        int int19 = year7.compareTo((java.lang.Object) timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (byte) 10 + "'", comparable17.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues9.setNotify(true);
//        int int12 = day0.compareTo((java.lang.Object) true);
//        long long13 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 1.0f);
        java.util.Date date7 = day4.getEnd();
        boolean boolean8 = year0.equals((java.lang.Object) day4);
        long long9 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
        int int6 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
        java.util.Date date9 = day3.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        boolean boolean9 = timePeriodValue7.equals((java.lang.Object) 5);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date13 = simpleTimePeriod12.getStart();
//        java.util.Date date14 = simpleTimePeriod12.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        long long17 = year15.getFirstMillisecond();
//        long long18 = year15.getLastMillisecond();
//        int int19 = simpleTimePeriod12.compareTo((java.lang.Object) year15);
//        java.lang.Object obj20 = null;
//        int int21 = year15.compareTo(obj20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) 1.0f);
//        int int25 = day22.getDayOfMonth();
//        int int26 = day22.getDayOfMonth();
//        int int27 = day22.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day22.previous();
//        long long29 = day22.getSerialIndex();
//        int int30 = year15.compareTo((java.lang.Object) day22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year15.next();
//        boolean boolean32 = timePeriodValue7.equals((java.lang.Object) regularTimePeriod31);
//        java.lang.Number number33 = timePeriodValue7.getValue();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues3.getMinMiddleIndex();
        int int12 = timePeriodValues3.getMinStartIndex();
        int int13 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 1, (long) (short) 100);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.lang.Class<?> wildcardClass4 = simpleTimePeriod2.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues8.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int13 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date16 = simpleTimePeriod15.getStart();
        long long17 = simpleTimePeriod15.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (double) 100.0f);
        timePeriodValues3.add(timePeriodValue19);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        java.lang.Object obj8 = timePeriodValue7.clone();
//        timePeriodValue7.setValue((java.lang.Number) (short) 100);
//        java.lang.Object obj11 = timePeriodValue7.clone();
//        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue7.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue7.getPeriod();
//        java.lang.Number number14 = timePeriodValue7.getValue();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(timePeriod12);
//        org.junit.Assert.assertNotNull(timePeriod13);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        timePeriodValues3.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 100.0f);
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int14 = day12.compareTo((java.lang.Object) 3);
        int int15 = day12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.next();
        org.jfree.data.time.SerialDate serialDate17 = day12.getSerialDate();
        java.util.Date date18 = day12.getStart();
        timePeriodValues11.setKey((java.lang.Comparable) day12);
        java.lang.String str20 = timePeriodValues11.getDescription();
        timePeriodValues11.setDomainDescription("TimePeriodValue[13-June-2019,-1.0]");
        timePeriodValues11.setRangeDescription("");
        timePeriodValues11.setRangeDescription("31-December-1969");
        try {
            int int27 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=false]", "org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]");
        java.lang.Comparable comparable7 = timePeriodValues6.getKey();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(comparable7);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 1.0f);
//        int int7 = day4.getDayOfMonth();
//        int int9 = day4.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) (byte) -1);
//        java.lang.Object obj12 = timePeriodValue11.clone();
//        java.lang.Object obj13 = timePeriodValue11.clone();
//        boolean boolean14 = day0.equals(obj13);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        timePeriodValues25.setDomainDescription("");
//        java.lang.String str41 = timePeriodValues25.getDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timePeriodValues25.addChangeListener(seriesChangeListener42);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str41);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
        java.util.Date date6 = day0.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 1.0f);
        int int12 = day9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day9.next();
        java.util.Date date15 = day9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date6, date15);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getFirstMillisecond();
        java.util.Date date17 = year15.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        java.lang.Object obj22 = new java.lang.Object();
        java.lang.Class<?> wildcardClass23 = obj22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (double) 1.0f);
        java.util.Date date28 = day25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date21, timeZone30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date17, timeZone30);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date10, timeZone30);
        java.lang.String str35 = day34.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day34.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        long long13 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        int int17 = timePeriodValues16.getMinEndIndex();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 3);
//        int int21 = day18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
//        org.jfree.data.time.SerialDate serialDate23 = day18.getSerialDate();
//        java.util.Date date24 = day18.getStart();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getLastMillisecond();
//        java.lang.Class<?> wildcardClass27 = day25.getClass();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (double) 1.0f);
//        int int31 = day28.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day28.next();
//        java.util.Date date34 = day28.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int38 = day36.compareTo((java.lang.Object) 3);
//        int int39 = day36.getYear();
//        java.lang.Class<?> wildcardClass40 = day36.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date45 = simpleTimePeriod44.getStart();
//        java.util.Date date46 = simpleTimePeriod44.getStart();
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46, timeZone49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date34, timeZone49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getFirstMillisecond();
//        java.util.Date date54 = year52.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        long long57 = year56.getLastMillisecond();
//        java.util.Date date58 = year56.getStart();
//        java.lang.Object obj59 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass60 = obj59.getClass();
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day62, (double) 1.0f);
//        java.util.Date date65 = day62.getEnd();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date65, timeZone67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date58, timeZone67);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date54, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date34, timeZone67);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date24, timeZone67);
//        boolean boolean73 = timePeriodValues16.equals((java.lang.Object) timeZone67);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue75 = timePeriodValues16.getDataItem((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("2019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date14 = simpleTimePeriod13.getStart();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        long long18 = year16.getFirstMillisecond();
        long long19 = year16.getLastMillisecond();
        int int20 = simpleTimePeriod13.compareTo((java.lang.Object) year16);
        long long21 = simpleTimePeriod13.getStartMillis();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 1.0d);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (double) 1.0f);
        int int27 = day24.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day24.next();
        boolean boolean30 = simpleTimePeriod13.equals((java.lang.Object) regularTimePeriod29);
        java.util.Date date31 = simpleTimePeriod13.getStart();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 10 + "'", comparable8.equals((byte) 10));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int4 = year3.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(class4);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        timePeriodValue2.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue2.getPeriod();
//        timePeriodValue2.setValue((java.lang.Number) 10.0d);
//        java.lang.String str8 = timePeriodValue2.toString();
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue2.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue2.getPeriod();
//        java.lang.String str11 = timePeriodValue2.toString();
//        org.junit.Assert.assertNotNull(timePeriod5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str8.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertNotNull(timePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str11.equals("TimePeriodValue[13-June-2019,10.0]"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        int int7 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(4, (int) (byte) -1);
        boolean boolean11 = timePeriodValues10.getNotify();
        int int12 = timePeriodValues10.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        int int10 = day8.compareTo((java.lang.Object) 3);
        int int11 = day8.getYear();
        java.lang.Class<?> wildcardClass12 = day8.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (java.lang.Number) 1560409200000L);
        java.lang.String str16 = timePeriodValues3.getRangeDescription();
        int int17 = timePeriodValues3.getItemCount();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        int int3 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
        java.util.Date date6 = day0.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        int int10 = day8.compareTo((java.lang.Object) 3);
        int int11 = day8.getYear();
        java.lang.Class<?> wildcardClass12 = day8.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date6, timeZone21);
        int int24 = day23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        java.util.Date date26 = regularTimePeriod25.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        int int9 = day0.getMonth();
//        java.lang.String str10 = day0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("2019");
//        int int13 = day0.compareTo((java.lang.Object) "2019");
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 1.0f);
//        int int8 = day5.getDayOfMonth();
//        int int10 = day5.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues14.setNotify(true);
//        int int17 = day5.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (short) 10);
//        timePeriodValues3.add(timePeriodValue19);
//        timePeriodValue19.setValue((java.lang.Number) 1560538799999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) (byte) 100);
//        int int6 = day0.getDayOfMonth();
//        long long7 = day0.getFirstMillisecond();
//        int int8 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        java.util.Calendar calendar11 = null;
//        try {
//            day8.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10]");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        boolean boolean11 = timePeriodValues3.getNotify();
        timePeriodValues3.setNotify(false);
        int int14 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues3.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        int int7 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(4, (int) (byte) -1);
        java.lang.Comparable comparable11 = timePeriodValues10.getKey();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 10 + "'", comparable11.equals((byte) 10));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues8.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int13 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        java.lang.Class<?> wildcardClass5 = day0.getClass();
        java.util.Date date6 = day0.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, 1577865599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener7);
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        java.util.Date date10 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj6 = timePeriodValues5.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener11);
        java.lang.Object obj13 = timePeriodValues5.clone();
        int int14 = timePeriodValues5.getMaxEndIndex();
        int int15 = timePeriodValues5.getItemCount();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        boolean boolean18 = timePeriodValues5.equals((java.lang.Object) seriesException17);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray20 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 10);
        java.lang.String str8 = timePeriodValues7.getRangeDescription();
        int int9 = timePeriodValues7.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues8.setNotify(true);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int13 = day11.compareTo((java.lang.Object) 3);
        int int14 = day11.getYear();
        int int15 = day11.getYear();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date21 = simpleTimePeriod20.getStart();
        long long22 = simpleTimePeriod20.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) 100.0f);
        timePeriodValues8.add(timePeriodValue24);
        java.lang.Object obj26 = timePeriodValue24.clone();
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue24.getPeriod();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(timePeriod28);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        boolean boolean5 = year0.equals((java.lang.Object) regularTimePeriod4);
        long long6 = regularTimePeriod4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5, "TimePeriodValue[13-June-2019,-1.0]", "TimePeriodValue[13-June-2019,12]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        timePeriodValues25.setDomainDescription("");
//        java.lang.String str41 = timePeriodValues25.getDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, (double) 1.0f);
//        int int45 = day42.getDayOfMonth();
//        int int47 = day42.compareTo((java.lang.Object) 1L);
//        int int48 = day42.getMonth();
//        timePeriodValues25.setKey((java.lang.Comparable) day42);
//        int int50 = day42.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 13 + "'", int50 == 13);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        try {
            int int6 = simpleTimePeriod2.compareTo(obj5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxEndIndex();
//        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        java.util.Date date11 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getLastMillisecond();
//        long long14 = year12.getFirstMillisecond();
//        long long15 = year12.getLastMillisecond();
//        int int16 = simpleTimePeriod9.compareTo((java.lang.Object) year12);
//        java.lang.Object obj17 = null;
//        int int18 = year12.compareTo(obj17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (double) 1.0f);
//        int int22 = day19.getDayOfMonth();
//        int int23 = day19.getDayOfMonth();
//        int int24 = day19.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.previous();
//        long long26 = day19.getSerialIndex();
//        int int27 = year12.compareTo((java.lang.Object) day19);
//        int int28 = day19.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timePeriodValues32.addPropertyChangeListener(propertyChangeListener33);
//        int int35 = timePeriodValues32.getMaxMiddleIndex();
//        boolean boolean36 = timePeriodValues32.isEmpty();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int39 = day37.compareTo((java.lang.Object) 3);
//        int int40 = day37.getYear();
//        java.lang.Class<?> wildcardClass41 = day37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day37.previous();
//        timePeriodValues32.add((org.jfree.data.time.TimePeriod) regularTimePeriod42, (java.lang.Number) 1560409200000L);
//        boolean boolean45 = day19.equals((java.lang.Object) timePeriodValues32);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getLastMillisecond();
//        java.util.Date date48 = year46.getStart();
//        int int49 = day19.compareTo((java.lang.Object) year46);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (double) (-1.0f));
//        java.util.Calendar calendar52 = null;
//        try {
//            long long53 = day19.getFirstMillisecond(calendar52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        timePeriodValues25.setDomainDescription("");
//        java.lang.String str41 = timePeriodValues25.getDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, (double) 1.0f);
//        int int45 = day42.getDayOfMonth();
//        int int47 = day42.compareTo((java.lang.Object) 1L);
//        int int48 = day42.getMonth();
//        timePeriodValues25.setKey((java.lang.Comparable) day42);
//        java.lang.Object obj50 = timePeriodValues25.clone();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(obj50);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        timePeriodValues3.delete(12, 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        long long9 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMinStartIndex();
        java.lang.Object obj7 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        try {
            timePeriodValues1.add(timePeriod5, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,9]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.lang.Object obj7 = new java.lang.Object();
        java.lang.Class<?> wildcardClass8 = obj7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) 1.0f);
        java.util.Date date13 = day10.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date13, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date6, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date2, timeZone15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        int int6 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date10 = simpleTimePeriod9.getStart();
//        java.util.Date date11 = simpleTimePeriod9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getLastMillisecond();
//        long long14 = year12.getFirstMillisecond();
//        long long15 = year12.getLastMillisecond();
//        int int16 = simpleTimePeriod9.compareTo((java.lang.Object) year12);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 1.0f);
//        int int20 = day17.getDayOfMonth();
//        int int21 = day17.getDayOfMonth();
//        int int22 = year12.compareTo((java.lang.Object) int21);
//        long long23 = year12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year12.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = timePeriodValues3.getDataItem(0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(timePeriodValue29);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        java.lang.Object obj0 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass1 = obj0.getClass();
//        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
//        java.util.Date date6 = day3.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date13 = simpleTimePeriod12.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (double) 1.0f);
//        int int17 = day14.getDayOfMonth();
//        int int19 = day14.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int22 = day20.compareTo((java.lang.Object) 3);
//        int int23 = day20.getYear();
//        java.lang.Class<?> wildcardClass24 = day20.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        int int26 = day14.compareTo((java.lang.Object) wildcardClass24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 3);
//        int int30 = day27.getYear();
//        java.lang.Class<?> wildcardClass31 = day27.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day27.next();
//        java.util.Date date33 = day27.getStart();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (double) 1.0f);
//        int int38 = day35.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day35.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day35.next();
//        java.util.Date date41 = day35.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int45 = day43.compareTo((java.lang.Object) 3);
//        int int46 = day43.getYear();
//        java.lang.Class<?> wildcardClass47 = day43.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date52 = simpleTimePeriod51.getStart();
//        java.util.Date date53 = simpleTimePeriod51.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date53, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date41, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date13, timeZone56);
//        java.util.Calendar calendar61 = null;
//        try {
//            long long62 = regularTimePeriod60.getMiddleMillisecond(calendar61);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getFirstMillisecond();
        java.util.Date date17 = year15.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        java.lang.Object obj22 = new java.lang.Object();
        java.lang.Class<?> wildcardClass23 = obj22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (double) 1.0f);
        java.util.Date date28 = day25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date21, timeZone30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date17, timeZone30);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date10, timeZone30);
        org.jfree.data.time.SerialDate serialDate35 = day34.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, 1577865599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timePeriodValues42.removeChangeListener(seriesChangeListener43);
        boolean boolean45 = simpleTimePeriod38.equals((java.lang.Object) timePeriodValues42);
        boolean boolean46 = day34.equals((java.lang.Object) timePeriodValues42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        int int8 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1969);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[13-June-2019,-1.0]]");
        int int9 = timePeriodValues3.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate5);
//        java.lang.Comparable comparable7 = timePeriodValues6.getKey();
//        java.lang.Comparable comparable8 = timePeriodValues6.getKey();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertNotNull(comparable8);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        long long39 = day12.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12, "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,10.0]", "1969");
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43629L + "'", long39 == 43629L);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int6 = day4.compareTo((java.lang.Object) 3);
        int int7 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.next();
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        java.util.Date date10 = day4.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) day4);
        java.lang.String str12 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,-1.0]");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getFirstMillisecond();
        java.util.Date date17 = year15.getStart();
        long long18 = year15.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year15);
        timePeriodValues3.setKey((java.lang.Comparable) year15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = day0.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 3);
//        int int11 = day8.getYear();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date17 = simpleTimePeriod16.getStart();
//        java.util.Date date18 = simpleTimePeriod16.getStart();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date6, timeZone21);
//        int int24 = day23.getYear();
//        long long25 = day23.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) (byte) 100);
//        int int6 = day0.getDayOfMonth();
//        long long7 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        boolean boolean11 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int18 = day16.compareTo((java.lang.Object) 3);
        int int19 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.next();
        org.jfree.data.time.SerialDate serialDate21 = day16.getSerialDate();
        java.util.Date date22 = day16.getStart();
        timePeriodValues15.setKey((java.lang.Comparable) day16);
        java.lang.String str24 = timePeriodValues15.getDescription();
        boolean boolean25 = timePeriodValues3.equals((java.lang.Object) timePeriodValues15);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[13-June-2019,-1.0]]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int6 = day4.compareTo((java.lang.Object) 3);
//        int int7 = day4.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.next();
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.util.Date date10 = day4.getStart();
//        timePeriodValues3.setKey((java.lang.Comparable) day4);
//        long long12 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day4.previous();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        java.lang.Object obj8 = timePeriodValue7.clone();
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue7.getPeriod();
//        java.lang.Object obj10 = timePeriodValue7.clone();
//        timePeriodValue7.setValue((java.lang.Number) 1546329600000L);
//        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue7.getPeriod();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(timePeriod13);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.fireSeriesChanged();
        int int9 = timePeriodValues3.getItemCount();
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        int int11 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (byte) 10 + "'", comparable10.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date7 = simpleTimePeriod6.getStart();
//        java.util.Date date8 = simpleTimePeriod6.getStart();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getLastMillisecond();
//        long long11 = year9.getFirstMillisecond();
//        long long12 = year9.getLastMillisecond();
//        int int13 = simpleTimePeriod6.compareTo((java.lang.Object) year9);
//        java.lang.Object obj14 = null;
//        int int15 = year9.compareTo(obj14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
//        int int19 = day16.getDayOfMonth();
//        int int20 = day16.getDayOfMonth();
//        int int21 = day16.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.previous();
//        long long23 = day16.getSerialIndex();
//        int int24 = year9.compareTo((java.lang.Object) day16);
//        int int25 = day16.getDayOfMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day16, (double) (byte) 0);
//        timePeriodValues1.delete((int) (short) 100, (int) (byte) -1);
//        int int31 = timePeriodValues1.getMaxStartIndex();
//        int int32 = timePeriodValues1.getMinStartIndex();
//        int int33 = timePeriodValues1.getMaxStartIndex();
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        int int5 = year3.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        boolean boolean8 = year3.equals((java.lang.Object) regularTimePeriod7);
        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod7);
        long long10 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getFirstMillisecond();
        java.util.Date date17 = year15.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        java.lang.Object obj22 = new java.lang.Object();
        java.lang.Class<?> wildcardClass23 = obj22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (double) 1.0f);
        java.util.Date date28 = day25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date21, timeZone30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date17, timeZone30);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date10, timeZone30);
        org.jfree.data.time.SerialDate serialDate35 = day34.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day34.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) (byte) 100);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        int int4 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setNotify(false);
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        java.lang.Object obj8 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 1.0f);
//        timePeriodValue11.setValue((java.lang.Number) 0);
//        java.lang.Object obj14 = timePeriodValue11.clone();
//        java.lang.String str15 = timePeriodValue11.toString();
//        timePeriodValues3.add(timePeriodValue11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues20.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues20.addPropertyChangeListener(propertyChangeListener23);
//        int int25 = timePeriodValues20.getMaxStartIndex();
//        boolean boolean26 = timePeriodValue11.equals((java.lang.Object) int25);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,0]" + "'", str15.equals("TimePeriodValue[13-June-2019,0]"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        java.lang.Object obj0 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass1 = obj0.getClass();
//        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
//        java.util.Date date6 = day3.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date13 = simpleTimePeriod12.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (double) 1.0f);
//        int int17 = day14.getDayOfMonth();
//        int int19 = day14.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int22 = day20.compareTo((java.lang.Object) 3);
//        int int23 = day20.getYear();
//        java.lang.Class<?> wildcardClass24 = day20.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        int int26 = day14.compareTo((java.lang.Object) wildcardClass24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 3);
//        int int30 = day27.getYear();
//        java.lang.Class<?> wildcardClass31 = day27.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day27.next();
//        java.util.Date date33 = day27.getStart();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (double) 1.0f);
//        int int38 = day35.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day35.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day35.next();
//        java.util.Date date41 = day35.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int45 = day43.compareTo((java.lang.Object) 3);
//        int int46 = day43.getYear();
//        java.lang.Class<?> wildcardClass47 = day43.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date52 = simpleTimePeriod51.getStart();
//        java.util.Date date53 = simpleTimePeriod51.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date53, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date41, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date13, timeZone56);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        long long62 = year61.getFirstMillisecond();
//        java.util.Date date63 = year61.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(date13, date63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int67 = day65.compareTo((java.lang.Object) 3);
//        int int68 = day65.getYear();
//        java.lang.Class<?> wildcardClass69 = day65.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date74 = simpleTimePeriod73.getStart();
//        java.util.Date date75 = simpleTimePeriod73.getStart();
//        java.util.TimeZone timeZone76 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date75, timeZone76);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date75, timeZone78);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod(date13, date75);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(timeZone78);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        int int4 = year0.getYear();
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
//        int int10 = day7.getMonth();
//        long long11 = day7.getLastMillisecond();
//        java.lang.String str12 = day7.toString();
//        long long13 = day7.getLastMillisecond();
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day7, (double) (short) 10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = timePeriodValues25.getMaxMiddleIndex();
//        boolean boolean29 = timePeriodValues25.isEmpty();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 3);
//        int int33 = day30.getYear();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) 1560409200000L);
//        boolean boolean38 = day12.equals((java.lang.Object) timePeriodValues25);
//        timePeriodValues25.setDomainDescription("");
//        java.lang.String str41 = timePeriodValues25.getDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, (double) 1.0f);
//        int int45 = day42.getDayOfMonth();
//        int int47 = day42.compareTo((java.lang.Object) 1L);
//        int int48 = day42.getMonth();
//        timePeriodValues25.setKey((java.lang.Comparable) day42);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        long long51 = year50.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.next();
//        java.util.Date date53 = regularTimePeriod52.getEnd();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod52, 0.0d);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timePeriodValues25.addChangeListener(seriesChangeListener56);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
//        java.lang.Number number9 = timePeriodValue7.getValue();
//        java.lang.String str10 = timePeriodValue7.toString();
//        timePeriodValue7.setValue((java.lang.Number) (byte) -1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(timePeriod8);
//        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str10.equals("TimePeriodValue[13-June-2019,-1.0]"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        java.lang.Object obj5 = null;
        boolean boolean6 = year3.equals(obj5);
        long long7 = year3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int6 = day4.compareTo((java.lang.Object) 3);
        int int7 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.next();
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        java.util.Date date10 = day4.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) day4);
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,-1.0]");
        java.lang.Object obj14 = null;
        boolean boolean15 = timePeriodValues3.equals(obj14);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        int int5 = day0.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) 1.0f);
//        timePeriodValue8.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
//        timePeriodValue8.setValue((java.lang.Number) 10.0d);
//        java.lang.String str14 = timePeriodValue8.toString();
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue8.getPeriod();
//        timePeriodValues3.add(timePeriodValue8);
//        boolean boolean17 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getFirstMillisecond();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (double) 1.0f);
//        int int24 = day21.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.next();
//        java.util.Date date27 = day21.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (double) 1577865599999L);
//        long long32 = simpleTimePeriod29.getEndMillis();
//        java.util.Date date33 = simpleTimePeriod29.getStart();
//        java.util.Date date34 = simpleTimePeriod29.getEnd();
//        java.lang.Object obj35 = null;
//        try {
//            int int36 = simpleTimePeriod29.compareTo(obj35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriod11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str14.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
        int int6 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
        java.util.Date date9 = day3.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 1.0f);
        int int7 = day4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
        java.util.Date date10 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day4.previous();
        int int12 = year0.compareTo((java.lang.Object) day4);
        long long13 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        timePeriodValue2.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue2.getPeriod();
//        timePeriodValue2.setValue((java.lang.Number) 10.0d);
//        java.lang.String str8 = timePeriodValue2.toString();
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue2.getPeriod();
//        java.lang.Number number10 = timePeriodValue2.getValue();
//        java.lang.Object obj11 = timePeriodValue2.clone();
//        org.junit.Assert.assertNotNull(timePeriod5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str8.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0d + "'", number10.equals(10.0d));
//        org.junit.Assert.assertNotNull(obj11);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
        java.util.Date date6 = day3.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6);
        java.lang.Class<?> wildcardClass13 = date6.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        java.util.Date date11 = year7.getStart();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year7.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = day0.getStart();
//        long long7 = day0.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        java.util.Date date22 = year20.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.lang.String str24 = year23.toString();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int27 = day25.compareTo((java.lang.Object) 3);
        int int28 = day25.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day25.next();
        org.jfree.data.time.SerialDate serialDate30 = day25.getSerialDate();
        int int31 = day25.getYear();
        int int32 = year23.compareTo((java.lang.Object) day25);
        boolean boolean33 = timePeriodValues3.equals((java.lang.Object) year23);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 0, 100);
        timePeriodValues9.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=false]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int7 = day5.compareTo((java.lang.Object) 3);
        int int8 = day5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (-1));
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int14 = day12.compareTo((java.lang.Object) 3);
        int int16 = day12.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod17, (java.lang.Number) (byte) 10);
        int int20 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str21 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getFirstMillisecond();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
//        int int6 = day3.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
//        java.util.Date date9 = day3.getEnd();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 3);
//        int int16 = day12.compareTo((java.lang.Object) 13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
//        long long18 = regularTimePeriod17.getMiddleMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod17);
//        java.lang.String str20 = seriesChangeEvent19.toString();
//        boolean boolean21 = simpleTimePeriod11.equals((java.lang.Object) seriesChangeEvent19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int24 = day22.compareTo((java.lang.Object) 3);
//        int int25 = day22.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.next();
//        org.jfree.data.time.SerialDate serialDate27 = day22.getSerialDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        int int29 = simpleTimePeriod11.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (double) 1.0f);
//        java.util.Date date33 = day30.getEnd();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        long long35 = day34.getSerialIndex();
//        boolean boolean36 = simpleTimePeriod11.equals((java.lang.Object) day34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date40 = simpleTimePeriod39.getStart();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int43 = day41.compareTo((java.lang.Object) 3);
//        int int44 = day41.getYear();
//        java.lang.Class<?> wildcardClass45 = day41.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day41.next();
//        java.util.Date date47 = day41.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date40, date47);
//        boolean boolean49 = simpleTimePeriod11.equals((java.lang.Object) date47);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560538799999L + "'", long18 == 1560538799999L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43629L + "'", long35 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int14 = day10.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod15);
        java.lang.String str17 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues3.createCopy((int) '#', 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(timePeriodValues20);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues5.setNotify(true);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 3);
//        int int11 = day8.getYear();
//        int int12 = day8.getYear();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 5);
//        int int15 = timePeriodValues5.getMaxStartIndex();
//        boolean boolean16 = timePeriodValues5.getNotify();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 1.0f);
//        int int20 = day17.getDayOfMonth();
//        int int22 = day17.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) (byte) -1);
//        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue24.getPeriod();
//        java.lang.Number number26 = timePeriodValue24.getValue();
//        java.lang.String str27 = timePeriodValue24.toString();
//        timePeriodValues5.add(timePeriodValue24);
//        boolean boolean29 = year0.equals((java.lang.Object) timePeriodValues5);
//        java.util.Date date30 = year0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(timePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0d) + "'", number26.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str27.equals("TimePeriodValue[13-June-2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=13]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int15 = day13.compareTo((java.lang.Object) 3);
        int int16 = day13.getYear();
        java.lang.Class<?> wildcardClass17 = day13.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) (short) 100);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) 10L);
        boolean boolean23 = timePeriodValues3.getNotify();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMinStartIndex();
        int int7 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number9 = timePeriodValues3.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) 1.0f);
//        timePeriodValue8.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
//        timePeriodValue8.setValue((java.lang.Number) 10.0d);
//        java.lang.String str14 = timePeriodValue8.toString();
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue8.getPeriod();
//        timePeriodValues3.add(timePeriodValue8);
//        boolean boolean17 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getFirstMillisecond();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (double) 1.0f);
//        int int24 = day21.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.next();
//        java.util.Date date27 = day21.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date20, date27);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, (double) 1577865599999L);
//        long long32 = simpleTimePeriod29.getEndMillis();
//        java.util.Date date33 = simpleTimePeriod29.getStart();
//        java.util.Date date34 = simpleTimePeriod29.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (double) 1.0f);
//        int int38 = day35.getDayOfMonth();
//        int int40 = day35.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (double) (byte) -1);
//        boolean boolean44 = timePeriodValue42.equals((java.lang.Object) 5);
//        java.lang.Object obj45 = timePeriodValue42.clone();
//        boolean boolean46 = simpleTimePeriod29.equals(obj45);
//        org.junit.Assert.assertNotNull(timePeriod11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str14.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(obj45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        int int13 = year11.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        boolean boolean16 = year11.equals((java.lang.Object) regularTimePeriod15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        int int31 = year11.compareTo((java.lang.Object) timePeriodFormatException24);
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        int int13 = timePeriodValues3.getMaxStartIndex();
        boolean boolean14 = timePeriodValues3.getNotify();
        int int15 = timePeriodValues3.getMaxStartIndex();
        int int16 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        int int4 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int13 = day11.compareTo((java.lang.Object) 3);
//        int int14 = day11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.next();
//        org.jfree.data.time.SerialDate serialDate16 = day11.getSerialDate();
//        java.util.Date date17 = day11.getStart();
//        timePeriodValues10.setKey((java.lang.Comparable) day11);
//        long long19 = day11.getFirstMillisecond();
//        int int20 = day11.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (short) 0);
//        java.util.Date date23 = day11.getEnd();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date23);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date16 = simpleTimePeriod15.getStart();
        long long17 = simpleTimePeriod15.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (double) 100.0f);
        timePeriodValues3.add(timePeriodValue19);
        boolean boolean21 = timePeriodValues3.isEmpty();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        boolean boolean9 = timePeriodValue7.equals((java.lang.Object) 5);
//        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue7.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue7.getPeriod();
//        java.lang.Number number12 = timePeriodValue7.getValue();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(timePeriod10);
//        org.junit.Assert.assertNotNull(timePeriod11);
//        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,10.0]");
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(2019, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int4);
//        java.lang.String str6 = seriesChangeEvent5.toString();
//        java.lang.String str7 = seriesChangeEvent5.toString();
//        java.lang.Object obj8 = seriesChangeEvent5.getSource();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=13]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=13]"));
//        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 13 + "'", obj8.equals(13));
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year5.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date25 = simpleTimePeriod24.getStart();
//        java.util.Date date26 = simpleTimePeriod24.getStart();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getLastMillisecond();
//        long long29 = year27.getFirstMillisecond();
//        long long30 = year27.getLastMillisecond();
//        int int31 = simpleTimePeriod24.compareTo((java.lang.Object) year27);
//        long long32 = simpleTimePeriod24.getStartMillis();
//        java.util.Date date33 = simpleTimePeriod24.getStart();
//        boolean boolean34 = year5.equals((java.lang.Object) date33);
//        java.lang.String str35 = year5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year5.next();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1560409200000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
        int int2 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        int int15 = year13.getYear();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        boolean boolean18 = year13.equals((java.lang.Object) regularTimePeriod17);
        int int19 = simpleTimePeriod12.compareTo((java.lang.Object) regularTimePeriod17);
        java.lang.Number number20 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod17, number20);
        int int22 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,1.560495599999E12]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 3);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        int int21 = year19.getYear();
//        long long22 = year19.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 10.0d);
//        long long25 = year19.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues29.fireSeriesChanged();
//        int int31 = timePeriodValues29.getMaxStartIndex();
//        int int32 = timePeriodValues29.getMinStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date36 = simpleTimePeriod35.getStart();
//        java.util.Date date37 = simpleTimePeriod35.getStart();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getLastMillisecond();
//        long long40 = year38.getFirstMillisecond();
//        long long41 = year38.getLastMillisecond();
//        int int42 = simpleTimePeriod35.compareTo((java.lang.Object) year38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (double) 1.0f);
//        int int46 = day43.getDayOfMonth();
//        int int47 = day43.getDayOfMonth();
//        int int48 = year38.compareTo((java.lang.Object) int47);
//        long long49 = year38.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year38.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year38.previous();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 3);
//        boolean boolean54 = year19.equals((java.lang.Object) 3);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 13 + "'", int46 == 13);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 13 + "'", int47 == 13);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("");
        try {
            timePeriodValues3.update(5, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 1.0f);
//        int int8 = day5.getDayOfMonth();
//        int int10 = day5.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues14.setNotify(true);
//        int int17 = day5.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (short) 10);
//        timePeriodValues3.add(timePeriodValue19);
//        java.lang.String str21 = timePeriodValues3.getDescription();
//        timePeriodValues3.fireSeriesChanged();
//        java.lang.Object obj23 = timePeriodValues3.clone();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(obj23);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        java.util.Calendar calendar11 = null;
        try {
            year7.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        boolean boolean11 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int18 = day16.compareTo((java.lang.Object) 3);
        int int19 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.next();
        org.jfree.data.time.SerialDate serialDate21 = day16.getSerialDate();
        java.util.Date date22 = day16.getStart();
        timePeriodValues15.setKey((java.lang.Comparable) day16);
        java.lang.String str24 = timePeriodValues15.getDescription();
        boolean boolean25 = timePeriodValues3.equals((java.lang.Object) timePeriodValues15);
        int int26 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.lang.String str28 = year27.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year27, (double) (short) 100);
        java.lang.Comparable comparable31 = timePeriodValues3.getKey();
        boolean boolean32 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (byte) 10 + "'", comparable31.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
//        int int10 = day7.getDayOfMonth();
//        int int12 = day7.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 3);
//        int int16 = day13.getYear();
//        java.lang.Class<?> wildcardClass17 = day13.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        int int19 = day7.compareTo((java.lang.Object) wildcardClass17);
//        long long20 = day7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day7.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.SerialDate serialDate24 = day7.getSerialDate();
//        java.lang.String str25 = day7.toString();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str14 = timePeriodFormatException1.toString();
        java.lang.String str15 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 3);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        int int21 = year19.getYear();
//        long long22 = year19.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 10.0d);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getLastMillisecond();
//        java.lang.Class<?> wildcardClass27 = day25.getClass();
//        timePeriodValues3.setKey((java.lang.Comparable) day25);
//        java.util.Calendar calendar29 = null;
//        try {
//            long long30 = day25.getLastMillisecond(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int14 = day10.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod15);
        boolean boolean17 = timePeriodValues3.getNotify();
        timePeriodValues3.delete(5, (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        java.lang.Object obj10 = timePeriodValues3.clone();
        try {
            timePeriodValues3.update(0, (java.lang.Number) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate7);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(2019L, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxEndIndex();
        int int6 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        boolean boolean5 = timePeriodValues4.getNotify();
        timePeriodValues4.setNotify(true);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues8.fireSeriesChanged();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 3);
//        int int13 = day10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        int int21 = year19.getYear();
//        long long22 = year19.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 10.0d);
//        long long25 = year19.getFirstMillisecond();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date29 = simpleTimePeriod28.getStart();
//        java.util.Date date30 = simpleTimePeriod28.getStart();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getLastMillisecond();
//        long long33 = year31.getFirstMillisecond();
//        long long34 = year31.getLastMillisecond();
//        int int35 = simpleTimePeriod28.compareTo((java.lang.Object) year31);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day36, (double) 1.0f);
//        int int39 = day36.getDayOfMonth();
//        int int40 = day36.getDayOfMonth();
//        int int41 = year31.compareTo((java.lang.Object) int40);
//        long long42 = year31.getLastMillisecond();
//        int int43 = year31.getYear();
//        boolean boolean44 = year19.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year19.next();
//        java.util.Date date46 = regularTimePeriod45.getStart();
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 13 + "'", int39 == 13);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 13 + "'", int40 == 13);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues12.setNotify(true);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int17 = day15.compareTo((java.lang.Object) 3);
        int int18 = day15.getYear();
        int int19 = day15.getYear();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 5);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0f);
        try {
            timePeriodValues3.update(1969, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        boolean boolean11 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int18 = day16.compareTo((java.lang.Object) 3);
        int int19 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.next();
        org.jfree.data.time.SerialDate serialDate21 = day16.getSerialDate();
        java.util.Date date22 = day16.getStart();
        timePeriodValues15.setKey((java.lang.Comparable) day16);
        java.lang.String str24 = timePeriodValues15.getDescription();
        boolean boolean25 = timePeriodValues3.equals((java.lang.Object) timePeriodValues15);
        int int26 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.lang.String str28 = year27.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year27, (double) (short) 100);
        long long31 = year27.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        java.util.Date date2 = year0.getStart();
//        long long3 = year0.getSerialIndex();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 1.0f);
//        java.util.Date date7 = day4.getEnd();
//        boolean boolean8 = year0.equals((java.lang.Object) day4);
//        long long9 = day4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = day0.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 3);
//        int int11 = day8.getYear();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date17 = simpleTimePeriod16.getStart();
//        java.util.Date date18 = simpleTimePeriod16.getStart();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date6, timeZone21);
//        int int24 = day23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        java.util.Date date26 = day23.getStart();
//        java.lang.String str27 = day23.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int14 = day10.compareTo((java.lang.Object) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod15);
        java.lang.Comparable comparable17 = null;
        try {
            timePeriodValues3.setKey(comparable17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        int int7 = timePeriodValues3.getMinEndIndex();
        int int8 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,1.560495599999E12]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,9]");
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        java.util.Date date0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues5.addPropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) 1.0f);
//        timePeriodValue10.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue10.getPeriod();
//        timePeriodValue10.setValue((java.lang.Number) 10.0d);
//        java.lang.String str16 = timePeriodValue10.toString();
//        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue10.getPeriod();
//        timePeriodValues5.add(timePeriodValue10);
//        boolean boolean19 = timePeriodValues5.isEmpty();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getFirstMillisecond();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (double) 1.0f);
//        int int26 = day23.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day23.next();
//        java.util.Date date29 = day23.getEnd();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date22, date29);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 1577865599999L);
//        java.util.Date date34 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (double) 1.0f);
//        int int38 = day35.getDayOfMonth();
//        int int40 = day35.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int43 = day41.compareTo((java.lang.Object) 3);
//        int int44 = day41.getYear();
//        java.lang.Class<?> wildcardClass45 = day41.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        int int47 = day35.compareTo((java.lang.Object) wildcardClass45);
//        long long48 = day35.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day35.next();
//        java.util.Date date50 = regularTimePeriod49.getEnd();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getFirstMillisecond();
//        java.util.Date date54 = year52.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        long long57 = year56.getLastMillisecond();
//        java.util.Date date58 = year56.getStart();
//        java.lang.Object obj59 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass60 = obj59.getClass();
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day62, (double) 1.0f);
//        java.util.Date date65 = day62.getEnd();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date65, timeZone67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date58, timeZone67);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date54, timeZone67);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date50, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date34, timeZone67);
//        try {
//            org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date0, timeZone67);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriod13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str16.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560409200000L + "'", long48 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues10.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues10.createCopy(0, (int) (short) 10);
        int int15 = day0.compareTo((java.lang.Object) (short) 10);
        java.util.Date date16 = day0.getStart();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues8.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 3);
        int int13 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-1));
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) -1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        int int21 = year19.getYear();
        long long22 = year19.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 10.0d);
        int int25 = year19.getYear();
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year19.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        java.util.Date date13 = year11.getStart();
        boolean boolean14 = timePeriodValues7.equals((java.lang.Object) year11);
        boolean boolean16 = year11.equals((java.lang.Object) (-1L));
        int int17 = year2.compareTo((java.lang.Object) year11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int4 = day0.compareTo((java.lang.Object) 13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = regularTimePeriod5.getMiddleMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod5);
//        java.lang.Object obj8 = seriesChangeEvent7.getSource();
//        java.lang.Object obj9 = seriesChangeEvent7.getSource();
//        java.lang.String str10 = seriesChangeEvent7.toString();
//        java.lang.String str11 = seriesChangeEvent7.toString();
//        java.lang.String str12 = seriesChangeEvent7.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560538799999L + "'", long6 == 1560538799999L);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]"));
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(5, (int) (byte) 0);
        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
        int int10 = timePeriodValues8.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        int int8 = year6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) 0.0f);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int13 = day11.compareTo((java.lang.Object) 3);
        int int14 = day11.getYear();
        int int16 = day11.compareTo((java.lang.Object) "hi!");
        boolean boolean17 = year6.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year6.next();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int21 = day19.compareTo((java.lang.Object) 3);
        int int22 = day19.getYear();
        int int24 = day19.compareTo((java.lang.Object) "hi!");
        boolean boolean25 = year6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year6.next();
        java.lang.String str27 = year6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getSerialIndex();
//        long long7 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("2019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date14 = simpleTimePeriod13.getStart();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        long long18 = year16.getFirstMillisecond();
        long long19 = year16.getLastMillisecond();
        int int20 = simpleTimePeriod13.compareTo((java.lang.Object) year16);
        long long21 = simpleTimePeriod13.getStartMillis();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod13, (java.lang.Number) 1.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date27 = simpleTimePeriod26.getStart();
        long long28 = simpleTimePeriod26.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (double) 100.0f);
        java.lang.Object obj31 = timePeriodValue30.clone();
        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue30.getPeriod();
        try {
            int int33 = simpleTimePeriod13.compareTo((java.lang.Object) timePeriodValue30);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 10 + "'", comparable8.equals((byte) 10));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(timePeriod32);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = null;
        try {
            timePeriodValues3.add(timePeriodValue7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 3);
//        int int11 = day8.getYear();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod13, (java.lang.Number) 1560409200000L);
//        java.lang.String str16 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (double) 1.0f);
//        int int22 = day19.getMonth();
//        long long23 = day19.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
//        java.util.Calendar calendar26 = null;
//        try {
//            day19.peg(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        long long3 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        int int8 = year6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) 0.0f);
        long long11 = year6.getFirstMillisecond();
        long long12 = year6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int6 = day4.compareTo((java.lang.Object) 3);
        int int7 = day4.getYear();
        java.lang.Class<?> wildcardClass8 = day4.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
        java.util.Date date10 = day4.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date3, date10);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str16 = timePeriodFormatException15.toString();
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        try {
            int int21 = simpleTimePeriod11.compareTo((java.lang.Object) timePeriodFormatException19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "1969");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        boolean boolean9 = timePeriodValue7.equals((java.lang.Object) 5);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date13 = simpleTimePeriod12.getStart();
//        java.util.Date date14 = simpleTimePeriod12.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        long long17 = year15.getFirstMillisecond();
//        long long18 = year15.getLastMillisecond();
//        int int19 = simpleTimePeriod12.compareTo((java.lang.Object) year15);
//        java.lang.Object obj20 = null;
//        int int21 = year15.compareTo(obj20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) 1.0f);
//        int int25 = day22.getDayOfMonth();
//        int int26 = day22.getDayOfMonth();
//        int int27 = day22.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day22.previous();
//        long long29 = day22.getSerialIndex();
//        int int30 = year15.compareTo((java.lang.Object) day22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year15.next();
//        boolean boolean32 = timePeriodValue7.equals((java.lang.Object) regularTimePeriod31);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod31, "TimePeriodValue[13-June-2019,0]", "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,10.0]");
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) '4');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
        java.util.Date date10 = day7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date3, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        boolean boolean18 = timePeriodValues17.getNotify();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        int int11 = timePeriodValues10.getMaxStartIndex();
//        timePeriodValues10.setNotify(false);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        java.lang.Object obj15 = timePeriodValues10.clone();
//        int int16 = day0.compareTo(obj15);
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 43629L);
//        java.util.Date date19 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date19);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
//        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) seriesException4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getLastMillisecond();
//        java.lang.Class<?> wildcardClass9 = day7.getClass();
//        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) wildcardClass9);
//        long long11 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long11);
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 10 + "'", comparable8.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date14 = simpleTimePeriod13.getStart();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        long long18 = year16.getFirstMillisecond();
        long long19 = year16.getLastMillisecond();
        int int20 = simpleTimePeriod13.compareTo((java.lang.Object) year16);
        long long21 = simpleTimePeriod13.getStartMillis();
        long long22 = simpleTimePeriod13.getStartMillis();
        java.lang.Object obj23 = null;
        boolean boolean24 = simpleTimePeriod13.equals(obj23);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod13);
        long long26 = simpleTimePeriod13.getStartMillis();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[13-June-2019,-1.0]]");
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy(12, (int) '#');
        int int13 = timePeriodValues12.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        long long6 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,1.560495599999E12]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        int int4 = day0.getYear();
        int int5 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "2019", "org.jfree.data.general.SeriesChangeEvent[source=13]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date12 = simpleTimePeriod11.getStart();
        long long13 = simpleTimePeriod11.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 100.0f);
        java.lang.Object obj16 = timePeriodValue15.clone();
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue15.getPeriod();
        boolean boolean18 = timePeriodValues8.equals((java.lang.Object) timePeriod17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getItemCount();
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        boolean boolean4 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 1.0f);
        int int6 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
        java.util.Date date9 = day3.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date2);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year12);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.setNotify(true);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        int int10 = day6.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        boolean boolean14 = timePeriodValues3.getNotify();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (double) 1.0f);
//        int int18 = day15.getDayOfMonth();
//        int int20 = day15.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (double) (byte) -1);
//        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue22.getPeriod();
//        java.lang.Number number24 = timePeriodValue22.getValue();
//        java.lang.String str25 = timePeriodValue22.toString();
//        timePeriodValues3.add(timePeriodValue22);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener27);
//        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,-1.0]");
//        java.lang.String str31 = timePeriodValues3.getDescription();
//        int int32 = timePeriodValues3.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timePeriod23);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str25.equals("TimePeriodValue[13-June-2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str31.equals("TimePeriodValue[13-June-2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) 1.0f);
//        int int11 = day8.getDayOfMonth();
//        int int13 = day8.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 3);
//        int int17 = day14.getYear();
//        java.lang.Class<?> wildcardClass18 = day14.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        int int20 = day8.compareTo((java.lang.Object) wildcardClass18);
//        long long21 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day8.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, (double) 1L);
//        int int25 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 1, (long) (short) 100);
//        java.util.Date date7 = simpleTimePeriod6.getStart();
//        java.util.Date date8 = simpleTimePeriod6.getEnd();
//        java.util.Date date9 = simpleTimePeriod6.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 3);
//        int int13 = day10.getYear();
//        java.lang.Class<?> wildcardClass14 = day10.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        java.util.Date date20 = simpleTimePeriod18.getStart();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date28 = simpleTimePeriod27.getStart();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int31 = day29.compareTo((java.lang.Object) 3);
//        int int32 = day29.getYear();
//        java.lang.Class<?> wildcardClass33 = day29.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.next();
//        java.util.Date date35 = day29.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date28, date35);
//        java.lang.Object obj37 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass38 = obj37.getClass();
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day40, (double) 1.0f);
//        java.util.Date date43 = day40.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone45);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date28, timeZone45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date20, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date9, timeZone45);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        long long8 = year5.getLastMillisecond();
        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
        long long10 = simpleTimePeriod2.getStartMillis();
        long long11 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod2.equals(obj12);
        java.util.Date date14 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        long long8 = year5.getLastMillisecond();
        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
        long long10 = simpleTimePeriod2.getStartMillis();
        long long11 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod2.equals(obj12);
        long long14 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 1.0f);
        java.util.Date date7 = day4.getEnd();
        boolean boolean8 = year0.equals((java.lang.Object) day4);
        int int9 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 100.0f);
        java.lang.Object obj7 = timePeriodValue6.clone();
        timePeriodValue6.setValue((java.lang.Number) 10);
        java.lang.Object obj10 = timePeriodValue6.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener5);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues4.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int6 = day4.compareTo((java.lang.Object) 3);
        int int7 = day4.getYear();
        java.lang.Class<?> wildcardClass8 = day4.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
        java.util.Date date10 = day4.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date3, date10);
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        long long13 = simpleTimePeriod11.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        long long8 = year5.getLastMillisecond();
//        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
//        java.lang.Object obj10 = null;
//        int int11 = year5.compareTo(obj10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getDayOfMonth();
//        int int17 = day12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
//        long long19 = day12.getSerialIndex();
//        int int20 = year5.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year5.next();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date25 = simpleTimePeriod24.getStart();
//        java.util.Date date26 = simpleTimePeriod24.getStart();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getLastMillisecond();
//        long long29 = year27.getFirstMillisecond();
//        long long30 = year27.getLastMillisecond();
//        int int31 = simpleTimePeriod24.compareTo((java.lang.Object) year27);
//        long long32 = simpleTimePeriod24.getStartMillis();
//        java.util.Date date33 = simpleTimePeriod24.getStart();
//        boolean boolean34 = year5.equals((java.lang.Object) date33);
//        java.lang.String str35 = year5.toString();
//        int int36 = year5.getYear();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("");
        int int8 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560495599999L);
        java.lang.Comparable comparable2 = timePeriodValues1.getKey();
        int int3 = timePeriodValues1.getMaxStartIndex();
        boolean boolean4 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 1560495599999L + "'", comparable2.equals(1560495599999L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,-1.0]");
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int12, "", "31-December-1969");
//        java.lang.String str16 = timePeriodValues15.getDescription();
//        timePeriodValues15.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNull(str16);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("");
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str16 = timePeriodFormatException12.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        long long7 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) (short) 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        int int6 = timePeriodValues5.getMaxStartIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        int int5 = timePeriodValues3.getMinMiddleIndex();
//        int int6 = timePeriodValues3.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.removeChangeListener(seriesChangeListener11);
//        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) seriesChangeListener11);
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        java.util.Date date20 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        long long22 = year21.getLastMillisecond();
//        long long23 = year21.getFirstMillisecond();
//        long long24 = year21.getLastMillisecond();
//        int int25 = simpleTimePeriod18.compareTo((java.lang.Object) year21);
//        java.lang.Object obj26 = null;
//        int int27 = year21.compareTo(obj26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (double) 1.0f);
//        int int31 = day28.getDayOfMonth();
//        int int32 = day28.getDayOfMonth();
//        int int33 = day28.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        long long35 = day28.getSerialIndex();
//        int int36 = year21.compareTo((java.lang.Object) day28);
//        int int37 = day28.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timePeriodValues41.addPropertyChangeListener(propertyChangeListener42);
//        int int44 = timePeriodValues41.getMaxMiddleIndex();
//        boolean boolean45 = timePeriodValues41.isEmpty();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int48 = day46.compareTo((java.lang.Object) 3);
//        int int49 = day46.getYear();
//        java.lang.Class<?> wildcardClass50 = day46.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day46.previous();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) regularTimePeriod51, (java.lang.Number) 1560409200000L);
//        boolean boolean54 = day28.equals((java.lang.Object) timePeriodValues41);
//        timePeriodValues41.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener57 = null;
//        timePeriodValues41.addPropertyChangeListener(propertyChangeListener57);
//        java.lang.Comparable comparable59 = timePeriodValues41.getKey();
//        boolean boolean60 = timePeriodValues3.equals((java.lang.Object) timePeriodValues41);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43629L + "'", long35 == 43629L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 13 + "'", int37 == 13);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + (byte) 10 + "'", comparable59.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        boolean boolean9 = timePeriodValue7.equals((java.lang.Object) 5);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date13 = simpleTimePeriod12.getStart();
//        java.util.Date date14 = simpleTimePeriod12.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        long long17 = year15.getFirstMillisecond();
//        long long18 = year15.getLastMillisecond();
//        int int19 = simpleTimePeriod12.compareTo((java.lang.Object) year15);
//        java.lang.Object obj20 = null;
//        int int21 = year15.compareTo(obj20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) 1.0f);
//        int int25 = day22.getDayOfMonth();
//        int int26 = day22.getDayOfMonth();
//        int int27 = day22.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day22.previous();
//        long long29 = day22.getSerialIndex();
//        int int30 = year15.compareTo((java.lang.Object) day22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year15.next();
//        boolean boolean32 = timePeriodValue7.equals((java.lang.Object) regularTimePeriod31);
//        java.util.Date date33 = regularTimePeriod31.getStart();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) 1.0f);
//        int int11 = day8.getDayOfMonth();
//        int int13 = day8.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int16 = day14.compareTo((java.lang.Object) 3);
//        int int17 = day14.getYear();
//        java.lang.Class<?> wildcardClass18 = day14.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        int int20 = day8.compareTo((java.lang.Object) wildcardClass18);
//        long long21 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day8.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, (double) 1L);
//        java.lang.Class<?> wildcardClass25 = timePeriodValues3.getClass();
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Object obj5 = timePeriodValues4.clone();
        java.lang.Object obj6 = timePeriodValues4.clone();
        int int7 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        int int10 = day8.compareTo((java.lang.Object) 3);
        int int12 = day8.compareTo((java.lang.Object) 13);
        boolean boolean13 = timePeriodValues4.equals((java.lang.Object) day8);
        int int14 = timePeriodValues4.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        long long8 = year5.getLastMillisecond();
        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year5.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.util.Date date0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date4 = simpleTimePeriod3.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(date0, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 1.0f);
//        int int8 = day5.getDayOfMonth();
//        int int10 = day5.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues14.setNotify(true);
//        int int17 = day5.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (short) 10);
//        timePeriodValues3.add(timePeriodValue19);
//        java.lang.Object obj21 = timePeriodValues3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener22);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(obj21);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
        java.lang.String str15 = day14.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day14, "31-December-1969", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-1969" + "'", str15.equals("31-December-1969"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        long long8 = year5.getLastMillisecond();
        int int9 = simpleTimePeriod2.compareTo((java.lang.Object) year5);
        long long10 = simpleTimePeriod2.getStartMillis();
        long long11 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod2.equals(obj12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener18);
        int int20 = timePeriodValues17.getItemCount();
        timePeriodValues17.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener23);
        int int25 = timePeriodValues17.getMinMiddleIndex();
        int int26 = timePeriodValues17.getMinStartIndex();
        int int27 = timePeriodValues17.getMaxStartIndex();
        try {
            int int28 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 10 + "'", comparable9.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        int int3 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
        java.util.Date date6 = day0.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        int int10 = day8.compareTo((java.lang.Object) 3);
        int int11 = day8.getYear();
        java.lang.Class<?> wildcardClass12 = day8.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date6, timeZone21);
        int int24 = day23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.next();
        int int27 = day23.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getSerialIndex();
//        java.util.Date date8 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) -1);
//        java.lang.Object obj8 = timePeriodValue7.clone();
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue7.getPeriod();
//        java.lang.Object obj10 = timePeriodValue7.clone();
//        timePeriodValue7.setValue((java.lang.Number) 1546329600000L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (double) 1.0f);
//        timePeriodValue21.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod24 = timePeriodValue21.getPeriod();
//        timePeriodValue21.setValue((java.lang.Number) 10.0d);
//        java.lang.String str27 = timePeriodValue21.toString();
//        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue21.getPeriod();
//        timePeriodValues16.add(timePeriodValue21);
//        boolean boolean30 = timePeriodValue7.equals((java.lang.Object) timePeriodValues16);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(timePeriod24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str27.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        long long13 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        int int17 = timePeriodValues16.getMinEndIndex();
//        int int18 = timePeriodValues16.getMinMiddleIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 3);
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int8 = day0.compareTo((java.lang.Object) (byte) 100);
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 3);
//        int int16 = day13.getYear();
//        java.lang.Class<?> wildcardClass17 = day13.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
//        java.util.Date date19 = day13.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (double) 1.0f);
//        int int24 = day21.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.next();
//        java.util.Date date27 = day21.getEnd();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int31 = day29.compareTo((java.lang.Object) 3);
//        int int32 = day29.getYear();
//        java.lang.Class<?> wildcardClass33 = day29.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date38 = simpleTimePeriod37.getStart();
//        java.util.Date date39 = simpleTimePeriod37.getStart();
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date39, timeZone40);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date39, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date27, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date19, timeZone42);
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(class47);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) false);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues3.setNotify(false);
        java.lang.String str6 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) year7);
        boolean boolean11 = timePeriodValues3.getNotify();
        int int12 = timePeriodValues3.getMinEndIndex();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 3);
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date7 = simpleTimePeriod6.getStart();
//        java.util.Date date8 = simpleTimePeriod6.getStart();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getLastMillisecond();
//        long long11 = year9.getFirstMillisecond();
//        long long12 = year9.getLastMillisecond();
//        int int13 = simpleTimePeriod6.compareTo((java.lang.Object) year9);
//        java.lang.Object obj14 = null;
//        int int15 = year9.compareTo(obj14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
//        int int19 = day16.getDayOfMonth();
//        int int20 = day16.getDayOfMonth();
//        int int21 = day16.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.previous();
//        long long23 = day16.getSerialIndex();
//        int int24 = year9.compareTo((java.lang.Object) day16);
//        int int25 = day16.getDayOfMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day16, (double) (byte) 0);
//        timePeriodValues1.delete((int) (short) 100, (int) (byte) -1);
//        int int31 = timePeriodValues1.getMaxStartIndex();
//        int int32 = timePeriodValues1.getMinStartIndex();
//        int int33 = timePeriodValues1.getMaxMiddleIndex();
//        int int34 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener35);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getSerialIndex();
//        java.util.Date date8 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        timePeriodValues12.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int17 = day15.compareTo((java.lang.Object) 3);
//        int int18 = day15.getYear();
//        int int19 = day15.getYear();
//        timePeriodValues12.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 5);
//        timePeriodValues12.fireSeriesChanged();
//        int int23 = day0.compareTo((java.lang.Object) timePeriodValues12);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        java.util.Date date4 = year2.getStart();
        java.lang.Object obj5 = new java.lang.Object();
        java.lang.Class<?> wildcardClass6 = obj5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (double) 1.0f);
        java.util.Date date11 = day8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date4, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date4);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        java.util.Date date2 = year0.getStart();
//        long long3 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=false]", "org.jfree.data.general.SeriesChangeEvent[source=14-June-2019]");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
//        int int10 = day7.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.next();
//        long long13 = day7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        boolean boolean15 = year0.equals((java.lang.Object) regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        java.lang.Number number3 = timePeriodValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1.0d + "'", number3.equals(1.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Object obj5 = timePeriodValues4.clone();
        java.lang.Object obj6 = timePeriodValues4.clone();
        int int7 = timePeriodValues4.getMaxMiddleIndex();
        int int8 = timePeriodValues4.getMaxMiddleIndex();
        timePeriodValues4.setDescription("2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        java.util.Date date4 = year0.getEnd();
        long long5 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(5, 11);
        int int12 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,9]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
//        int int10 = day7.getDayOfMonth();
//        int int12 = day7.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 3);
//        int int16 = day13.getYear();
//        java.lang.Class<?> wildcardClass17 = day13.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        int int19 = day7.compareTo((java.lang.Object) wildcardClass17);
//        long long20 = day7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day7.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.SerialDate serialDate24 = day7.getSerialDate();
//        long long25 = day7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560495599999L + "'", long25 == 1560495599999L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560495599999L);
        boolean boolean2 = timePeriodValues1.getNotify();
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[13-June-2019,10.0]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(5, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        boolean boolean15 = simpleTimePeriod11.equals((java.lang.Object) seriesException13);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener22);
        int int24 = timePeriodValues21.getItemCount();
        timePeriodValues21.setNotify(false);
        int int27 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean28 = timePeriodValues21.getNotify();
        int int29 = timePeriodValues21.getItemCount();
        boolean boolean30 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener31);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        int int8 = year6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) 0.0f);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int13 = day11.compareTo((java.lang.Object) 3);
        int int14 = day11.getYear();
        int int16 = day11.compareTo((java.lang.Object) "hi!");
        boolean boolean17 = year6.equals((java.lang.Object) int16);
        java.util.Date date18 = year6.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number10 = timePeriodValues3.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) 1.0f);
//        timePeriodValue8.setValue((java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue8.getPeriod();
//        timePeriodValue8.setValue((java.lang.Number) 10.0d);
//        java.lang.String str14 = timePeriodValue8.toString();
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue8.getPeriod();
//        java.lang.Number number16 = timePeriodValue8.getValue();
//        boolean boolean17 = simpleTimePeriod2.equals((java.lang.Object) number16);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(timePeriod11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str14.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0d + "'", number16.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2, (long) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 2019L);
        long long5 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues3.clone();
        java.lang.Object obj12 = timePeriodValues3.clone();
        timePeriodValues3.delete(13, 1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date14 = simpleTimePeriod13.getStart();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        long long18 = year16.getFirstMillisecond();
        long long19 = year16.getLastMillisecond();
        int int20 = simpleTimePeriod13.compareTo((java.lang.Object) year16);
        long long21 = simpleTimePeriod13.getStartMillis();
        long long22 = simpleTimePeriod13.getStartMillis();
        java.lang.Object obj23 = null;
        boolean boolean24 = simpleTimePeriod13.equals(obj23);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod13);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-1969" + "'", str5.equals("31-December-1969"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = day0.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 3);
//        int int11 = day8.getYear();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date17 = simpleTimePeriod16.getStart();
//        java.util.Date date18 = simpleTimePeriod16.getStart();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date6, timeZone21);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day23);
//        java.lang.String str25 = seriesChangeEvent24.toString();
//        java.lang.Class<?> wildcardClass26 = seriesChangeEvent24.getClass();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str25.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 1, (long) (short) 100);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues7.getMaxMiddleIndex();
//        java.lang.Comparable comparable11 = timePeriodValues7.getKey();
//        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int19 = day17.compareTo((java.lang.Object) 3);
//        int int20 = day17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.next();
//        org.jfree.data.time.SerialDate serialDate22 = day17.getSerialDate();
//        java.util.Date date23 = day17.getStart();
//        timePeriodValues16.setKey((java.lang.Comparable) day17);
//        long long25 = day17.getFirstMillisecond();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int28 = day26.compareTo((java.lang.Object) 3);
//        int int29 = day26.getYear();
//        java.lang.Class<?> wildcardClass30 = day26.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date35 = simpleTimePeriod34.getStart();
//        java.util.Date date36 = simpleTimePeriod34.getStart();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date36, timeZone37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date36, timeZone39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getFirstMillisecond();
//        java.util.Date date43 = year41.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getLastMillisecond();
//        java.util.Date date47 = year45.getStart();
//        java.lang.Object obj48 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass49 = obj48.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, (double) 1.0f);
//        java.util.Date date54 = day51.getEnd();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date54, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date47, timeZone56);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date43, timeZone56);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date36, timeZone56);
//        boolean boolean61 = day17.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 100.0f);
//        timePeriodValues7.add(timePeriodValue63);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 10 + "'", comparable11.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeEvent2);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener5);
//        int int7 = timePeriodValues3.getMaxEndIndex();
//        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener9);
//        int int11 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 1.0f);
//        int int15 = day12.getDayOfMonth();
//        int int17 = day12.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) (byte) -1);
//        java.lang.Object obj20 = timePeriodValue19.clone();
//        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue19.getPeriod();
//        timePeriodValues3.setKey((java.lang.Comparable) timePeriod21);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 10 + "'", comparable8.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(timePeriod21);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
//        int int10 = day7.getDayOfMonth();
//        int int12 = day7.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 3);
//        int int16 = day13.getYear();
//        java.lang.Class<?> wildcardClass17 = day13.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        int int19 = day7.compareTo((java.lang.Object) wildcardClass17);
//        long long20 = day7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day7.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (byte) -1);
//        try {
//            timePeriodValues3.update(5, (java.lang.Number) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getDayOfMonth();
//        int int5 = day0.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int8 = day6.compareTo((java.lang.Object) 3);
//        int int9 = day6.getYear();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        int int12 = day0.compareTo((java.lang.Object) wildcardClass10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int12, "", "31-December-1969");
//        java.lang.String str16 = timePeriodValues15.getDescription();
//        java.lang.String str17 = timePeriodValues15.getDescription();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNull(str17);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int8 = day6.compareTo((java.lang.Object) 3);
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date16 = simpleTimePeriod15.getStart();
        long long17 = simpleTimePeriod15.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (double) 100.0f);
        timePeriodValues3.add(timePeriodValue19);
        boolean boolean21 = timePeriodValues3.isEmpty();
        int int22 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        java.util.Date date11 = day8.getEnd();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues8.removeChangeListener(seriesChangeListener9);
        timePeriodValues8.fireSeriesChanged();
        int int12 = timePeriodValues8.getMaxEndIndex();
        try {
            int int13 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-1969");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int3 = day1.compareTo((java.lang.Object) 3);
//        int int5 = day1.compareTo((java.lang.Object) 13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day1.next();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        java.util.Date date8 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (double) 1.0f);
//        int int13 = day10.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
//        java.util.Date date16 = day10.getEnd();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 3);
//        int int21 = day18.getYear();
//        java.lang.Class<?> wildcardClass22 = day18.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date27 = simpleTimePeriod26.getStart();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date28, timeZone29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date28, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date16, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int37 = day35.compareTo((java.lang.Object) 3);
//        int int38 = day35.getYear();
//        java.lang.Class<?> wildcardClass39 = day35.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date44 = simpleTimePeriod43.getStart();
//        java.util.Date date45 = simpleTimePeriod43.getStart();
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date45, timeZone46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        long long51 = year50.getFirstMillisecond();
//        java.util.Date date52 = year50.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date52);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        long long55 = year54.getLastMillisecond();
//        java.util.Date date56 = year54.getStart();
//        java.lang.Object obj57 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass58 = obj57.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day60, (double) 1.0f);
//        java.util.Date date63 = day60.getEnd();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date63, timeZone65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date56, timeZone65);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date52, timeZone65);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date45, timeZone65);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date8, timeZone65);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560538799999L + "'", long7 == 1560538799999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[13-June-2019,-1.0]]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 1.0f);
//        int int8 = day5.getDayOfMonth();
//        int int10 = day5.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) (byte) -1);
//        timePeriodValues3.add(timePeriodValue12);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        int int15 = timePeriodValues3.getMinMiddleIndex();
//        int int16 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date20 = simpleTimePeriod19.getStart();
//        java.util.Date date21 = simpleTimePeriod19.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        long long24 = year22.getFirstMillisecond();
//        long long25 = year22.getLastMillisecond();
//        int int26 = simpleTimePeriod19.compareTo((java.lang.Object) year22);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (double) 1.0f);
//        int int30 = day27.getDayOfMonth();
//        int int31 = day27.getDayOfMonth();
//        int int32 = year22.compareTo((java.lang.Object) int31);
//        long long33 = year22.getLastMillisecond();
//        int int34 = year22.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 1L);
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = year22.getLastMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 10 + "'", comparable14.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 1.0f);
        java.util.Date date7 = day4.getEnd();
        boolean boolean8 = year0.equals((java.lang.Object) day4);
        long long9 = year0.getSerialIndex();
        long long10 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10, "org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1.0f);
//        int int10 = day7.getDayOfMonth();
//        int int12 = day7.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int15 = day13.compareTo((java.lang.Object) 3);
//        int int16 = day13.getYear();
//        java.lang.Class<?> wildcardClass17 = day13.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        int int19 = day7.compareTo((java.lang.Object) wildcardClass17);
//        long long20 = day7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day7.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (byte) -1);
//        int int24 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=13]");
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = day0.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 1.0f);
//        int int12 = day9.getDayOfMonth();
//        int int14 = day9.compareTo((java.lang.Object) 1L);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int17 = day15.compareTo((java.lang.Object) 3);
//        int int18 = day15.getYear();
//        java.lang.Class<?> wildcardClass19 = day15.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        int int21 = day9.compareTo((java.lang.Object) wildcardClass19);
//        long long22 = day9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day9.next();
//        java.util.Date date24 = regularTimePeriod23.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
//        int int26 = timePeriodValues25.getMinEndIndex();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int29 = day27.compareTo((java.lang.Object) 3);
//        int int30 = day27.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.next();
//        org.jfree.data.time.SerialDate serialDate32 = day27.getSerialDate();
//        java.util.Date date33 = day27.getStart();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getLastMillisecond();
//        java.lang.Class<?> wildcardClass36 = day34.getClass();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day37, (double) 1.0f);
//        int int40 = day37.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day37.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day37.next();
//        java.util.Date date43 = day37.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int47 = day45.compareTo((java.lang.Object) 3);
//        int int48 = day45.getYear();
//        java.lang.Class<?> wildcardClass49 = day45.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 0L);
//        java.util.Date date54 = simpleTimePeriod53.getStart();
//        java.util.Date date55 = simpleTimePeriod53.getStart();
//        java.util.TimeZone timeZone56 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date55, timeZone56);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date55, timeZone58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date43, timeZone58);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        long long62 = year61.getFirstMillisecond();
//        java.util.Date date63 = year61.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date63);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
//        long long66 = year65.getLastMillisecond();
//        java.util.Date date67 = year65.getStart();
//        java.lang.Object obj68 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass69 = obj68.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day71, (double) 1.0f);
//        java.util.Date date74 = day71.getEnd();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date74, timeZone76);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date67, timeZone76);
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date63, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone76);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date33, timeZone76);
//        boolean boolean82 = timePeriodValues25.equals((java.lang.Object) timeZone76);
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date6, timeZone76);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560495599999L + "'", long35 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577865599999L + "'", long66 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }
//}

