import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (byte) 10);
        org.jfree.data.KeyedObjects keyedObjects4 = new org.jfree.data.KeyedObjects();
        boolean boolean5 = numberTickUnit1.equals((java.lang.Object) keyedObjects4);
        java.lang.Object obj7 = keyedObjects4.getObject((java.lang.Comparable) false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendGraphic18.getShapeAnchor();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor27, 0.0d, (double) 100L);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone(shape30);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint37 = textFragment36.getPaint();
        java.awt.Paint paint38 = textFragment36.getPaint();
        categoryAxis34.setAxisLinePaint(paint38);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint42 = textTitle41.getBackgroundPaint();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int44 = color43.getAlpha();
        java.awt.Color color45 = color43.darker();
        int int46 = color45.getTransparency();
        boolean boolean47 = textTitle41.equals((java.lang.Object) color45);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        categoryPlot48.setRangeAxis((int) (byte) 100, valueAxis50, true);
        java.awt.Stroke stroke53 = categoryPlot48.getOutlineStroke();
        java.awt.Shape shape55 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape59 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape55, rectangleAnchor56, 0.0d, (double) 100L);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.clone(shape59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis61.setCategoryMargin((double) '4');
        java.awt.Stroke stroke64 = categoryAxis61.getTickMarkStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor65 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint67 = textTitle66.getPaint();
        boolean boolean68 = itemLabelAnchor65.equals((java.lang.Object) paint67);
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("Category Plot", "{0}", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "", false, shape31, true, paint38, false, (java.awt.Paint) color45, stroke53, true, shape60, stroke64, paint67);
        legendGraphic18.setLinePaint(paint38);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(itemLabelAnchor65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(255);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.data.RangeType rangeType16 = numberAxis1.getRangeType();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rangeType16);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint8 = textFragment7.getPaint();
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font5, paint8, (float) ' ');
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("10", font5, (java.awt.Paint) color11, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot14.setRangeAxis((int) (byte) 100, valueAxis16, true);
        java.awt.Stroke stroke19 = categoryPlot14.getOutlineStroke();
        categoryPlot14.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        jFreeChart23.setTextAntiAlias(true);
        java.awt.Image image26 = jFreeChart23.getBackgroundImage();
        int int27 = jFreeChart23.getSubtitleCount();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint33 = textFragment32.getPaint();
        java.awt.Paint paint34 = textFragment32.getPaint();
        categoryAxis30.setAxisLinePaint(paint34);
        legendTitle1.setItemPaint(paint34);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        numberAxis42.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 25.0d);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint1, stroke2, rectangleInsets3);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = lineBorder5.getInsets();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint9 = textTitle8.getPaint();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str12 = rectangleInsets11.toString();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder(paint9, stroke10, rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range19 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range22 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range19, range22);
        double double24 = range22.getLowerBound();
        numberAxis16.setDefaultAutoRange(range22);
        numberAxis16.setLowerBound(100.0d);
        boolean boolean28 = numberAxis16.isTickLabelsVisible();
        numberAxis16.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = legendTitle32.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str35 = rectangleInsets34.toString();
        legendTitle32.setItemLabelPadding(rectangleInsets34);
        legendTitle32.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle32.getBounds();
        numberAxis16.setUpArrow((java.awt.Shape) rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets14.createInsetRectangle(rectangle2D39, true, false);
        lineBorder5.draw(graphics2D7, rectangle2D43);
        java.awt.Paint paint45 = lineBorder5.getPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str35.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        boolean boolean8 = categoryAxis5.equals((java.lang.Object) "ThreadContext");
        categoryPlot0.setDomainAxis(categoryAxis5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer11.getURLGenerator(0, (int) (short) 10);
        barRenderer11.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer11.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint21 = barRenderer11.getSeriesOutlinePaint((-1));
        boolean boolean22 = barRenderer11.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        barRenderer11.setBaseURLGenerator(categoryURLGenerator23, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        barRenderer11.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator27);
        categoryPlot0.setRenderer((int) (byte) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11, true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 255, 0.0d);
        java.lang.Object obj3 = size2D2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getMargin();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer0.getPlot();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(categoryPlot3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot10.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation13);
        java.lang.String str15 = plotOrientation13.toString();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.VERTICAL" + "'", str15.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.2d);
        java.util.List list2 = axisState1.getTicks();
        axisState1.cursorDown((double) 2);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot10);
        try {
            java.lang.Number number14 = defaultStatisticalCategoryDataset0.getMeanValue(15, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer5.getItemOutlineStroke(0, 0);
        barRenderer0.setSeriesStroke(1, stroke8);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 'a', (double) (byte) 1, (double) 15, (java.awt.Paint) color15);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, 0.0d, (double) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        categoryPlot21.setRangeAxis((int) (byte) 100, valueAxis23, true);
        int int26 = categoryPlot21.getDatasetCount();
        java.awt.Font font27 = categoryPlot21.getNoDataMessageFont();
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray35, numberArray40, numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray56);
        boolean boolean58 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset57);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset57);
        categoryPlot21.setDataset(15, categoryDataset57);
        java.lang.Comparable comparable62 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity63 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "GradientPaintTransformType.CENTER_VERTICAL", "", categoryDataset57, (java.lang.Comparable) true, comparable62);
        categoryItemEntity63.setColumnKey((java.lang.Comparable) "Category Plot");
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int3 = color2.getAlpha();
        java.awt.Color color4 = color2.darker();
        int int5 = color4.getTransparency();
        boolean boolean6 = textTitle0.equals((java.lang.Object) color4);
        java.lang.String str7 = textTitle0.getToolTipText();
        java.awt.Paint paint8 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator16);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor40 = itemLabelPosition39.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor41 = itemLabelPosition39.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor42 = itemLabelPosition39.getRotationAnchor();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition39);
        java.awt.Paint paint44 = null;
        try {
            barRenderer0.setBaseFillPaint(paint44, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(itemLabelAnchor40);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer0.getItemOutlineStroke(0, 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator5, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getSeriesURLGenerator((-16777214));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        double double2 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getAlpha();
        java.awt.Color color2 = color0.darker();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean13 = chartEntity11.equals((java.lang.Object) color12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = categoryLabelPosition15.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions14, categoryLabelPosition15);
        java.awt.Color color18 = java.awt.Color.green;
        float[] floatArray24 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        boolean boolean26 = categoryLabelPositions14.equals((java.lang.Object) floatArray24);
        float[] floatArray27 = color12.getRGBColorComponents(floatArray24);
        float[] floatArray28 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) (short) -1, (int) 'a', floatArray27);
        float[] floatArray29 = color2.getRGBColorComponents(floatArray27);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = itemLabelPosition4.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition4.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition4.getRotationAnchor();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        int int9 = barRenderer0.getColumnCount();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', paint14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot17.setRangeAxis((int) (byte) 100, valueAxis19, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot17.setRenderer((int) 'a', categoryItemRenderer23, true);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            barRenderer0.drawOutline(graphics2D16, categoryPlot17, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.setRangeCrosshairValue((double) 255);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle0.getMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot9.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo18, point2D19);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray27, numberArray32, numberArray37, numberArray42, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray48);
        boolean boolean50 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot9.getRendererForDataset(categoryDataset49);
        boolean boolean52 = textTitle0.equals((java.lang.Object) categoryPlot9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        java.lang.String str3 = numberTickUnit1.valueToString(0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 10);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("VerticalAlignment.BOTTOM");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle0.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str10 = rectangleInsets9.toString();
        textTitle0.setMargin(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str4 = numberTickUnit2.valueToString((double) 10);
        java.lang.String str6 = numberTickUnit2.valueToString((double) (short) 100);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtTop();
        java.util.List list3 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5);
        java.awt.Stroke stroke8 = barRenderer0.lookupSeriesStroke((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Font font11 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot13.setRangeAxis((int) (byte) 100, valueAxis15, true);
        int int18 = categoryPlot13.getDatasetCount();
        java.util.List list19 = categoryPlot13.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot13.getDomainAxis((int) (byte) -1);
        java.awt.Stroke stroke22 = categoryPlot13.getOutlineStroke();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            barRenderer0.drawDomainGridline(graphics2D12, categoryPlot13, rectangle2D23, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) font1);
        java.util.List list3 = blockContainer0.getBlocks();
        boolean boolean4 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets2.calculateRightInset((double) (byte) -1);
        double double6 = rectangleInsets2.calculateBottomInset((double) (short) 1);
        boolean boolean7 = objectList1.equals((java.lang.Object) double6);
        java.lang.Object obj9 = objectList1.get(2);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        legendGraphic18.setLine(shape20);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer22 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType23 = standardGradientPaintTransformer22.getType();
        legendGraphic18.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer22);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(gradientPaintTransformType23);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        org.jfree.chart.text.TextFragment textFragment17 = null;
        textLine16.removeFragment(textFragment17);
        org.jfree.chart.text.TextFragment textFragment19 = null;
        textLine16.removeFragment(textFragment19);
        org.jfree.chart.text.TextFragment textFragment21 = textLine16.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(textFragment21);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getNegativeItemLabelPosition(100, (int) (short) 1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font3);
        java.awt.Color color10 = java.awt.Color.magenta;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", font3, (java.awt.Paint) color10);
        int int12 = color10.getAlpha();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot6.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo15, point2D16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot6.setRangeGridlineStroke(stroke18);
        java.awt.Paint paint20 = categoryPlot6.getOutlinePaint();
        categoryAxis0.setTickMarkPaint(paint20);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        boolean boolean2 = blockContainer1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        double double5 = categoryPlot0.getAnchorValue();
        int int6 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        legendItem12.setDatasetIndex((int) (short) -1);
        int int16 = legendItem12.getDatasetIndex();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot17.setRangeAxis((int) (byte) 100, valueAxis19, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        categoryPlot23.setRangeAxis((int) (byte) 100, valueAxis25, true);
        java.awt.Stroke stroke28 = categoryPlot23.getOutlineStroke();
        categoryPlot23.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.setCategoryMargin((double) '4');
        java.awt.Stroke stroke35 = categoryAxis32.getTickMarkStroke();
        categoryPlot23.setDomainAxis((int) (byte) 100, categoryAxis32, false);
        categoryPlot17.setDomainAxis(0, categoryAxis32, false);
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray69 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58, numberArray63, numberArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray69);
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("GradientPaintTransformType.CENTER_VERTICAL", "Layer.BACKGROUND", numberArray69);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = categoryPlot17.getRendererForDataset(categoryDataset71);
        legendItem12.setDataset((org.jfree.data.general.Dataset) categoryDataset71);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNull(categoryItemRenderer72);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape0, "GradientPaintTransformType.HORIZONTAL", "VerticalAlignment.BOTTOM");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color2 };
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { paint7 };
        java.awt.Paint[] paintArray9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray10 = null;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray8, paintArray9, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke15, stroke16 };
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, rectangleAnchor21, 0.0d, (double) 100L);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape25);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] { shape19, shape24, shape25, shape33 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray3, paintArray9, strokeArray17, strokeArray18, shapeArray34);
        java.awt.Shape shape36 = defaultDrawingSupplier35.getNextShape();
        java.lang.Object obj37 = defaultDrawingSupplier35.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        org.jfree.data.RangeType rangeType54 = org.jfree.data.RangeType.FULL;
        java.lang.String str55 = rangeType54.toString();
        numberAxis42.setRangeType(rangeType54);
        java.awt.Shape shape57 = null;
        try {
            numberAxis42.setRightArrow(shape57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RangeType.FULL" + "'", str55.equals("RangeType.FULL"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        barRenderer0.setSeriesCreateEntities(15, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        java.awt.Stroke stroke26 = jFreeChart21.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart21.addProgressListener(chartProgressListener27);
        java.lang.Object obj29 = jFreeChart21.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        java.awt.Stroke stroke4 = categoryAxis0.getAxisLineStroke();
        java.lang.String str5 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        double double3 = rectangleInsets1.extendHeight((double) 1.0f);
        double double5 = rectangleInsets1.calculateBottomInset((double) 'a');
        double double6 = rectangleInsets1.getTop();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            rectangleInsets1.trim(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("TextBlockAnchor.BOTTOM_CENTER", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        int int19 = color17.getBlue();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 192 + "'", int19 == 192);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        numberAxis23.setAutoRange(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        org.jfree.data.RangeType rangeType54 = org.jfree.data.RangeType.FULL;
        java.lang.String str55 = rangeType54.toString();
        numberAxis42.setRangeType(rangeType54);
        java.lang.String str57 = numberAxis42.getLabel();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RangeType.FULL" + "'", str55.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleAnchor.CENTER" + "'", str57.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) (byte) -1);
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range6 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toRangeHeight(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle1.getSources();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint7 = textTitle6.getPaint();
        boolean boolean8 = textTitle6.getExpandToFitSpace();
        textTitle6.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint20 = textFragment19.getPaint();
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font17, paint20, (float) ' ');
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("10", font17, (java.awt.Paint) color23, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        categoryPlot26.setRangeAxis((int) (byte) 100, valueAxis28, true);
        java.awt.Stroke stroke31 = categoryPlot26.getOutlineStroke();
        categoryPlot26.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("", font17, (org.jfree.chart.plot.Plot) categoryPlot26, false);
        jFreeChart35.setTextAntiAlias(true);
        java.awt.Image image38 = jFreeChart35.getBackgroundImage();
        int int39 = jFreeChart35.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart35.getCategoryPlot();
        textTitle6.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart35);
        org.jfree.chart.event.ChartProgressListener chartProgressListener42 = null;
        jFreeChart35.removeProgressListener(chartProgressListener42);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart35);
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("hi!");
        try {
            jFreeChart35.setTextAntiAlias((java.lang.Object) labelBlock46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.block.LabelBlock@2e3a3f44 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(image38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(categoryPlot40);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        float float5 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean8 = barRenderer6.getSeriesCreateEntities(0);
        java.lang.Boolean boolean10 = barRenderer6.getSeriesVisible(15);
        boolean boolean11 = barRenderer6.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke14 = barRenderer6.getItemStroke((int) (byte) 0, (int) (short) 1);
        categoryAxis0.setTickMarkStroke(stroke14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint19 = textTitle18.getPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str22 = rectangleInsets21.toString();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder(paint19, stroke20, rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = lineBorder23.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range32 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint(range29, range32);
        double double34 = range32.getLowerBound();
        numberAxis26.setDefaultAutoRange(range32);
        numberAxis26.setLowerBound(100.0d);
        boolean boolean38 = numberAxis26.isTickLabelsVisible();
        numberAxis26.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = legendTitle42.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str45 = rectangleInsets44.toString();
        legendTitle42.setItemLabelPadding(rectangleInsets44);
        legendTitle42.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D49 = legendTitle42.getBounds();
        numberAxis26.setUpArrow((java.awt.Shape) rectangle2D49);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets24.createInsetRectangle(rectangle2D49, true, false);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint55 = textTitle54.getPaint();
        java.awt.Stroke stroke56 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str58 = rectangleInsets57.toString();
        org.jfree.chart.block.LineBorder lineBorder59 = new org.jfree.chart.block.LineBorder(paint55, stroke56, rectangleInsets57);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = lineBorder59.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range65 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range68 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint(range65, range68);
        double double70 = range68.getLowerBound();
        numberAxis62.setDefaultAutoRange(range68);
        numberAxis62.setLowerBound(100.0d);
        boolean boolean74 = numberAxis62.isTickLabelsVisible();
        numberAxis62.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource77 = null;
        org.jfree.chart.title.LegendTitle legendTitle78 = new org.jfree.chart.title.LegendTitle(legendItemSource77);
        org.jfree.chart.util.VerticalAlignment verticalAlignment79 = legendTitle78.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str81 = rectangleInsets80.toString();
        legendTitle78.setItemLabelPadding(rectangleInsets80);
        legendTitle78.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D85 = legendTitle78.getBounds();
        numberAxis62.setUpArrow((java.awt.Shape) rectangle2D85);
        java.awt.geom.Rectangle2D rectangle2D89 = rectangleInsets60.createInsetRectangle(rectangle2D85, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo91 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo91);
        java.awt.geom.Rectangle2D rectangle2D93 = null;
        plotRenderingInfo92.setPlotArea(rectangle2D93);
        java.lang.Object obj95 = plotRenderingInfo92.clone();
        try {
            org.jfree.chart.axis.AxisState axisState96 = categoryAxis0.draw(graphics2D16, (double) 192, rectangle2D53, rectangle2D89, rectangleEdge90, plotRenderingInfo92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str22.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str45.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str58.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.0d + "'", double70 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(verticalAlignment79);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str81.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertNotNull(obj95);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        float float26 = jFreeChart21.getBackgroundImageAlpha();
        java.lang.Object obj27 = jFreeChart21.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint8 = textTitle7.getPaint();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str11 = rectangleInsets10.toString();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint8, stroke9, rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = lineBorder12.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range18 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range21 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range18, range21);
        double double23 = range21.getLowerBound();
        numberAxis15.setDefaultAutoRange(range21);
        numberAxis15.setLowerBound(100.0d);
        boolean boolean27 = numberAxis15.isTickLabelsVisible();
        numberAxis15.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = legendTitle31.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str34 = rectangleInsets33.toString();
        legendTitle31.setItemLabelPadding(rectangleInsets33);
        legendTitle31.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle31.getBounds();
        numberAxis15.setUpArrow((java.awt.Shape) rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets13.createInsetRectangle(rectangle2D38, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range47 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range50 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint(range47, range50);
        double double52 = range50.getLowerBound();
        numberAxis44.setDefaultAutoRange(range50);
        numberAxis44.setLowerBound(100.0d);
        boolean boolean56 = numberAxis44.isTickLabelsVisible();
        numberAxis44.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle(legendItemSource59);
        org.jfree.chart.util.VerticalAlignment verticalAlignment61 = legendTitle60.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str63 = rectangleInsets62.toString();
        legendTitle60.setItemLabelPadding(rectangleInsets62);
        legendTitle60.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D67 = legendTitle60.getBounds();
        numberAxis44.setUpArrow((java.awt.Shape) rectangle2D67);
        boolean boolean69 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D42, rectangle2D67);
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str34.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 10.0d + "'", double52 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(verticalAlignment61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str63.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        try {
            categoryPlot0.mapDatasetToDomainAxis((-1), (-16777214));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 10);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("VerticalAlignment.BOTTOM", graphics2D1, (float) 1, (float) 255, 98.0d, (float) (short) -1, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        java.lang.Object obj55 = null;
        boolean boolean56 = categoryItemEntity54.equals(obj55);
        java.lang.String str57 = categoryItemEntity54.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit59 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str61 = numberTickUnit59.valueToString((double) 10);
        int int62 = numberTickUnit59.getMinorTickCount();
        categoryItemEntity54.setRowKey((java.lang.Comparable) int62);
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = barRenderer64.getURLGenerator(0, (int) (short) 10);
        barRenderer64.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition72 = barRenderer64.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator73 = null;
        barRenderer64.setBaseURLGenerator(categoryURLGenerator73);
        java.awt.Font font77 = barRenderer64.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape80 = barRenderer64.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color81 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic82 = new org.jfree.chart.title.LegendGraphic(shape80, (java.awt.Paint) color81);
        boolean boolean83 = categoryItemEntity54.equals((java.lang.Object) shape80);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "10" + "'", str61.equals("10"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(categoryURLGenerator67);
        org.junit.Assert.assertNotNull(itemLabelPosition72);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range6 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range3, range6);
        double double8 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range3, (double) 0.5f);
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "RangeType.FULL", (java.lang.Object) rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 25.0d + "'", double8 == 25.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.setBackgroundImageAlignment((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot40.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot40.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder44);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(sortOrder44);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemToolTipGenerator();
        double double13 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font2);
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        labelBlock8.setPaint(paint9);
        java.awt.Graphics2D graphics2D11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = labelBlock8.arrange(graphics2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) -1);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryTick5.getRotationAnchor();
        org.jfree.chart.text.TextBlock textBlock7 = categoryTick5.getLabel();
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryTick5.getTextAnchor();
        java.lang.String str9 = categoryTick5.getText();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(textBlock7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8, false);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener11 = null;
        try {
            barRenderer0.removeChangeListener(rendererChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.setBackgroundImageAlignment((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double13 = rectangleInsets11.calculateRightInset((double) (byte) -1);
        double double15 = rectangleInsets11.calculateBottomInset((double) (short) 1);
        legendTitle10.setItemLabelPadding(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Font font2 = categoryPlot0.getNoDataMessageFont();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color5 };
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { paint7, color8 };
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { paint10 };
        java.awt.Paint[] paintArray12 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray11, paintArray12, strokeArray13, strokeArray14, shapeArray16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        java.awt.Stroke[] strokeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, rectangleAnchor24, 0.0d, (double) 100L);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape28);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape22, shape27, shape28, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray6, paintArray12, strokeArray20, strokeArray21, shapeArray37);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        categoryPlot40.setRangeAxis((int) (byte) 100, valueAxis42, true);
        java.awt.Stroke stroke45 = categoryPlot40.getOutlineStroke();
        categoryPlot0.setOutlineStroke(stroke45);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.util.List list4 = projectInfo0.getContributors();
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list6 = axisCollection5.getAxesAtTop();
        projectInfo0.setContributors(list6);
        java.util.Collection collection8 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        double double14 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { paint15, color16 };
        java.awt.Paint paint18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { paint18 };
        java.awt.Paint[] paintArray20 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray21 = null;
        java.awt.Stroke[] strokeArray22 = new java.awt.Stroke[] {};
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray24 = new java.awt.Shape[] { shape23 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray19, paintArray20, strokeArray21, strokeArray22, shapeArray24);
        java.awt.Paint paint26 = defaultDrawingSupplier25.getNextOutlinePaint();
        java.awt.Shape shape27 = defaultDrawingSupplier25.getNextShape();
        numberAxis1.setLeftArrow(shape27);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint3 = textTitle2.getPaint();
        boolean boolean4 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str8 = verticalAlignment7.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment7, (double) 'a', (double) (byte) 100);
        columnArrangement11.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean14 = columnArrangement11.equals((java.lang.Object) columnArrangement13);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str8.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        size2D0.setWidth((double) 192);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        java.lang.Boolean boolean13 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(true, false);
        java.lang.Boolean boolean18 = barRenderer0.getSeriesItemLabelsVisible((-254));
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelWidthType.RANGE", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer1.getURLGenerator(0, (int) (short) 10);
        barRenderer1.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer1.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer1.setBaseURLGenerator(categoryURLGenerator10);
        java.awt.Font font14 = barRenderer1.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape17 = barRenderer1.getItemShape((int) (short) 100, (int) (byte) -1);
        barRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer1.notifyListeners(rendererChangeEvent20);
        java.awt.Shape shape24 = barRenderer1.getItemShape((int) '#', 10);
        boolean boolean25 = rangeType0.equals((java.lang.Object) shape24);
        org.jfree.data.Range range28 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range31 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range28, range31);
        boolean boolean33 = rangeType0.equals((java.lang.Object) rectangleConstraint32);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = itemLabelPosition2.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition2.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition2.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor5, textAnchor7, 35.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        java.awt.Font font15 = categoryPlot9.getNoDataMessageFont();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        categoryPlot9.setDataset(15, categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range52 = numberAxis51.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = barRenderer53.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        barRenderer53.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer53);
        java.lang.String str61 = numberAxis51.getLabel();
        org.jfree.data.Range range62 = numberAxis51.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent63 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis51);
        int int64 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis51);
        numberAxis51.setVerticalTickLabels(true);
        double double67 = numberAxis51.getUpperMargin();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(categoryURLGenerator56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleAnchor.CENTER" + "'", str61.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.05d + "'", double67 == 0.05d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        legendGraphic18.setLine(shape20);
        legendGraphic18.setShapeOutlineVisible(true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.addObject((java.lang.Comparable) '4', (java.lang.Object) 10L);
        int int5 = keyedObjects0.getIndex((java.lang.Comparable) 500.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        java.lang.Boolean boolean4 = barRenderer0.getSeriesVisible(15);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getAlpha();
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        boolean boolean11 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.centerRange(98.0d);
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) -1);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryTick5.getRotationAnchor();
        org.jfree.chart.text.TextBlock textBlock7 = categoryTick5.getLabel();
        java.lang.String str8 = categoryTick5.toString();
        java.lang.Comparable comparable9 = categoryTick5.getCategory();
        java.lang.String str10 = categoryTick5.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(textBlock7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (short) 0);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) '4');
        double double2 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot11.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot11.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(500, axisLocation16, true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation16.getOpposite();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        java.awt.Font font15 = categoryPlot9.getNoDataMessageFont();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        categoryPlot9.setDataset(15, categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range52 = numberAxis51.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = barRenderer53.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        barRenderer53.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer53);
        java.lang.String str61 = numberAxis51.getLabel();
        org.jfree.data.Range range62 = numberAxis51.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent63 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis51);
        int int64 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis51);
        double double65 = numberAxis51.getUpperMargin();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(categoryURLGenerator56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleAnchor.CENTER" + "'", str61.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.05d + "'", double65 == 0.05d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str4 = numberTickUnit2.valueToString((double) (byte) 10);
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        keyedObjects0.addObject((java.lang.Comparable) numberTickUnit2, (java.lang.Object) rectangleConstraint7);
        java.lang.Comparable comparable9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer10.getURLGenerator(0, (int) (short) 10);
        barRenderer10.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer10.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint20 = barRenderer10.getSeriesOutlinePaint((-1));
        boolean boolean21 = barRenderer10.isDrawBarOutline();
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint28 = textFragment27.getPaint();
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font25, paint28, (float) ' ');
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("10", font25, (java.awt.Paint) color31, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        categoryPlot34.setRangeAxis((int) (byte) 100, valueAxis36, true);
        java.awt.Stroke stroke39 = categoryPlot34.getOutlineStroke();
        categoryPlot34.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", font25, (org.jfree.chart.plot.Plot) categoryPlot34, false);
        barRenderer10.setBaseItemLabelFont(font25);
        keyedObjects0.addObject(comparable9, (java.lang.Object) barRenderer10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint9 = textTitle8.getPaint();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str12 = rectangleInsets11.toString();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder(paint9, stroke10, rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range19 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range22 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range19, range22);
        double double24 = range22.getLowerBound();
        numberAxis16.setDefaultAutoRange(range22);
        numberAxis16.setLowerBound(100.0d);
        boolean boolean28 = numberAxis16.isTickLabelsVisible();
        numberAxis16.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = legendTitle32.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str35 = rectangleInsets34.toString();
        legendTitle32.setItemLabelPadding(rectangleInsets34);
        legendTitle32.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle32.getBounds();
        numberAxis16.setUpArrow((java.awt.Shape) rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets14.createInsetRectangle(rectangle2D39, true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState48 = barRenderer0.initialise(graphics2D7, rectangle2D43, categoryPlot44, 1, plotRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str35.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8, false);
        int int11 = barRenderer0.getColumnCount();
        java.awt.Color color13 = java.awt.Color.YELLOW;
        barRenderer0.setSeriesOutlinePaint(100, (java.awt.Paint) color13);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        textTitle0.setPaint((java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color7 = java.awt.Color.green;
        float[] floatArray13 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        java.lang.Object obj15 = textTitle0.draw(graphics2D5, rectangle2D6, (java.lang.Object) color7);
        java.awt.Paint paint16 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint14 = textFragment13.getPaint();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font11, paint14, (float) ' ');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("10", font11, (java.awt.Paint) color17, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot20.setRangeAxis((int) (byte) 100, valueAxis22, true);
        java.awt.Stroke stroke25 = categoryPlot20.getOutlineStroke();
        categoryPlot20.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) categoryPlot20, false);
        jFreeChart29.setTextAntiAlias(true);
        java.awt.Image image32 = jFreeChart29.getBackgroundImage();
        int int33 = jFreeChart29.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = jFreeChart29.getCategoryPlot();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        java.awt.RenderingHints renderingHints36 = null;
        try {
            jFreeChart29.setRenderingHints(renderingHints36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(categoryPlot34);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.addObject((java.lang.Comparable) '4', (java.lang.Object) 10L);
        java.lang.Object obj4 = keyedObjects0.clone();
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset(0);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint17 = textFragment16.getPaint();
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font14, paint17, (float) ' ');
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("10", font14, (java.awt.Paint) color20, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        categoryPlot23.setRangeAxis((int) (byte) 100, valueAxis25, true);
        java.awt.Stroke stroke28 = categoryPlot23.getOutlineStroke();
        categoryPlot23.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", font14, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart32.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener35 = null;
        jFreeChart32.addProgressListener(chartProgressListener35);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart32);
        org.jfree.chart.event.ChartChangeListener chartChangeListener38 = null;
        try {
            jFreeChart32.removeChangeListener(chartChangeListener38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart21.getCategoryPlot();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getRangeMarkers((-1), layer28);
        java.lang.Object obj30 = categoryPlot26.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryPlot26);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str4 = numberTickUnit2.valueToString((double) (byte) 10);
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        keyedObjects0.addObject((java.lang.Comparable) numberTickUnit2, (java.lang.Object) rectangleConstraint7);
        java.lang.Object obj9 = null;
        int int10 = numberTickUnit2.compareTo(obj9);
        boolean boolean12 = numberTickUnit2.equals((java.lang.Object) 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart21.createBufferedImage((int) (byte) 100, (int) (short) 10);
        float float25 = jFreeChart21.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        numberAxis1.setNegativeArrowVisible(true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        float float5 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean8 = barRenderer6.getSeriesCreateEntities(0);
        java.lang.Boolean boolean10 = barRenderer6.getSeriesVisible(15);
        boolean boolean11 = barRenderer6.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke14 = barRenderer6.getItemStroke((int) (byte) 0, (int) (short) 1);
        categoryAxis0.setTickMarkStroke(stroke14);
        double double16 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint3 = textTitle2.getPaint();
        boolean boolean4 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean9 = blockContainer7.equals((java.lang.Object) font8);
        java.util.List list10 = blockContainer7.getBlocks();
        boolean boolean11 = horizontalAlignment5.equals((java.lang.Object) blockContainer7);
        blockContainer7.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement13);
        java.util.List list15 = blockContainer14.getBlocks();
        try {
            blockContainer7.add((org.jfree.chart.block.Block) blockContainer14, (java.lang.Object) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint3 = textTitle2.getPaint();
        boolean boolean4 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = legendTitle8.getVerticalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = legendTitle11.getVerticalAlignment();
        boolean boolean13 = verticalAlignment9.equals((java.lang.Object) verticalAlignment12);
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment9, (double) (byte) 1, 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.configureDomainAxes();
        float float11 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setWidth((double) (short) 0);
        size2D0.setWidth((double) 100L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        barRenderer0.notifyListeners(rendererChangeEvent19);
        java.awt.Shape shape23 = barRenderer0.getItemShape((int) '#', 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean30 = categoryAxis26.equals((java.lang.Object) textAnchor29);
        java.awt.Paint paint31 = categoryAxis26.getLabelPaint();
        boolean boolean32 = categoryAxis26.isTickMarksVisible();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape33, rectangleAnchor34, 0.0d, (double) 100L);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape33, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity44 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis26, shape33, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        categoryPlot47.setRangeAxis((int) (byte) 100, valueAxis49, true);
        int int52 = categoryPlot47.getDatasetCount();
        java.awt.Font font53 = categoryPlot47.getNoDataMessageFont();
        java.lang.Number[] numberArray61 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray81 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray82 = new java.lang.Number[][] { numberArray61, numberArray66, numberArray71, numberArray76, numberArray81 };
        org.jfree.data.category.CategoryDataset categoryDataset83 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray82);
        boolean boolean84 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset83);
        org.jfree.data.Range range85 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset83);
        categoryPlot47.setDataset(15, categoryDataset83);
        java.lang.Comparable comparable88 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity89 = new org.jfree.chart.entity.CategoryItemEntity(shape33, "GradientPaintTransformType.CENTER_VERTICAL", "", categoryDataset83, (java.lang.Comparable) true, comparable88);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit91 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity93 = new org.jfree.chart.entity.CategoryItemEntity(shape23, "RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]", "ChartChangeEventType.NEW_DATASET", categoryDataset83, (java.lang.Comparable) (-1.0f), (java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(categoryDataset83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(range85);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) '#');
        java.lang.Boolean boolean4 = booleanList0.getBoolean((int) (short) 100);
        boolean boolean6 = booleanList0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        size2D3.height = 500;
        boolean boolean6 = legendItemCollection0.equals((java.lang.Object) 500);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer7.getURLGenerator(0, (int) (short) 10);
        barRenderer7.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer7.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer7.setBaseURLGenerator(categoryURLGenerator16);
        java.awt.Font font20 = barRenderer7.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape23 = barRenderer7.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color24);
        boolean boolean26 = legendItemCollection0.equals((java.lang.Object) legendGraphic25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("10", font2, (java.awt.Paint) color8, (float) (short) 0);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint16 = textFragment15.getPaint();
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font13, paint16, (float) ' ');
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint23 = textFragment22.getPaint();
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font20, paint23, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font13, paint23);
        org.jfree.chart.text.TextLine textLine27 = textBlock26.getLastLine();
        org.jfree.chart.text.TextFragment textFragment28 = null;
        textLine27.removeFragment(textFragment28);
        org.jfree.chart.text.TextFragment textFragment30 = null;
        textLine27.removeFragment(textFragment30);
        java.lang.Object obj32 = null;
        boolean boolean33 = textLine27.equals(obj32);
        boolean boolean34 = textFragment10.equals((java.lang.Object) boolean33);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(textLine27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        legendTitle1.setNotify(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getPadding();
        java.awt.Font font8 = legendTitle1.getItemFont();
        java.awt.Color color9 = java.awt.Color.red;
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        java.awt.color.ColorSpace colorSpace18 = color10.getColorSpace();
        float[] floatArray19 = null;
        float[] floatArray20 = color9.getColorComponents(colorSpace18, floatArray19);
        java.awt.Color color21 = color9.darker();
        legendTitle1.setItemPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) '4');
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape14);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean21 = chartEntity19.equals((java.lang.Object) color20);
        barRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color20, false);
        java.awt.Shape shape25 = barRenderer0.lookupSeriesShape((int) (short) 0);
        barRenderer0.setBaseCreateEntities(false);
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        java.lang.Object obj32 = barRenderer0.clone();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, 0.0d, (double) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str19 = axisLabelEntity18.getURLText();
        java.lang.String str20 = axisLabelEntity18.toString();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str19.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLabelEntity: label = null" + "'", str20.equals("AxisLabelEntity: label = null"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        double double9 = itemLabelPosition8.getAngle();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlock textBlock5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick9 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock5, textBlockAnchor6, textAnchor7, (double) (short) -1);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.BOTTOM_CENTER", graphics2D1, 0.0f, (float) 15, textAnchor7, 0.0d, (float) '#', (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        int int4 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color2 };
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { paint7 };
        java.awt.Paint[] paintArray9 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray10 = null;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray8, paintArray9, strokeArray10, strokeArray11, shapeArray13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke15, stroke16 };
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, rectangleAnchor21, 0.0d, (double) 100L);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape25);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] { shape19, shape24, shape25, shape33 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray3, paintArray9, strokeArray17, strokeArray18, shapeArray34);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str39 = numberTickUnit37.valueToString((double) (byte) 10);
        org.jfree.data.KeyedObjects keyedObjects40 = new org.jfree.data.KeyedObjects();
        boolean boolean41 = numberTickUnit37.equals((java.lang.Object) keyedObjects40);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        java.awt.Paint paint45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle44.setBackgroundPaint(paint45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray48 = new org.jfree.chart.LegendItemSource[] { legendItemSource47 };
        legendTitle44.setSources(legendItemSourceArray48);
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment53 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint54 = textFragment53.getPaint();
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font51, paint54, (float) ' ');
        legendTitle44.setItemFont(font51);
        boolean boolean58 = legendTitle44.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle44.setPosition(rectangleEdge59);
        keyedObjects40.setObject((java.lang.Comparable) false, (java.lang.Object) legendTitle44);
        boolean boolean62 = defaultDrawingSupplier35.equals((java.lang.Object) legendTitle44);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(legendItemSourceArray48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
        java.awt.Color color4 = java.awt.Color.green;
        float[] floatArray10 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray11 = color4.getRGBColorComponents(floatArray10);
        boolean boolean12 = categoryLabelPositions0.equals((java.lang.Object) floatArray10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition13);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = categoryLabelPosition15.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = categoryLabelPosition15.getWidthType();
        org.jfree.chart.text.TextAnchor textAnchor18 = categoryLabelPosition15.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition15);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        java.awt.Stroke stroke11 = categoryPlot6.getOutlineStroke();
        categoryPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setCategoryMargin((double) '4');
        java.awt.Stroke stroke18 = categoryAxis15.getTickMarkStroke();
        categoryPlot6.setDomainAxis((int) (byte) 100, categoryAxis15, false);
        categoryPlot0.setDomainAxis(0, categoryAxis15, false);
        java.lang.String str23 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setAnchorValue((double) 100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot6.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo15, point2D16);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint21 = textTitle20.getPaint();
        boolean boolean22 = itemLabelAnchor19.equals((java.lang.Object) paint21);
        barRenderer0.setBasePaint(paint21);
        double double24 = barRenderer0.getItemMargin();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0, obj1);
        java.lang.Object obj3 = keyedObject2.clone();
        java.lang.Object obj4 = keyedObject2.getObject();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        boolean boolean13 = barRenderer0.isItemLabelVisible(10, (-1));
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer15.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor20 = itemLabelPosition19.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = itemLabelPosition19.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor22 = itemLabelPosition19.getRotationAnchor();
        barRenderer15.setNegativeItemLabelPositionFallback(itemLabelPosition19);
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor24);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition25, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(itemLabelAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 1.0f, "100", textAnchor3, textAnchor4, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot8.getRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int13 = color12.getAlpha();
        java.awt.Color color14 = color12.darker();
        int int15 = color14.getTransparency();
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = axisLocation17.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation17, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        java.lang.Object obj55 = null;
        boolean boolean56 = categoryItemEntity54.equals(obj55);
        java.lang.Comparable comparable57 = categoryItemEntity54.getRowKey();
        java.lang.Comparable comparable58 = null;
        categoryItemEntity54.setColumnKey(comparable58);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + (byte) 1 + "'", comparable57.equals((byte) 1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        java.lang.Object obj55 = null;
        boolean boolean56 = categoryItemEntity54.equals(obj55);
        java.lang.String str57 = categoryItemEntity54.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit59 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str61 = numberTickUnit59.valueToString((double) 10);
        int int62 = numberTickUnit59.getMinorTickCount();
        categoryItemEntity54.setRowKey((java.lang.Comparable) int62);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer64 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType65 = standardGradientPaintTransformer64.getType();
        boolean boolean66 = categoryItemEntity54.equals((java.lang.Object) standardGradientPaintTransformer64);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "10" + "'", str61.equals("10"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        boolean boolean4 = flowArrangement0.equals((java.lang.Object) '#');
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle5.getPadding();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint8 = textTitle7.getPaint();
        boolean boolean9 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle7.getHorizontalAlignment();
        textTitle5.setHorizontalAlignment(horizontalAlignment10);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean14 = blockContainer12.equals((java.lang.Object) font13);
        java.util.List list15 = blockContainer12.getBlocks();
        boolean boolean16 = horizontalAlignment10.equals((java.lang.Object) blockContainer12);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, (double) 'a');
        org.jfree.data.Range range23 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range23, range26);
        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range23, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint20.toRangeWidth(range29);
        org.jfree.chart.util.Size2D size2D31 = flowArrangement0.arrange(blockContainer12, graphics2D17, rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(size2D31);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryItemEntity54.getDataset();
        java.lang.String str56 = categoryItemEntity54.toString();
        java.lang.String str57 = categoryItemEntity54.toString();
        categoryItemEntity54.setColumnKey((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(categoryDataset55);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        java.lang.Boolean boolean4 = barRenderer0.getSeriesVisible(15);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setCategoryMargin((double) '4');
        java.awt.Stroke stroke8 = categoryAxis5.getTickMarkStroke();
        barRenderer0.setBaseOutlineStroke(stroke8, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean6 = blockContainer4.equals((java.lang.Object) font5);
        numberAxis1.setTickLabelFont(font5);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset36, true);
        numberAxis1.setRange(range40);
        org.jfree.data.Range range44 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range47 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint(range44, range47);
        boolean boolean50 = range44.contains((double) 500.0f);
        numberAxis1.setRangeWithMargins(range44, true, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot11.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot11.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(500, axisLocation16, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation19);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        java.lang.Boolean boolean13 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Paint paint18 = barRenderer0.lookupSeriesOutlinePaint(100);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        legendTitle1.setNotify(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getPadding();
        legendTitle1.setMargin(2.0d, 3.0d, (double) (short) -1, (double) (-16777214));
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) "{0}");
        java.lang.Number number9 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) "CategoryLabelWidthType.RANGE", (java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.awt.Color color52 = java.awt.Color.green;
        float[] floatArray58 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray59 = color52.getRGBColorComponents(floatArray58);
        java.awt.color.ColorSpace colorSpace60 = color52.getColorSpace();
        barRenderer44.setBaseOutlinePaint((java.awt.Paint) color52, true);
        double double63 = barRenderer44.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator66 = barRenderer44.getURLGenerator((int) (byte) -1, (-254));
        double double67 = barRenderer44.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(colorSpace60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.2d + "'", double63 == 0.2d);
        org.junit.Assert.assertNull(categoryURLGenerator66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("GradientPaintTransformType.CENTER_VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key GradientPaintTransformType.CENTER_VERTICAL");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        int int11 = barRenderer0.getRowCount();
        barRenderer0.setSeriesItemLabelsVisible(500, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        org.jfree.data.RangeType rangeType54 = org.jfree.data.RangeType.FULL;
        java.lang.String str55 = rangeType54.toString();
        numberAxis42.setRangeType(rangeType54);
        org.jfree.data.Range range57 = numberAxis42.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RangeType.FULL" + "'", str55.equals("RangeType.FULL"));
        org.junit.Assert.assertNotNull(range57);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint9 = textTitle8.getPaint();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str12 = rectangleInsets11.toString();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder(paint9, stroke10, rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range19 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range22 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range19, range22);
        double double24 = range22.getLowerBound();
        numberAxis16.setDefaultAutoRange(range22);
        numberAxis16.setLowerBound(100.0d);
        boolean boolean28 = numberAxis16.isTickLabelsVisible();
        numberAxis16.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = legendTitle32.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str35 = rectangleInsets34.toString();
        legendTitle32.setItemLabelPadding(rectangleInsets34);
        legendTitle32.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle32.getBounds();
        numberAxis16.setUpArrow((java.awt.Shape) rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets14.createInsetRectangle(rectangle2D39, true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot44.getRangeAxis((int) (short) 100);
        categoryPlot44.setDomainGridlinesVisible(true);
        double double49 = categoryPlot44.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection50 = categoryPlot44.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot44.getRangeAxisEdge();
        double double52 = categoryAxis0.getCategoryEnd(192, 3, rectangle2D43, rectangleEdge51);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str35.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        jFreeChart21.setBackgroundImageAlpha((float) 'a');
        java.awt.Paint paint26 = jFreeChart21.getBorderPaint();
        org.jfree.chart.event.ChartChangeListener chartChangeListener27 = null;
        try {
            jFreeChart21.addChangeListener(chartChangeListener27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer1.getURLGenerator(0, (int) (short) 10);
        barRenderer1.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer1.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer1.setBaseURLGenerator(categoryURLGenerator10);
        java.awt.Font font14 = barRenderer1.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape17 = barRenderer1.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        boolean boolean20 = verticalAlignment0.equals((java.lang.Object) shape17);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7, true);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection11 = categoryPlot5.getDomainMarkers(layer10);
        try {
            categoryPlot0.addDomainMarker((int) (byte) 100, categoryMarker4, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setID("1");
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle5.setBackgroundPaint(paint6);
        labelBlock1.setPaint(paint6);
        java.awt.Paint paint9 = labelBlock1.getPaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint12 = textTitle11.getPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str15 = rectangleInsets14.toString();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder(paint12, stroke13, rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = lineBorder16.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range22 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range25 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range22, range25);
        double double27 = range25.getLowerBound();
        numberAxis19.setDefaultAutoRange(range25);
        numberAxis19.setLowerBound(100.0d);
        boolean boolean31 = numberAxis19.isTickLabelsVisible();
        numberAxis19.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = legendTitle35.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str38 = rectangleInsets37.toString();
        legendTitle35.setItemLabelPadding(rectangleInsets37);
        legendTitle35.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle35.getBounds();
        numberAxis19.setUpArrow((java.awt.Shape) rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets17.createInsetRectangle(rectangle2D42, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range51 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range54 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range51, range54);
        double double56 = range54.getLowerBound();
        numberAxis48.setDefaultAutoRange(range54);
        numberAxis48.setLowerBound(100.0d);
        boolean boolean60 = numberAxis48.isTickLabelsVisible();
        numberAxis48.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource63 = null;
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle(legendItemSource63);
        org.jfree.chart.util.VerticalAlignment verticalAlignment65 = legendTitle64.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str67 = rectangleInsets66.toString();
        legendTitle64.setItemLabelPadding(rectangleInsets66);
        legendTitle64.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D71 = legendTitle64.getBounds();
        numberAxis48.setUpArrow((java.awt.Shape) rectangle2D71);
        boolean boolean73 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D46, rectangle2D71);
        try {
            labelBlock1.draw(graphics2D10, rectangle2D71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str15.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(verticalAlignment36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str38.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 10.0d + "'", double56 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(verticalAlignment65);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str67.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        java.lang.Boolean boolean4 = barRenderer0.getSeriesVisible(15);
        java.awt.Stroke stroke6 = barRenderer0.getSeriesOutlineStroke(255);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "VerticalAlignment.BOTTOM", "10", image4, "", "TextBlockAnchor.CENTER_LEFT", "RectangleAnchor.CENTER");
        projectInfo8.setCopyright("RectangleAnchor.CENTER");
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        org.jfree.chart.ui.Library[] libraryArray12 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '#');
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range4.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range4, (double) 0.5f);
        boolean boolean12 = objectList1.equals((java.lang.Object) range4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 25.0d + "'", double9 == 25.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        java.lang.Object obj4 = textTitle2.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle2.getMargin();
        double double7 = rectangleInsets5.calculateRightOutset((double) 10L);
        legendTitle1.setPadding(rectangleInsets5);
        java.awt.Font font9 = null;
        try {
            legendTitle1.setItemFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        boolean boolean53 = numberAxis42.isNegativeArrowVisible();
        numberAxis42.setUpperBound((double) 500.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = barRenderer0.getLegendItemToolTipGenerator();
        barRenderer0.setSeriesVisibleInLegend(10, (java.lang.Boolean) true, true);
        boolean boolean44 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 100);
        barRenderer0.setBaseCreateEntities(true, false);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle1.setBackgroundPaint(paint2);
        legendTitle1.setID("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = categoryLabelPosition7.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions6, categoryLabelPosition7);
        java.awt.Color color10 = java.awt.Color.green;
        float[] floatArray16 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        boolean boolean18 = categoryLabelPositions6.equals((java.lang.Object) floatArray16);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions6, categoryLabelPosition19);
        boolean boolean21 = legendTitle1.equals((java.lang.Object) categoryLabelPosition19);
        legendTitle1.setMargin(0.0d, 0.0d, (double) 500.0f, (double) 2);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) "{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str10 = numberTickUnit8.valueToString((double) 10);
        java.lang.String str12 = numberTickUnit8.valueToString((double) (short) 100);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset6, (java.lang.Comparable) numberTickUnit8, (double) '4');
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
        org.junit.Assert.assertNotNull(pieDataset14);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        numberAxis42.zoomRange((double) (byte) -1, (double) 0);
        org.jfree.data.RangeType rangeType56 = numberAxis42.getRangeType();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rangeType56);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray10 = new float[] { 100, 500.0f, 1, (short) 1, 0, 2.0f };
        float[] floatArray11 = color3.getComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (byte) 10, (int) (short) 0, 15, floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        double double14 = numberAxis1.getAutoRangeMinimumSize();
        numberAxis1.setLabel("1");
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        float float26 = jFreeChart21.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo29.getDataArea();
        try {
            jFreeChart21.draw(graphics2D27, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint18 = textFragment17.getPaint();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font15, paint18, (float) ' ');
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("10", font15, (java.awt.Paint) color21, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        categoryPlot24.setRangeAxis((int) (byte) 100, valueAxis26, true);
        java.awt.Stroke stroke29 = categoryPlot24.getOutlineStroke();
        categoryPlot24.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) categoryPlot24, false);
        barRenderer0.setBaseItemLabelFont(font15);
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        double double37 = barRenderer0.getItemMargin();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textBlock15.calculateDimensions(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(255);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        boolean boolean4 = booleanList0.equals((java.lang.Object) objectList3);
        booleanList0.setBoolean(1, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer0.getItemOutlineStroke(0, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint6 = textTitle5.getPaint();
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        textTitle5.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        boolean boolean13 = standardCategorySeriesLabelGenerator4.equals((java.lang.Object) (short) 1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = legendTitle15.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle15.setItemLabelPadding(rectangleInsets17);
        boolean boolean20 = standardCategorySeriesLabelGenerator4.equals((java.lang.Object) rectangleInsets17);
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator23, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.addObject((java.lang.Comparable) '4', (java.lang.Object) 10L);
        java.lang.Comparable comparable5 = keyedObjects0.getKey((int) (byte) 10);
        java.util.List list6 = keyedObjects0.getKeys();
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        double double2 = axisState1.getCursor();
        axisState1.cursorRight((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
        java.awt.Color color4 = java.awt.Color.green;
        float[] floatArray10 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray11 = color4.getRGBColorComponents(floatArray10);
        boolean boolean12 = categoryLabelPositions0.equals((java.lang.Object) floatArray10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str17 = textBlockAnchor16.toString();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType20 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str21 = categoryLabelWidthType20.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16, textAnchor18, (double) ' ', categoryLabelWidthType20, (float) 500);
        float float24 = categoryLabelPosition23.getWidthRatio();
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        boolean boolean26 = categoryLabelPosition23.equals((java.lang.Object) paint25);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions14, categoryLabelPosition23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = categoryLabelPosition23.getCategoryAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str17.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelWidthType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str21.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 500.0f + "'", float24 == 500.0f);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) '4', (float) 100, textAnchor4, (double) 10.0f, textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        legendItem12.setDatasetIndex((int) (short) -1);
        int int16 = legendItem12.getDatasetIndex();
        java.awt.Paint paint17 = legendItem12.getFillPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot11.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot11.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(500, axisLocation16, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        float float16 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        defaultStatisticalCategoryDataset0.setGroup(datasetGroup2);
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "PlotOrientation.VERTICAL");
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle5.getPadding();
        double double8 = rectangleInsets6.extendHeight((double) 1.0f);
        double double10 = rectangleInsets6.calculateBottomInset((double) 'a');
        double double12 = rectangleInsets6.calculateLeftInset((double) 10L);
        categoryPlot0.setInsets(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 100);
        double double2 = axisState1.getCursor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        textTitle10.setPaint((java.awt.Paint) color12);
        java.awt.Color color15 = color12.darker();
        barRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color15, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getAlpha();
        java.awt.Color color21 = color19.darker();
        int int22 = color21.getTransparency();
        barRenderer0.setSeriesPaint((int) (short) 10, (java.awt.Paint) color21, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 10);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape14);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean21 = chartEntity19.equals((java.lang.Object) color20);
        barRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color20, false);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font24, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = barRenderer0.getItemLabelGenerator((int) ' ', 1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        double double4 = rectangleInsets2.extendWidth((double) (short) 100);
        double double6 = rectangleInsets2.extendHeight((double) 2.0f);
        double double8 = rectangleInsets2.extendWidth((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        textTitle10.setPaint((java.awt.Paint) color12);
        java.awt.Color color15 = color12.darker();
        barRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color15, false);
        boolean boolean19 = barRenderer0.isSeriesItemLabelsVisible((int) (short) -1);
        boolean boolean21 = barRenderer0.isSeriesVisible((int) (byte) -1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        java.lang.String str10 = sortOrder8.toString();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "SortOrder.ASCENDING" + "'", str10.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint14 = textFragment13.getPaint();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font11, paint14, (float) ' ');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("10", font11, (java.awt.Paint) color17, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot20.setRangeAxis((int) (byte) 100, valueAxis22, true);
        java.awt.Stroke stroke25 = categoryPlot20.getOutlineStroke();
        categoryPlot20.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) categoryPlot20, false);
        jFreeChart29.setTextAntiAlias(true);
        java.awt.Image image32 = jFreeChart29.getBackgroundImage();
        int int33 = jFreeChart29.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = jFreeChart29.getCategoryPlot();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_CYAN;
        textTitle0.setPaint((java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(categoryPlot34);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        barRenderer0.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color4 };
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { paint8, color9 };
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { paint11 };
        java.awt.Paint[] paintArray13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray14 = null;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] { shape16 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray12, paintArray13, strokeArray14, strokeArray15, shapeArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, rectangleAnchor25, 0.0d, (double) 100L);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape29);
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray38 = new java.awt.Shape[] { shape23, shape28, shape29, shape37 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray7, paintArray13, strokeArray21, strokeArray22, shapeArray38);
        java.awt.Shape shape40 = defaultDrawingSupplier39.getNextShape();
        java.awt.Color color41 = java.awt.Color.red;
        java.awt.Color color42 = java.awt.Color.green;
        float[] floatArray48 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray49 = color42.getRGBColorComponents(floatArray48);
        java.awt.color.ColorSpace colorSpace50 = color42.getColorSpace();
        float[] floatArray51 = null;
        float[] floatArray52 = color41.getColorComponents(colorSpace50, floatArray51);
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "1", "GradientPaintTransformType.CENTER_VERTICAL", shape40, (java.awt.Paint) color41);
        boolean boolean54 = legendItem53.isLineVisible();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer55 = legendItem53.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(colorSpace50);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer55);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        int int27 = jFreeChart21.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        double double30 = axisState29.getCursor();
        java.util.List list31 = axisState29.getTicks();
        jFreeChart21.setSubtitles(list31);
        int int33 = jFreeChart21.getSubtitleCount();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightInset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateBottomInset((double) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7, true);
        int int10 = categoryPlot5.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot5.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo14, point2D15);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot5.getRendererForDataset(categoryDataset45);
        org.jfree.data.category.CategoryDataset categoryDataset49 = categoryPlot5.getDataset((int) (byte) 100);
        categoryPlot5.clearDomainAxes();
        boolean boolean51 = rectangleInsets0.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNull(categoryDataset49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint7 = textTitle6.getPaint();
        boolean boolean8 = textTitle6.getExpandToFitSpace();
        textTitle6.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle6.getMargin();
        categoryAxis0.setTickLabelInsets(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        java.awt.Stroke stroke12 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis9, false);
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        categoryAxis9.setUpperMargin((double) (short) 100);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint20 = textTitle19.getPaint();
        categoryAxis9.setAxisLinePaint(paint20);
        java.lang.String str23 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) "1");
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        float float10 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot10.getRenderer();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int15 = color14.getAlpha();
        java.awt.Color color16 = color14.darker();
        int int17 = color16.getTransparency();
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot10.getRangeAxisLocation();
        categoryPlot10.configureDomainAxes();
        categoryPlot10.setForegroundAlpha((float) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray30, numberArray35, numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray51);
        boolean boolean53 = axisLocation23.equals((java.lang.Object) "");
        categoryPlot10.setRangeAxisLocation(axisLocation23);
        categoryPlot0.setDomainAxisLocation(axisLocation23);
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot0.getDomainAxisLocation((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        java.lang.String str3 = rectangleAnchor0.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextBlock textBlock6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock6, textBlockAnchor7, textAnchor8, (double) (short) -1);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType12 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor4, textAnchor8, (double) (short) -1, categoryLabelWidthType12, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.RIGHT" + "'", str3.equals("RectangleAnchor.RIGHT"));
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer0.getItemOutlineStroke(0, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint6 = textTitle5.getPaint();
        boolean boolean7 = textTitle5.getExpandToFitSpace();
        textTitle5.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        boolean boolean13 = standardCategorySeriesLabelGenerator4.equals((java.lang.Object) (short) 1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = legendTitle15.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle15.setItemLabelPadding(rectangleInsets17);
        boolean boolean20 = standardCategorySeriesLabelGenerator4.equals((java.lang.Object) rectangleInsets17);
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        boolean boolean24 = barRenderer0.getItemVisible(3, (int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer5.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer5.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer5.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator13, false);
        java.awt.Stroke stroke17 = barRenderer5.lookupSeriesOutlineStroke((int) (byte) -1);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot20.setRangeAxis((int) (byte) 100, valueAxis22, true);
        int int25 = categoryPlot20.getDatasetCount();
        java.awt.Font font26 = categoryPlot20.getNoDataMessageFont();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray34, numberArray39, numberArray44, numberArray49, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray55);
        boolean boolean57 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset56);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset56);
        categoryPlot20.setDataset(15, categoryDataset56);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range63 = numberAxis62.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = barRenderer64.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = null;
        barRenderer64.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator69);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis60, (org.jfree.chart.axis.ValueAxis) numberAxis62, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer64);
        java.lang.String str72 = numberAxis62.getLabel();
        org.jfree.data.Range range73 = numberAxis62.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent74 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis62);
        org.jfree.chart.plot.Marker marker75 = null;
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint77 = textTitle76.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D78 = textTitle76.getBounds();
        barRenderer5.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis62, marker75, rectangle2D78);
        int int80 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis62);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNull(categoryURLGenerator67);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "RectangleAnchor.CENTER" + "'", str72.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNull(paint77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        float float6 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint10 = textTitle9.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle9.getBounds();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint13 = textTitle12.getPaint();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str16 = rectangleInsets15.toString();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder(paint13, stroke14, rectangleInsets15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = lineBorder17.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range23 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range23, range26);
        double double28 = range26.getLowerBound();
        numberAxis20.setDefaultAutoRange(range26);
        numberAxis20.setLowerBound(100.0d);
        boolean boolean32 = numberAxis20.isTickLabelsVisible();
        numberAxis20.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = legendTitle36.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str39 = rectangleInsets38.toString();
        legendTitle36.setItemLabelPadding(rectangleInsets38);
        legendTitle36.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle36.getBounds();
        numberAxis20.setUpArrow((java.awt.Shape) rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets18.createInsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis50 = categoryPlot48.getRangeAxis((int) (short) 100);
        categoryPlot48.setDomainGridlinesVisible(true);
        double double53 = categoryPlot48.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection54 = categoryPlot48.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot48.getRangeAxisEdge();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        plotRenderingInfo57.setPlotArea(rectangle2D58);
        try {
            org.jfree.chart.axis.AxisState axisState60 = categoryAxis0.draw(graphics2D7, (double) 0L, rectangle2D11, rectangle2D47, rectangleEdge55, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str16.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str39.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = barRenderer0.getLegendItemURLGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) 'a', (java.lang.Boolean) true);
        barRenderer0.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        defaultStatisticalCategoryDataset0.setGroup(datasetGroup2);
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.plot.Plot plot12 = categoryPlot6.getRootPlot();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) plot12);
        defaultStatisticalCategoryDataset0.validateObject();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot25.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent30);
        java.awt.Stroke stroke32 = categoryPlot25.getOutlineStroke();
        jFreeChart21.setBorderStroke(stroke32);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        java.awt.Stroke stroke26 = jFreeChart21.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint28 = textTitle27.getPaint();
        boolean boolean29 = textTitle27.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textTitle27.getHorizontalAlignment();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle27);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle33.setBackgroundPaint(paint34);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray37 = new org.jfree.chart.LegendItemSource[] { legendItemSource36 };
        legendTitle33.setSources(legendItemSourceArray37);
        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint43 = textFragment42.getPaint();
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font40, paint43, (float) ' ');
        legendTitle33.setItemFont(font40);
        boolean boolean47 = legendTitle33.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle33.setPosition(rectangleEdge48);
        jFreeChart21.addLegend(legendTitle33);
        jFreeChart21.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(legendItemSourceArray37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setSeriesURLGenerator(192, categoryURLGenerator5);
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        boolean boolean4 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        legendTitle1.setItemLabelPadding(rectangleInsets3);
        legendTitle1.setID("{0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle1.getPadding();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint15 = textFragment14.getPaint();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font12, paint15, (float) ' ');
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("10", font12, (java.awt.Paint) color18, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        categoryPlot21.setRangeAxis((int) (byte) 100, valueAxis23, true);
        java.awt.Stroke stroke26 = categoryPlot21.getOutlineStroke();
        categoryPlot21.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) categoryPlot21, false);
        jFreeChart30.setTextAntiAlias(true);
        java.awt.Image image33 = jFreeChart30.getBackgroundImage();
        jFreeChart30.setNotify(false);
        int int36 = jFreeChart30.getBackgroundImageAlignment();
        java.lang.Object obj37 = jFreeChart30.clone();
        java.awt.Paint paint38 = jFreeChart30.getBorderPaint();
        java.awt.Font font41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment43 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint44 = textFragment43.getPaint();
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font41, paint44, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font41);
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        labelBlock47.setPaint(paint48);
        jFreeChart30.setBackgroundPaint(paint48);
        legendTitle1.setItemPaint(paint48);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(image33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 15 + "'", int36 == 15);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint28 = textTitle27.getPaint();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str31 = rectangleInsets30.toString();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder(paint28, stroke29, rectangleInsets30);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = lineBorder32.getInsets();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint36 = textTitle35.getPaint();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str39 = rectangleInsets38.toString();
        org.jfree.chart.block.LineBorder lineBorder40 = new org.jfree.chart.block.LineBorder(paint36, stroke37, rectangleInsets38);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = lineBorder40.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range46 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range49 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(range46, range49);
        double double51 = range49.getLowerBound();
        numberAxis43.setDefaultAutoRange(range49);
        numberAxis43.setLowerBound(100.0d);
        boolean boolean55 = numberAxis43.isTickLabelsVisible();
        numberAxis43.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = legendTitle59.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str62 = rectangleInsets61.toString();
        legendTitle59.setItemLabelPadding(rectangleInsets61);
        legendTitle59.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D66 = legendTitle59.getBounds();
        numberAxis43.setUpArrow((java.awt.Shape) rectangle2D66);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets41.createInsetRectangle(rectangle2D66, true, false);
        lineBorder32.draw(graphics2D34, rectangle2D70);
        try {
            jFreeChart21.draw(graphics2D26, rectangle2D70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str31.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str39.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.0d + "'", double51 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(verticalAlignment60);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str62.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge();
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font2 = barRenderer0.getSeriesItemLabelFont(0);
        java.awt.Shape shape3 = barRenderer0.getBaseShape();
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer((int) 'a', categoryItemRenderer6, true);
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str12 = axisLocation11.toString();
        categoryPlot0.setRangeAxisLocation(0, axisLocation11, false);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str12.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint4 = textFragment3.getPaint();
        java.awt.Paint paint5 = textFragment3.getPaint();
        categoryAxis1.setAxisLinePaint(paint5);
        categoryAxis1.setLabelURL("100");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        defaultStatisticalCategoryDataset0.setGroup(datasetGroup2);
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.plot.Plot plot12 = categoryPlot6.getRootPlot();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) plot12);
        try {
            java.lang.Comparable comparable15 = defaultStatisticalCategoryDataset0.getRowKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        double double5 = categoryPlot0.getAnchorValue();
        int int6 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot8.setRangeAxis((int) (byte) 100, valueAxis10, true);
        int int13 = categoryPlot8.getDatasetCount();
        java.awt.Font font14 = categoryPlot8.getNoDataMessageFont();
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray22, numberArray27, numberArray32, numberArray37, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray43);
        boolean boolean45 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset44);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset44);
        categoryPlot8.setDataset(15, categoryDataset44);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        categoryPlot50.setRangeAxis((int) (byte) 100, valueAxis52, true);
        java.awt.Stroke stroke55 = categoryPlot50.getOutlineStroke();
        categoryPlot50.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis59.setCategoryMargin((double) '4');
        java.awt.Stroke stroke62 = categoryAxis59.getTickMarkStroke();
        categoryPlot50.setDomainAxis((int) (byte) 100, categoryAxis59, false);
        categoryAxis59.setCategoryLabelPositionOffset((int) '4');
        java.lang.String str68 = categoryAxis59.getCategoryLabelToolTip((java.lang.Comparable) "CategoryLabelWidthType.RANGE");
        categoryPlot8.setDomainAxis(10, categoryAxis59, false);
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis59, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(str68);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape14);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean21 = chartEntity19.equals((java.lang.Object) color20);
        barRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color20, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        barRenderer0.setSeriesURLGenerator((int) '#', categoryURLGenerator25, false);
        java.awt.Font font29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        barRenderer0.setSeriesItemLabelFont(192, font29, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator16);
        java.awt.Paint paint18 = barRenderer0.getBasePaint();
        barRenderer0.setBaseCreateEntities(false, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, 3.0d, (double) (short) 0);
        boolean boolean7 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) 3.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot8.getRangeAxis((int) (short) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint17 = textFragment16.getPaint();
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font14, paint17, (float) ' ');
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("10", font14, (java.awt.Paint) color20, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        categoryPlot23.setRangeAxis((int) (byte) 100, valueAxis25, true);
        java.awt.Stroke stroke28 = categoryPlot23.getOutlineStroke();
        categoryPlot23.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", font14, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart32.setTextAntiAlias(true);
        boolean boolean35 = jFreeChart32.getAntiAlias();
        boolean boolean36 = jFreeChart32.getAntiAlias();
        categoryPlot8.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart32);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot8.getDatasetRenderingOrder();
        boolean boolean39 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) categoryPlot8);
        int int40 = categoryPlot8.getDatasetCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 255, 0.0d);
        java.lang.Object obj3 = null;
        boolean boolean4 = size2D2.equals(obj3);
        size2D2.height = 10;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean6 = blockContainer4.equals((java.lang.Object) font5);
        numberAxis1.setTickLabelFont(font5);
        double double8 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("10", font9, (java.awt.Paint) color15, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        categoryPlot18.setRangeAxis((int) (byte) 100, valueAxis20, true);
        java.awt.Stroke stroke23 = categoryPlot18.getOutlineStroke();
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        categoryAxis0.setLabelFont(font9);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        org.jfree.data.RangeType rangeType54 = org.jfree.data.RangeType.FULL;
        java.lang.String str55 = rangeType54.toString();
        numberAxis42.setRangeType(rangeType54);
        org.jfree.data.RangeType rangeType57 = org.jfree.data.RangeType.FULL;
        java.lang.String str58 = rangeType57.toString();
        numberAxis42.setRangeType(rangeType57);
        numberAxis42.setRangeWithMargins(0.0d, 2.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RangeType.FULL" + "'", str55.equals("RangeType.FULL"));
        org.junit.Assert.assertNotNull(rangeType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RangeType.FULL" + "'", str58.equals("RangeType.FULL"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint(0);
        double double5 = barRenderer0.getItemMargin();
        java.awt.Paint paint6 = null;
        try {
            barRenderer0.setBaseFillPaint(paint6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        legendTitle1.setItemLabelPadding(rectangleInsets3);
        legendTitle1.setID("{0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle1.getPadding();
        double double10 = rectangleInsets8.calculateLeftOutset(25.0d);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape53, rectangleAnchor54, 0.0d, (double) 100L);
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.clone(shape57);
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape59, rectangleAnchor60, 0.0d, (double) 100L);
        java.awt.Shape shape67 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape59, (double) 100, (float) 'a', (float) 10L);
        boolean boolean68 = org.jfree.chart.util.ShapeUtilities.equal(shape58, shape59);
        numberAxis42.setDownArrow(shape59);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity72 = new org.jfree.chart.entity.TickLabelEntity(shape59, "Layer.BACKGROUND", "poly");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = categoryLabelPosition17.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions16, categoryLabelPosition17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = categoryLabelPosition21.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions20, categoryLabelPosition21);
        java.awt.Color color24 = java.awt.Color.green;
        float[] floatArray30 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray31 = color24.getRGBColorComponents(floatArray30);
        boolean boolean32 = categoryLabelPositions20.equals((java.lang.Object) floatArray30);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions34 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions20, categoryLabelPosition33);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions16, categoryLabelPosition33);
        boolean boolean36 = numberAxis1.equals((java.lang.Object) categoryLabelPosition33);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions34);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean7 = chartEntity5.equals((java.lang.Object) color6);
        chartEntity5.setURLText("RectangleAnchor.CENTER");
        java.lang.String str10 = chartEntity5.getURLText();
        chartEntity5.setToolTipText("TextBlockAnchor.BOTTOM_CENTER");
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = legendTitle14.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str17 = rectangleInsets16.toString();
        legendTitle14.setItemLabelPadding(rectangleInsets16);
        legendTitle14.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle14.getLegendItemGraphicEdge();
        boolean boolean23 = chartEntity5.equals((java.lang.Object) rectangleEdge22);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.CENTER" + "'", str10.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str17.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET");
        java.lang.String str2 = labelBlock1.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range10 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range7, range10);
        double double12 = range10.getLowerBound();
        numberAxis4.setDefaultAutoRange(range10);
        numberAxis4.setLowerBound(100.0d);
        boolean boolean16 = numberAxis4.isTickLabelsVisible();
        numberAxis4.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = legendTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str23 = rectangleInsets22.toString();
        legendTitle20.setItemLabelPadding(rectangleInsets22);
        legendTitle20.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle20.getBounds();
        numberAxis4.setUpArrow((java.awt.Shape) rectangle2D27);
        labelBlock1.setBounds(rectangle2D27);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str23.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str9 = numberTickUnit7.valueToString((double) 10);
        int int10 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 1);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        java.awt.Paint paint2 = null;
        textTitle0.setBackgroundPaint(paint2);
        org.junit.Assert.assertNull(paint1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint9 = textFragment8.getPaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, paint9, (float) ' ');
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("10", font6, (java.awt.Paint) color12, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot15.setRangeAxis((int) (byte) 100, valueAxis17, true);
        java.awt.Stroke stroke20 = categoryPlot15.getOutlineStroke();
        categoryPlot15.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        jFreeChart24.setTextAntiAlias(true);
        boolean boolean27 = jFreeChart24.getAntiAlias();
        boolean boolean28 = jFreeChart24.getAntiAlias();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Font font31 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker34 = null;
        try {
            categoryPlot0.addRangeMarker(marker34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape14);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean21 = chartEntity19.equals((java.lang.Object) color20);
        barRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color20, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        barRenderer0.setSeriesURLGenerator((int) '#', categoryURLGenerator25, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.setCategoryMargin((double) '4');
        java.awt.Stroke stroke32 = categoryAxis29.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke(255, stroke32);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        java.lang.Object obj20 = legendGraphic18.clone();
        boolean boolean21 = legendGraphic18.isLineVisible();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint18 = textFragment17.getPaint();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font15, paint18, (float) ' ');
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("10", font15, (java.awt.Paint) color21, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        categoryPlot24.setRangeAxis((int) (byte) 100, valueAxis26, true);
        java.awt.Stroke stroke29 = categoryPlot24.getOutlineStroke();
        categoryPlot24.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) categoryPlot24, false);
        barRenderer0.setBaseItemLabelFont(font15);
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 'a', (double) (byte) 1, (double) 15, (java.awt.Paint) color41);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color41, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        java.lang.Object obj27 = jFreeChart21.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        categoryPlot4.setRangeAxis((int) (byte) 100, valueAxis6, true);
        java.awt.Stroke stroke9 = categoryPlot4.getOutlineStroke();
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setCategoryMargin((double) '4');
        java.awt.Stroke stroke16 = categoryAxis13.getTickMarkStroke();
        categoryPlot4.setDomainAxis((int) (byte) 100, categoryAxis13, false);
        categoryAxis13.setCategoryLabelPositionOffset((int) '4');
        java.awt.Paint paint21 = categoryAxis13.getTickLabelPaint();
        categoryAxis13.setUpperMargin((double) 1);
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis13);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle27.setBackgroundPaint(paint28);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement30);
        legendTitle27.setWrapper(blockContainer31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle27.getItemLabelPadding();
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint35 = textTitle34.getPaint();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str38 = rectangleInsets37.toString();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder(paint35, stroke36, rectangleInsets37);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = lineBorder39.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range45 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range48 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint(range45, range48);
        double double50 = range48.getLowerBound();
        numberAxis42.setDefaultAutoRange(range48);
        numberAxis42.setLowerBound(100.0d);
        boolean boolean54 = numberAxis42.isTickLabelsVisible();
        numberAxis42.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        org.jfree.chart.util.VerticalAlignment verticalAlignment59 = legendTitle58.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str61 = rectangleInsets60.toString();
        legendTitle58.setItemLabelPadding(rectangleInsets60);
        legendTitle58.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D65 = legendTitle58.getBounds();
        numberAxis42.setUpArrow((java.awt.Shape) rectangle2D65);
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets40.createInsetRectangle(rectangle2D65, true, false);
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D69, (double) (byte) 10, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets33.createInsetRectangle(rectangle2D69, false, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        boolean boolean79 = categoryPlot0.render(graphics2D25, rectangle2D75, (int) 'a', plotRenderingInfo78);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str38.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 10.0d + "'", double50 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(verticalAlignment59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        boolean boolean53 = numberAxis42.isNegativeArrowVisible();
        boolean boolean54 = numberAxis42.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        categoryItemRendererState1.setBarWidth((double) 500);
        categoryItemRendererState1.setBarWidth(0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0L, (double) 10.0f, (int) (byte) 100, (java.lang.Comparable) "DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Paint paint18 = barRenderer0.getSeriesItemLabelPaint(100);
        barRenderer0.setBase((double) 0.0f);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        categoryPlot0.setAnchorValue((double) 15, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot8.getRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int13 = color12.getAlpha();
        java.awt.Color color14 = color12.darker();
        int int15 = color14.getTransparency();
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = axisLocation17.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation17, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str6 = categoryLabelWidthType5.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor3, (double) ' ', categoryLabelWidthType5, (float) 500);
        float float9 = categoryLabelPosition8.getWidthRatio();
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        boolean boolean11 = categoryLabelPosition8.equals((java.lang.Object) paint10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range16 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range19 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range16, range19);
        double double21 = range19.getLowerBound();
        numberAxis13.setDefaultAutoRange(range19);
        numberAxis13.setLowerBound(100.0d);
        boolean boolean25 = categoryLabelPosition8.equals((java.lang.Object) numberAxis13);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str2.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str6.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 500.0f + "'", float9 == 500.0f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle5.getPadding();
        double double8 = rectangleInsets6.extendHeight((double) 1.0f);
        double double10 = rectangleInsets6.calculateBottomInset((double) 'a');
        double double12 = rectangleInsets6.calculateLeftInset((double) 10L);
        categoryAxis0.setLabelInsets(rectangleInsets6);
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets6.getUnitType();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        legendGraphic18.setLine(shape20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle22.getPadding();
        java.awt.Color color24 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        textTitle22.setPaint((java.awt.Paint) color24);
        java.awt.Color color27 = color24.darker();
        legendGraphic18.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint29 = legendGraphic18.getOutlinePaint();
        legendGraphic18.setShapeFilled(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendGraphic18.getShapeAnchor();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        boolean boolean4 = flowArrangement0.equals((java.lang.Object) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7, true);
        int int10 = categoryPlot5.getDatasetCount();
        java.awt.Font font11 = categoryPlot5.getNoDataMessageFont();
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray40);
        boolean boolean42 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset41);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset41);
        categoryPlot5.setDataset(15, categoryDataset41);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range48 = numberAxis47.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator52 = barRenderer49.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = null;
        barRenderer49.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer49);
        java.lang.String str57 = numberAxis47.getLabel();
        org.jfree.data.Range range58 = numberAxis47.getRange();
        boolean boolean59 = flowArrangement0.equals((java.lang.Object) numberAxis47);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(categoryURLGenerator52);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleAnchor.CENTER" + "'", str57.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 100);
        double double2 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list2 = defaultStatisticalCategoryDataset1.getRowKeys();
        java.lang.Number number5 = defaultStatisticalCategoryDataset1.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot6.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge();
        org.jfree.chart.plot.Plot plot11 = categoryPlot6.getRootPlot();
        defaultStatisticalCategoryDataset1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot11);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) (-254));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot0.notifyListeners(plotChangeEvent4);
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        boolean boolean8 = categoryAxis5.equals((java.lang.Object) "ThreadContext");
        categoryPlot0.setDomainAxis(categoryAxis5);
        int int10 = categoryAxis5.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot1.setRangeAxis((int) (byte) 100, valueAxis3, true);
        java.awt.Stroke stroke6 = categoryPlot1.getOutlineStroke();
        categoryPlot1.clearAnnotations();
        java.awt.Font font8 = categoryPlot1.getNoDataMessageFont();
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int12 = color11.getAlpha();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font10, (java.awt.Paint) color11);
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font8, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str10 = categoryLabelWidthType9.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, textAnchor7, (double) ' ', categoryLabelWidthType9, (float) 500);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = categoryLabelPosition13.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType15 = categoryLabelPosition13.getWidthType();
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = categoryLabelPosition18.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions17, categoryLabelPosition18);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition22.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions21, categoryLabelPosition22);
        java.awt.Color color25 = java.awt.Color.green;
        float[] floatArray31 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray32 = color25.getRGBColorComponents(floatArray31);
        boolean boolean33 = categoryLabelPositions21.equals((java.lang.Object) floatArray31);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition34 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions21, categoryLabelPosition34);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions17, categoryLabelPosition34);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition1, categoryLabelPosition12, categoryLabelPosition13, categoryLabelPosition34);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str6.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str10.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelWidthType15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 15, (java.lang.Number) 100);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100 + "'", number3.equals(100));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        java.text.NumberFormat numberFormat3 = null;
        numberAxis2.setNumberFormatOverride(numberFormat3);
        boolean boolean5 = numberAxis2.getAutoRangeStickyZero();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        double double2 = categoryPlot0.getAnchorValue();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue(0.0d);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str4 = numberTickUnit2.valueToString((double) (byte) 10);
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        keyedObjects0.addObject((java.lang.Comparable) numberTickUnit2, (java.lang.Object) rectangleConstraint7);
        int int9 = keyedObjects0.getItemCount();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(98.0d, (double) (-16777214));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        categoryPlot18.setRangeAxis((int) (short) 10, valueAxis39);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 10, (float) 255);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer7.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer7.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator12);
        java.awt.Stroke stroke15 = barRenderer7.lookupSeriesStroke((int) '4');
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (-1L), 0.0f, (-1.0f));
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("NOID", "AxisLabelEntity: label = null", "poly", "TextBlockAnchor.TOP_CENTER", shape6, stroke15, (java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        java.awt.Font font15 = categoryPlot9.getNoDataMessageFont();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        categoryPlot9.setDataset(15, categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range52 = numberAxis51.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = barRenderer53.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        barRenderer53.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer53);
        java.lang.String str61 = numberAxis51.getLabel();
        org.jfree.data.Range range62 = numberAxis51.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent63 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis51);
        int int64 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis51);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit66 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str68 = numberTickUnit66.valueToString((double) 10);
        java.lang.String str70 = numberTickUnit66.valueToString((double) (short) 100);
        numberAxis51.setTickUnit(numberTickUnit66, true, false);
        java.text.NumberFormat numberFormat74 = numberAxis51.getNumberFormatOverride();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(categoryURLGenerator56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleAnchor.CENTER" + "'", str61.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10" + "'", str68.equals("10"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "100" + "'", str70.equals("100"));
        org.junit.Assert.assertNull(numberFormat74);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.isNotify();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            java.awt.image.BufferedImage bufferedImage29 = jFreeChart21.createBufferedImage(0, (int) (short) 0, (-1), chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 'a', (double) (byte) 1, (double) 15, (java.awt.Paint) color4);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle7.getSources();
        boolean boolean9 = blockBorder5.equals((java.lang.Object) legendTitle7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle7.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        java.text.NumberFormat numberFormat5 = null;
        numberAxis4.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer7.getURLGenerator(0, (int) (short) 10);
        barRenderer7.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer7.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer7.setBaseURLGenerator(categoryURLGenerator16);
        java.awt.Font font20 = barRenderer7.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape23 = barRenderer7.getItemShape((int) (short) 100, (int) (byte) -1);
        numberAxis4.setDownArrow(shape23);
        java.text.NumberFormat numberFormat25 = null;
        numberAxis4.setNumberFormatOverride(numberFormat25);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        boolean boolean26 = jFreeChart21.isNotify();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        jFreeChart21.setBorderStroke(stroke27);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        java.awt.Stroke stroke11 = categoryPlot6.getOutlineStroke();
        categoryPlot6.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setCategoryMargin((double) '4');
        java.awt.Stroke stroke18 = categoryAxis15.getTickMarkStroke();
        categoryPlot6.setDomainAxis((int) (byte) 100, categoryAxis15, false);
        categoryPlot0.setDomainAxis(0, categoryAxis15, false);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray31, numberArray36, numberArray41, numberArray46, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("GradientPaintTransformType.CENTER_VERTICAL", "Layer.BACKGROUND", numberArray52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot0.getRendererForDataset(categoryDataset54);
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNull(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(sortOrder56);
        org.junit.Assert.assertNotNull(legendItemCollection57);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint11 = textFragment10.getPaint();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font8, paint11, (float) ' ');
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("10", font8, (java.awt.Paint) color14, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot17.setRangeAxis((int) (byte) 100, valueAxis19, true);
        java.awt.Stroke stroke22 = categoryPlot17.getOutlineStroke();
        categoryPlot17.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) categoryPlot17, false);
        jFreeChart26.setTextAntiAlias(true);
        boolean boolean29 = jFreeChart26.getAntiAlias();
        boolean boolean30 = jFreeChart26.getAntiAlias();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart26);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean17 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer19.getURLGenerator(0, (int) (short) 10);
        barRenderer19.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer19.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition27);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        legendItem12.setDatasetIndex((int) (short) -1);
        int int16 = legendItem12.getDatasetIndex();
        java.text.AttributedString attributedString17 = legendItem12.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(attributedString17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle1.getSources();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint7 = textTitle6.getPaint();
        boolean boolean8 = textTitle6.getExpandToFitSpace();
        textTitle6.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint20 = textFragment19.getPaint();
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font17, paint20, (float) ' ');
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("10", font17, (java.awt.Paint) color23, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        categoryPlot26.setRangeAxis((int) (byte) 100, valueAxis28, true);
        java.awt.Stroke stroke31 = categoryPlot26.getOutlineStroke();
        categoryPlot26.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("", font17, (org.jfree.chart.plot.Plot) categoryPlot26, false);
        jFreeChart35.setTextAntiAlias(true);
        java.awt.Image image38 = jFreeChart35.getBackgroundImage();
        int int39 = jFreeChart35.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart35.getCategoryPlot();
        textTitle6.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart35);
        org.jfree.chart.event.ChartProgressListener chartProgressListener42 = null;
        jFreeChart35.removeProgressListener(chartProgressListener42);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart35);
        java.lang.Object obj45 = jFreeChart35.clone();
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(image38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape14);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean21 = chartEntity19.equals((java.lang.Object) color20);
        barRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color20, false);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font24, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = barRenderer0.getPlot();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(categoryPlot27);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("NOID");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color7 };
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color9 };
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color12 = java.awt.Color.green;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { paint11, color12 };
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { paint14 };
        java.awt.Paint[] paintArray16 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray15, paintArray16, strokeArray17, strokeArray18, shapeArray20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke22, stroke23 };
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, rectangleAnchor28, 0.0d, (double) 100L);
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape32, rectangleAnchor33, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape32);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray41 = new java.awt.Shape[] { shape26, shape31, shape32, shape40 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray10, paintArray16, strokeArray24, strokeArray25, shapeArray41);
        java.awt.Shape shape43 = defaultDrawingSupplier42.getNextShape();
        boolean boolean44 = org.jfree.chart.util.ShapeUtilities.equal(shape6, shape43);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity(shape6, "VerticalAlignment.BOTTOM");
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("", "10", "VerticalAlignment.BOTTOM", "AxisLabelEntity: label = null", shape6, (java.awt.Paint) color47);
        legendItem48.setDatasetIndex((int) 'a');
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shapeArray41);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range6 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range3, range6);
        double double8 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 25.0d + "'", double8 == 25.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean17 = barRenderer0.getAutoPopulateSeriesStroke();
        boolean boolean19 = barRenderer0.isSeriesVisible((int) (short) 1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryItemEntity54.getDataset();
        try {
            org.jfree.data.general.PieDataset pieDataset57 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset55, (java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(categoryDataset55);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        java.awt.Stroke stroke12 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis9, false);
        java.lang.String str16 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) "100");
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState19 = new org.jfree.chart.axis.AxisState((double) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer20.getURLGenerator(0, (int) (short) 10);
        barRenderer20.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = barRenderer20.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint30 = barRenderer20.getSeriesOutlinePaint((-1));
        boolean boolean31 = barRenderer20.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = barRenderer20.getGradientPaintTransformer();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, rectangleAnchor35, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape34);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean41 = chartEntity39.equals((java.lang.Object) color40);
        barRenderer20.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color40, false);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        barRenderer20.setBaseItemLabelFont(font44, true);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint49 = textTitle48.getPaint();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str52 = rectangleInsets51.toString();
        org.jfree.chart.block.LineBorder lineBorder53 = new org.jfree.chart.block.LineBorder(paint49, stroke50, rectangleInsets51);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = lineBorder53.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range59 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range62 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range59, range62);
        double double64 = range62.getLowerBound();
        numberAxis56.setDefaultAutoRange(range62);
        numberAxis56.setLowerBound(100.0d);
        boolean boolean68 = numberAxis56.isTickLabelsVisible();
        numberAxis56.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        org.jfree.chart.util.VerticalAlignment verticalAlignment73 = legendTitle72.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str75 = rectangleInsets74.toString();
        legendTitle72.setItemLabelPadding(rectangleInsets74);
        legendTitle72.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D79 = legendTitle72.getBounds();
        numberAxis56.setUpArrow((java.awt.Shape) rectangle2D79);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets54.createInsetRectangle(rectangle2D79, true, false);
        barRenderer20.setSeriesShape((int) (byte) 100, (java.awt.Shape) rectangle2D83);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.util.List list86 = categoryAxis9.refreshTicks(graphics2D17, axisState19, rectangle2D83, rectangleEdge85);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str52.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.0d + "'", double64 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(verticalAlignment73);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str75.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(list86);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray27);
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        org.jfree.data.Range range35 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range38 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(range35, range38);
        org.jfree.data.Range range41 = org.jfree.data.Range.shift(range35, (double) (short) 1);
        double double43 = range35.constrain(255.0d);
        double double45 = range35.constrain((double) ' ');
        org.jfree.data.Range range46 = org.jfree.data.Range.combine(range32, range35);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.0d + "'", double43 == 35.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 32.0d + "'", double45 == 32.0d);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean((int) (short) 10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "Layer.BACKGROUND", "ClassContext", "RectangleAnchor.RIGHT", "Layer.BACKGROUND");
        boolean boolean9 = booleanList0.equals((java.lang.Object) "Layer.BACKGROUND");
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        legendItem12.setDatasetIndex(0);
        boolean boolean15 = legendItem12.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0.5f, (double) (byte) 0, (double) 1, (double) 100.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) itemLabelAnchor5);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame9 = textTitle0.getFrame();
        java.lang.Object obj10 = textTitle0.clone();
        org.jfree.chart.util.BooleanList booleanList11 = new org.jfree.chart.util.BooleanList();
        boolean boolean13 = booleanList11.equals((java.lang.Object) '#');
        boolean boolean14 = textTitle0.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(blockFrame9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint11 = textFragment10.getPaint();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font8, paint11, (float) ' ');
        legendTitle1.setItemFont(font8);
        boolean boolean15 = legendTitle1.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle1.setPosition(rectangleEdge16);
        boolean boolean18 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getRootPlot();
        java.awt.Stroke stroke7 = plot6.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint14 = barRenderer0.getSeriesFillPaint((int) '4');
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', paint14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_BLUE;
        barRenderer0.setBasePaint((java.awt.Paint) color16, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, range5);
        double double7 = range5.getLowerBound();
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range5, 25.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RangeType.FULL");
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint18 = textFragment17.getPaint();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font15, paint18, (float) ' ');
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("10", font15, (java.awt.Paint) color21, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        categoryPlot24.setRangeAxis((int) (byte) 100, valueAxis26, true);
        java.awt.Stroke stroke29 = categoryPlot24.getOutlineStroke();
        categoryPlot24.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) categoryPlot24, false);
        barRenderer0.setBaseItemLabelFont(font15);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator35 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator35);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.lang.String str6 = chartEntity5.getShapeType();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color12 };
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color15 = java.awt.Color.green;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { paint14, color15 };
        java.awt.Paint paint17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { paint17 };
        java.awt.Paint[] paintArray19 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] {};
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] { shape22 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray18, paintArray19, strokeArray20, strokeArray21, shapeArray23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke25, stroke26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape30, rectangleAnchor31, 0.0d, (double) 100L);
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape35, rectangleAnchor36, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity(shape35);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] { shape29, shape34, shape35, shape43 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray13, paintArray19, strokeArray27, strokeArray28, shapeArray44);
        java.awt.Shape shape46 = defaultDrawingSupplier45.getNextShape();
        boolean boolean47 = org.jfree.chart.util.ShapeUtilities.equal(shape9, shape46);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity(shape9, "VerticalAlignment.BOTTOM");
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape9, 0.2d, (float) (short) 0, (float) 2);
        chartEntity5.setArea(shape9);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "poly" + "'", str6.equals("poly"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shapeArray44);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(shape53);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        jFreeChart21.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener28 = null;
        jFreeChart21.removeProgressListener(chartProgressListener28);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = itemLabelPosition4.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition4.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition4.getRotationAnchor();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition4.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor10 = itemLabelPosition4.getRotationAnchor();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 500.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator16);
        java.awt.Paint paint18 = barRenderer0.getBasePaint();
        boolean boolean20 = barRenderer0.isSeriesVisibleInLegend(255);
        java.awt.Font font22 = barRenderer0.getSeriesItemLabelFont(192);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(font22);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textBlock15.getLineAlignment();
        org.jfree.chart.text.TextLine textLine18 = textBlock15.getLastLine();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(textLine18);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        boolean boolean20 = legendGraphic18.isShapeVisible();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (byte) 10);
        double double4 = numberTickUnit1.getSize();
        org.jfree.chart.text.TextBlock textBlock5 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryLabelPosition6.getLabelAnchor();
        java.lang.String str8 = textBlockAnchor7.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = categoryLabelPosition9.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = categoryLabelPosition9.getWidthType();
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition9.getRotationAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick14 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit1, textBlock5, textBlockAnchor7, textAnchor12, 100.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str8.equals("TextBlockAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot6.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo15, point2D16);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(drawingSupplier19);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font4, paint7, (float) ' ');
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("10", font4, (java.awt.Paint) color10, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot13.setRangeAxis((int) (byte) 100, valueAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot13.getOutlineStroke();
        categoryPlot13.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        jFreeChart22.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
        jFreeChart22.addProgressListener(chartProgressListener25);
        boolean boolean27 = chartChangeEventType0.equals((java.lang.Object) jFreeChart22);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = barRenderer0.getLegendItems();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection38);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        java.awt.Font font38 = numberAxis23.getLabelFont();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        double double2 = axisState1.getCursor();
        axisState1.cursorLeft((double) 0);
        axisState1.cursorLeft((double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font3);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("100", font3);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        org.jfree.data.RangeType rangeType54 = org.jfree.data.RangeType.FULL;
        java.lang.String str55 = rangeType54.toString();
        numberAxis42.setRangeType(rangeType54);
        org.jfree.data.RangeType rangeType57 = org.jfree.data.RangeType.FULL;
        java.lang.String str58 = rangeType57.toString();
        numberAxis42.setRangeType(rangeType57);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent60 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis42);
        java.lang.Object obj61 = numberAxis42.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RangeType.FULL" + "'", str55.equals("RangeType.FULL"));
        org.junit.Assert.assertNotNull(rangeType57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RangeType.FULL" + "'", str58.equals("RangeType.FULL"));
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, 0.0d, (double) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        categoryPlot21.setRangeAxis((int) (byte) 100, valueAxis23, true);
        int int26 = categoryPlot21.getDatasetCount();
        java.awt.Font font27 = categoryPlot21.getNoDataMessageFont();
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray35, numberArray40, numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray56);
        boolean boolean58 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset57);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset57);
        categoryPlot21.setDataset(15, categoryDataset57);
        java.lang.Comparable comparable62 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity63 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "GradientPaintTransformType.CENTER_VERTICAL", "", categoryDataset57, (java.lang.Comparable) true, comparable62);
        org.jfree.chart.block.LabelBlock labelBlock65 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock65.setID("1");
        org.jfree.chart.LegendItemSource legendItemSource68 = null;
        org.jfree.chart.title.LegendTitle legendTitle69 = new org.jfree.chart.title.LegendTitle(legendItemSource68);
        java.awt.Paint paint70 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle69.setBackgroundPaint(paint70);
        labelBlock65.setPaint(paint70);
        org.jfree.chart.title.LegendGraphic legendGraphic73 = new org.jfree.chart.title.LegendGraphic(shape7, paint70);
        java.awt.Shape shape74 = legendGraphic73.getLine();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNull(shape74);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean17 = barRenderer0.getAutoPopulateSeriesStroke();
        double double18 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.lang.Boolean boolean18 = barRenderer0.getSeriesVisible((int) (byte) 10);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint3 = textTitle2.getPaint();
        boolean boolean4 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str8 = verticalAlignment7.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment7, (double) 'a', (double) (byte) 100);
        columnArrangement11.clear();
        org.jfree.chart.block.BlockContainer blockContainer13 = null;
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = columnArrangement11.arrange(blockContainer13, graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str8.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.util.List list6 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis((int) (byte) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) horizontalAlignment9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = legendTitle12.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment13, (double) 2, (double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle18.setBackgroundPaint(paint19);
        legendTitle18.setID("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle18.getLegendItemGraphicLocation();
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle25.getSources();
        columnArrangement16.add((org.jfree.chart.block.Block) legendTitle18, (java.lang.Object) legendItemSourceArray26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryItemEntity54.getDataset();
        java.lang.String str56 = categoryItemEntity54.toString();
        java.lang.Comparable comparable57 = categoryItemEntity54.getRowKey();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator58 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator59 = null;
        try {
            java.lang.String str60 = categoryItemEntity54.getImageMapAreaTag(toolTipTagFragmentGenerator58, uRLTagFragmentGenerator59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + (byte) 1 + "'", comparable57.equals((byte) 1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = categoryPlot0.getOrientation();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        categoryPlot0.setNoDataMessage("ClassContext");
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setCategoryMargin((double) '4');
        java.awt.Stroke stroke10 = categoryAxis7.getTickMarkStroke();
        java.awt.Stroke stroke11 = categoryAxis7.getAxisLineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent13);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        legendItem12.setDatasetIndex((int) (short) -1);
        int int16 = legendItem12.getDatasetIndex();
        java.awt.Shape shape17 = legendItem12.getLine();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list21 = defaultStatisticalCategoryDataset20.getRowKeys();
        java.lang.Number number24 = defaultStatisticalCategoryDataset20.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity27 = new org.jfree.chart.entity.CategoryItemEntity(shape17, "AxisLocation.BOTTOM_OR_RIGHT", "100", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, (java.lang.Comparable) (byte) 100, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        defaultStatisticalCategoryDataset20.add((double) 500.0f, (double) 1, (java.lang.Comparable) "100", (java.lang.Comparable) 500);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNull(number24);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        barRenderer0.notifyListeners(rendererChangeEvent19);
        java.lang.Object obj21 = barRenderer0.clone();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint1, stroke2, rectangleInsets3);
        double double7 = rectangleInsets3.calculateLeftOutset(3.0d);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint9 = textTitle8.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, paint9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.util.List list4 = projectInfo0.getContributors();
        projectInfo0.setName("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        projectInfo0.setLicenceText("RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = categoryPlot0.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.Plot plot5 = categoryPlot0.getRootPlot();
        plot5.setBackgroundAlpha((float) 3);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) ' ', (double) (byte) 100, 98.0d, 3.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer0.getItemOutlineStroke(0, 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator5, false);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        barRenderer0.setBasePaint(paint12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        categoryPlot16.setRangeAxis((int) (byte) 100, valueAxis18, true);
        int int21 = categoryPlot16.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot16.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo25, point2D26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setRangeGridlineStroke(stroke28);
        java.awt.Paint paint30 = categoryPlot16.getOutlinePaint();
        barRenderer0.setBaseItemLabelPaint(paint30);
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font32, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceName();
        projectInfo0.setLicenceName("10");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        java.lang.Object obj55 = null;
        boolean boolean56 = categoryItemEntity54.equals(obj55);
        java.lang.Comparable comparable57 = categoryItemEntity54.getRowKey();
        java.awt.Shape shape58 = categoryItemEntity54.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + (byte) 1 + "'", comparable57.equals((byte) 1));
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setWidth((double) (short) 0);
        size2D0.setWidth((double) (-254));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Stroke stroke19 = legendGraphic18.getLineStroke();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        legendGraphic18.setLine(shape20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = textTitle22.getPadding();
        java.awt.Color color24 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        textTitle22.setPaint((java.awt.Paint) color24);
        java.awt.Color color27 = color24.darker();
        legendGraphic18.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint29 = legendGraphic18.getOutlinePaint();
        legendGraphic18.setShapeFilled(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot32.getOrientation();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot32);
        categoryPlot32.setNoDataMessage("ClassContext");
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setCategoryMargin((double) '4');
        java.awt.Stroke stroke42 = categoryAxis39.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis39.getAxisLineStroke();
        categoryPlot32.setRangeGridlineStroke(stroke43);
        legendGraphic18.setOutlineStroke(stroke43);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.clearDomainMarkers();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor9, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape8);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint15 = null;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape8, stroke14, paint15);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = legendItem16.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj19 = standardGradientPaintTransformer18.clone();
        legendItem16.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer18);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset21 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list22 = defaultStatisticalCategoryDataset21.getRowKeys();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, 3.0d, (double) (short) 0);
        boolean boolean28 = defaultStatisticalCategoryDataset21.equals((java.lang.Object) 3.0d);
        legendItem16.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset21);
        int int31 = defaultStatisticalCategoryDataset21.getColumnIndex((java.lang.Comparable) 255.0d);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset21);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.util.List list4 = projectInfo0.getContributors();
        java.lang.String str5 = projectInfo0.getLicenceText();
        java.awt.Image image6 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer0.getItemOutlineStroke(0, 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator5, false);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        barRenderer0.setBasePaint(paint12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getDataArea();
        barRenderer0.setBaseShape((java.awt.Shape) rectangle2D18);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isAutoRange();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        categoryAxis0.setAxisLineVisible(true);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint19 = textFragment18.getPaint();
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font16, paint19, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint19);
        org.jfree.chart.text.TextLine textLine23 = textBlock22.getLastLine();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot25.getFixedLegendItems();
        java.awt.Font font27 = categoryPlot25.getNoDataMessageFont();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        java.awt.Paint paint31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle30.setBackgroundPaint(paint31);
        boolean boolean33 = chartChangeEventType28.equals((java.lang.Object) paint31);
        textBlock22.addLine("", font27, paint31);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) true, font27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNotNull(textLine23);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(chartChangeEventType28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint13 = textFragment12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font10, paint13, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint13);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot19.getFixedLegendItems();
        java.awt.Font font21 = categoryPlot19.getNoDataMessageFont();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle24.setBackgroundPaint(paint25);
        boolean boolean27 = chartChangeEventType22.equals((java.lang.Object) paint25);
        textBlock16.addLine("", font21, paint25);
        boolean boolean29 = categoryLabelWidthType0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textLine17);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setText("100");
        double double4 = textTitle1.getWidth();
        textTitle1.setText("1");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.util.List list4 = projectInfo0.getContributors();
        projectInfo0.setName("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint13 = textFragment12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font10, paint13, (float) ' ');
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("10", font10, (java.awt.Paint) color16, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot19.setRangeAxis((int) (byte) 100, valueAxis21, true);
        java.awt.Stroke stroke24 = categoryPlot19.getOutlineStroke();
        categoryPlot19.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) categoryPlot19, false);
        java.awt.image.BufferedImage bufferedImage31 = jFreeChart28.createBufferedImage((int) (byte) 100, (int) (short) 10);
        projectInfo0.setLogo((java.awt.Image) bufferedImage31);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(bufferedImage31);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer7.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer7.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator12);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer7.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator15, false);
        java.awt.Stroke stroke19 = barRenderer7.lookupSeriesOutlineStroke((int) (byte) -1);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        categoryPlot22.setRangeAxis((int) (byte) 100, valueAxis24, true);
        int int27 = categoryPlot22.getDatasetCount();
        java.awt.Font font28 = categoryPlot22.getNoDataMessageFont();
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray36, numberArray41, numberArray46, numberArray51, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray57);
        boolean boolean59 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset58);
        org.jfree.data.Range range60 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset58);
        categoryPlot22.setDataset(15, categoryDataset58);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range65 = numberAxis64.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator69 = barRenderer66.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator71 = null;
        barRenderer66.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator71);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis62, (org.jfree.chart.axis.ValueAxis) numberAxis64, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer66);
        java.lang.String str74 = numberAxis64.getLabel();
        org.jfree.data.Range range75 = numberAxis64.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent76 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis64);
        org.jfree.chart.plot.Marker marker77 = null;
        org.jfree.chart.title.TextTitle textTitle78 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint79 = textTitle78.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D80 = textTitle78.getBounds();
        barRenderer7.drawRangeMarker(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis64, marker77, rectangle2D80);
        categoryPlot0.setRenderer(3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNull(categoryURLGenerator69);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "RectangleAnchor.CENTER" + "'", str74.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNull(paint79);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        java.awt.Paint paint26 = jFreeChart21.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot9.getOrientation();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot9);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color16 };
        java.awt.Paint paint18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { paint18, color19 };
        java.awt.Paint paint21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { paint21 };
        java.awt.Paint[] paintArray23 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray24 = null;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] {};
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray27 = new java.awt.Shape[] { shape26 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray20, paintArray22, paintArray23, strokeArray24, strokeArray25, shapeArray27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke29, stroke30 };
        java.awt.Stroke[] strokeArray32 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, rectangleAnchor35, 0.0d, (double) 100L);
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape39, rectangleAnchor40, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape39);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray48 = new java.awt.Shape[] { shape33, shape38, shape39, shape47 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray17, paintArray23, strokeArray31, strokeArray32, shapeArray48);
        java.awt.Paint[] paintArray50 = null;
        java.awt.Stroke[] strokeArray51 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray52 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray53 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray50, strokeArray51, strokeArray52, shapeArray53);
        java.awt.Stroke stroke55 = defaultDrawingSupplier54.getNextOutlineStroke();
        categoryPlot9.setDomainGridlineStroke(stroke55);
        categoryPlot0.setDomainGridlineStroke(stroke55);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shapeArray48);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        boolean boolean6 = verticalAlignment2.equals((java.lang.Object) verticalAlignment5);
        java.lang.String str7 = verticalAlignment2.toString();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "VerticalAlignment.CENTER" + "'", str7.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str20 = rectangleInsets19.toString();
        legendTitle17.setItemLabelPadding(rectangleInsets19);
        legendTitle17.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle17.getBounds();
        numberAxis1.setUpArrow((java.awt.Shape) rectangle2D24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D24);
        org.jfree.data.KeyedObjects keyedObjects27 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str31 = numberTickUnit29.valueToString((double) (byte) 10);
        org.jfree.data.Range range33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(0.0d, range33);
        keyedObjects27.addObject((java.lang.Comparable) numberTickUnit29, (java.lang.Object) rectangleConstraint34);
        java.lang.Object obj36 = null;
        int int37 = numberTickUnit29.compareTo(obj36);
        legendItemEntity26.setSeriesKey((java.lang.Comparable) numberTickUnit29);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str20.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10" + "'", str31.equals("10"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer14 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj15 = standardGradientPaintTransformer14.clone();
        legendItem12.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer14);
        boolean boolean18 = standardGradientPaintTransformer14.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        numberAxis2.setVerticalTickLabels(true);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean7 = blockContainer5.equals((java.lang.Object) font6);
        numberAxis2.setTickLabelFont(font6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer13 = new org.jfree.chart.text.G2TextMeasurer(graphics2D12);
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, (java.awt.Paint) color9, (float) 0, (int) (short) 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer13);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot8.getRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int13 = color12.getAlpha();
        java.awt.Color color14 = color12.darker();
        int int15 = color14.getTransparency();
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = axisLocation17.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation17, false);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection28 = categoryPlot0.getDomainMarkers((int) '4', layer27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        categoryPlot0.markerChanged(markerChangeEvent29);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        numberAxis42.setAutoRange(true);
        org.jfree.data.Range range56 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        numberAxis42.setRange(range56, false, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        legendTitle1.setNotify(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getPadding();
        java.awt.Font font8 = legendTitle1.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D9 = legendTitle1.getBounds();
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint9 = textFragment8.getPaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, paint9, (float) ' ');
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("10", font6, (java.awt.Paint) color12, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot15.setRangeAxis((int) (byte) 100, valueAxis17, true);
        java.awt.Stroke stroke20 = categoryPlot15.getOutlineStroke();
        categoryPlot15.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        jFreeChart24.setTextAntiAlias(true);
        boolean boolean27 = jFreeChart24.getAntiAlias();
        boolean boolean28 = jFreeChart24.getAntiAlias();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = barRenderer31.getURLGenerator(0, (int) (short) 10);
        barRenderer31.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = barRenderer31.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint41 = barRenderer31.getSeriesOutlinePaint((-1));
        double double42 = barRenderer31.getUpperClip();
        int int43 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer31);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot2.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot2.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot2.getRangeAxisLocation();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("Layer.BACKGROUND", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        int int10 = jFreeChart9.getSubtitleCount();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        textTitle10.setPaint((java.awt.Paint) color12);
        java.awt.Color color15 = color12.darker();
        barRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color15, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getAlpha();
        java.awt.Color color21 = color19.darker();
        int int22 = color21.getTransparency();
        barRenderer0.setSeriesPaint((int) (short) 10, (java.awt.Paint) color21, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = barRenderer26.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = itemLabelPosition30.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor32 = itemLabelPosition30.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor33 = itemLabelPosition30.getRotationAnchor();
        barRenderer26.setNegativeItemLabelPositionFallback(itemLabelPosition30);
        org.jfree.chart.text.TextAnchor textAnchor35 = itemLabelPosition30.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor25, textAnchor35);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition36);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNull(categoryURLGenerator29);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(textAnchor35);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font2);
        java.lang.Object obj9 = labelBlock8.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator5);
        java.awt.Stroke stroke8 = barRenderer0.lookupSeriesStroke((int) '4');
        java.awt.Color color12 = java.awt.Color.getColor("{0}", 2);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        int int14 = color12.getTransparency();
        barRenderer0.setSeriesPaint(100, (java.awt.Paint) color12, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color17 };
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color19 };
        java.awt.Paint paint21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color22 = java.awt.Color.green;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint21, color22 };
        java.awt.Paint paint24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { paint24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray27 = null;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] {};
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray30 = new java.awt.Shape[] { shape29 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke32, stroke33 };
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape37, rectangleAnchor38, 0.0d, (double) 100L);
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape42, rectangleAnchor43, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape42);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray51 = new java.awt.Shape[] { shape36, shape41, shape42, shape50 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier52 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray20, paintArray26, strokeArray34, strokeArray35, shapeArray51);
        java.awt.Paint[] paintArray53 = null;
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray55 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray56 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier57 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray53, strokeArray54, strokeArray55, shapeArray56);
        java.awt.Stroke stroke58 = defaultDrawingSupplier57.getNextOutlineStroke();
        barRenderer0.setBaseOutlineStroke(stroke58);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shapeArray30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shapeArray51);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(strokeArray55);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint4 = textFragment3.getPaint();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, paint4, (float) ' ');
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.2d, 0.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot6.setRangeAxis((int) (byte) 100, valueAxis8, true);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot6.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo15, point2D16);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator19, false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
        java.lang.String str2 = numberTickUnit1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=10]" + "'", str2.equals("[size=10]"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        float float6 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape8, "RectangleAnchor.CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.Number number1 = null;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 1, number1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = null;
        try {
            textBlock15.draw(graphics2D16, 0.5f, 10.0f, textBlockAnchor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, 0.0d, (double) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        categoryPlot21.setRangeAxis((int) (byte) 100, valueAxis23, true);
        int int26 = categoryPlot21.getDatasetCount();
        java.awt.Font font27 = categoryPlot21.getNoDataMessageFont();
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray35, numberArray40, numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray56);
        boolean boolean58 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset57);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset57);
        categoryPlot21.setDataset(15, categoryDataset57);
        java.lang.Comparable comparable62 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity63 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "GradientPaintTransformType.CENTER_VERTICAL", "", categoryDataset57, (java.lang.Comparable) true, comparable62);
        org.jfree.chart.block.LabelBlock labelBlock65 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock65.setID("1");
        org.jfree.chart.LegendItemSource legendItemSource68 = null;
        org.jfree.chart.title.LegendTitle legendTitle69 = new org.jfree.chart.title.LegendTitle(legendItemSource68);
        java.awt.Paint paint70 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle69.setBackgroundPaint(paint70);
        labelBlock65.setPaint(paint70);
        org.jfree.chart.title.LegendGraphic legendGraphic73 = new org.jfree.chart.title.LegendGraphic(shape7, paint70);
        java.awt.Paint paint74 = legendGraphic73.getLinePaint();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNull(paint74);
    }
}

