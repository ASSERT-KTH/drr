import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) 1.0f, categoryLabelWidthType4, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Color color0 = java.awt.Color.green;
        float[] floatArray2 = new float[] { 100.0f };
        try {
            float[] floatArray3 = color0.getRGBColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Stroke stroke5 = null;
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "", "", "", shape4, stroke5, paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) -1, 1.0f, textAnchor4, (double) 10.0f, 0.0f, (float) (byte) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) '#', (double) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("{0}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("{0}");
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1, "hi!", textAnchor2, textAnchor3, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17, numberArray22, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray28);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer31 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) categoryDataset29, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (-1.0d), (double) (byte) -1);
        org.jfree.chart.block.Block block5 = null;
        flowArrangement4.add(block5, (java.lang.Object) 100.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        float[] floatArray3 = new float[] { (short) 10, 15 };
        try {
            float[] floatArray4 = color0.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (short) 10, 0.0d, (float) 10, (float) (short) 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray27);
        try {
            org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset28, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color2 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 0, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.plot.Plot plot8 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", font2, plot8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, 10.0f, (float) 100, (double) (-1), 1.0f, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlock textBlock3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock3, textBlockAnchor4, textAnchor5, (double) (short) -1);
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 10.0f, textBlock1, textBlockAnchor4, textAnchor8, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextBlockAnchor.CENTER_LEFT", graphics2D1, (float) (-1), 100.0f, (double) 2, (float) 100L, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { paint0, color1 };
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { paint3 };
        java.awt.Paint[] paintArray5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] {};
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray9 = new java.awt.Shape[] { shape8 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray4, paintArray5, strokeArray6, strokeArray7, shapeArray9);
        try {
            java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shapeArray9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", graphics2D1, (float) 100, (float) 255, (double) 255, 0.5f, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        java.lang.String str5 = rectangleAnchor1.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.CENTER" + "'", str5.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range3, lengthConstraintType4, (double) (short) -1, range6, lengthConstraintType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("{0}", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "hi!");
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "CategoryLabelWidthType.RANGE", (java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray27);
        try {
            org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset28, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 1.0f, numberFormat1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition6.getTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", graphics2D1, (float) (-1), (float) ' ', textAnchor4, (double) (byte) 100, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle0.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, 0.0d, (double) 100L);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 255, 0.0d);
        double double3 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 255.0d + "'", double3 == 255.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) '#');
        booleanList0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setHeight((double) 100.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets1.createOutsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            legendTitle1.setLegendItemGraphicEdge(rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, range5);
        double double7 = range2.getLength();
        boolean boolean9 = range2.contains(255.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 25.0d + "'", double7 == 25.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint1, stroke2, rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightInset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateBottomInset((double) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getAlpha();
        java.awt.Color color2 = color0.darker();
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray4 = null;
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace3, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = plotRenderingInfo1.getSubplotInfo(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.Plot plot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace8 = categoryAxis0.reserveSpace(graphics2D3, plot4, rectangle2D5, rectangleEdge6, axisSpace7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = categoryLabelPosition0.getLabelAnchor();
        double double2 = categoryLabelPosition0.getAngle();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.color.ColorSpace colorSpace7 = null;
        float[] floatArray8 = null;
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace7, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
        java.awt.Color color4 = java.awt.Color.green;
        float[] floatArray10 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray11 = color4.getRGBColorComponents(floatArray10);
        boolean boolean12 = categoryLabelPositions0.equals((java.lang.Object) floatArray10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = categoryLabelPosition16.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions15, categoryLabelPosition16);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = categoryLabelPosition20.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions19, categoryLabelPosition20);
        java.awt.Color color23 = java.awt.Color.green;
        float[] floatArray29 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray30 = color23.getRGBColorComponents(floatArray29);
        boolean boolean31 = categoryLabelPositions19.equals((java.lang.Object) floatArray29);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition32 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions19, categoryLabelPosition32);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions34 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions15, categoryLabelPosition32);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions14, categoryLabelPosition32);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions33);
        org.junit.Assert.assertNotNull(categoryLabelPositions34);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double5 = categoryAxis0.getCategoryMiddle((int) (byte) -1, 15, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { paint0, color1 };
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { paint3 };
        java.awt.Paint[] paintArray5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] {};
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray9 = new java.awt.Shape[] { shape8 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray4, paintArray5, strokeArray6, strokeArray7, shapeArray9);
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextPaint();
        java.lang.Object obj12 = defaultDrawingSupplier10.clone();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean7 = chartEntity5.equals((java.lang.Object) color6);
        chartEntity5.setURLText("RectangleAnchor.CENTER");
        chartEntity5.setURLText("{0}");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        try {
            java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage((int) (short) -1, 10, (int) ' ', chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, range4);
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle0.arrange(graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = categoryLabelPosition2.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot9.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo18, point2D19);
        try {
            org.jfree.chart.axis.AxisState axisState21 = categoryAxis0.draw(graphics2D4, 0.0d, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "ThreadContext", "GradientPaintTransformType.HORIZONTAL", image3, "RectangleAnchor.CENTER", "", "GradientPaintTransformType.HORIZONTAL");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint1, stroke2, rectangleInsets3);
        double double6 = rectangleInsets3.getBottom();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextBlockAnchor.CENTER_LEFT", "VerticalAlignment.BOTTOM", "10", "10");
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, range4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint7.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D9 = legendTitle1.arrange(graphics2D2, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        boolean boolean8 = categoryAxis5.equals((java.lang.Object) "ThreadContext");
        categoryPlot0.setDomainAxis(categoryAxis5);
        org.jfree.chart.plot.Plot plot10 = categoryAxis5.getPlot();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            legendTitle1.setMargin(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double6 = categoryAxis0.getCategoryEnd(500, (int) (short) 10, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState(0.0d);
        double double6 = axisState5.getCursor();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getDomainAxisEdge((int) (short) 10);
        try {
            java.util.List list13 = categoryAxis0.refreshTicks(graphics2D3, axisState5, rectangle2D7, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setForegroundAlpha((float) (byte) 10);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleAnchor.CENTER", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (byte) 10);
        java.lang.String str5 = numberTickUnit1.valueToString((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.trimHeight((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 98.0d + "'", double3 == 98.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1.0d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double6 = categoryAxis0.getCategoryStart(0, (int) (byte) 10, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ThreadContext" + "'", str2.equals("ThreadContext"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.lang.String str6 = chartEntity5.getShapeType();
        chartEntity5.setURLText("CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "poly" + "'", str6.equals("poly"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        double double2 = size2D0.getHeight();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("poly");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name poly, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        try {
            java.awt.image.BufferedImage bufferedImage27 = jFreeChart21.createBufferedImage(0, (int) '4', (-1.0d), (double) (-1.0f), chartRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (52) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint3 = textTitle2.getPaint();
        boolean boolean4 = itemLabelAnchor1.equals((java.lang.Object) paint3);
        boolean boolean5 = textBlockAnchor0.equals((java.lang.Object) paint3);
        java.lang.String str6 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str6.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        plotRenderingInfo1.setPlotArea(rectangle2D2);
        java.awt.geom.Point2D point2D4 = null;
        try {
            int int5 = plotRenderingInfo1.getSubplotIndex(point2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "ThreadContext");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        java.awt.Color color3 = java.awt.Color.green;
        float[] floatArray9 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray10 = color3.getRGBColorComponents(floatArray9);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, 0.0d, (double) 100L);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 100, (float) 'a', (float) 10L);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke18 = null;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color23 };
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color25 };
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { paint27, color28 };
        java.awt.Paint paint30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] { paint30 };
        java.awt.Paint[] paintArray32 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] {};
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray36 = new java.awt.Shape[] { shape35 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray29, paintArray31, paintArray32, strokeArray33, strokeArray34, shapeArray36);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke38, stroke39 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape43, rectangleAnchor44, 0.0d, (double) 100L);
        java.awt.Shape shape48 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape48, rectangleAnchor49, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity(shape48);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray57 = new java.awt.Shape[] { shape42, shape47, shape48, shape56 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier58 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray26, paintArray32, strokeArray40, strokeArray41, shapeArray57);
        java.awt.Shape shape59 = defaultDrawingSupplier58.getNextShape();
        boolean boolean60 = org.jfree.chart.util.ShapeUtilities.equal(shape22, shape59);
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity(shape22, "VerticalAlignment.BOTTOM");
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, 0.2d, (float) (short) 0, (float) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis67.setCategoryMargin((double) '4');
        java.awt.Stroke stroke70 = categoryAxis67.getTickMarkStroke();
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "10", "VerticalAlignment.BOTTOM", true, shape5, false, paint15, false, (java.awt.Paint) color17, stroke18, false, shape22, stroke70, (java.awt.Paint) color71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shapeArray36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shapeArray57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(color71);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        plotRenderingInfo1.setPlotArea(rectangle2D2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo5.setPlotArea(rectangle2D6);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo5);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = plotRenderingInfo5.getSubplotInfo((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int3 = color2.getAlpha();
        java.awt.Color color4 = color2.darker();
        int int5 = color4.getTransparency();
        org.jfree.chart.text.TextMeasurer textMeasurer8 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("AxisLocation.BOTTOM_OR_RIGHT", font1, (java.awt.Paint) color4, (float) 1L, (int) (byte) -1, textMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = null;
        try {
            categoryPlot12.setDomainGridlinePosition(categoryAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color2 = java.awt.Color.getColor("GradientPaintTransformType.HORIZONTAL", 500);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo9, point2D10);
        int int12 = plotRenderingInfo9.getSubplotCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            labelBlock1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        boolean boolean8 = categoryAxis5.equals((java.lang.Object) "ThreadContext");
        categoryPlot0.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(500);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot0.getDataset((int) '#');
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlock textBlock5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick9 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock5, textBlockAnchor6, textAnchor7, (double) (short) -1);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextBlockAnchor.CENTER_LEFT", graphics2D1, 0.0f, (float) (byte) 10, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color5 };
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { paint7, color8 };
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { paint10 };
        java.awt.Paint[] paintArray12 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray11, paintArray12, strokeArray13, strokeArray14, shapeArray16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        java.awt.Stroke[] strokeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, rectangleAnchor24, 0.0d, (double) 100L);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape28);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape22, shape27, shape28, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray6, paintArray12, strokeArray20, strokeArray21, shapeArray37);
        java.awt.Shape shape39 = defaultDrawingSupplier38.getNextShape();
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape39);
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity(shape2, "VerticalAlignment.BOTTOM");
        boolean boolean44 = chartEntity42.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        java.lang.Object obj2 = textTitle0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle0.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.isNotify();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        try {
            jFreeChart21.setTextAntiAlias((java.lang.Object) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=255,g=128,b=255] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint3 = textTitle2.getPaint();
        boolean boolean4 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle0.arrange(graphics2D7, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font2);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getPadding();
        java.lang.Object obj13 = textTitle11.clone();
        try {
            java.lang.Object obj14 = labelBlock8.draw(graphics2D9, rectangle2D10, (java.lang.Object) textTitle11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-1L), 0.0f, (-1.0f));
        int int4 = color3.getRGB();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-254) + "'", int4 == (-254));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "ChartChangeEventType.NEW_DATASET");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        double double4 = rectangleInsets2.extendWidth((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets2.createInsetRectangle(rectangle2D5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo9, point2D10);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray39);
        boolean boolean41 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot0.getRendererForDataset(categoryDataset40);
        try {
            org.jfree.data.general.PieDataset pieDataset44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset40, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryItemRenderer42);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        java.lang.String str9 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str6 = categoryLabelWidthType5.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor3, (double) ' ', categoryLabelWidthType5, (float) 500);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray16 = new float[] { 100, 500.0f, 1, (short) 1, 0, 2.0f };
        float[] floatArray17 = color9.getComponents(floatArray16);
        boolean boolean18 = categoryLabelWidthType5.equals((java.lang.Object) color9);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str2.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str6.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot0.setRangeAxis((int) (short) 1, valueAxis10, true);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo9, point2D10);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray39);
        boolean boolean41 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot0.getRendererForDataset(categoryDataset40);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset40, true);
        try {
            org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset40, (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 100, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.util.List list6 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot8.setRangeAxis((int) (byte) 100, valueAxis10, true);
        int int13 = categoryPlot8.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot8.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo17, point2D18);
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo17, point2D20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot0.getRenderer((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        java.awt.Paint paint2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color3 = java.awt.Color.green;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { paint2, color3 };
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint5 };
        java.awt.Paint[] paintArray7 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray8 = null;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] {};
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray11 = new java.awt.Shape[] { shape10 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray6, paintArray7, strokeArray8, strokeArray9, shapeArray11);
        boolean boolean13 = booleanList0.equals((java.lang.Object) paintArray6);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shapeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        java.awt.Stroke stroke12 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis9, false);
        java.awt.Paint paint16 = categoryAxis9.getTickLabelPaint((java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setID("1");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = labelBlock1.getPadding();
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("ThreadContext");
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("CategoryLabelWidthType.RANGE", "CategoryLabelWidthType.RANGE", "{0}", "");
        basicProjectInfo0.addOptionalLibrary(library7);
        java.lang.String str9 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font2);
        double double9 = labelBlock8.getHeight();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot11.setRangeAxis((int) (byte) 100, valueAxis13, true);
        java.awt.Stroke stroke16 = categoryPlot11.getOutlineStroke();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem(attributedString0, "poly", "", "GradientPaintTransformType.HORIZONTAL", shape9, paint10, stroke16, (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        categoryAxis0.setLabelURL("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        categoryAxis0.setMaximumCategoryLabelLines((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        java.util.List list17 = textBlock15.getLines();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("{0}", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "hi!");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getLicenceText();
        java.lang.String str7 = projectInfo5.getName();
        java.lang.String str8 = projectInfo5.getLicenceText();
        java.util.List list9 = projectInfo5.getContributors();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        basicProjectInfo4.addOptionalLibrary("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        org.jfree.chart.text.TextFragment textFragment17 = null;
        textLine16.removeFragment(textFragment17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textLine16.draw(graphics2D19, (-1.0f), (float) 2, textAnchor22, (float) 10L, (float) 0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ChartChangeEventType.NEW_DATASET");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ChartChangeEventType.NEW_DATASET, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart21.getCategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        categoryPlot29.setRangeAxis((int) (byte) 100, valueAxis31, true);
        int int34 = categoryPlot29.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot29.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo38, point2D39);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot29.setRangeGridlineStroke(stroke41);
        java.awt.Paint paint43 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        categoryPlot29.handleClick((int) (short) 0, (-1), plotRenderingInfo47);
        categoryPlot26.handleClick((int) (byte) -1, (int) (short) 1, plotRenderingInfo47);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryPlot26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 100);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        categoryAxis0.setLabelURL("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot11.setRangeAxis((int) (byte) 100, valueAxis13, true);
        int int16 = categoryPlot11.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo20, point2D21);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot11.setRangeGridlineStroke(stroke23);
        java.awt.Paint paint25 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        categoryPlot11.handleClick((int) (short) 0, (-1), plotRenderingInfo29);
        try {
            org.jfree.chart.axis.AxisState axisState31 = categoryAxis0.draw(graphics2D6, (double) (short) 1, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint2 = textFragment1.getPaint();
        java.awt.Paint paint3 = textFragment1.getPaint();
        java.lang.String str4 = textFragment1.getText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        double double3 = rectangleInsets1.extendHeight((double) 1.0f);
        double double5 = rectangleInsets1.calculateRightOutset((double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle2.setBackgroundPaint(paint3);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = new org.jfree.chart.LegendItemSource[] { legendItemSource5 };
        legendTitle2.setSources(legendItemSourceArray6);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        legendTitle2.setItemFont(font9);
        java.awt.Paint paint16 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.CENTER_LEFT", font9, paint16, (-1.0f), 10, textMeasurer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        plotRenderingInfo1.setPlotArea(rectangle2D2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo5.setPlotArea(rectangle2D6);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = itemLabelPosition4.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition4.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition4.getRotationAnchor();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
        java.awt.Color color4 = java.awt.Color.green;
        float[] floatArray10 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray11 = color4.getRGBColorComponents(floatArray10);
        boolean boolean12 = categoryLabelPositions0.equals((java.lang.Object) floatArray10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle16.setBackgroundPaint(paint17);
        boolean boolean19 = categoryLabelPosition13.equals((java.lang.Object) paint17);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.awt.Paint paint2 = null;
        textTitle0.setBackgroundPaint(paint2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.getAntiAlias();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            jFreeChart21.draw(graphics2D25, rectangle2D26, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.isNotify();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = null;
        try {
            jFreeChart21.titleChanged(titleChangeEvent25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        categoryAxis0.setTickMarkOutsideLength(10.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getDomainAxisEdge((int) (short) 10);
        try {
            double double13 = categoryAxis0.getCategoryEnd(0, (-254), rectangle2D7, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("{0}", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "hi!");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getLicenceText();
        java.lang.String str7 = projectInfo5.getName();
        java.lang.String str8 = projectInfo5.getLicenceText();
        java.util.List list9 = projectInfo5.getContributors();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        boolean boolean12 = basicProjectInfo4.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "VerticalAlignment.BOTTOM", "10", image3, "", "TextBlockAnchor.CENTER_LEFT", "RectangleAnchor.CENTER");
        projectInfo7.setCopyright("RectangleAnchor.CENTER");
        projectInfo7.setLicenceText("{0}");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint2 = textFragment1.getPaint();
        java.awt.Paint paint3 = textFragment1.getPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            textFragment1.draw(graphics2D4, (float) (short) 10, (float) 0L, textAnchor7, 0.0f, 1.0f, 25.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (byte) 10);
        org.jfree.data.KeyedObjects keyedObjects4 = new org.jfree.data.KeyedObjects();
        boolean boolean5 = numberTickUnit1.equals((java.lang.Object) keyedObjects4);
        int int6 = keyedObjects4.getItemCount();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        try {
            categoryPlot12.notifyListeners(plotChangeEvent22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 255, 0.0d);
        size2D2.setHeight((double) (short) -1);
        double double5 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 255.0d + "'", double5 == 255.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightInset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateBottomInset((double) (short) 1);
        double double6 = rectangleInsets0.calculateLeftInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        java.awt.Font font4 = textTitle0.getFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0.5f, (double) (byte) 0, (double) 1, (double) 100.0f);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ChartChangeEventType.NEW_DATASET");
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 500.0f, 1.0f, (float) ' ');
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Category Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Object obj0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint9 = textFragment8.getPaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, paint9, (float) ' ');
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("10", font6, (java.awt.Paint) color12, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot15.setRangeAxis((int) (byte) 100, valueAxis17, true);
        java.awt.Stroke stroke20 = categoryPlot15.getOutlineStroke();
        categoryPlot15.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        jFreeChart24.setTextAntiAlias(true);
        java.awt.Image image27 = jFreeChart24.getBackgroundImage();
        int int28 = jFreeChart24.getSubtitleCount();
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart24);
        java.awt.Paint paint30 = jFreeChart24.getBackgroundPaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle33.setBackgroundPaint(paint34);
        boolean boolean36 = chartChangeEventType31.equals((java.lang.Object) paint34);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart24, chartChangeEventType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        boolean boolean27 = jFreeChart21.getAntiAlias();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        try {
            barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0E-8d, (double) (-1), (double) ' ', paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        legendItem12.setDatasetIndex(0);
        java.lang.Comparable comparable15 = legendItem12.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(comparable15);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 'a', (double) 500.0f, (double) 255, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        try {
            booleanList0.setBoolean((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            textTitle0.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(0.0d, range5);
        java.lang.String str7 = rectangleConstraint6.toString();
        try {
            org.jfree.chart.util.Size2D size2D8 = blockContainer0.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str7.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        java.awt.Stroke stroke26 = jFreeChart21.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint28 = textTitle27.getPaint();
        boolean boolean29 = textTitle27.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textTitle27.getHorizontalAlignment();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = textTitle27.getTextAlignment();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint1, stroke2, rectangleInsets3);
        java.awt.Paint paint6 = lineBorder5.getPaint();
        java.lang.Object obj7 = null;
        boolean boolean8 = lineBorder5.equals(obj7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        java.awt.Stroke stroke12 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis9, false);
        categoryAxis9.setCategoryLabelPositionOffset((int) '4');
        categoryAxis9.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        numberAxis42.configure();
        try {
            numberAxis42.zoomRange(100.0d, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10500.0) <= upper (1050.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) font1);
        java.util.List list3 = blockContainer0.getBlocks();
        org.jfree.chart.block.Arrangement arrangement4 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(arrangement4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        categoryPlot0.setDomainAxis(categoryAxis9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint15 = textTitle14.getPaint();
        boolean boolean16 = textTitle14.getExpandToFitSpace();
        textTitle14.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        boolean boolean22 = categoryAnchor13.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.getAntiAlias();
        boolean boolean25 = jFreeChart21.getAntiAlias();
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart21.createBufferedImage((int) (byte) 100, 1);
        jFreeChart21.setBackgroundImageAlpha((float) (byte) 10);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(bufferedImage28);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getAlpha();
        java.awt.Color color2 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        double double12 = barRenderer0.getBase();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot14.getRangeAxisLocation();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            barRenderer0.drawBackground(graphics2D13, categoryPlot14, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color1 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 15, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = categoryItemRendererState1.getInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = categoryItemRendererState1.getInfo();
        categoryItemRendererState1.setBarWidth((double) 2.0f);
        categoryItemRendererState1.setBarWidth((double) 255);
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertNull(plotRenderingInfo3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockContainer1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint9 = textFragment8.getPaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font6, paint9, (float) ' ');
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("10", font6, (java.awt.Paint) color12, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot15.setRangeAxis((int) (byte) 100, valueAxis17, true);
        java.awt.Stroke stroke20 = categoryPlot15.getOutlineStroke();
        categoryPlot15.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        java.awt.image.BufferedImage bufferedImage27 = jFreeChart24.createBufferedImage((int) (byte) 100, (int) (short) 10);
        org.jfree.chart.ui.ProjectInfo projectInfo31 = new org.jfree.chart.ui.ProjectInfo("ThreadContext", "10", "CategoryLabelWidthType.RANGE", (java.awt.Image) bufferedImage27, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(bufferedImage27);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint1, stroke2, rectangleInsets3);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = lineBorder5.getInsets();
        double double8 = rectangleInsets6.calculateBottomInset(25.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str3 = numberTickUnit1.valueToString((double) 10);
        int int4 = numberTickUnit1.getMinorTickCount();
        double double5 = numberTickUnit1.getSize();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.lang.String str6 = chartEntity5.getShapeType();
        java.lang.String str7 = chartEntity5.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "poly" + "'", str6.equals("poly"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            java.awt.Color color1 = java.awt.Color.decode("AxisLocation.BOTTOM_OR_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AxisLocation.BOTTOM_OR_RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) '4');
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int12 = color11.getAlpha();
        java.awt.Color color13 = color11.darker();
        int int14 = color13.getTransparency();
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot7.getRangeAxis((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        categoryPlot18.setRangeAxis((int) (byte) 100, valueAxis20, true);
        java.awt.Stroke stroke23 = categoryPlot18.getOutlineStroke();
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setCategoryMargin((double) '4');
        java.awt.Stroke stroke30 = categoryAxis27.getTickMarkStroke();
        categoryPlot18.setDomainAxis((int) (byte) 100, categoryAxis27, false);
        java.lang.String str34 = categoryAxis27.getCategoryLabelToolTip((java.lang.Comparable) "100");
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D6, categoryPlot7, categoryAxis27, categoryMarker35, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        java.lang.Boolean boolean4 = barRenderer0.getSeriesVisible(15);
        boolean boolean5 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint8 = textFragment7.getPaint();
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font5, paint8, (float) ' ');
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("10", font5, (java.awt.Paint) color11, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot14.setRangeAxis((int) (byte) 100, valueAxis16, true);
        java.awt.Stroke stroke19 = categoryPlot14.getOutlineStroke();
        categoryPlot14.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) categoryPlot14, false);
        jFreeChart23.setTextAntiAlias(true);
        java.awt.Image image26 = jFreeChart23.getBackgroundImage();
        int int27 = jFreeChart23.getSubtitleCount();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "AxisLocation.BOTTOM_OR_RIGHT", 0.0d, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.util.List list6 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis((int) (byte) -1);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 1, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        java.lang.Object obj2 = textTitle0.clone();
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        barRenderer0.notifyListeners(rendererChangeEvent4);
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        boolean boolean3 = textTitle0.getNotify();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RangeType.FULL", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorDown((double) (-1L));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        categoryPlot0.setBackgroundImageAlignment((int) '4');
        java.lang.Object obj10 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle0.setHorizontalAlignment(horizontalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        categoryAxis0.setLabelURL("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str7 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        double double3 = legendTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, 0.0d, (double) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str19 = axisLabelEntity18.toString();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AxisLabelEntity: label = null" + "'", str19.equals("AxisLabelEntity: label = null"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = categoryPlot1.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot1.getRangeAxisEdge();
        try {
            double double6 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor53 = itemLabelPosition52.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor54 = itemLabelPosition52.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor55 = itemLabelPosition52.getRotationAnchor();
        barRenderer44.setNegativeItemLabelPositionFallback(itemLabelPosition52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertNotNull(itemLabelAnchor53);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertNotNull(textAnchor55);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, 0.0d, (double) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 100, (float) 'a', (float) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str19 = axisLabelEntity18.getURLText();
        org.jfree.chart.axis.Axis axis20 = axisLabelEntity18.getAxis();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str19.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(axis20);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        java.awt.Stroke stroke39 = barRenderer0.getSeriesStroke((int) ' ');
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNull(stroke39);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        jFreeChart21.fireChartChanged();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            jFreeChart21.handleClick((int) '4', 100, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint4 = textFragment3.getPaint();
        java.awt.Paint paint5 = textFragment3.getPaint();
        categoryAxis1.setAxisLinePaint(paint5);
        categoryAxis1.setUpperMargin((double) 2.0f);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint2 = textTitle1.getPaint();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str5 = rectangleInsets4.toString();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder(paint2, stroke3, rectangleInsets4);
        categoryAxis0.setTickMarkStroke(stroke3);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState(0.2d);
        java.util.List list11 = axisState10.getTicks();
        axisState10.cursorLeft((double) 500);
        axisState10.cursorDown(1.0E-8d);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        try {
            java.util.List list18 = categoryAxis0.refreshTicks(graphics2D8, axisState10, rectangle2D16, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str4 = numberTickUnit2.valueToString((double) (byte) 10);
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(0.0d, range6);
        keyedObjects0.addObject((java.lang.Comparable) numberTickUnit2, (java.lang.Object) rectangleConstraint7);
        java.lang.Object obj9 = keyedObjects0.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint7 = textFragment6.getPaint();
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font4, paint7, (float) ' ');
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("10", font4, (java.awt.Paint) color10, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot13.setRangeAxis((int) (byte) 100, valueAxis15, true);
        java.awt.Stroke stroke18 = categoryPlot13.getOutlineStroke();
        categoryPlot13.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        jFreeChart22.setTextAntiAlias(true);
        boolean boolean25 = jFreeChart22.isNotify();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean25);
        boolean boolean27 = horizontalAlignment0.equals((java.lang.Object) chartChangeEvent26);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint2 = textTitle1.getPaint();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        textTitle1.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        boolean boolean9 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) (short) 1);
        java.lang.Object obj10 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (short) 100, (float) (byte) 10, (double) 0.0f, 0.0f, (float) 0L);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        java.awt.Stroke stroke12 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis9, false);
        java.lang.String str16 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) "100");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis9.getTickLabelInsets();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { paint0, color1 };
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { paint3 };
        java.awt.Paint[] paintArray5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] {};
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray9 = new java.awt.Shape[] { shape8 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray4, paintArray5, strokeArray6, strokeArray7, shapeArray9);
        java.lang.Object obj11 = defaultDrawingSupplier10.clone();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color5 };
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { paint7, color8 };
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { paint10 };
        java.awt.Paint[] paintArray12 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray11, paintArray12, strokeArray13, strokeArray14, shapeArray16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        java.awt.Stroke[] strokeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, rectangleAnchor24, 0.0d, (double) 100L);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape28);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) 10L);
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape22, shape27, shape28, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray6, paintArray12, strokeArray20, strokeArray21, shapeArray37);
        java.awt.Shape shape39 = defaultDrawingSupplier38.getNextShape();
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape39);
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity(shape2, "VerticalAlignment.BOTTOM");
        java.lang.Object obj43 = chartEntity42.clone();
        chartEntity42.setURLText("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.05d, (double) 'a');
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str5 = chartChangeEventType4.toString();
        chartChangeEvent2.setType(chartChangeEventType4);
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str5.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = categoryPlot0.getOrientation();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot5.getFixedLegendItems();
        boolean boolean7 = categoryPlot0.equals((java.lang.Object) legendItemCollection6);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Category Plot", graphics2D1, (float) 255, 0.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        boolean boolean14 = legendItem12.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint14 = textFragment13.getPaint();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font11, paint14, (float) ' ');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("10", font11, (java.awt.Paint) color17, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot20.setRangeAxis((int) (byte) 100, valueAxis22, true);
        java.awt.Stroke stroke25 = categoryPlot20.getOutlineStroke();
        categoryPlot20.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) categoryPlot20, false);
        jFreeChart29.setTextAntiAlias(true);
        java.awt.Image image32 = jFreeChart29.getBackgroundImage();
        int int33 = jFreeChart29.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = jFreeChart29.getCategoryPlot();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        org.jfree.chart.event.ChartProgressListener chartProgressListener36 = null;
        jFreeChart29.removeProgressListener(chartProgressListener36);
        try {
            java.awt.image.BufferedImage bufferedImage40 = jFreeChart29.createBufferedImage(500, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (500) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(categoryPlot34);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str4 = rectangleInsets3.toString();
        legendTitle1.setItemLabelPadding(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets3.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font2);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle11.setBackgroundPaint(paint12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint21 = textFragment20.getPaint();
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font18, paint21, (float) ' ');
        legendTitle11.setItemFont(font18);
        labelBlock8.setFont(font18);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            labelBlock8.draw(graphics2D26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getAlpha();
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font18, (java.awt.Paint) color19);
        textLine16.addFragment(textFragment21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            float float25 = textFragment21.calculateBaselineOffset(graphics2D23, textAnchor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("{0}", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "hi!");
        basicProjectInfo4.setCopyright("CategoryLabelWidthType.RANGE");
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot40.getRangeAxis((int) (short) 100);
        java.awt.Font font46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint49 = textFragment48.getPaint();
        org.jfree.chart.text.TextFragment textFragment51 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font46, paint49, (float) ' ');
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment54 = new org.jfree.chart.text.TextFragment("10", font46, (java.awt.Paint) color52, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        categoryPlot55.setRangeAxis((int) (byte) 100, valueAxis57, true);
        java.awt.Stroke stroke60 = categoryPlot55.getOutlineStroke();
        categoryPlot55.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart64 = new org.jfree.chart.JFreeChart("", font46, (org.jfree.chart.plot.Plot) categoryPlot55, false);
        jFreeChart64.setTextAntiAlias(true);
        boolean boolean67 = jFreeChart64.getAntiAlias();
        boolean boolean68 = jFreeChart64.getAntiAlias();
        categoryPlot40.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart64);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        try {
            barRenderer0.drawOutline(graphics2D39, categoryPlot40, rectangle2D70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.util.List list6 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo9, point2D10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Paint paint14 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        categoryPlot0.handleClick((int) (short) 0, (-1), plotRenderingInfo18);
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint25 = textFragment24.getPaint();
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font22, paint25, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font22);
        boolean boolean29 = plotRenderingInfo18.equals((java.lang.Object) "RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("ChartChangeEventType.NEW_DATASET");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.Marker marker6 = null;
        try {
            categoryPlot0.addRangeMarker(marker6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str1.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str8 = datasetRenderingOrder7.toString();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str8.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, (double) 'a');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range8 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range5, range8);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range5, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeWidth(range11);
        java.lang.String str13 = rectangleConstraint12.toString();
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]" + "'", str13.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        barRenderer0.setDrawBarOutline(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = barRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        categoryPlot0.setDomainAxis(categoryAxis9);
        java.util.List list13 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(list13);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, range5);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range2, (double) (short) 1);
        double double10 = range2.constrain((double) 10);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis0.hasListener(eventListener2);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        java.lang.Object obj5 = chartChangeEvent2.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent2.setType(chartChangeEventType6);
        java.lang.Object obj8 = null;
        boolean boolean9 = chartChangeEventType6.equals(obj8);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 0.0d + "'", obj5.equals(0.0d));
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        paintList0.clear();
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType1 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean2 = keyedObjects0.equals((java.lang.Object) lengthAdjustmentType1);
        java.lang.Object obj4 = keyedObjects0.getObject(15);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) '4');
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) textAnchor3);
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.Stroke stroke6 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.0d, shape1, "RectangleAnchor.CENTER", "poly");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart21.addProgressListener(chartProgressListener24);
        java.awt.Stroke stroke26 = jFreeChart21.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint28 = textTitle27.getPaint();
        boolean boolean29 = textTitle27.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textTitle27.getHorizontalAlignment();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) textTitle27);
        org.jfree.chart.title.Title title33 = null;
        try {
            jFreeChart21.addSubtitle((int) '4', title33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]");
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("10", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        java.awt.Color color3 = java.awt.Color.green;
        float[] floatArray9 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray10 = color3.getRGBColorComponents(floatArray9);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot0.getDataset();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNull(categoryDataset12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot10.getRangeAxis((int) (short) 100);
        categoryPlot10.setDomainGridlinesVisible(true);
        categoryPlot10.setOutlineVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        categoryPlot18.setRangeAxis((int) (byte) 100, valueAxis20, true);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection24 = categoryPlot18.getDomainMarkers(layer23);
        java.util.Collection collection25 = categoryPlot10.getRangeMarkers((int) 'a', layer23);
        try {
            barRenderer0.addAnnotation(categoryAnnotation9, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.getAntiAlias();
        boolean boolean25 = jFreeChart21.getAntiAlias();
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart21.createBufferedImage((int) (byte) 100, 1);
        java.awt.Paint paint29 = jFreeChart21.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(bufferedImage28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        jFreeChart21.setBackgroundImageAlignment((int) '#');
        float float26 = jFreeChart21.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer5.getItemOutlineStroke(0, 0);
        barRenderer0.setSeriesStroke(1, stroke8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer0.getItemLabelGenerator((int) (byte) 100, (int) (byte) -1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj24 = size2D23.clone();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray29 = legendTitle28.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle28.setLegendItemGraphicLocation(rectangleAnchor30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle28.setLegendItemGraphicLocation(rectangleAnchor32);
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) '4', (double) 10L, rectangleAnchor32);
        java.awt.geom.Point2D point2D35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        try {
            jFreeChart21.draw(graphics2D22, rectangle2D34, point2D35, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(legendItemSourceArray29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint11 = textFragment10.getPaint();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font8, paint11, (float) ' ');
        legendTitle1.setItemFont(font8);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj17 = size2D16.clone();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle21.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle21.setLegendItemGraphicLocation(rectangleAnchor23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle21.setLegendItemGraphicLocation(rectangleAnchor25);
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) '4', (double) 10L, rectangleAnchor25);
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int31 = color30.getAlpha();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font29, (java.awt.Paint) color30);
        try {
            java.lang.Object obj33 = legendTitle1.draw(graphics2D15, rectangle2D27, (java.lang.Object) textFragment32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 255 + "'", int31 == 255);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        int int27 = jFreeChart21.getBackgroundImageAlignment();
        java.lang.Object obj28 = jFreeChart21.clone();
        java.awt.Paint paint29 = jFreeChart21.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        try {
            jFreeChart21.handleClick((-1), (int) (short) -1, chartRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        try {
            textBlock15.draw(graphics2D16, (float) '#', (float) 0, textBlockAnchor19, (float) 100L, (float) 255, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray27);
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        org.jfree.data.Range range33 = org.jfree.data.Range.shift(range30, (double) 1, false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setMargin(0.0d, (double) 0.0f, 3.0d, (double) (short) 1);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint14 = textFragment13.getPaint();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font11, paint14, (float) ' ');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("10", font11, (java.awt.Paint) color17, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot20.setRangeAxis((int) (byte) 100, valueAxis22, true);
        java.awt.Stroke stroke25 = categoryPlot20.getOutlineStroke();
        categoryPlot20.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) categoryPlot20, false);
        jFreeChart29.setTextAntiAlias(true);
        java.awt.Image image32 = jFreeChart29.getBackgroundImage();
        int int33 = jFreeChart29.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = jFreeChart29.getCategoryPlot();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        boolean boolean36 = jFreeChart29.isNotify();
        org.jfree.chart.event.ChartChangeListener chartChangeListener37 = null;
        try {
            jFreeChart29.addChangeListener(chartChangeListener37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(categoryPlot34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot22 = jFreeChart21.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.getAntiAlias();
        float float25 = jFreeChart21.getBackgroundImageAlpha();
        java.lang.Object obj26 = jFreeChart21.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.util.List list4 = projectInfo0.getContributors();
        projectInfo0.setName("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        projectInfo0.setCopyright("{0}");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo9, point2D10);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray39);
        boolean boolean41 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot0.getRendererForDataset(categoryDataset40);
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot0.getDataset((int) (byte) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection45);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNull(categoryDataset44);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        labelBlock1.setID("1");
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle5.setBackgroundPaint(paint6);
        labelBlock1.setPaint(paint6);
        java.awt.Font font9 = labelBlock1.getFont();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle0.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range8 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range5, range8);
        double double10 = range5.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range2, range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 25.0d + "'", double10 == 25.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint15 = textTitle14.getPaint();
        boolean boolean16 = legendItem12.equals((java.lang.Object) textTitle14);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        barRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        java.lang.String str7 = layer5.toString();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.BACKGROUND" + "'", str7.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '#');
        java.lang.Object obj2 = objectList1.clone();
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState(0.0d);
        double double6 = axisState5.getMax();
        try {
            objectList1.set((int) (short) -1, (java.lang.Object) axisState5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.lang.Object obj6 = chartEntity5.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        org.jfree.data.RangeType rangeType13 = numberAxis1.getRangeType();
        numberAxis1.setFixedAutoRange((double) 'a');
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertNotNull(rangeType13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        org.jfree.data.RangeType rangeType54 = org.jfree.data.RangeType.FULL;
        java.lang.String str55 = rangeType54.toString();
        numberAxis42.setRangeType(rangeType54);
        double double57 = numberAxis42.getLabelAngle();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RangeType.FULL" + "'", str55.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin((double) '4');
        java.awt.Stroke stroke12 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis9, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.2d);
        java.util.List list2 = axisState1.getTicks();
        java.util.List list3 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        int int27 = jFreeChart21.getBackgroundImageAlignment();
        java.lang.Object obj28 = jFreeChart21.clone();
        java.awt.Paint paint29 = jFreeChart21.getBorderPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = null;
        try {
            jFreeChart21.plotChanged(plotChangeEvent30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        double double4 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot12.setRenderer((int) 'a', categoryItemRenderer18, true);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        barRenderer0.drawRangeMarker(graphics2D11, categoryPlot12, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot12.getRangeAxisEdge();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        legendTitle1.setNotify(true);
        java.awt.Font font7 = null;
        try {
            legendTitle1.setItemFont(font7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0L, 0.0d, (double) 100L);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo7.setPlotArea(rectangle2D8);
        java.lang.Object obj10 = plotRenderingInfo7.clone();
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo7.getDataArea();
        try {
            blockBorder4.draw(graphics2D5, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        double double9 = range7.getLowerBound();
        numberAxis1.setDefaultAutoRange(range7);
        numberAxis1.setLowerBound(100.0d);
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        java.awt.Shape shape16 = null;
        try {
            numberAxis1.setRightArrow(shape16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        try {
            org.jfree.chart.title.Title title28 = jFreeChart21.getSubtitle(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleAnchor.CENTER");
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color2 = java.awt.Color.getColor("{0}", 2);
        int int3 = color2.getRGB();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777214) + "'", int3 == (-16777214));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart21.getCategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot26.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryPlot26);
        org.junit.Assert.assertNotNull(sortOrder27);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        categoryPlot4.setRangeAxis((int) (byte) 100, valueAxis6, true);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo13, point2D14);
        boolean boolean16 = legendItemCollection0.equals((java.lang.Object) point2D14);
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = itemLabelPosition0.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor2 = itemLabelPosition0.getTextAnchor();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle4.setBackgroundPaint(paint5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = new org.jfree.chart.LegendItemSource[] { legendItemSource7 };
        legendTitle4.setSources(legendItemSourceArray8);
        boolean boolean10 = itemLabelPosition0.equals((java.lang.Object) legendItemSourceArray8);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        org.jfree.data.Range range53 = numberAxis42.getRange();
        java.awt.Shape shape54 = numberAxis42.getLeftArrow();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(shape54);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { paint0, color1 };
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { paint3 };
        java.awt.Paint[] paintArray5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] {};
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray9 = new java.awt.Shape[] { shape8 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray4, paintArray5, strokeArray6, strokeArray7, shapeArray9);
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextPaint();
        java.awt.Paint paint12 = defaultDrawingSupplier10.getNextPaint();
        java.awt.Paint paint13 = defaultDrawingSupplier10.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType1 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean2 = keyedObjects0.equals((java.lang.Object) lengthAdjustmentType1);
        try {
            keyedObjects0.removeValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint11 = null;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("ChartChangeEventType.NEW_DATASET", "100", "CategoryLabelWidthType.RANGE", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape4, stroke10, paint11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer14 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj15 = standardGradientPaintTransformer14.clone();
        legendItem12.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer14);
        org.jfree.data.general.Dataset dataset17 = legendItem12.getDataset();
        java.awt.Paint paint18 = legendItem12.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        try {
            categoryPlot0.zoom((double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Category Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle1.setBackgroundPaint(paint2);
        legendTitle1.setHeight((double) 10);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = categoryLabelPosition0.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getAlpha();
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font18, (java.awt.Paint) color19);
        textLine16.addFragment(textFragment21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextAnchor textAnchor26 = null;
        try {
            textFragment21.draw(graphics2D23, (float) (byte) 0, (float) ' ', textAnchor26, 2.0f, (float) (-16777214), 255.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray7 = new double[] { 10L, (short) 0, 1, (-254), (short) -1 };
        double[] doubleArray13 = new double[] { 10L, (short) 0, 1, (-254), (short) -1 };
        double[] doubleArray19 = new double[] { 10L, (short) 0, 1, (-254), (short) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]", doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        int int27 = jFreeChart21.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        double double30 = axisState29.getCursor();
        java.util.List list31 = axisState29.getTicks();
        jFreeChart21.setSubtitles(list31);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        try {
            jFreeChart21.handleClick((int) ' ', 1, chartRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        double double3 = rectangleInsets1.extendHeight((double) 1.0f);
        double double4 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Category Plot");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) font1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = legendTitle4.getVerticalAlignment();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = legendTitle4.getSources();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot7.getOrientation();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) legendTitle4, (java.lang.Object) categoryPlot7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(legendItemSourceArray6);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, range5);
        boolean boolean8 = range2.contains(1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis((int) (short) 100);
        categoryPlot0.setDomainGridlinesVisible(true);
        double double5 = categoryPlot0.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge();
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        double double2 = axisState1.getCursor();
        java.util.List list3 = axisState1.getTicks();
        axisState1.cursorLeft((double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart21.removeProgressListener(chartProgressListener22);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getAlpha();
        java.awt.Color color2 = color0.darker();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor9, 0.0d, (double) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape8);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean15 = chartEntity13.equals((java.lang.Object) color14);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = categoryLabelPosition17.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions16, categoryLabelPosition17);
        java.awt.Color color20 = java.awt.Color.green;
        float[] floatArray26 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray27 = color20.getRGBColorComponents(floatArray26);
        boolean boolean28 = categoryLabelPositions16.equals((java.lang.Object) floatArray26);
        float[] floatArray29 = color14.getRGBColorComponents(floatArray26);
        float[] floatArray30 = java.awt.Color.RGBtoHSB((int) (byte) -1, (int) (short) -1, (int) 'a', floatArray29);
        float[] floatArray31 = color0.getColorComponents(colorSpace4, floatArray29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = textTitle0.getPadding();
        java.lang.Object obj2 = textTitle0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle0.getMargin();
        double double5 = rectangleInsets3.calculateTopInset((double) (-1));
        java.lang.String str6 = rectangleInsets3.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str6.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("ThreadContext");
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) "ThreadContext");
        java.awt.Paint paint4 = null;
        try {
            categoryAxis0.setTickLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryItemEntity54.getDataset();
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55, (double) (short) 1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range57);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 25.0d, (double) 10L, (double) 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        jFreeChart21.setNotify(false);
        int int27 = jFreeChart21.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        double double30 = axisState29.getCursor();
        java.util.List list31 = axisState29.getTicks();
        jFreeChart21.setSubtitles(list31);
        org.jfree.chart.event.ChartChangeListener chartChangeListener33 = null;
        try {
            jFreeChart21.removeChangeListener(chartChangeListener33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart21.getCategoryPlot();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getRangeMarkers((-1), layer28);
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint36 = textFragment35.getPaint();
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font33, paint36, (float) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("10", font33, (java.awt.Paint) color39, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        categoryPlot42.setRangeAxis((int) (byte) 100, valueAxis44, true);
        java.awt.Stroke stroke47 = categoryPlot42.getOutlineStroke();
        categoryPlot42.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("", font33, (org.jfree.chart.plot.Plot) categoryPlot42, false);
        java.awt.image.BufferedImage bufferedImage54 = jFreeChart51.createBufferedImage((int) (byte) 100, (int) (short) 10);
        categoryPlot26.setBackgroundImage((java.awt.Image) bufferedImage54);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryPlot26);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(bufferedImage54);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (byte) 10);
        org.jfree.data.KeyedObjects keyedObjects4 = new org.jfree.data.KeyedObjects();
        boolean boolean5 = numberTickUnit1.equals((java.lang.Object) keyedObjects4);
        java.lang.Object obj7 = keyedObjects4.getObject((int) (short) 100);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint10 = textTitle9.getBackgroundPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int12 = color11.getAlpha();
        java.awt.Color color13 = color11.darker();
        int int14 = color13.getTransparency();
        boolean boolean15 = textTitle9.equals((java.lang.Object) color13);
        keyedObjects4.setObject((java.lang.Comparable) (byte) -1, (java.lang.Object) color13);
        java.lang.Object obj17 = keyedObjects4.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) -1);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryTick5.getRotationAnchor();
        org.jfree.chart.text.TextBlock textBlock7 = categoryTick5.getLabel();
        java.lang.String str8 = categoryTick5.toString();
        org.jfree.chart.text.TextBlock textBlock9 = categoryTick5.getLabel();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(textBlock7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(textBlock9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, paint12, (float) ' ');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint12);
        org.jfree.chart.text.TextLine textLine16 = textBlock15.getLastLine();
        org.jfree.chart.text.TextFragment textFragment17 = textLine16.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(textLine16);
        org.junit.Assert.assertNotNull(textFragment17);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
        java.lang.String str3 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        barRenderer0.setItemLabelAnchorOffset(0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.awt.Color color52 = java.awt.Color.green;
        float[] floatArray58 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray59 = color52.getRGBColorComponents(floatArray58);
        java.awt.color.ColorSpace colorSpace60 = color52.getColorSpace();
        barRenderer44.setBaseOutlinePaint((java.awt.Paint) color52, true);
        double double63 = barRenderer44.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator66 = barRenderer44.getURLGenerator((int) (byte) -1, (-254));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator67 = barRenderer44.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(colorSpace60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.2d + "'", double63 == 0.2d);
        org.junit.Assert.assertNull(categoryURLGenerator66);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator67);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        java.awt.Font font15 = categoryPlot9.getNoDataMessageFont();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        categoryPlot9.setDataset(15, categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range52 = numberAxis51.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = barRenderer53.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        barRenderer53.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer53);
        java.lang.String str61 = numberAxis51.getLabel();
        org.jfree.data.Range range62 = numberAxis51.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent63 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis51);
        int int64 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis51);
        numberAxis51.setUpperBound((double) 0.5f);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(categoryURLGenerator56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleAnchor.CENTER" + "'", str61.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesCreateEntities(0);
        java.awt.Paint paint4 = barRenderer0.getSeriesPaint((int) (byte) 0);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font2, paint5, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.CENTER", font2);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendTitle11.setBackgroundPaint(paint12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint21 = textFragment20.getPaint();
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font18, paint21, (float) ' ');
        legendTitle11.setItemFont(font18);
        labelBlock8.setFont(font18);
        labelBlock8.setID("");
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.data.Range range29 = null;
        org.jfree.data.Range range30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(range29, range30);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint31.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint33.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedHeight((double) 1);
        try {
            org.jfree.chart.util.Size2D size2D37 = labelBlock8.arrange(graphics2D28, rectangleConstraint36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        java.lang.String str38 = categoryPlot18.getNoDataMessage();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint4 = textFragment3.getPaint();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font1, paint4, (float) ' ');
        java.lang.String str7 = textFragment6.getText();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str9 = projectInfo8.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getOptionalLibraries();
        boolean boolean11 = textFragment6.equals((java.lang.Object) libraryArray10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str7.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 2, (float) (-16777214), 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor3);
        legendTitle1.setNotify(true);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean11 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) ' ', categoryItemLabelGenerator16);
        barRenderer0.setBase(0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        boolean boolean24 = jFreeChart21.isNotify();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean24);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(jFreeChart26);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        java.awt.Paint paint10 = barRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Paint paint11 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator12 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj13 = standardCategorySeriesLabelGenerator12.clone();
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator12);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint22 = textFragment21.getPaint();
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font19, paint22, (float) ' ');
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("10", font19, (java.awt.Paint) color25, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        categoryPlot28.setRangeAxis((int) (byte) 100, valueAxis30, true);
        java.awt.Stroke stroke33 = categoryPlot28.getOutlineStroke();
        categoryPlot28.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("", font19, (org.jfree.chart.plot.Plot) categoryPlot28, false);
        jFreeChart37.setTextAntiAlias(true);
        java.awt.Image image40 = jFreeChart37.getBackgroundImage();
        int int41 = jFreeChart37.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = jFreeChart37.getCategoryPlot();
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot42.getRangeMarkers((-1), layer44);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = legendTitle47.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str50 = rectangleInsets49.toString();
        legendTitle47.setItemLabelPadding(rectangleInsets49);
        legendTitle47.setID("{0}");
        java.awt.geom.Rectangle2D rectangle2D54 = legendTitle47.getBounds();
        try {
            barRenderer0.drawBackground(graphics2D15, categoryPlot42, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(image40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(categoryPlot42);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str50.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray2 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            legendTitle1.setMargin(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemSourceArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toFixedWidth((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(datasetGroup6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo9, point2D10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        textTitle10.setPaint((java.awt.Paint) color12);
        java.awt.Color color15 = color12.darker();
        barRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        try {
            barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setToolTipText("RectangleConstraint[RectangleConstraintType.RANGE: width=36.0, height=97.0]");
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.awt.Color color52 = java.awt.Color.green;
        float[] floatArray58 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray59 = color52.getRGBColorComponents(floatArray58);
        java.awt.color.ColorSpace colorSpace60 = color52.getColorSpace();
        barRenderer44.setBaseOutlinePaint((java.awt.Paint) color52, true);
        java.awt.Shape shape65 = barRenderer44.getItemShape(15, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(colorSpace60);
        org.junit.Assert.assertNotNull(shape65);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint6 = textFragment5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font3, paint6, (float) ' ');
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("10", font3, (java.awt.Paint) color9, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot12.setRangeAxis((int) (byte) 100, valueAxis14, true);
        java.awt.Stroke stroke17 = categoryPlot12.getOutlineStroke();
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        jFreeChart21.setTextAntiAlias(true);
        java.awt.Image image24 = jFreeChart21.getBackgroundImage();
        int int25 = jFreeChart21.getSubtitleCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart21.getCategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot27.getOrientation();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot27);
        try {
            jFreeChart21.setTextAntiAlias((java.lang.Object) categoryPlot27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.CategoryPlot@48a231e2 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryPlot26);
        org.junit.Assert.assertNotNull(plotOrientation30);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 0.0d, (double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9, true);
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) 100L, (double) 1L, plotRenderingInfo16, point2D17);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray25, numberArray30, numberArray35, numberArray40, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray46);
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot7.getRendererForDataset(categoryDataset47);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "ThreadContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset47, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryItemEntity54.getDataset();
        java.lang.String str56 = categoryItemEntity54.toString();
        java.lang.String str57 = categoryItemEntity54.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "poly" + "'", str57.equals("poly"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtTop();
        java.util.List list3 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getURLGenerator(0, (int) (short) 10);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Font font13 = barRenderer0.getItemLabelFont((int) (byte) 100, 0);
        java.awt.Shape shape16 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) -1);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.data.Range range29 = new org.jfree.data.Range((double) (byte) 10, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range26, range29);
        double double31 = range29.getLowerBound();
        numberAxis23.setDefaultAutoRange(range29);
        numberAxis23.setLowerBound(100.0d);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker35, rectangle2D36);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = barRenderer0.getLegendItemToolTipGenerator();
        barRenderer0.setSeriesVisibleInLegend(10, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 100, categoryToolTipGenerator44, true);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "VerticalAlignment.BOTTOM", "10", image3, "", "TextBlockAnchor.CENTER_LEFT", "RectangleAnchor.CENTER");
        org.jfree.chart.axis.AxisCollection axisCollection8 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list9 = axisCollection8.getAxesAtRight();
        projectInfo7.setContributors(list9);
        java.lang.String str11 = projectInfo7.getLicenceText();
        java.util.List list12 = projectInfo7.getContributors();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleAnchor.CENTER" + "'", str11.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getTransparency();
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot9.setRangeAxis((int) (byte) 100, valueAxis11, true);
        int int14 = categoryPlot9.getDatasetCount();
        java.awt.Font font15 = categoryPlot9.getNoDataMessageFont();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        categoryPlot9.setDataset(15, categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range52 = numberAxis51.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = barRenderer53.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        barRenderer53.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer53);
        java.lang.String str61 = numberAxis51.getLabel();
        org.jfree.data.Range range62 = numberAxis51.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent63 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis51);
        int int64 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis51);
        numberAxis51.setVerticalTickLabels(true);
        numberAxis51.setFixedAutoRange((double) 500);
        boolean boolean69 = numberAxis51.getAutoRangeIncludesZero();
        org.jfree.data.Range range70 = numberAxis51.getRange();
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(categoryURLGenerator56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleAnchor.CENTER" + "'", str61.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(range70);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100L, (java.lang.Comparable) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.lang.String str52 = numberAxis42.getLabel();
        numberAxis42.configure();
        numberAxis42.setVerticalTickLabels(false);
        org.jfree.data.RangeType rangeType56 = org.jfree.data.RangeType.FULL;
        java.lang.String str57 = rangeType56.toString();
        numberAxis42.setRangeType(rangeType56);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.CENTER" + "'", str52.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rangeType56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RangeType.FULL" + "'", str57.equals("RangeType.FULL"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle3.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle3.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle3.getSources();
        boolean boolean8 = tickUnits0.equals((java.lang.Object) legendTitle3);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20, numberArray25, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("GradientPaintTransformType.CENTER_VERTICAL", "Layer.BACKGROUND", numberArray31);
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RangeType.FULL", "ClassContext", numberArray31);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(categoryDataset34);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        categoryPlot0.setRangeAxis((int) (byte) 100, valueAxis2, true);
        int int5 = categoryPlot0.getDatasetCount();
        java.awt.Font font6 = categoryPlot0.getNoDataMessageFont();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (short) 10, 100L, (byte) 10, 15 };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray14, numberArray19, numberArray24, numberArray29, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "{0}", numberArray35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        categoryPlot0.setDataset(15, categoryDataset36);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
        org.jfree.data.Range range43 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer44.getURLGenerator(0, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = null;
        barRenderer44.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        java.awt.Color color52 = java.awt.Color.green;
        float[] floatArray58 = new float[] { 1, 0L, 0L, 0, (-1.0f) };
        float[] floatArray59 = color52.getRGBColorComponents(floatArray58);
        java.awt.color.ColorSpace colorSpace60 = color52.getColorSpace();
        barRenderer44.setBaseOutlinePaint((java.awt.Paint) color52, true);
        double double63 = barRenderer44.getItemMargin();
        java.awt.Paint paint65 = null;
        try {
            barRenderer44.setSeriesFillPaint((-16777214), paint65, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryURLGenerator47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(colorSpace60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.2d + "'", double63 == 0.2d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(100);
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }
}

