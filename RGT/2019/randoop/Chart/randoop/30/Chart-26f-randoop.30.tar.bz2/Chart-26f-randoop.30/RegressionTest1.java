import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}");
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        double double4 = ringPlot0.getInteriorGap();
        java.awt.Shape shape5 = ringPlot0.getLegendItemShape();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        categoryPlot62.mapDatasetToRangeAxis((int) (short) 0, 0);
        org.jfree.chart.plot.Plot plot76 = categoryPlot62.getRootPlot();
        categoryPlot62.setWeight((int) (short) 1);
        java.awt.Stroke stroke79 = categoryPlot62.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(plot76);
        org.junit.Assert.assertNotNull(stroke79);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot62.getDomainAxisEdge();
        double double69 = categoryPlot62.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        try {
            stackedBarRenderer1.setSeriesPaint((int) (short) -1, (java.awt.Paint) color3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 100L);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D0.getRowKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13, false);
        stackedBarRenderer3D3.setBaseCreateEntities(true);
        boolean boolean19 = stackedBarRenderer3D3.isSeriesItemLabelsVisible((int) (short) 1);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("Oct");
        xYPlot4.setDomainAxis(13, (org.jfree.chart.axis.ValueAxis) numberAxis15, false);
        java.awt.Paint paint18 = numberAxis15.getAxisLinePaint();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 100L);
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean4 = categoryAxis2.equals((java.lang.Object) chartChangeEventType3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "Oct", "hi!");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis2, shape5, "", "{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) numberTickUnit13, shape14, "Oct", "Oct");
        java.awt.Paint paint18 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) "Oct");
        legendTitle1.setItemPaint(paint18);
        java.awt.Color color22 = java.awt.Color.getColor("hi!", 0);
        java.awt.Color color23 = color22.brighter();
        legendTitle1.setBackgroundPaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition10.getTextAnchor();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        intervalMarker2.setStartValue((double) '4');
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot9.setRenderer(xYItemRenderer10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        xYPlot9.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot9.setRangeAxisLocation(0, axisLocation15, true);
        boolean boolean18 = xYPlot9.isRangeCrosshairVisible();
        xYPlot9.setRangeCrosshairLockedOnData(false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 900000L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        size2D0.setHeight(Double.NaN);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        java.awt.Paint paint65 = categoryPlot62.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((double) 10.0f, (java.lang.Comparable) ' ', (java.lang.Comparable) 1546329600000L);
        defaultCategoryDataset0.setValue((java.lang.Number) 12, (java.lang.Comparable) 8.64E7d, (java.lang.Comparable) 1);
        try {
            java.lang.Number number11 = defaultCategoryDataset0.getValue(12, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        boolean boolean10 = stackedBarRenderer3D4.isSeriesVisible(1);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray55);
        org.jfree.data.Range range57 = stackedBarRenderer3D4.findRangeBounds(categoryDataset56);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape61 = numberAxis60.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis58, (org.jfree.chart.axis.ValueAxis) numberAxis60, categoryItemRenderer62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Point2D point2D67 = null;
        categoryPlot63.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo66, point2D67);
        categoryPlot63.setAnchorValue((double) 10, false);
        java.awt.Paint paint73 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions75 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis74.setCategoryLabelPositions(categoryLabelPositions75);
        java.awt.Stroke stroke77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis74.setAxisLineStroke(stroke77);
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint73, stroke77);
        categoryPlot63.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker79);
        boolean boolean81 = defaultDrawingSupplier0.equals((java.lang.Object) categoryMarker79);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(categoryLabelPositions75);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        java.lang.String str57 = range56.toString();
        double double58 = range56.getCentralValue();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Range[0.0,600.0]" + "'", str57.equals("Range[0.0,600.0]"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 300.0d + "'", double58 == 300.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        textTitle53.setFont(font55);
        java.awt.Paint paint58 = textTitle53.getBackgroundPaint();
        jFreeChart50.setTitle(textTitle53);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = textTitle53.getPadding();
        double double62 = rectangleInsets60.trimWidth((double) (short) 100);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 98.0d + "'", double62 == 98.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 2);
        java.awt.Paint paint3 = ganttRenderer0.getIncompletePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = null;
        try {
            org.jfree.chart.util.Size2D size2D31 = legendGraphic28.arrange(graphics2D29, rectangleConstraint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("Oct");
        xYPlot4.setDomainAxis(13, (org.jfree.chart.axis.ValueAxis) numberAxis15, false);
        xYPlot4.zoom(Double.NaN);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis73.setCategoryLabelPositions(categoryLabelPositions74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis73.setAxisLineStroke(stroke76);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint72, stroke76);
        categoryPlot62.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78);
        boolean boolean80 = categoryMarker78.getDrawAsLine();
        boolean boolean81 = categoryMarker78.getDrawAsLine();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Color color13 = java.awt.Color.BLACK;
        java.awt.Color color14 = color13.brighter();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(0.0d, (double) (byte) 10, (double) ' ', (double) 15, (java.awt.Paint) color14);
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = xYPlot4.getDomainTickBandPaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        try {
            keyedObjects0.removeValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Number number93 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset92);
        int int94 = defaultIntervalCategoryDataset92.getRowCount();
        int int96 = defaultIntervalCategoryDataset92.getSeriesIndex((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.0d + "'", number93.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 6 + "'", int94 == 6);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-1) + "'", int96 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Oct", "hi!");
        java.lang.String str4 = chartEntity3.getShapeCoords();
        chartEntity3.setToolTipText("");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(false);
        int int3 = statisticalLineAndShapeRenderer0.getPassCount();
        java.lang.Boolean boolean5 = statisticalLineAndShapeRenderer0.getSeriesShapesFilled(0);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator6 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        statisticalLineAndShapeRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator6, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator61 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Oct", "", "hi!");
        stackedBarRenderer3D3.setSeriesURLGenerator(0, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator61);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection63 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean64 = standardCategoryURLGenerator61.equals((java.lang.Object) taskSeriesCollection63);
        try {
            java.lang.Number number67 = taskSeriesCollection63.getValue(9, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        java.awt.Font font63 = numberAxis59.getLabelFont();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(font63);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        textTitle53.setFont(font55);
        java.awt.Paint paint58 = textTitle53.getBackgroundPaint();
        jFreeChart50.setTitle(textTitle53);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = textTitle53.getPadding();
        java.lang.String str61 = textTitle53.getText();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.INSIDE12", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis25, marker26, rectangle2D27);
        stackedBarRenderer3D3.setRenderAsPercentages(false);
        java.awt.Paint paint31 = stackedBarRenderer3D3.getWallPaint();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        categoryAxis0.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis0.getTickLabelInsets();
        java.lang.Comparable comparable6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int8 = color7.getBlue();
        try {
            categoryAxis0.setTickLabelPaint(comparable6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        categoryAxis0.setLabel("Oct");
        java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint7 = categoryAxis0.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis8.setCategoryLabelPositions(categoryLabelPositions9);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        boolean boolean13 = xYPlot4.isRangeCrosshairVisible();
        java.awt.Paint paint14 = null;
        try {
            xYPlot4.setDomainZeroBaselinePaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.util.Iterator iterator8 = legendItemCollection7.iterator();
        java.lang.Object obj9 = legendItemCollection7.clone();
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection7.get((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(iterator8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        java.lang.String str4 = rectangleEdge1.toString();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleEdge.LEFT" + "'", str4.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot5.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("", "hi!", "{0}", "");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D9.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = stackedBarRenderer3D9.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D17.setSeriesItemLabelPaint(100, paint19, false);
        stackedBarRenderer3D9.setBaseItemLabelPaint(paint19);
        org.jfree.chart.LegendItem legendItem25 = stackedBarRenderer3D9.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator26 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D9.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator26, true);
        java.awt.Color color30 = java.awt.Color.BLACK;
        stackedBarRenderer3D9.setSeriesPaint((int) (byte) 10, (java.awt.Paint) color30);
        boolean boolean32 = library5.equals((java.lang.Object) color30);
        boolean boolean33 = categoryAnchor0.equals((java.lang.Object) boolean32);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        java.awt.RenderingHints renderingHints18 = jFreeChart14.getRenderingHints();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D23.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = stackedBarRenderer3D23.getLegendItems();
        java.lang.Boolean boolean29 = stackedBarRenderer3D23.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font31 = null;
        stackedBarRenderer3D23.setSeriesItemLabelFont(255, font31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D23);
        double double34 = legendTitle33.getContentXOffset();
        org.jfree.chart.block.BlockContainer blockContainer35 = null;
        legendTitle33.setWrapper(blockContainer35);
        legendTitle33.setID("GradientPaintTransformType.VERTICAL");
        jFreeChart14.addSubtitle((int) (byte) 0, (org.jfree.chart.title.Title) legendTitle33);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(renderingHints18);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Category 3");
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent63);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset66, valueAxis67, valueAxis68, xYItemRenderer69);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        xYPlot70.setRenderer(xYItemRenderer71);
        categoryAxis65.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot70);
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape76 = numberAxis75.getLeftArrow();
        numberAxis75.setAutoTickUnitSelection(false);
        boolean boolean79 = numberAxis75.getAutoRangeIncludesZero();
        xYPlot70.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis75);
        org.jfree.data.Range range81 = categoryPlot62.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis75);
        java.awt.Paint paint82 = null;
        try {
            numberAxis75.setAxisLinePaint(paint82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNull(range81);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        double double4 = ringPlot0.getShadowXOffset();
        ringPlot0.setSectionDepth((double) (-1L));
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.geom.Point2D point2D16 = xYPlot5.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(point2D16);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        java.lang.Comparable comparable4 = keyedObjects0.getKey((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Color color10 = java.awt.Color.cyan;
        categoryAxis5.setTickLabelPaint((java.lang.Comparable) numberTickUnit9, (java.awt.Paint) color10);
        java.lang.Object obj12 = keyedObjects0.getObject((java.lang.Comparable) numberTickUnit9);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.awt.Paint paint11 = stackedBarRenderer3D3.lookupSeriesOutlinePaint(10);
        java.awt.Paint paint13 = stackedBarRenderer3D3.lookupSeriesFillPaint(12);
        boolean boolean16 = stackedBarRenderer3D3.getItemVisible(0, 255);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(true);
        polarPlot0.removeCornerTextItem("UnitType.RELATIVE");
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        stackedBarRenderer3D3.setItemLabelAnchorOffset((double) 'a');
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        boolean boolean11 = stackedBarRenderer3D5.isSeriesVisible(1);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray56);
        org.jfree.data.Range range58 = stackedBarRenderer3D5.findRangeBounds(categoryDataset57);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator59 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        stackedBarRenderer3D5.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator59);
        double double61 = stackedBarRenderer3D5.getMinimumBarLength();
        keyedObjects2D0.addObject((java.lang.Object) stackedBarRenderer3D5, (java.lang.Comparable) 2, (java.lang.Comparable) 1);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        stackedBarRenderer3D3.setSeriesShape(0, shape21);
        stackedBarRenderer3D3.setBase((double) (short) 10);
        stackedBarRenderer3D3.setSeriesVisibleInLegend(12, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D6.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = stackedBarRenderer3D6.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        int int12 = polarPlot11.getBackgroundImageAlignment();
        stackedBarRenderer3D6.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        java.awt.Stroke stroke14 = polarPlot11.getOutlineStroke();
        boolean boolean15 = defaultStatisticalCategoryDataset2.equals((java.lang.Object) stroke14);
        java.lang.Comparable comparable19 = null;
        defaultStatisticalCategoryDataset2.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, (double) 10.0f);
        boolean boolean24 = range22.contains((double) 60000L);
        dateAxis1.setRange(range22, false, false);
        java.util.Date date28 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange((double) 2);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Oct", "Oct", "hi!", "({0}, {1}) = {2}", "");
        java.lang.String str6 = basicProjectInfo5.getName();
        basicProjectInfo5.setCopyright("XY Plot");
        java.lang.String str9 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oct" + "'", str6.equals("Oct"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "XY Plot" + "'", str9.equals("XY Plot"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        java.lang.Boolean boolean25 = stackedBarRenderer3D19.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font27 = null;
        stackedBarRenderer3D19.setSeriesItemLabelFont(255, font27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D19);
        double double30 = legendTitle29.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame31 = legendTitle29.getFrame();
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) legendTitle29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = legendTitle29.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor34 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint41 = intervalMarker40.getLabelPaint();
        boolean boolean42 = chartRenderingInfo36.equals((java.lang.Object) intervalMarker40);
        java.lang.Object obj43 = chartRenderingInfo36.clone();
        boolean boolean44 = textAnchor35.equals(obj43);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType46 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition48 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor33, textBlockAnchor34, textAnchor35, (double) (-1), categoryLabelWidthType46, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(textBlockAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) (byte) 100, 8);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle18 = null;
        jFreeChart14.setTitle(textTitle18);
        java.awt.Image image20 = null;
        jFreeChart14.setBackgroundImage(image20);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        double double14 = legendTitle13.getContentXOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.TOP;
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer19 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean20 = stackedBarRenderer19.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D25.setSeriesItemLabelPaint(100, paint27, false);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D25.setBaseStroke(stroke30);
        stackedBarRenderer19.setSeriesOutlineStroke(8, stroke30, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection34 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range35 = stackedBarRenderer19.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection34);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(range35, 0.0d);
        org.jfree.chart.util.Size2D size2D38 = legendTitle13.arrange(graphics2D17, rectangleConstraint37);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(size2D38);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13, false);
        stackedBarRenderer3D3.setBaseCreateEntities(true);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D3.setBaseOutlineStroke(stroke18, false);
        int int21 = stackedBarRenderer3D3.getRowCount();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (short) -1, 0);
        java.awt.Paint paint8 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D12.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = stackedBarRenderer3D12.getLegendItems();
        boolean boolean18 = stackedBarRenderer3D12.isSeriesVisible(1);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray63 = new java.lang.Number[][] { numberArray27, numberArray34, numberArray41, numberArray48, numberArray55, numberArray62 };
        org.jfree.data.category.CategoryDataset categoryDataset64 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray63);
        org.jfree.data.Range range65 = stackedBarRenderer3D12.findRangeBounds(categoryDataset64);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape69 = numberAxis68.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot(categoryDataset64, categoryAxis66, (org.jfree.chart.axis.ValueAxis) numberAxis68, categoryItemRenderer70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        java.awt.geom.Point2D point2D75 = null;
        categoryPlot71.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo74, point2D75);
        categoryPlot71.setAnchorValue((double) 10, false);
        java.awt.Paint paint81 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions83 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis82.setCategoryLabelPositions(categoryLabelPositions83);
        java.awt.Stroke stroke85 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis82.setAxisLineStroke(stroke85);
        org.jfree.chart.plot.CategoryMarker categoryMarker87 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint81, stroke85);
        categoryPlot71.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker87);
        float float89 = categoryMarker87.getAlpha();
        boolean boolean90 = statisticalBarRenderer0.equals((java.lang.Object) categoryMarker87);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(categoryDataset64);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(categoryLabelPositions83);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertTrue("'" + float89 + "' != '" + 1.0f + "'", float89 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        int int8 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYPlot4.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection9.get((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke4 = ringPlot0.getOutlineStroke();
        ringPlot0.setLabelGap((double) (-2208960000000L));
        java.awt.Shape shape7 = ringPlot0.getLegendItemShape();
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape7, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = ringPlot0.getLegendLabelURLGenerator();
        boolean boolean2 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setExplodePercent((java.lang.Comparable) "hi!", 0.0d);
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray90 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray91 = new java.lang.Number[][] { numberArray55, numberArray62, numberArray69, numberArray76, numberArray83, numberArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset93 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray45, numberArray91);
        java.lang.Number number94 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset93);
        java.lang.Comparable comparable96 = defaultIntervalCategoryDataset93.getColumnKey(2);
        java.lang.Comparable comparable97 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer98 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset93, comparable97);
        int int99 = defaultIntervalCategoryDataset93.getCategoryCount();
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 1.0d + "'", number94.equals(1.0d));
        org.junit.Assert.assertTrue("'" + comparable96 + "' != '" + "Category 3" + "'", comparable96.equals("Category 3"));
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 6 + "'", int99 == 6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = polarPlot3.getRenderer();
        polarPlot3.clearCornerTextItems();
        polarPlot3.setAngleGridlinesVisible(true);
        java.awt.Font font8 = polarPlot3.getAngleLabelFont();
        java.awt.Color color9 = java.awt.Color.BLACK;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("GradientPaintTransformType.VERTICAL", font8, (java.awt.Paint) color10);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = ringPlot12.getLabelGenerator();
        double double14 = ringPlot12.getSectionDepth();
        boolean boolean15 = ringPlot12.getIgnoreNullValues();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("org.jfree.data.time.TimePeriodFormatException: ItemLabelAnchor.INSIDE12", font8, (org.jfree.chart.plot.Plot) ringPlot12, false);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8);
        java.awt.Font font19 = textFragment18.getFont();
        org.junit.Assert.assertNull(polarItemRenderer4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D8.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = stackedBarRenderer3D8.getLegendItems();
        boolean boolean14 = stackedBarRenderer3D8.isSeriesVisible(1);
        java.awt.Paint paint16 = stackedBarRenderer3D8.lookupSeriesOutlinePaint(10);
        stackedBarRenderer3D8.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType20 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str21 = gradientPaintTransformType20.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer22 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType20);
        stackedBarRenderer3D8.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer22);
        intervalMarker2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer22);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(gradientPaintTransformType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str21.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setLowerMargin(100.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 100L);
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) 300.0d, (java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic28.getShapeAnchor();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        java.lang.String str11 = xYPlot4.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot16.setRangeAxisLocation((int) ' ', axisLocation18);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer23);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22);
        double double26 = xYPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultCategoryDataset0.hasListener((java.util.EventListener) polarPlot9);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.OUTSIDE1");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        boolean boolean11 = stackedBarRenderer3D5.isSeriesVisible(1);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray56);
        org.jfree.data.Range range58 = stackedBarRenderer3D5.findRangeBounds(categoryDataset57);
        java.awt.Font font60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        stackedBarRenderer3D5.setSeriesItemLabelFont((int) (short) 100, font60, true);
        labelBlock1.setFont(font60);
        java.lang.Object obj64 = labelBlock1.clone();
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D67 = chartRenderingInfo66.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity68 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D70 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor69);
        try {
            labelBlock1.draw(graphics2D65, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(point2D70);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        java.awt.Stroke stroke29 = null;
        legendGraphic28.setLineStroke(stroke29);
        java.awt.Paint paint31 = legendGraphic28.getOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 'a', (double) 0L, (double) (byte) 100);
        java.lang.Object obj37 = null;
        boolean boolean38 = blockBorder36.equals(obj37);
        java.awt.Paint paint39 = blockBorder36.getPaint();
        legendGraphic28.setLinePaint(paint39);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        boolean boolean4 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setLabelLinkMargin((double) (-1L));
        double double7 = ringPlot0.getLabelGap();
        boolean boolean8 = ringPlot0.isCircular();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = stackedAreaRenderer0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Shape shape0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalBarRenderer1.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator3, false);
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemPaint((int) (short) -1, 0);
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape0, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 0);
        java.awt.Color color3 = color2.brighter();
        int int4 = color3.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font25);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("", font28);
        textTitle26.setFont(font28);
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font28);
        stackedBarRenderer3D3.setBaseItemLabelFont(font28, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D3.getSeriesPositiveItemLabelPosition(15);
        double double36 = itemLabelPosition35.getAngle();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("Oct");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray90 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray91 = new java.lang.Number[][] { numberArray55, numberArray62, numberArray69, numberArray76, numberArray83, numberArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset93 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray45, numberArray91);
        java.lang.Number number94 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset93);
        java.lang.Comparable comparable96 = defaultIntervalCategoryDataset93.getColumnKey(2);
        java.lang.Comparable comparable97 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer98 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset93, comparable97);
        legendItemBlockContainer98.clear();
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 1.0d + "'", number94.equals(1.0d));
        org.junit.Assert.assertTrue("'" + comparable96 + "' != '" + "Category 3" + "'", comparable96.equals("Category 3"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) 1);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        categoryPlot62.mapDatasetToRangeAxis((int) (short) 0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = categoryPlot62.getRangeAxisEdge(0);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D0.getColumnKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer1.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer6.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot14.setRangeAxisLocation((int) ' ', axisLocation16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot23.setRangeAxisLocation((int) ' ', axisLocation25);
        xYPlot14.setDomainAxisLocation((int) '4', axisLocation25, true);
        ganttRenderer6.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot14);
        stackedBarRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.awt.Paint paint11 = stackedBarRenderer3D3.lookupSeriesOutlinePaint(10);
        java.awt.Paint paint13 = stackedBarRenderer3D3.lookupSeriesFillPaint(12);
        stackedBarRenderer3D3.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = stackedBarRenderer3D3.getSeriesToolTipGenerator((int) (byte) 10);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13, false);
        stackedBarRenderer3D3.setDrawBarOutline(true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoTickUnitSelection(false);
        double double5 = numberAxis1.getAutoRangeMinimumSize();
        float float6 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setFixedAutoRange((double) (short) 1);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(numberFormat9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TextAnchor.HALF_ASCENT_RIGHT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = stackedAreaRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType2 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        stackedAreaRenderer0.setEndType(areaRendererEndType2);
        stackedAreaRenderer0.setRenderAsPercentages(true);
        boolean boolean6 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        try {
            stackedAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(areaRendererEndType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setStartPercent((double) 2);
        double double3 = ganttRenderer0.getStartPercent();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoTickUnitSelection(false);
        double double5 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D9.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = stackedBarRenderer3D9.getLegendItems();
        java.lang.Boolean boolean15 = stackedBarRenderer3D9.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font17 = null;
        stackedBarRenderer3D9.setSeriesItemLabelFont(255, font17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        legendTitle19.setWidth((double) (-1.0f));
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis22.setCategoryLabelPositions(categoryLabelPositions23);
        categoryAxis22.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis22.getTickLabelInsets();
        legendTitle19.setLegendItemGraphicPadding(rectangleInsets27);
        numberAxis1.setTickLabelInsets(rectangleInsets27);
        double double31 = rectangleInsets27.calculateBottomInset(12.0d);
        double double32 = rectangleInsets27.getRight();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer1.setBaseItemLabelPaint(paint3, false);
        stackedBarRenderer1.setBaseSeriesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot1.getRenderer();
        polarPlot1.clearCornerTextItems();
        polarPlot1.setAngleGridlinesVisible(true);
        java.awt.Font font6 = polarPlot1.getAngleLabelFont();
        java.awt.Color color7 = java.awt.Color.BLACK;
        java.awt.Color color8 = color7.brighter();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("GradientPaintTransformType.VERTICAL", font6, (java.awt.Paint) color8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textBlock9.getLineAlignment();
        org.junit.Assert.assertNull(polarItemRenderer2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis25, marker26, rectangle2D27);
        stackedBarRenderer3D3.setRenderAsPercentages(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = stackedBarRenderer3D3.getSeriesURLGenerator((-460));
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNull(categoryURLGenerator32);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        boolean boolean31 = legendGraphic28.isShapeFilled();
        boolean boolean32 = legendGraphic28.isShapeVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot4.getAxisOffset();
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer((int) (byte) 100, xYItemRenderer11);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Oct", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot6.setRenderer(xYItemRenderer7);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        numberAxis11.setAutoTickUnitSelection(false);
        boolean boolean15 = numberAxis11.getAutoRangeIncludesZero();
        xYPlot6.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis11);
        boolean boolean17 = categoryAxis0.equals((java.lang.Object) xYPlot6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        java.awt.Font font14 = stackedBarRenderer3D3.getSeriesItemLabelFont((-8388480));
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        categoryAxis2.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis2.getTickLabelInsets();
        java.awt.Paint paint8 = categoryAxis2.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape14 = numberAxis13.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo16.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D21.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = stackedBarRenderer3D21.getLegendItems();
        boolean boolean27 = stackedBarRenderer3D21.isSeriesVisible(1);
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] { numberArray36, numberArray43, numberArray50, numberArray57, numberArray64, numberArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        org.jfree.data.Range range74 = stackedBarRenderer3D21.findRangeBounds(categoryDataset73);
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape78 = numberAxis77.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis75, (org.jfree.chart.axis.ValueAxis) numberAxis77, categoryItemRenderer79);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        java.awt.geom.Point2D point2D84 = null;
        categoryPlot80.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo83, point2D84);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = categoryPlot80.getDomainAxisEdge();
        double double87 = numberAxis13.valueToJava2D((double) (short) 10, rectangle2D17, rectangleEdge86);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = null;
        double double89 = categoryAxis2.getCategoryJava2DCoordinate(categoryAnchor9, (-1), (int) (short) 10, rectangle2D17, rectangleEdge88);
        java.awt.geom.Rectangle2D rectangle2D92 = rectangleInsets0.createInsetRectangle(rectangle2D17, false, false);
        java.awt.Shape shape96 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D17, (double) (short) 1, (float) 10, (float) 15);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D92);
        org.junit.Assert.assertNotNull(shape96);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int2 = color1.getRGB();
        float[] floatArray10 = new float[] { (-1), 4, (-1), 1 };
        float[] floatArray11 = java.awt.Color.RGBtoHSB((int) (byte) -1, 5, (int) 'a', floatArray10);
        float[] floatArray12 = color1.getColorComponents(floatArray10);
        float[] floatArray13 = color0.getComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8388480) + "'", int2 == (-8388480));
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        boolean boolean59 = range56.intersects(0.0d, (double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset60, valueAxis61, valueAxis62, xYItemRenderer63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot64.setRangeAxisLocation((int) ' ', axisLocation66);
        org.jfree.chart.plot.IntervalMarker intervalMarker70 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer71 = null;
        xYPlot64.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker70, layer71);
        org.jfree.chart.util.Layer layer73 = null;
        java.util.Collection collection74 = xYPlot64.getRangeMarkers(layer73);
        boolean boolean75 = range56.equals((java.lang.Object) layer73);
        org.jfree.data.time.DateRange dateRange76 = new org.jfree.data.time.DateRange(range56);
        java.lang.String str77 = dateRange76.toString();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str77.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        categoryAxis5.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis5.getTickLabelInsets();
        java.awt.Paint paint11 = categoryAxis5.getTickMarkPaint();
        ringPlot0.setLabelShadowPaint(paint11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = ringPlot0.getURLGenerator();
        ringPlot0.setLabelGap((double) 0.0f);
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(pieURLGenerator13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        java.lang.Boolean boolean2 = stackedBarRenderer0.getSeriesItemLabelsVisible((int) (short) 10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D6.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = stackedBarRenderer3D6.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D14.setSeriesItemLabelPaint(100, paint16, false);
        stackedBarRenderer3D6.setBaseItemLabelPaint(paint16);
        org.jfree.chart.LegendItem legendItem22 = stackedBarRenderer3D6.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator23 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D6.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator23, true);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("", font28);
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("", font31);
        textTitle29.setFont(font31);
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font31);
        stackedBarRenderer3D6.setBaseItemLabelFont(font31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = stackedBarRenderer3D6.getSeriesPositiveItemLabelPosition(15);
        stackedBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition38);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Category 3", "Oct");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.awt.Paint paint11 = stackedBarRenderer3D3.lookupSeriesOutlinePaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = stackedBarRenderer3D3.getURLGenerator(13, 0);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        stackedBarRenderer3D3.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color16);
        float[] floatArray22 = new float[] { 900000L, 7, (-1L), 86400000L };
        float[] floatArray23 = color16.getRGBComponents(floatArray22);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot62.getDomainAxisEdge();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer70 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        groupedStackedBarRenderer70.setRenderAsPercentages(true);
        categoryPlot62.setRenderer((int) '4', (org.jfree.chart.renderer.category.CategoryItemRenderer) groupedStackedBarRenderer70, true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(4, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis0.setAxisLineStroke(stroke3);
        double double5 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis73.setCategoryLabelPositions(categoryLabelPositions74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis73.setAxisLineStroke(stroke76);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint72, stroke76);
        categoryPlot62.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78);
        float float80 = categoryMarker78.getAlpha();
        java.lang.String str81 = categoryMarker78.getLabel();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + float80 + "' != '" + 1.0f + "'", float80 == 1.0f);
        org.junit.Assert.assertNull(str81);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        jFreeChart14.setBackgroundImageAlignment(8);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Number number93 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset92);
        try {
            java.lang.Number number96 = defaultIntervalCategoryDataset92.getStartValue(8, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.0d + "'", number93.equals(1.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart14.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer16 = legendTitle15.getItemContainer();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(blockContainer16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray9 = new float[] { (-1), 4, (-1), 1 };
        float[] floatArray10 = java.awt.Color.RGBtoHSB((int) (byte) -1, 5, (int) 'a', floatArray9);
        try {
            float[] floatArray11 = color0.getComponents(colorSpace1, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        boolean boolean16 = stackedBarRenderer3D3.isDrawBarOutline();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        boolean boolean31 = legendGraphic28.isShapeFilled();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendGraphic28.getShapeAnchor();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0.5f);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisState1.moveCursor((double) (-1), rectangleEdge3);
        axisState1.setMax(0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D6.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = stackedBarRenderer3D6.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        int int12 = polarPlot11.getBackgroundImageAlignment();
        stackedBarRenderer3D6.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        java.awt.Stroke stroke14 = polarPlot11.getOutlineStroke();
        boolean boolean15 = defaultStatisticalCategoryDataset2.equals((java.lang.Object) stroke14);
        java.lang.Comparable comparable19 = null;
        defaultStatisticalCategoryDataset2.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, (double) 10.0f);
        boolean boolean24 = range22.contains((double) 60000L);
        dateAxis1.setRange(range22, false, false);
        org.jfree.chart.axis.Timeline timeline28 = dateAxis1.getTimeline();
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeline28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot4.getRenderer();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer13);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.lang.String str10 = boxAndWhiskerItem9.toString();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D();
        int int13 = defaultKeyedValues2D11.getRowIndex((java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D11.removeValue((java.lang.Comparable) 1.0E-8d, (java.lang.Comparable) (byte) 100);
        boolean boolean17 = boxAndWhiskerItem9.equals((java.lang.Object) 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        java.lang.Object obj13 = xYPlot4.clone();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            xYPlot4.setRangeAxisLocation((int) (short) -1, axisLocation15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (short) -1, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = statisticalBarRenderer0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation((int) ' ', axisLocation15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot13.getDomainMarkers((int) (short) 0, layer18);
        java.util.List list20 = xYPlot13.getAnnotations();
        boolean boolean21 = statisticalBarRenderer0.equals((java.lang.Object) list20);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot4.getRangeAxisLocation(13);
        xYPlot4.setForegroundAlpha(0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        boolean boolean25 = stackedBarRenderer3D19.isSeriesVisible(1);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray34, numberArray41, numberArray48, numberArray55, numberArray62, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray70);
        org.jfree.data.Range range72 = stackedBarRenderer3D19.findRangeBounds(categoryDataset71);
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape76 = numberAxis75.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer77 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis73, (org.jfree.chart.axis.ValueAxis) numberAxis75, categoryItemRenderer77);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        java.awt.geom.Point2D point2D82 = null;
        categoryPlot78.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo81, point2D82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = categoryPlot78.getDomainAxisEdge();
        double double85 = numberAxis11.valueToJava2D((double) (short) 10, rectangle2D15, rectangleEdge84);
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.util.Layer layer87 = null;
        java.util.Collection collection88 = xYPlot4.getDomainMarkers(layer87);
        java.awt.Paint paint89 = null;
        try {
            xYPlot4.setRangeGridlinePaint(paint89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNull(collection88);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 10, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions4.getLabelPosition(rectangleEdge5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions4, categoryLabelPosition9);
        org.jfree.chart.text.TextAnchor textAnchor11 = categoryLabelPosition9.getRotationAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.INSIDE12", graphics2D1, (float) (-1L), 2.0f, textAnchor11, (double) 0.5f, (float) 1L, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(categoryLabelPosition6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) false);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Oct", "Oct", "hi!", "({0}, {1}) = {2}", "");
        java.lang.String str6 = basicProjectInfo5.getName();
        basicProjectInfo5.setName("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        basicProjectInfo5.setName("({0}, {1}) = {3} - {4}");
        basicProjectInfo5.setCopyright("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        basicProjectInfo5.setLicenceName("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oct" + "'", str6.equals("Oct"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(4, year1);
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) year1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        xYPlot5.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo9, point2D10);
        java.awt.geom.Point2D point2D12 = xYPlot5.getQuadrantOrigin();
        boolean boolean13 = paintList0.equals((java.lang.Object) point2D12);
        java.io.ObjectOutputStream objectOutputStream14 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D12, objectOutputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D12.setSeriesItemLabelPaint(100, paint14, false);
        stackedBarRenderer3D4.setBaseItemLabelPaint(paint14);
        org.jfree.chart.LegendItem legendItem20 = stackedBarRenderer3D4.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator21 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D4.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator21, true);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("", font26);
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("", font29);
        textTitle27.setFont(font29);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font29);
        stackedBarRenderer3D4.setBaseItemLabelFont(font29, true);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("hi!", font29);
        java.lang.String str36 = textTitle35.getURLText();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean38 = textTitle35.equals((java.lang.Object) itemLabelAnchor37);
        org.jfree.data.gantt.TaskSeries taskSeries40 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D41 = new org.jfree.data.DefaultKeyedValues2D();
        int int43 = defaultKeyedValues2D41.getRowIndex((java.lang.Comparable) (short) 100);
        boolean boolean44 = taskSeries40.equals((java.lang.Object) (short) 100);
        java.lang.String str45 = taskSeries40.getDescription();
        boolean boolean46 = taskSeries40.getNotify();
        boolean boolean47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) boolean38, (java.lang.Object) taskSeries40);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        polarPlot0.clearCornerTextItems();
        polarPlot0.setAngleGridlinesVisible(true);
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot6.getLegendLabelToolTipGenerator();
        ringPlot6.setLabelLinksVisible(false);
        java.awt.Paint paint10 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        ringPlot6.setOutlinePaint(paint10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        ringPlot6.setLabelOutlineStroke(stroke12);
        polarPlot0.setRadiusGridlineStroke(stroke12);
        java.awt.Stroke stroke15 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(false);
        boolean boolean3 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        try {
            lineAndShapeRenderer2.setSeriesShapesFilled((-8388480), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoTickUnitSelection(false);
        double double5 = numberAxis1.getAutoRangeMinimumSize();
        float float6 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setFixedAutoRange((double) (short) 1);
        java.awt.Stroke stroke9 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot62.setFixedDomainAxisSpace(axisSpace65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = categoryPlot62.getFixedLegendItems();
        boolean boolean68 = categoryPlot62.getDrawSharedDomainAxis();
        categoryPlot62.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNull(legendItemCollection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        boolean boolean20 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) 15);
        java.util.List list21 = defaultStatisticalCategoryDataset0.getColumnKeys();
        try {
            java.lang.Number number24 = defaultStatisticalCategoryDataset0.getValue((int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = stackedBarRenderer3D3.getDrawingSupplier();
        boolean boolean25 = stackedBarRenderer3D3.getItemCreateEntity((int) 'a', (-33));
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        stackedBarRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D22.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedBarRenderer3D22.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D30.setSeriesItemLabelPaint(100, paint32, false);
        stackedBarRenderer3D22.setBaseItemLabelPaint(paint32);
        org.jfree.chart.LegendItem legendItem38 = stackedBarRenderer3D22.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator39 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D22.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator39, true);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("", font44);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("", font47);
        textTitle45.setFont(font47);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font47);
        stackedBarRenderer3D22.setBaseItemLabelFont(font47, true);
        stackedBarRenderer1.setSeriesItemLabelFont(1, font47, false);
        stackedBarRenderer1.setItemLabelAnchorOffset((double) 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(legendItem38);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor(1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, (double) '4');
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, (double) 15, false);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = stackedBarRenderer3D3.getDrawingSupplier();
        org.jfree.chart.LegendItem legendItem25 = stackedBarRenderer3D3.getLegendItem(13, 13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = stackedBarRenderer3D3.getURLGenerator((int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNull(categoryURLGenerator28);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelToolTipGenerator();
        ringPlot1.setLabelLinksVisible(false);
        ringPlot1.setNoDataMessage("XY Plot");
        keyedObjects2D0.addObject((java.lang.Object) ringPlot1, (java.lang.Comparable) (short) -1, (java.lang.Comparable) "({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = stackedBarRenderer3D3.getDrawingSupplier();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font25);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("", font28);
        textTitle26.setFont(font28);
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font28);
        stackedBarRenderer3D3.setBaseItemLabelFont(font28, false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        statisticalBarRenderer2.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator4, false);
        java.awt.Paint paint9 = statisticalBarRenderer2.getItemPaint((int) (short) -1, 0);
        java.awt.Paint paint10 = statisticalBarRenderer2.getErrorIndicatorPaint();
        statisticalBarRenderer0.setBaseItemLabelPaint(paint10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        boolean boolean10 = stackedBarRenderer3D4.isSeriesVisible(1);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray19, numberArray26, numberArray33, numberArray40, numberArray47, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray55);
        org.jfree.data.Range range57 = stackedBarRenderer3D4.findRangeBounds(categoryDataset56);
        java.awt.Font font59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        stackedBarRenderer3D4.setSeriesItemLabelFont((int) (short) 100, font59, true);
        java.awt.Color color62 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextBlock textBlock63 = org.jfree.chart.text.TextUtilities.createTextBlock("poly", font59, (java.awt.Paint) color62);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer65 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean66 = stackedBarRenderer65.getRenderAsPercentages();
        java.awt.Paint paint67 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer65.setBaseItemLabelPaint(paint67, false);
        boolean boolean70 = textBlock63.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(textBlock63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        boolean boolean1 = stackedAreaRenderer0.getRenderAsPercentages();
        int int2 = stackedAreaRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        textTitle2.setFont(font4);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle2.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape13 = numberAxis12.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D20.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = stackedBarRenderer3D20.getLegendItems();
        boolean boolean26 = stackedBarRenderer3D20.isSeriesVisible(1);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray71 = new java.lang.Number[][] { numberArray35, numberArray42, numberArray49, numberArray56, numberArray63, numberArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray71);
        org.jfree.data.Range range73 = stackedBarRenderer3D20.findRangeBounds(categoryDataset72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape77 = numberAxis76.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset72, categoryAxis74, (org.jfree.chart.axis.ValueAxis) numberAxis76, categoryItemRenderer78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        java.awt.geom.Point2D point2D83 = null;
        categoryPlot79.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo82, point2D83);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = categoryPlot79.getDomainAxisEdge();
        double double86 = numberAxis12.valueToJava2D((double) (short) 10, rectangle2D16, rectangleEdge85);
        textTitle2.draw(graphics2D10, rectangle2D16);
        java.awt.Paint paint88 = textTitle2.getPaint();
        java.lang.String str89 = textTitle2.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "" + "'", str89.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = polarPlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem4 = legendItemCollection2.get((-8388480));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLabelGenerator();
        double double2 = ringPlot0.getSectionDepth();
        boolean boolean3 = ringPlot0.getIgnoreNullValues();
        double double4 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        double double6 = ringPlot0.getLabelGap();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D26.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = stackedBarRenderer3D26.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stackedBarRenderer3D26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = stackedBarRenderer3D26.getSeriesPositiveItemLabelPosition((int) (byte) -1);
        try {
            stackedBarRenderer3D3.setSeriesPositiveItemLabelPosition((-460), itemLabelPosition33, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        textTitle53.setFont(font55);
        java.awt.Paint paint58 = textTitle53.getBackgroundPaint();
        jFreeChart50.setTitle(textTitle53);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = textTitle53.getPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D62 = chartRenderingInfo61.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity63 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D62);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets60.createOutsetRectangle(rectangle2D62, true, true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Comparable comparable1 = null;
        try {
            defaultKeyedValues0.setValue(comparable1, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D27.setSeriesItemLabelPaint(100, paint29, false);
        stackedBarRenderer3D19.setBaseItemLabelPaint(paint29);
        org.jfree.chart.LegendItem legendItem35 = stackedBarRenderer3D19.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator36 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D19.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36, true);
        stackedBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D43.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = stackedBarRenderer3D43.getLegendItems();
        java.lang.Boolean boolean49 = stackedBarRenderer3D43.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font51 = null;
        stackedBarRenderer3D43.setSeriesItemLabelFont(255, font51);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D43);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection54 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range55 = stackedBarRenderer3D43.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection54);
        int int56 = taskSeriesCollection54.getRowCount();
        try {
            java.lang.String str59 = standardCategoryToolTipGenerator36.generateToolTip((org.jfree.data.category.CategoryDataset) taskSeriesCollection54, (-460), (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(legendItem35);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        groupedStackedBarRenderer0.setRenderAsPercentages(true);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis7.setAxisLineStroke(stroke10);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint6, stroke10);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font4, paint6, (float) 0L);
        float float15 = textFragment14.getBaselineOffset();
        boolean boolean16 = groupedStackedBarRenderer0.equals((java.lang.Object) float15);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        xYPlot4.setNoDataMessage("Category 3");
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject(255);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) (-8388480), 0.0d, (double) (-1L));
        boolean boolean6 = columnArrangement0.equals((java.lang.Object) (-8388480));
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        double double14 = legendTitle13.getContentXOffset();
        org.jfree.chart.event.TitleChangeListener titleChangeListener15 = null;
        legendTitle13.addChangeListener(titleChangeListener15);
        java.awt.Font font18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot23.setRangeAxisLocation((int) ' ', axisLocation25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot23.getDomainMarkers((int) (short) 0, layer28);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("", font18, (org.jfree.chart.plot.Plot) xYPlot23, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = jFreeChart31.getPadding();
        boolean boolean33 = jFreeChart31.isNotify();
        legendTitle13.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart31);
        org.jfree.chart.plot.Plot plot35 = jFreeChart31.getPlot();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(plot35);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Number number93 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset92);
        java.util.List list94 = defaultIntervalCategoryDataset92.getRowKeys();
        java.lang.Comparable comparable96 = null;
        try {
            defaultIntervalCategoryDataset92.setEndValue((int) (byte) 10, comparable96, (java.lang.Number) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.0d + "'", number93.equals(1.0d));
        org.junit.Assert.assertNotNull(list94);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        legendGraphic28.setLineVisible(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        boolean boolean16 = jFreeChart14.isNotify();
        int int17 = jFreeChart14.getSubtitleCount();
        java.awt.Image image18 = jFreeChart14.getBackgroundImage();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        categoryAxis0.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis0.getTickLabelInsets();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis0.setAxisLineStroke(stroke6);
        boolean boolean8 = categoryAxis0.isAxisLineVisible();
        boolean boolean9 = categoryAxis0.isVisible();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) year1);
        int int4 = task3.getSubtaskCount();
        try {
            org.jfree.data.gantt.Task task6 = task3.getSubtask((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        boolean boolean31 = legendGraphic28.isShapeFilled();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = null;
        try {
            legendGraphic28.setShapeLocation(rectangleAnchor32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation10, plotOrientation13);
        java.lang.String str15 = plotOrientation13.toString();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.VERTICAL" + "'", str15.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        double[][] doubleArray2 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, (java.lang.Comparable[]) strArray1, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        java.lang.Comparable comparable4 = keyedObjects0.getKey((int) (short) 100);
        java.lang.Object obj5 = keyedObjects0.clone();
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((double) 10.0f, (java.lang.Comparable) ' ', (java.lang.Comparable) 1546329600000L);
        defaultCategoryDataset0.setValue((java.lang.Number) 12, (java.lang.Comparable) 8.64E7d, (java.lang.Comparable) 1);
        java.lang.Comparable comparable9 = null;
        try {
            defaultCategoryDataset0.removeValue(comparable9, (java.lang.Comparable) 8.64E7d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis25, marker26, rectangle2D27);
        java.awt.Paint paint29 = stackedBarRenderer3D3.getWallPaint();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot4 = categoryAxis3D1.getPlot();
        categoryAxis3D1.setLowerMargin((double) '4');
        java.lang.Object obj7 = categoryAxis3D1.clone();
        double double8 = categoryAxis3D1.getLabelAngle();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) 10.0f);
        java.lang.Comparable comparable22 = defaultStatisticalCategoryDataset0.getColumnKey(0);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(comparable22);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("WMAP_Plot");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        org.junit.Assert.assertNotNull(icon1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range17 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range17, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint19.getHeightConstraintType();
        java.lang.String str21 = rectangleConstraint19.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str21.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Oct", "hi!");
        java.io.ObjectOutputStream objectOutputStream4 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getLowerMargin();
        categoryAxis0.setCategoryLabelPositionOffset(13);
        double double5 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = stackedAreaRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType2 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        stackedAreaRenderer0.setEndType(areaRendererEndType2);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        stackedAreaRenderer0.setBaseItemLabelFont(font4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(areaRendererEndType2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 15, (double) 5);
        java.lang.String str5 = verticalAlignment1.toString();
        java.lang.String str6 = verticalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.TOP" + "'", str5.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.TOP" + "'", str6.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = ringPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot4.getAxisOffset();
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(13, xYItemRenderer11);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Comparable comparable94 = defaultIntervalCategoryDataset92.getRowKey(0);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + comparable94 + "' != '" + "Series 1" + "'", comparable94.equals("Series 1"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer8.setDrawOutlines(false);
        boolean boolean11 = statisticalLineAndShapeRenderer8.getBaseShapesVisible();
        java.awt.Paint paint12 = statisticalLineAndShapeRenderer8.getErrorIndicatorPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis13.setCategoryLabelPositions(categoryLabelPositions14);
        categoryAxis13.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis13.getTickLabelInsets();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis13.setAxisLineStroke(stroke19);
        statisticalLineAndShapeRenderer8.setBaseStroke(stroke19, false);
        boolean boolean23 = legendItemCollection7.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        polarPlot0.clearCornerTextItems();
        polarPlot0.setAngleGridlinesVisible(true);
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot6.getLegendLabelToolTipGenerator();
        ringPlot6.setLabelLinksVisible(false);
        java.awt.Paint paint10 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        ringPlot6.setOutlinePaint(paint10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        ringPlot6.setLabelOutlineStroke(stroke12);
        polarPlot0.setRadiusGridlineStroke(stroke12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D18.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = stackedBarRenderer3D18.getLegendItems();
        boolean boolean24 = stackedBarRenderer3D18.isSeriesVisible(1);
        java.awt.Paint paint26 = stackedBarRenderer3D18.lookupSeriesOutlinePaint(10);
        polarPlot0.setAngleLabelPaint(paint26);
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot4.getAxisOffset();
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis11.setCategoryLabelPositions(categoryLabelPositions12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke14);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint10, stroke14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker16);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D21.setSeriesItemLabelPaint(100, paint23, false);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D21.setBaseStroke(stroke26);
        categoryMarker16.setOutlineStroke(stroke26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot33.setRenderer(xYItemRenderer34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot33.getAxisOffset();
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(10.0d);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot33.addDomainMarker((-8388480), (org.jfree.chart.plot.Marker) valueMarker39, layer40);
        xYPlot4.addDomainMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker16, layer40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        int int44 = xYPlot4.getIndexOf(xYItemRenderer43);
        int int45 = xYPlot4.getDatasetCount();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        boolean boolean2 = stackedAreaRenderer0.isSeriesItemLabelsVisible((int) (short) 1);
        java.lang.Object obj3 = stackedAreaRenderer0.clone();
        java.awt.Stroke stroke6 = stackedAreaRenderer0.getItemStroke((int) (byte) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        java.lang.Boolean boolean4 = stackedBarRenderer1.getSeriesVisibleInLegend((-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        categoryPlot62.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = categoryPlot62.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge76);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 0.3f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.30000001192092896d + "'", double2 == 0.30000001192092896d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray90 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray91 = new java.lang.Number[][] { numberArray55, numberArray62, numberArray69, numberArray76, numberArray83, numberArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset93 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray45, numberArray91);
        java.lang.Number number94 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset93);
        java.lang.Comparable comparable96 = defaultIntervalCategoryDataset93.getColumnKey(2);
        java.lang.Comparable comparable97 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer98 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset93, comparable97);
        org.jfree.data.general.Dataset dataset99 = legendItemBlockContainer98.getDataset();
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 1.0d + "'", number94.equals(1.0d));
        org.junit.Assert.assertTrue("'" + comparable96 + "' != '" + "Category 3" + "'", comparable96.equals("Category 3"));
        org.junit.Assert.assertNotNull(dataset99);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot4.getRangeAxisLocation(13);
        xYPlot4.setForegroundAlpha(0.0f);
        boolean boolean10 = xYPlot4.isRangeGridlinesVisible();
        xYPlot4.clearRangeMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot4.getLegendItems();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke4 = ringPlot0.getOutlineStroke();
        java.awt.Stroke stroke5 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        legendTitle13.setWidth((double) (-1.0f));
        double double16 = legendTitle13.getContentXOffset();
        legendTitle13.setWidth((double) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle13.getBounds();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        java.lang.String str2 = textAnchor0.toString();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D6.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = stackedBarRenderer3D6.getLegendItems();
        boolean boolean12 = stackedBarRenderer3D6.isSeriesVisible(1);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray21, numberArray28, numberArray35, numberArray42, numberArray49, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray57);
        org.jfree.data.Range range59 = stackedBarRenderer3D6.findRangeBounds(categoryDataset58);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape63 = numberAxis62.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis60, (org.jfree.chart.axis.ValueAxis) numberAxis62, categoryItemRenderer64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot65.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo68, point2D69);
        categoryPlot65.setWeight((int) (short) -1);
        boolean boolean73 = categoryPlot65.getDrawSharedDomainAxis();
        java.awt.Stroke stroke74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot65.setOutlineStroke(stroke74);
        categoryPlot65.mapDatasetToRangeAxis((int) (short) 0, 0);
        org.jfree.chart.plot.Plot plot79 = categoryPlot65.getRootPlot();
        categoryPlot65.setWeight((int) (short) 1);
        boolean boolean82 = textAnchor0.equals((java.lang.Object) categoryPlot65);
        categoryPlot65.clearAnnotations();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str1.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str2.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(plot79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        boolean boolean2 = stackedAreaRenderer0.isSeriesItemLabelsVisible((int) (short) 1);
        boolean boolean3 = stackedAreaRenderer0.getRenderAsPercentages();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray12, numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray48);
        java.lang.Number number50 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset49);
        org.jfree.data.Range range51 = stackedAreaRenderer0.findRangeBounds(categoryDataset49);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.0d + "'", number50.equals(0.0d));
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinRegularValue();
        java.lang.Number number11 = boxAndWhiskerItem9.getMinRegularValue();
        java.lang.Number number12 = boxAndWhiskerItem9.getMean();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) -1 + "'", number11.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 100 + "'", number12.equals((byte) 100));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(7, (int) ' ', dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 10);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 2);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        java.util.List list9 = taskSeriesCollection0.getRowKeys();
        try {
            java.lang.Comparable comparable11 = taskSeriesCollection0.getColumnKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "PlotOrientation.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        java.awt.Font font66 = null;
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot(xYDataset67, valueAxis68, valueAxis69, xYItemRenderer70);
        org.jfree.chart.axis.AxisLocation axisLocation73 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot71.setRangeAxisLocation((int) ' ', axisLocation73);
        org.jfree.chart.util.Layer layer76 = null;
        java.util.Collection collection77 = xYPlot71.getDomainMarkers((int) (short) 0, layer76);
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("", font66, (org.jfree.chart.plot.Plot) xYPlot71, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = jFreeChart79.getPadding();
        boolean boolean81 = jFreeChart79.isNotify();
        jFreeChart79.setBackgroundImageAlignment(0);
        categoryPlot62.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart79);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(axisLocation73);
        org.junit.Assert.assertNull(collection77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.awt.Paint paint11 = stackedBarRenderer3D3.lookupSeriesOutlinePaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = stackedBarRenderer3D3.getURLGenerator(13, 0);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        stackedBarRenderer3D3.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color16);
        java.awt.Paint paint18 = stackedBarRenderer3D3.getBaseFillPaint();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        numberAxis10.setRangeWithMargins(1.0E-8d, (double) ' ');
        java.awt.Shape shape19 = numberAxis10.getLeftArrow();
        numberAxis10.resizeRange(0.0d, (double) 1546329600000L);
        numberAxis10.setAxisLineVisible(true);
        numberAxis10.setUpperMargin((double) 86400000L);
        boolean boolean27 = numberAxis10.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint60 = intervalMarker59.getLabelPaint();
        boolean boolean61 = chartRenderingInfo55.equals((java.lang.Object) intervalMarker59);
        java.lang.Object obj62 = chartRenderingInfo55.clone();
        java.awt.image.BufferedImage bufferedImage63 = jFreeChart50.createBufferedImage(3, (int) ' ', 300.0d, (double) 1.0f, chartRenderingInfo55);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(bufferedImage63);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        java.lang.Comparable comparable4 = keyedObjects0.getKey((int) (short) 100);
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) 0.5f);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        try {
            taskSeriesCollection0.remove(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        boolean boolean20 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) 15);
        org.jfree.data.Range range22 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range22, 1.0d, false);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        int int68 = plotRenderingInfo67.getSubplotCount();
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot62.zoomDomainAxes((double) (byte) 10, (double) '#', plotRenderingInfo67, point2D69);
        org.jfree.data.category.CategoryDataset categoryDataset71 = categoryPlot62.getDataset();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(categoryDataset71);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        java.lang.Object obj2 = chartRenderingInfo0.clone();
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection3);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: ItemLabelAnchor.INSIDE12", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D27.setSeriesItemLabelPaint(100, paint29, false);
        stackedBarRenderer3D19.setBaseItemLabelPaint(paint29);
        org.jfree.chart.LegendItem legendItem35 = stackedBarRenderer3D19.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator36 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D19.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36, true);
        stackedBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36);
        double double40 = stackedBarRenderer1.getBase();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(legendItem35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        boolean boolean31 = legendGraphic28.isShapeFilled();
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator33 = ringPlot32.getLegendLabelToolTipGenerator();
        ringPlot32.setLabelLinksVisible(false);
        java.awt.Paint paint36 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        ringPlot32.setOutlinePaint(paint36);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        ringPlot32.setLabelOutlineStroke(stroke38);
        legendGraphic28.setOutlineStroke(stroke38);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        int int11 = polarPlot10.getBackgroundImageAlignment();
        stackedBarRenderer3D5.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        polarPlot10.setAngleGridlinePaint((java.awt.Paint) color13);
        boolean boolean15 = dateAxis1.equals((java.lang.Object) color13);
        java.util.Date date16 = dateAxis1.getMaximumDate();
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = polarPlot1.getLegendItems();
        boolean boolean3 = polarPlot1.isAngleLabelsVisible();
        java.lang.Object obj4 = polarPlot1.clone();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("Oct", (org.jfree.chart.plot.Plot) polarPlot1);
        java.awt.Paint paint6 = polarPlot1.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        stackedBarRenderer3D3.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) false, true);
        double double12 = stackedBarRenderer3D3.getBase();
        org.jfree.chart.block.Arrangement arrangement13 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        try {
            org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3, arrangement13, (org.jfree.chart.block.Arrangement) columnArrangement14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13, false);
        stackedBarRenderer3D3.setBaseCreateEntities(true);
        stackedBarRenderer3D3.setSeriesVisible(9, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        int int8 = xYPlot4.getDomainAxisCount();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot4.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot4.getAxisOffset();
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedRangeAxisSpace(axisSpace11);
        axisSpace11.setRight((double) (-460));
        java.lang.Object obj15 = axisSpace11.clone();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(false);
        org.jfree.chart.renderer.Outlier outlier3 = null;
        boolean boolean4 = outlierListCollection0.add(outlier3);
        org.jfree.chart.renderer.Outlier outlier5 = null;
        boolean boolean6 = outlierListCollection0.add(outlier5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj1 = standardCategoryToolTipGenerator0.clone();
        java.lang.Object obj2 = standardCategoryToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) numberTickUnit1, shape2, "Oct", "Oct");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("", font8);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("", font11);
        textTitle9.setFont(font11);
        textTitle9.setToolTipText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle9.getHorizontalAlignment();
        boolean boolean17 = legendItemEntity6.equals((java.lang.Object) textTitle9);
        java.lang.Object obj18 = legendItemEntity6.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        java.awt.Paint paint3 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) "UnitType.RELATIVE", paint3);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean3 = statisticalLineAndShapeRenderer0.getBaseShapesVisible();
        java.awt.Paint paint4 = statisticalLineAndShapeRenderer0.getErrorIndicatorPaint();
        boolean boolean7 = statisticalLineAndShapeRenderer0.getItemLineVisible((int) (short) -1, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace64 = categoryPlot62.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset65 = categoryPlot62.getDataset();
        categoryPlot62.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertNull(axisSpace64);
        org.junit.Assert.assertNotNull(categoryDataset65);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        ringPlot0.setInteriorGap((double) 0.0f);
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        int int18 = jFreeChart14.getSubtitleCount();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot4.getLegendItems();
        boolean boolean12 = xYPlot4.isDomainCrosshairLockedOnData();
        java.awt.Paint paint13 = xYPlot4.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2);
        try {
            boolean boolean4 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Point2D point2D9 = null;
        xYPlot4.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Paint paint19 = xYPlot18.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot18.getRangeAxisLocation(13);
        xYPlot4.setRangeAxisLocation((int) (byte) 0, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot4.setRenderer(xYItemRenderer24);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        int int13 = xYPlot4.getWeight();
        xYPlot4.setNoDataMessage("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot4.getDatasetGroup();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(datasetGroup16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range17 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection16);
        java.awt.Stroke stroke20 = stackedBarRenderer1.getItemStroke(4, 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean3 = statisticalLineAndShapeRenderer0.getBaseShapesVisible();
        boolean boolean4 = statisticalLineAndShapeRenderer0.getBaseLinesVisible();
        java.lang.Boolean boolean6 = statisticalLineAndShapeRenderer0.getSeriesShapesVisible(3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot4.getDomainMarkers((int) (short) 0, layer9);
        java.util.List list11 = xYPlot4.getAnnotations();
        java.util.Collection collection12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list11);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace64 = categoryPlot62.getFixedRangeAxisSpace();
        boolean boolean65 = categoryPlot62.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertNull(axisSpace64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) numberTickUnit1, shape2, "Oct", "Oct");
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape8 = numberAxis7.getLeftArrow();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        stackedBarRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D22.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedBarRenderer3D22.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D30.setSeriesItemLabelPaint(100, paint32, false);
        stackedBarRenderer3D22.setBaseItemLabelPaint(paint32);
        org.jfree.chart.LegendItem legendItem38 = stackedBarRenderer3D22.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator39 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D22.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator39, true);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("", font44);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("", font47);
        textTitle45.setFont(font47);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font47);
        stackedBarRenderer3D22.setBaseItemLabelFont(font47, true);
        stackedBarRenderer1.setSeriesItemLabelFont(1, font47, false);
        stackedBarRenderer1.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(legendItem38);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        boolean boolean59 = range56.intersects(0.0d, (double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset60, valueAxis61, valueAxis62, xYItemRenderer63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot64.setRangeAxisLocation((int) ' ', axisLocation66);
        org.jfree.chart.plot.IntervalMarker intervalMarker70 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer71 = null;
        xYPlot64.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker70, layer71);
        org.jfree.chart.util.Layer layer73 = null;
        java.util.Collection collection74 = xYPlot64.getRangeMarkers(layer73);
        boolean boolean75 = range56.equals((java.lang.Object) layer73);
        org.jfree.data.time.DateRange dateRange76 = new org.jfree.data.time.DateRange(range56);
        java.util.Date date77 = dateRange76.getUpperDate();
        java.util.Date date78 = dateRange76.getUpperDate();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(date78);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        double double4 = ringPlot0.getInteriorGap();
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot11.setRangeAxisLocation((int) ' ', axisLocation13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot11.getDomainMarkers((int) (short) 0, layer16);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) xYPlot11, true);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        java.awt.Color color21 = java.awt.Color.cyan;
        jFreeChart19.setBorderPaint((java.awt.Paint) color21);
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = null;
        intervalMarker26.setGradientPaintTransformer(gradientPaintTransformer27);
        java.awt.Paint paint29 = intervalMarker26.getOutlinePaint();
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color21, paint29);
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        try {
            stackedAreaRenderer0.setSeriesItemLabelGenerator((-460), categoryItemLabelGenerator2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = categoryPlot62.getInsets();
        double double67 = rectangleInsets65.trimWidth((double) (short) 100);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 84.0d + "'", double67 == 84.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "");
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        org.jfree.chart.util.Rotation rotation3 = ringPlot0.getDirection();
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) (-1));
        double double7 = numberTickUnit6.getSize();
        int int8 = keyedObjects2D4.getColumnIndex((java.lang.Comparable) numberTickUnit6);
        java.awt.Paint paint9 = null;
        ringPlot0.setSectionPaint((java.lang.Comparable) numberTickUnit6, paint9);
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) 10.0f);
        double double22 = defaultStatisticalCategoryDataset0.getRangeUpperBound(true);
        double double24 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        java.awt.Color color11 = color10.brighter();
        boolean boolean12 = boxAndWhiskerItem9.equals((java.lang.Object) color10);
        java.util.List list13 = boxAndWhiskerItem9.getOutliers();
        java.lang.Number number14 = boxAndWhiskerItem9.getQ1();
        java.lang.Number number15 = boxAndWhiskerItem9.getMaxOutlier();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 10 + "'", number14.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) false);
        statisticalLineAndShapeRenderer0.setBaseLinesVisible(true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent63);
        java.awt.Paint paint66 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions68 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis67.setCategoryLabelPositions(categoryLabelPositions68);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis67.setAxisLineStroke(stroke70);
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint66, stroke70);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent73 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker72);
        categoryPlot62.markerChanged(markerChangeEvent73);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(categoryLabelPositions68);
        org.junit.Assert.assertNotNull(stroke70);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        numberAxis10.setRangeWithMargins(1.0E-8d, (double) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D22.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedBarRenderer3D22.getLegendItems();
        boolean boolean28 = stackedBarRenderer3D22.isSeriesVisible(1);
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray72 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray73 = new java.lang.Number[][] { numberArray37, numberArray44, numberArray51, numberArray58, numberArray65, numberArray72 };
        org.jfree.data.category.CategoryDataset categoryDataset74 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray73);
        org.jfree.data.Range range75 = stackedBarRenderer3D22.findRangeBounds(categoryDataset74);
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape79 = numberAxis78.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer80 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot(categoryDataset74, categoryAxis76, (org.jfree.chart.axis.ValueAxis) numberAxis78, categoryItemRenderer80);
        org.jfree.chart.util.SortOrder sortOrder82 = categoryPlot81.getRowRenderingOrder();
        boolean boolean83 = numberAxis10.hasListener((java.util.EventListener) categoryPlot81);
        numberAxis10.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer86 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer86.setDrawOutlines(false);
        boolean boolean89 = statisticalLineAndShapeRenderer86.getBaseShapesVisible();
        boolean boolean90 = statisticalLineAndShapeRenderer86.getBaseLinesVisible();
        boolean boolean91 = numberAxis10.equals((java.lang.Object) statisticalLineAndShapeRenderer86);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(categoryDataset74);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(sortOrder82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(range63);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        boolean boolean32 = legendGraphic28.equals((java.lang.Object) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer36 = null;
        intervalMarker35.setGradientPaintTransformer(gradientPaintTransformer36);
        java.awt.Paint paint38 = intervalMarker35.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker35.getLabelAnchor();
        legendGraphic28.setShapeAnchor(rectangleAnchor39);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("GradientPaintTransformType.VERTICAL");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getRenderAsPercentages();
        stackedBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        xYPlot4.setForegroundAlpha((float) 15);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (short) -1, 0);
        boolean boolean8 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("GradientPaintTransformType.VERTICAL");
        boolean boolean11 = statisticalBarRenderer0.equals((java.lang.Object) dateAxis10);
        boolean boolean13 = dateAxis10.isHiddenValue((long) (byte) 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        int int68 = plotRenderingInfo67.getSubplotCount();
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot62.zoomDomainAxes((double) (byte) 10, (double) '#', plotRenderingInfo67, point2D69);
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot62.setDomainAxisLocation((int) '#', axisLocation72);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(axisLocation72);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean2 = categoryAxis0.equals((java.lang.Object) chartChangeEventType1);
        java.awt.Paint paint4 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("", font32);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer35 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean36 = stackedBarRenderer35.getRenderAsPercentages();
        java.awt.Paint paint39 = stackedBarRenderer35.getItemFillPaint((int) (byte) 100, 5);
        textTitle33.setBackgroundPaint(paint39);
        legendGraphic28.setOutlinePaint(paint39);
        boolean boolean42 = legendGraphic28.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        java.lang.Boolean boolean25 = stackedBarRenderer3D19.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font27 = null;
        stackedBarRenderer3D19.setSeriesItemLabelFont(255, font27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D19);
        double double30 = legendTitle29.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame31 = legendTitle29.getFrame();
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) legendTitle29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = legendTitle29.getLegendItemGraphicAnchor();
        java.lang.String str34 = legendTitle29.getID();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        int int2 = plotRenderingInfo1.getSubplotCount();
        int int3 = plotRenderingInfo1.getSubplotCount();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        stackedBarRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D22.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedBarRenderer3D22.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D30.setSeriesItemLabelPaint(100, paint32, false);
        stackedBarRenderer3D22.setBaseItemLabelPaint(paint32);
        org.jfree.chart.LegendItem legendItem38 = stackedBarRenderer3D22.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator39 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D22.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator39, true);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("", font44);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("", font47);
        textTitle45.setFont(font47);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font47);
        stackedBarRenderer3D22.setBaseItemLabelFont(font47, true);
        stackedBarRenderer1.setSeriesItemLabelFont(1, font47, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = null;
        stackedBarRenderer1.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition56, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(legendItem38);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        legendGraphic28.setLineVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendGraphic28.getShapeLocation();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace64 = categoryPlot62.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset65 = categoryPlot62.getDataset();
        categoryPlot62.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertNull(axisSpace64);
        org.junit.Assert.assertNotNull(categoryDataset65);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 15, "hi!");
        categoryAxis0.setCategoryMargin((double) (byte) 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        groupedStackedBarRenderer0.setRenderAsPercentages(true);
        org.jfree.data.KeyToGroupMap keyToGroupMap4 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1);
        int int6 = keyToGroupMap4.getKeyCount((java.lang.Comparable) "TextAnchor.HALF_ASCENT_RIGHT");
        groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap4);
        org.jfree.chart.LegendItem legendItem10 = groupedStackedBarRenderer0.getLegendItem((int) ' ', (int) (short) -1);
        java.lang.Boolean boolean12 = groupedStackedBarRenderer0.getSeriesVisibleInLegend(12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot62.getDomainAxisEdge(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor75 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot62.setDomainGridlinePosition(categoryAnchor75);
        boolean boolean77 = categoryPlot62.isRangeCrosshairVisible();
        java.lang.Object obj78 = categoryPlot62.clone();
        categoryPlot62.clearDomainAxes();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(categoryAnchor75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(obj78);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D8.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = stackedBarRenderer3D8.getLegendItems();
        java.lang.Boolean boolean14 = stackedBarRenderer3D8.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font16 = null;
        stackedBarRenderer3D8.setSeriesItemLabelFont(255, font16);
        java.awt.Paint paint18 = stackedBarRenderer3D8.getBaseOutlinePaint();
        boolean boolean19 = horizontalAlignment4.equals((java.lang.Object) stackedBarRenderer3D8);
        keyedObjects0.setObject((java.lang.Comparable) 0.25d, (java.lang.Object) horizontalAlignment4);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer4 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean5 = stackedBarRenderer4.getRenderAsPercentages();
        java.awt.Paint paint8 = stackedBarRenderer4.getItemFillPaint((int) (byte) 100, 5);
        textTitle2.setBackgroundPaint(paint8);
        java.lang.Object obj10 = textTitle2.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle2.getMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) defaultKeyedValues0);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues0.getKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 7);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot4 = categoryAxis3D1.getPlot();
        categoryAxis3D1.setLowerMargin((double) '4');
        categoryAxis3D1.setCategoryMargin(0.25d);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        groupedStackedBarRenderer0.setRenderAsPercentages(true);
        org.jfree.data.KeyToGroupMap keyToGroupMap4 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1);
        int int6 = keyToGroupMap4.getKeyCount((java.lang.Comparable) "TextAnchor.HALF_ASCENT_RIGHT");
        groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap4);
        keyToGroupMap4.mapKeyToGroup((java.lang.Comparable) "ThreadContext", (java.lang.Comparable) (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo5.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D10.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = stackedBarRenderer3D10.getLegendItems();
        boolean boolean16 = stackedBarRenderer3D10.isSeriesVisible(1);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray61 = new java.lang.Number[][] { numberArray25, numberArray32, numberArray39, numberArray46, numberArray53, numberArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray61);
        org.jfree.data.Range range63 = stackedBarRenderer3D10.findRangeBounds(categoryDataset62);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape67 = numberAxis66.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis64, (org.jfree.chart.axis.ValueAxis) numberAxis66, categoryItemRenderer68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        java.awt.geom.Point2D point2D73 = null;
        categoryPlot69.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo72, point2D73);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = categoryPlot69.getDomainAxisEdge();
        double double76 = numberAxis2.valueToJava2D((double) (short) 10, rectangle2D6, rectangleEdge75);
        numberAxis2.setLowerBound((double) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape81 = numberAxis80.getLeftArrow();
        numberAxis80.setAutoTickUnitSelection(false);
        double double84 = numberAxis80.getAutoRangeMinimumSize();
        float float85 = numberAxis80.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer86 = null;
        org.jfree.chart.plot.XYPlot xYPlot87 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis80, xYItemRenderer86);
        numberAxis80.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.0E-8d + "'", double84 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + float85 + "' != '" + 0.0f + "'", float85 == 0.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot4.getRangeAxisLocation(13);
        xYPlot4.setForegroundAlpha(0.0f);
        boolean boolean10 = xYPlot4.isRangeCrosshairLockedOnData();
        xYPlot4.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot62.getDomainAxisEdge();
        boolean boolean69 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge68);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setRangeAxisLocation((int) ' ', axisLocation14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot21.setRangeAxisLocation((int) ' ', axisLocation23);
        xYPlot12.setDomainAxisLocation((int) '4', axisLocation23, true);
        xYPlot12.setDomainCrosshairValue(100.0d);
        java.awt.Stroke stroke29 = xYPlot12.getDomainCrosshairStroke();
        intervalMarker2.setStroke(stroke29);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D9.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = stackedBarRenderer3D9.getLegendItems();
        boolean boolean15 = stackedBarRenderer3D9.isSeriesVisible(1);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray24, numberArray31, numberArray38, numberArray45, numberArray52, numberArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray60);
        org.jfree.data.Range range62 = stackedBarRenderer3D9.findRangeBounds(categoryDataset61);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape66 = numberAxis65.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis63, (org.jfree.chart.axis.ValueAxis) numberAxis65, categoryItemRenderer67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Point2D point2D72 = null;
        categoryPlot68.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo71, point2D72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot68.getDomainAxisEdge();
        double double75 = numberAxis1.valueToJava2D((double) (short) 10, rectangle2D5, rectangleEdge74);
        java.lang.String str76 = rectangleEdge74.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "RectangleEdge.BOTTOM" + "'", str76.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint1, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D12.setSeriesItemLabelPaint(100, paint14, false);
        categoryMarker7.setOutlinePaint(paint14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = categoryMarker7.getLabelOffsetType();
        boolean boolean20 = categoryMarker7.equals((java.lang.Object) 12);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker7.getLabelTextAnchor();
        java.lang.Comparable comparable22 = categoryMarker7.getKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0f + "'", comparable22.equals(100.0f));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Paint paint2 = stackedAreaRenderer0.lookupSeriesFillPaint(3);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.lang.String str10 = boxAndWhiskerItem9.toString();
        java.util.List list11 = boxAndWhiskerItem9.getOutliers();
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation((int) ' ', axisLocation15);
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation15, true);
        xYPlot4.setDomainCrosshairValue(100.0d);
        boolean boolean21 = xYPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape24 = numberAxis23.getLeftArrow();
        numberAxis23.setAutoTickUnitSelection(false);
        double double27 = numberAxis23.getAutoRangeMinimumSize();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = numberAxis23.getMarkerBand();
        org.jfree.data.Range range29 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E-8d + "'", double27 == 1.0E-8d);
        org.junit.Assert.assertNull(markerAxisBand28);
        org.junit.Assert.assertNull(range29);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(0.0d, (double) 100L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation((int) ' ', axisLocation15);
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation15, true);
        xYPlot4.setDomainCrosshairValue(100.0d);
        boolean boolean21 = xYPlot4.isDomainGridlinesVisible();
        java.awt.Paint paint22 = xYPlot4.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.TimePeriod timePeriod4 = task3.getDuration();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) year6);
        int int9 = task8.getSubtaskCount();
        task3.addSubtask(task8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        java.awt.Color color11 = color10.brighter();
        boolean boolean12 = boxAndWhiskerItem9.equals((java.lang.Object) color10);
        java.lang.Number number13 = boxAndWhiskerItem9.getMaxOutlier();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0f + "'", number13.equals(100.0f));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        java.lang.Object obj9 = rendererChangeEvent8.getRenderer();
        java.lang.String str10 = rendererChangeEvent8.toString();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) 15, "hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity20 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) numberTickUnit16, shape17, "Oct", "Oct");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity23 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis11, shape17, "hi!", "{0}");
        java.awt.Paint paint24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryAxis11.setTickLabelPaint(paint24);
        xYPlot4.setDomainGridlinePaint(paint24);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = xYPlot4.getOrientation();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(plotOrientation27);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) false, (java.lang.Number) 1546329600000L);
        try {
            defaultKeyedValues0.insertValue((int) '#', (java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 10);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 2);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        java.util.List list9 = taskSeriesCollection0.getRowKeys();
        try {
            java.lang.Number number12 = taskSeriesCollection0.getValue(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        stackedBarRenderer3D3.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot8);
        double double11 = stackedBarRenderer3D3.getXOffset();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setWidth((double) 0L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range17 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range17, 0.0d);
        org.jfree.data.Range range20 = rectangleConstraint19.getHeightRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = categoryPlot62.getOrientation();
        categoryPlot62.setAnchorValue((double) 9);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(plotOrientation73);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis1.setAxisLineStroke(stroke4);
        boolean boolean6 = categoryLabelPositions0.equals((java.lang.Object) stroke4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = categoryLabelPositions10.getLabelPosition(rectangleEdge11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions7, categoryLabelPosition12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition12.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions16.getLabelPosition(rectangleEdge17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = categoryLabelPositions19.getLabelPosition(rectangleEdge20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions16, categoryLabelPosition21);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryLabelPosition21.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions15, categoryLabelPosition21);
        double double25 = categoryLabelPosition21.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(categoryLabelPosition12);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(categoryLabelPosition18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(categoryLabelPosition21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        taskSeries1.setKey((java.lang.Comparable) year2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot62.getDomainAxisEdge(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor75 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot62.setDomainGridlinePosition(categoryAnchor75);
        boolean boolean77 = categoryPlot62.isRangeCrosshairVisible();
        boolean boolean78 = categoryPlot62.isRangeZoomable();
        java.awt.Font font80 = null;
        org.jfree.data.xy.XYDataset xYDataset81 = null;
        org.jfree.chart.axis.ValueAxis valueAxis82 = null;
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = null;
        org.jfree.chart.plot.XYPlot xYPlot85 = new org.jfree.chart.plot.XYPlot(xYDataset81, valueAxis82, valueAxis83, xYItemRenderer84);
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot85.setRangeAxisLocation((int) ' ', axisLocation87);
        org.jfree.chart.util.Layer layer90 = null;
        java.util.Collection collection91 = xYPlot85.getDomainMarkers((int) (short) 0, layer90);
        org.jfree.chart.JFreeChart jFreeChart93 = new org.jfree.chart.JFreeChart("", font80, (org.jfree.chart.plot.Plot) xYPlot85, true);
        jFreeChart93.setTextAntiAlias(false);
        java.awt.Paint paint96 = jFreeChart93.getBackgroundPaint();
        categoryPlot62.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart93);
        jFreeChart93.setNotify(true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(categoryAnchor75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertNull(collection91);
        org.junit.Assert.assertNotNull(paint96);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D8.setBaseSeriesVisible(true, false);
        java.awt.Shape shape14 = stackedBarRenderer3D8.getItemShape((int) (short) -1, 0);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer16 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint17 = ganttRenderer16.getIncompletePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D22.setSeriesItemLabelPaint(100, paint24, false);
        java.awt.Shape shape27 = stackedBarRenderer3D22.getBaseShape();
        java.awt.Paint paint28 = stackedBarRenderer3D22.getBaseOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot33.setRangeAxisLocation((int) ' ', axisLocation35);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset38, valueAxis39, valueAxis40, xYItemRenderer41);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot42.setRangeAxisLocation((int) ' ', axisLocation44);
        xYPlot33.setDomainAxisLocation((int) '4', axisLocation44, true);
        xYPlot33.setDomainCrosshairValue(100.0d);
        java.awt.Stroke stroke50 = xYPlot33.getDomainCrosshairStroke();
        java.awt.Shape shape52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions54 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis53.setCategoryLabelPositions(categoryLabelPositions54);
        categoryAxis53.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = categoryAxis53.getTickLabelInsets();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis53.setAxisLineStroke(stroke59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions62 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis61.setCategoryLabelPositions(categoryLabelPositions62);
        categoryAxis61.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = categoryAxis61.getTickLabelInsets();
        java.awt.Paint paint67 = categoryAxis61.getTickMarkPaint();
        try {
            org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem(attributedString0, "({0}, {1}) = {2}", "", "RectangleEdge.LEFT", true, shape14, true, paint17, true, paint28, stroke50, true, shape52, stroke59, paint67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(categoryLabelPositions54);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(categoryLabelPositions62);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Color color13 = java.awt.Color.BLACK;
        java.awt.Color color14 = color13.brighter();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(0.0d, (double) (byte) 10, (double) ' ', (double) 15, (java.awt.Paint) color14);
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = xYPlot4.getDomainTickBandPaint();
        boolean boolean18 = xYPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 10);
        double double5 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset4);
        java.lang.Comparable comparable6 = null;
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset4, comparable6, (double) 2, 9999);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        xYPlot4.setDomainCrosshairValue((double) (byte) 100, false);
        java.awt.Paint paint16 = xYPlot4.getRangeTickBandPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean19 = categoryAxis17.equals((java.lang.Object) chartChangeEventType18);
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape20, "Oct", "hi!");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis17, shape20, "", "{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) numberTickUnit28, shape29, "Oct", "Oct");
        java.awt.Paint paint33 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) "Oct");
        xYPlot4.setRangeTickBandPaint(paint33);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        double double17 = rectangleInsets15.extendWidth(0.0d);
        double double19 = rectangleInsets15.calculateRightInset((double) 10L);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot62.setFixedDomainAxisSpace(axisSpace65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = categoryPlot62.getFixedLegendItems();
        boolean boolean68 = categoryPlot62.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = categoryPlot62.getRangeAxisLocation((-460));
        categoryPlot62.setRangeCrosshairValue((-1.0d));
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNull(legendItemCollection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(axisLocation70);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Paint paint51 = xYPlot20.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemPaint((int) (short) -1, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = statisticalBarRenderer0.getDrawingSupplier();
        java.awt.Paint paint9 = statisticalBarRenderer0.getBasePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean2 = categoryAxis0.equals((java.lang.Object) chartChangeEventType1);
        categoryAxis0.setCategoryMargin(0.05d);
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis73.setCategoryLabelPositions(categoryLabelPositions74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis73.setAxisLineStroke(stroke76);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint72, stroke76);
        categoryPlot62.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78);
        categoryPlot62.zoom((double) (-1.0f));
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions83 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis82.setCategoryLabelPositions(categoryLabelPositions83);
        categoryAxis82.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = categoryAxis82.getTickLabelInsets();
        java.awt.Stroke stroke88 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis82.setAxisLineStroke(stroke88);
        java.util.List list90 = categoryPlot62.getCategoriesForAxis(categoryAxis82);
        categoryPlot62.clearRangeMarkers((int) 'a');
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(categoryLabelPositions83);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(list90);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis10.setMarkerBand(markerAxisBand16);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        java.lang.Boolean boolean25 = stackedBarRenderer3D19.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font27 = null;
        stackedBarRenderer3D19.setSeriesItemLabelFont(255, font27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D19);
        double double30 = legendTitle29.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame31 = legendTitle29.getFrame();
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) legendTitle29);
        java.lang.Object obj33 = null;
        boolean boolean34 = jFreeChart14.equals(obj33);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        double double5 = intervalMarker2.getEndValue();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = polarPlot8.getRenderer();
        polarPlot8.clearCornerTextItems();
        polarPlot8.setAngleGridlinesVisible(true);
        java.awt.Font font13 = polarPlot8.getAngleLabelFont();
        java.awt.Color color14 = java.awt.Color.BLACK;
        java.awt.Color color15 = color14.brighter();
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("GradientPaintTransformType.VERTICAL", font13, (java.awt.Paint) color15);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = ringPlot17.getLabelGenerator();
        double double19 = ringPlot17.getSectionDepth();
        boolean boolean20 = ringPlot17.getIgnoreNullValues();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("org.jfree.data.time.TimePeriodFormatException: ItemLabelAnchor.INSIDE12", font13, (org.jfree.chart.plot.Plot) ringPlot17, false);
        intervalMarker2.setLabelFont(font13);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertNull(polarItemRenderer9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 13);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot62.setFixedDomainAxisSpace(axisSpace65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = categoryPlot62.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = categoryPlot62.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation71 = null;
        categoryPlot62.setRangeAxisLocation((int) (short) 1, axisLocation71);
        org.jfree.chart.axis.AxisLocation axisLocation74 = categoryPlot62.getDomainAxisLocation(3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNull(legendItemCollection67);
        org.junit.Assert.assertNotNull(categoryAxis69);
        org.junit.Assert.assertNotNull(axisLocation74);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        categoryPlot62.mapDatasetToRangeAxis((int) (short) 0, 0);
        org.jfree.chart.plot.PlotOrientation plotOrientation76 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot62.setOrientation(plotOrientation76);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(plotOrientation76);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        statisticalBarRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator5, false);
        java.awt.Paint paint10 = statisticalBarRenderer3.getItemPaint((int) (short) -1, 0);
        boolean boolean11 = statisticalBarRenderer3.getAutoPopulateSeriesFillPaint();
        boolean boolean12 = statisticalLineAndShapeRenderer0.equals((java.lang.Object) statisticalBarRenderer3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoTickUnitSelection(false);
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        java.awt.Color color13 = java.awt.Color.BLACK;
        java.awt.Color color14 = color13.brighter();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(0.0d, (double) (byte) 10, (double) ' ', (double) 15, (java.awt.Paint) color14);
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = null;
        xYPlot4.setDomainTickBandPaint(paint17);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Number number93 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset92);
        java.lang.Comparable comparable95 = defaultIntervalCategoryDataset92.getColumnKey(2);
        java.lang.String[] strArray97 = org.jfree.data.time.SerialDate.getMonths(true);
        try {
            defaultIntervalCategoryDataset92.setCategoryKeys((java.lang.Comparable[]) strArray97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of categories does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.0d + "'", number93.equals(1.0d));
        org.junit.Assert.assertTrue("'" + comparable95 + "' != '" + "Category 3" + "'", comparable95.equals("Category 3"));
        org.junit.Assert.assertNotNull(strArray97);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Number number93 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset92);
        java.lang.Object obj94 = defaultIntervalCategoryDataset92.clone();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.0d + "'", number93.equals(1.0d));
        org.junit.Assert.assertNotNull(obj94);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        stackedBarRenderer3D3.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        polarPlot8.setAngleGridlinePaint((java.awt.Paint) color11);
        java.awt.Stroke stroke13 = polarPlot8.getRadiusGridlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        polarPlot8.markerChanged(markerChangeEvent14);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Color color3 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", (-33));
        java.awt.Color color4 = java.awt.Color.getColor("Oct", color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(4, year1);
        org.jfree.data.time.Year year4 = month3.getYear();
        long long5 = month3.getSerialIndex();
        long long6 = month3.getFirstMillisecond();
        long long7 = month3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24232L + "'", long5 == 24232L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1554102000000L + "'", long6 == 1554102000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1556693999999L + "'", long7 == 1556693999999L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot62.getDomainAxisEdge(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor75 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot62.setDomainGridlinePosition(categoryAnchor75);
        boolean boolean77 = categoryPlot62.isRangeCrosshairVisible();
        boolean boolean78 = categoryPlot62.isRangeZoomable();
        java.awt.Font font80 = null;
        org.jfree.data.xy.XYDataset xYDataset81 = null;
        org.jfree.chart.axis.ValueAxis valueAxis82 = null;
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = null;
        org.jfree.chart.plot.XYPlot xYPlot85 = new org.jfree.chart.plot.XYPlot(xYDataset81, valueAxis82, valueAxis83, xYItemRenderer84);
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot85.setRangeAxisLocation((int) ' ', axisLocation87);
        org.jfree.chart.util.Layer layer90 = null;
        java.util.Collection collection91 = xYPlot85.getDomainMarkers((int) (short) 0, layer90);
        org.jfree.chart.JFreeChart jFreeChart93 = new org.jfree.chart.JFreeChart("", font80, (org.jfree.chart.plot.Plot) xYPlot85, true);
        jFreeChart93.setTextAntiAlias(false);
        java.awt.Paint paint96 = jFreeChart93.getBackgroundPaint();
        categoryPlot62.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart93);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent98 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent98);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(categoryAnchor75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertNull(collection91);
        org.junit.Assert.assertNotNull(paint96);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        boolean boolean16 = jFreeChart14.isNotify();
        java.awt.Paint paint17 = jFreeChart14.getBorderPaint();
        java.awt.Image image18 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("Oct");
        double double21 = numberAxis20.getLowerMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D25.setBaseSeriesVisible(true, false);
        java.awt.Shape shape31 = stackedBarRenderer3D25.getItemShape((int) (short) -1, 0);
        numberAxis20.setDownArrow(shape31);
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) numberAxis20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.axis.NumberAxis@13500 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0.5f);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisState1.moveCursor((double) (-1), rectangleEdge3);
        axisState1.cursorDown(84.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        categoryPlot62.mapDatasetToRangeAxis((int) (short) 0, 0);
        categoryPlot62.clearRangeMarkers();
        java.util.List list77 = categoryPlot62.getAnnotations();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(list77);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        int int13 = xYPlot4.getWeight();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = ringPlot14.getLegendLabelToolTipGenerator();
        ringPlot14.setLabelLinksVisible(false);
        java.awt.Paint paint18 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        ringPlot14.setOutlinePaint(paint18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        ringPlot14.setLabelOutlineStroke(stroke20);
        xYPlot4.setDomainGridlineStroke(stroke20);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) 6);
        axisState0.cursorDown(0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) -1, 31, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo0.getChartArea();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setRenderAsPercentages(true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        categoryPlot62.setOutlineVisible(false);
        try {
            java.lang.Object obj72 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        boolean boolean11 = stackedBarRenderer3D5.isSeriesVisible(1);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray56);
        org.jfree.data.Range range58 = stackedBarRenderer3D5.findRangeBounds(categoryDataset57);
        java.awt.Font font60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        stackedBarRenderer3D5.setSeriesItemLabelFont((int) (short) 100, font60, true);
        java.awt.Color color63 = java.awt.Color.BLACK;
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("poly", font60, (java.awt.Paint) color63);
        java.awt.Paint paint65 = null;
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset66, valueAxis67, valueAxis68, xYItemRenderer69);
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot70.setRangeAxisLocation((int) ' ', axisLocation72);
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer78 = null;
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot(xYDataset75, valueAxis76, valueAxis77, xYItemRenderer78);
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot79.setRangeAxisLocation((int) ' ', axisLocation81);
        xYPlot70.setDomainAxisLocation((int) '4', axisLocation81, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = xYPlot70.getDomainAxisEdge();
        java.awt.Font font87 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle88 = new org.jfree.chart.title.TextTitle("", font87);
        java.awt.Font font90 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle91 = new org.jfree.chart.title.TextTitle("", font90);
        textTitle88.setFont(font90);
        textTitle88.setToolTipText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment95 = textTitle88.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment96 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets97 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle98 = new org.jfree.chart.title.TextTitle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font60, paint65, rectangleEdge85, horizontalAlignment95, verticalAlignment96, rectangleInsets97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'paint' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(font87);
        org.junit.Assert.assertNotNull(font90);
        org.junit.Assert.assertNotNull(horizontalAlignment95);
        org.junit.Assert.assertNotNull(verticalAlignment96);
        org.junit.Assert.assertNotNull(rectangleInsets97);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot4.getRangeAxisLocation(13);
        xYPlot4.setForegroundAlpha(0.0f);
        boolean boolean10 = xYPlot4.isRangeCrosshairLockedOnData();
        java.awt.Image image11 = xYPlot4.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        ringPlot0.setNoDataMessage("XY Plot");
        int int6 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = stackedAreaRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType2 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        stackedAreaRenderer0.setEndType(areaRendererEndType2);
        stackedAreaRenderer0.setRenderAsPercentages(true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Oct", "", "hi!");
        stackedAreaRenderer0.setSeriesURLGenerator(12, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10, true);
        java.awt.Shape shape15 = stackedAreaRenderer0.getItemShape(0, 255);
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(areaRendererEndType2);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        java.awt.Stroke stroke65 = categoryPlot62.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot62.getDomainAxisLocation();
        java.awt.Color color67 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot62.setOutlinePaint((java.awt.Paint) color67);
        int int69 = categoryPlot62.getDatasetCount();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(100.0d, (double) (short) 10, (double) 4, (double) (short) 10);
        double double5 = rectangleInsets4.getTop();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.title.Title title16 = jFreeChart14.getSubtitle((int) (short) 0);
        float float17 = jFreeChart14.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(title16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, 84.0d, categoryLabelWidthType4, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D8.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = stackedBarRenderer3D8.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        int int14 = polarPlot13.getBackgroundImageAlignment();
        stackedBarRenderer3D8.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot13);
        java.awt.Stroke stroke16 = polarPlot13.getOutlineStroke();
        boolean boolean17 = defaultStatisticalCategoryDataset4.equals((java.lang.Object) stroke16);
        java.lang.Comparable comparable21 = null;
        defaultStatisticalCategoryDataset4.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) 10.0f);
        boolean boolean26 = range24.contains((double) 60000L);
        dateAxis3.setRange(range24, false, false);
        java.util.Date date30 = dateAxis3.getMaximumDate();
        java.util.Date date31 = dateTickUnit1.addToDate(date30);
        java.util.Date date32 = dateTickUnit0.addToDate(date31);
        int int33 = dateTickUnit0.getCount();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        xYPlot5.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo9, point2D10);
        java.awt.geom.Point2D point2D12 = xYPlot5.getQuadrantOrigin();
        boolean boolean13 = paintList0.equals((java.lang.Object) point2D12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        paintList0.setPaint((int) '4', (java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        textTitle2.setFont(font4);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle2.getHorizontalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = ringPlot10.getLegendLabelURLGenerator();
        java.awt.Font font12 = ringPlot10.getLabelFont();
        textTitle2.setFont(font12);
        java.lang.Object obj14 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = ringPlot0.getDrawingSupplier();
        ringPlot0.setOuterSeparatorExtension(4.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        java.lang.String str64 = sortOrder63.toString();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "SortOrder.ASCENDING" + "'", str64.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = polarPlot0.getDrawingSupplier();
        java.awt.Stroke stroke4 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        int int11 = polarPlot10.getBackgroundImageAlignment();
        stackedBarRenderer3D5.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        polarPlot10.setAngleGridlinePaint((java.awt.Paint) color13);
        boolean boolean15 = dateAxis1.equals((java.lang.Object) color13);
        java.util.Date date16 = dateAxis1.getMaximumDate();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year17.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 10);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 2);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        java.util.List list9 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.gantt.TaskSeries taskSeries11 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        taskSeries11.removeChangeListener((org.jfree.data.general.SeriesChangeListener) taskSeriesCollection12);
        taskSeriesCollection0.add(taskSeries11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D();
        int int4 = defaultKeyedValues2D2.getRowIndex((java.lang.Comparable) (short) 100);
        boolean boolean5 = taskSeries1.equals((java.lang.Object) (short) 100);
        java.lang.String str6 = taskSeries1.getDescription();
        java.lang.Comparable comparable7 = taskSeries1.getKey();
        int int8 = taskSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "{0}" + "'", comparable7.equals("{0}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "ThreadContext");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer12 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean13 = stackedBarRenderer12.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D18.setSeriesItemLabelPaint(100, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D18.setBaseStroke(stroke23);
        stackedBarRenderer12.setSeriesOutlineStroke(8, stroke23, false);
        stackedBarRenderer12.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D33.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection37 = stackedBarRenderer3D33.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint43 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D41.setSeriesItemLabelPaint(100, paint43, false);
        stackedBarRenderer3D33.setBaseItemLabelPaint(paint43);
        org.jfree.chart.LegendItem legendItem49 = stackedBarRenderer3D33.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator50 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D33.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator50, true);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("", font58);
        textTitle56.setFont(font58);
        org.jfree.chart.text.TextLine textLine61 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font58);
        stackedBarRenderer3D33.setBaseItemLabelFont(font58, true);
        stackedBarRenderer12.setSeriesItemLabelFont(1, font58, false);
        categoryAxis0.setTickLabelFont(font58);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(legendItemCollection37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(legendItem49);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(font58);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis5.setAxisLineStroke(stroke8);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint4, stroke8);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font2, paint4, (float) 0L);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("Oct", font2);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedDomainAxisSpace(axisSpace11);
        xYPlot4.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot4.setRenderer(0, xYItemRenderer15, true);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) xYItemRenderer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        java.lang.Comparable comparable4 = keyedObjects0.getKey((int) (short) 100);
        java.lang.Comparable comparable5 = null;
        try {
            keyedObjects0.removeValue(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(comparable4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.Number[][] numberArray0 = null;
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray90 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray91 = new java.lang.Number[][] { numberArray55, numberArray62, numberArray69, numberArray76, numberArray83, numberArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset93 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray45, numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset94 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray0, numberArray45);
        try {
            java.lang.Number number97 = defaultIntervalCategoryDataset94.getEndValue((int) (short) 100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent63);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset66, valueAxis67, valueAxis68, xYItemRenderer69);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        xYPlot70.setRenderer(xYItemRenderer71);
        categoryAxis65.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot70);
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape76 = numberAxis75.getLeftArrow();
        numberAxis75.setAutoTickUnitSelection(false);
        boolean boolean79 = numberAxis75.getAutoRangeIncludesZero();
        xYPlot70.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis75);
        org.jfree.data.Range range81 = categoryPlot62.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis75);
        numberAxis75.setLowerMargin((double) 2);
        org.jfree.chart.util.RectangleInsets rectangleInsets88 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) (-8388480), 0.0d, (double) (-1L));
        numberAxis75.setLabelInsets(rectangleInsets88);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNull(range81);
    }
}

