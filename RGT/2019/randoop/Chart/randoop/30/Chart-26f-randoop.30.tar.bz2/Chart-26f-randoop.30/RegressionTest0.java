import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) -1, (float) (short) 100, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-33) + "'", int3 == (-33));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.awt.Shape shape9 = stackedBarRenderer3D3.getSeriesShape((int) (byte) 1);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(shape9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        try {
            stackedBarRenderer3D3.setSeriesVisibleInLegend((-33), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D9.setSeriesItemLabelPaint(100, paint11, false);
        polarPlot5.setAngleGridlinePaint(paint11);
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", shape4, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D13.setSeriesItemLabelPaint(100, paint15, false);
        stackedBarRenderer3D5.setBaseItemLabelPaint(paint15);
        try {
            org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("Oct", font1, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(255, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) -1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        try {
            java.lang.String str48 = standardCategorySeriesLabelGenerator0.generateLabel(categoryDataset46, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            stackedBarRenderer3D3.drawDomainGridline(graphics2D10, categoryPlot11, rectangle2D12, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (255) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.BLACK;
        java.awt.Color color8 = color7.brighter();
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("{0}", "", "", "hi!", shape4, paint5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue(255, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis22.setCategoryLabelPositions(categoryLabelPositions23);
        categoryAxis22.setLabelURL("hi!");
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            stackedBarRenderer3D3.drawDomainMarker(graphics2D20, categoryPlot21, categoryAxis22, categoryMarker27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions8);
        categoryAxis7.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (-33), (-1.0f), (byte) 0, 100.0d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (-33), (-1.0f), (byte) 0, 100.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-33), (-1.0f), (byte) 0, 100.0d };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (-33), (-1.0f), (byte) 0, 100.0d };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (-33), (-1.0f), (byte) 0, 100.0d };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray19, numberArray24, numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Oct", "", numberArray40);
        try {
            stackedBarRenderer1.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis7, valueAxis12, categoryDataset41, (int) (short) 10, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.lang.String str23 = standardCategoryToolTipGenerator20.getLabelFormat();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "({0}, {1}) = {2}" + "'", str23.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        try {
            stackedBarRenderer3D3.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "({0}, {1}) = {2}");
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray31, numberArray38, numberArray45, numberArray52, numberArray59, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray67);
        try {
            java.lang.String str71 = standardCategoryToolTipGenerator20.generateToolTip(categoryDataset68, 15, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        try {
            stackedBarRenderer3D3.setBasePositiveItemLabelPosition(itemLabelPosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Oct", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        boolean boolean8 = color0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(true);
        java.awt.Font font3 = null;
        try {
            polarPlot0.setNoDataMessageFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.awt.Paint paint11 = stackedBarRenderer3D3.lookupSeriesOutlinePaint(10);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) false);
        int int15 = stackedBarRenderer3D3.getPassCount();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        xYPlot4.configureRangeAxes();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart14.handleClick((int) '#', 2, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot4.getDomainMarkers((int) (short) 0, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray11 = null;
        try {
            xYPlot4.setRenderers(xYItemRendererArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 'a', (double) 0L, (double) (byte) 100);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("({0}, {1}) = {2}", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot4.getDomainMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = null;
        try {
            xYPlot4.setDatasetRenderingOrder(datasetRenderingOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        xYPlot4.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint1, stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            categoryMarker7.setLabelOffsetType(lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        boolean boolean20 = stackedBarRenderer3D3.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        float[] floatArray4 = new float[] { 2 };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB(0, (int) (byte) 10, 0, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        polarPlot0.handleClick((int) (short) -1, 1, plotRenderingInfo4);
        try {
            polarPlot0.zoom((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(polarItemRenderer1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        categoryAxis0.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createOutsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        java.lang.String str16 = rectangleInsets15.toString();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str16.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        try {
            categoryPlot62.zoomRangeAxes(10.0d, 0.0d, plotRenderingInfo65, point2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.5) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("Oct");
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        try {
            java.lang.Number number18 = taskSeriesCollection14.getPercentComplete(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer94 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean95 = stackedBarRenderer94.getRenderAsPercentages();
        java.awt.Paint paint96 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer94.setBaseItemLabelPaint(paint96, false);
        boolean boolean99 = defaultIntervalCategoryDataset92.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(paint96);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean2 = categoryAxis0.equals((java.lang.Object) chartChangeEventType1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "Oct", "hi!");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape3, "", "{0}");
        java.lang.String str10 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        java.awt.geom.Point2D point2D13 = null;
        try {
            xYPlot4.setQuadrantOrigin(point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        try {
            statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            xYPlot4.setOrientation(plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions2.getLabelPosition(rectangleEdge3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = categoryLabelPositions5.getLabelPosition(rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions2, categoryLabelPosition7);
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryLabelPosition7.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor9, (double) (-2208960000000L), categoryLabelWidthType11, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(categoryLabelPosition7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        java.lang.Number number57 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset55);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 100.0d + "'", number57.equals(100.0d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            legendTitle2.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean6 = categoryAxis4.equals((java.lang.Object) chartChangeEventType5);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "Oct", "hi!");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis4, shape7, "", "{0}");
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D18.setSeriesItemLabelPaint(100, paint20, false);
        polarPlot14.setAngleGridlinePaint(paint20);
        java.awt.Paint paint25 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis26.setCategoryLabelPositions(categoryLabelPositions27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis26.setAxisLineStroke(stroke29);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint25, stroke29);
        java.awt.Color color32 = java.awt.Color.BLACK;
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "", "{0}", shape7, paint20, stroke29, (java.awt.Paint) color32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray3 = new float[] { (byte) 100, (short) 0 };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        java.awt.Color color11 = color10.brighter();
        boolean boolean12 = boxAndWhiskerItem9.equals((java.lang.Object) color10);
        java.awt.color.ColorSpace colorSpace13 = null;
        float[] floatArray16 = new float[] { 10, 86400000L };
        try {
            float[] floatArray17 = color10.getComponents(colorSpace13, floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        xYPlot6.clearRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = null;
        try {
            xYPlot4.setQuadrantOrigin(point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        stackedBarRenderer3D3.setItemMargin((double) 'a');
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        stackedBarRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = stackedBarRenderer3D3.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        stackedBarRenderer3D3.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition24, true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNull(drawingSupplier22);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        xYPlot4.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue((java.lang.Comparable) 1.0f, (java.lang.Comparable) 0.5f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.5");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        try {
            java.lang.Comparable comparable20 = defaultStatisticalCategoryDataset0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.awt.Color color1 = color0.brighter();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.util.Date date2 = dateTickUnit0.addToDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        try {
            defaultKeyedValues2D0.removeRow((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        stackedBarRenderer3D3.setBaseCreateEntities(true, false);
        boolean boolean11 = stackedBarRenderer3D3.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType2 = stackedAreaRenderer1.getEndType();
        java.awt.Shape shape4 = stackedAreaRenderer1.getSeriesShape((-1));
        org.junit.Assert.assertNotNull(areaRendererEndType2);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, (float) 900000L, (float) 10L, textAnchor4, (double) 1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation((int) ' ', axisLocation15);
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation15, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.lang.Object obj1 = null;
        boolean boolean2 = textBlock0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 100L, (double) 1.0f, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setAutoPopulateSeriesPaint(false);
        double double6 = stackedBarRenderer3D3.getXOffset();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        stackedBarRenderer3D3.setAutoPopulateSeriesStroke(false);
        boolean boolean11 = stackedBarRenderer3D3.isSeriesVisibleInLegend(1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        polarPlot0.setRenderer(polarItemRenderer2);
        try {
            double double4 = polarPlot0.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot6.getLegendLabelToolTipGenerator();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        int int11 = plotRenderingInfo10.getSubplotCount();
        try {
            org.jfree.chart.plot.PiePlotState piePlotState12 = ringPlot0.initialise(graphics2D3, rectangle2D5, (org.jfree.chart.plot.PiePlot) ringPlot6, (java.lang.Integer) 2, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        try {
            defaultIntervalCategoryDataset92.setEndValue(0, (java.lang.Comparable) (byte) 1, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: unrecognised category.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D9.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = stackedBarRenderer3D9.getLegendItems();
        boolean boolean15 = stackedBarRenderer3D9.isSeriesVisible(1);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray24, numberArray31, numberArray38, numberArray45, numberArray52, numberArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray60);
        org.jfree.data.Range range62 = stackedBarRenderer3D9.findRangeBounds(categoryDataset61);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape66 = numberAxis65.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis63, (org.jfree.chart.axis.ValueAxis) numberAxis65, categoryItemRenderer67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Point2D point2D72 = null;
        categoryPlot68.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo71, point2D72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot68.getDomainAxisEdge();
        double double75 = numberAxis1.valueToJava2D((double) (short) 10, rectangle2D5, rectangleEdge74);
        boolean boolean76 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L));
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) numberTickUnit1, shape2, "Oct", "Oct");
        java.lang.String str6 = categoryLabelEntity5.toString();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape9 = numberAxis8.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo11.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D16.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = stackedBarRenderer3D16.getLegendItems();
        boolean boolean22 = stackedBarRenderer3D16.isSeriesVisible(1);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray31, numberArray38, numberArray45, numberArray52, numberArray59, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray67);
        org.jfree.data.Range range69 = stackedBarRenderer3D16.findRangeBounds(categoryDataset68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape73 = numberAxis72.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, categoryAxis70, (org.jfree.chart.axis.ValueAxis) numberAxis72, categoryItemRenderer74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot75.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo78, point2D79);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot75.getDomainAxisEdge();
        double double82 = numberAxis8.valueToJava2D((double) (short) 10, rectangle2D12, rectangleEdge81);
        categoryLabelEntity5.setArea((java.awt.Shape) rectangle2D12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        int int2 = plotRenderingInfo1.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(rectangle2D3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D3.setBaseStroke(stroke8);
        double double10 = stackedBarRenderer3D3.getItemMargin();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D18.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = stackedBarRenderer3D18.getLegendItems();
        boolean boolean24 = stackedBarRenderer3D18.isSeriesVisible(1);
        java.awt.Paint paint26 = stackedBarRenderer3D18.lookupSeriesOutlinePaint(10);
        java.awt.Stroke stroke27 = stackedBarRenderer3D18.getBaseStroke();
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) stackedBarRenderer3D18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.renderer.category.StackedBarRenderer3D@1dc4114d incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Paint paint73 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions75 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis74.setCategoryLabelPositions(categoryLabelPositions75);
        java.awt.Stroke stroke77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis74.setAxisLineStroke(stroke77);
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint73, stroke77);
        org.jfree.chart.util.Layer layer80 = null;
        try {
            categoryPlot62.addDomainMarker((int) (short) 100, categoryMarker79, layer80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(categoryLabelPositions75);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        java.awt.Shape shape8 = stackedBarRenderer3D3.getBaseShape();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "Range[0.0,600.0]", "hi!");
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis73.setCategoryLabelPositions(categoryLabelPositions74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis73.setAxisLineStroke(stroke76);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint72, stroke76);
        categoryPlot62.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78);
        java.lang.Object obj80 = categoryMarker78.clone();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(obj80);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        stackedBarRenderer3D3.setRenderAsPercentages(false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            polarPlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D0.getColumnKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator20 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator20, true);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font25);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("", font28);
        textTitle26.setFont(font28);
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE1", font28);
        stackedBarRenderer3D3.setBaseItemLabelFont(font28, true);
        java.awt.Paint paint36 = stackedBarRenderer3D3.getItemFillPaint((int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot62.getDomainAxisEdge(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor75 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot62.setDomainGridlinePosition(categoryAnchor75);
        java.awt.Stroke stroke77 = null;
        try {
            categoryPlot62.setRangeGridlineStroke(stroke77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(categoryAnchor75);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        double double4 = ringPlot0.getShadowYOffset();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot7.getLegendLabelToolTipGenerator();
        double double9 = ringPlot7.getInteriorGap();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        int int13 = plotRenderingInfo12.getSubplotCount();
        try {
            org.jfree.chart.plot.PiePlotState piePlotState14 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) ringPlot7, (java.lang.Integer) 5, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.25d + "'", double9 == 0.25d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        polarPlot0.datasetChanged(datasetChangeEvent2);
        boolean boolean4 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot5.getRangeAxisForDataset((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        int int1 = polarPlot0.getBackgroundImageAlignment();
        float float2 = polarPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        try {
            java.lang.Number number5 = defaultKeyedValues2D0.getValue(15, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        categoryPlot62.setRangeCrosshairValue((double) (-1L), true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-1L));
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range3, 0.0d, (double) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-1L));
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range11, 0.0d, (double) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 1L, range3, lengthConstraintType7, (double) 86400000L, range11, lengthConstraintType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14, (double) 900000L);
        try {
            int int20 = taskSeriesCollection14.getSubIntervalCount((java.lang.Comparable) 12, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        boolean boolean3 = categoryAnchor0.equals((java.lang.Object) standardCategorySeriesLabelGenerator1);
        java.lang.Object obj4 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.util.Date date0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint5 = intervalMarker4.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker4.setLabelAnchor(rectangleAnchor6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        intervalMarker4.setLabelTextAnchor(textAnchor8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.axis.DateTick dateTick12 = new org.jfree.chart.axis.DateTick(date0, "", textAnchor8, textAnchor10, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        java.util.List list19 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ChartChangeEventType.DATASET_UPDATED", "UnitType.RELATIVE", "", "{0}");
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        int int2 = plotRenderingInfo1.getSubplotCount();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = plotRenderingInfo1.getSubplotInfo(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D9.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = stackedBarRenderer3D9.getLegendItems();
        java.lang.Boolean boolean15 = stackedBarRenderer3D9.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font17 = null;
        stackedBarRenderer3D9.setSeriesItemLabelFont(255, font17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        double double20 = legendTitle19.getContentXOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.TOP;
        legendTitle19.setLegendItemGraphicEdge(rectangleEdge21);
        java.awt.Font font23 = legendTitle19.getItemFont();
        intervalMarker2.setLabelFont(font23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        java.awt.Color color11 = color10.brighter();
        boolean boolean12 = boxAndWhiskerItem9.equals((java.lang.Object) color10);
        java.lang.Number number13 = boxAndWhiskerItem9.getMean();
        java.lang.Number number14 = boxAndWhiskerItem9.getMaxRegularValue();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 100 + "'", number13.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1 + "'", number14.equals(1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.event.ChartChangeListener chartChangeListener48 = null;
        try {
            jFreeChart44.removeChangeListener(chartChangeListener48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        java.awt.Image image2 = polarPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("");
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable2 = null;
        try {
            defaultCategoryDataset0.addValue((double) 255, comparable2, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray54, numberArray61, numberArray68, numberArray75, numberArray82, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray90);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset92 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray44, numberArray90);
        java.lang.Number number93 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset92);
        try {
            defaultIntervalCategoryDataset92.setStartValue(5, (java.lang.Comparable) "Oct", (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: unrecognised category.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.0d + "'", number93.equals(1.0d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D10.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = stackedBarRenderer3D10.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        int int16 = polarPlot15.getBackgroundImageAlignment();
        stackedBarRenderer3D10.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot15);
        java.awt.Stroke stroke18 = polarPlot15.getOutlineStroke();
        boolean boolean19 = defaultStatisticalCategoryDataset6.equals((java.lang.Object) stroke18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis24.setCategoryLabelPositions(categoryLabelPositions25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis24.setAxisLineStroke(stroke27);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint23, stroke27);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("", font21, paint23, (float) 0L);
        try {
            org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.OUTSIDE1", "ChartChangeEventType.DATASET_UPDATED", "{0}", shape4, (java.awt.Paint) color5, stroke18, paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("({0}, {1}) = {2}", (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "Oct", "hi!");
        stackedBarRenderer3D5.setSeriesShape(10, shape7);
        shapeList0.setShape((int) (short) 0, shape7);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = stackedBarRenderer3D3.getSeriesItemLabelGenerator(255);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot4.getAxisOffset();
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = xYPlot4.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinRegularValue();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean12 = boxAndWhiskerItem9.equals((java.lang.Object) textAnchor11);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        double double22 = stackedBarRenderer3D3.getMinimumBarLength();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis1.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint7 = categoryAxis1.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape13 = numberAxis12.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D20.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = stackedBarRenderer3D20.getLegendItems();
        boolean boolean26 = stackedBarRenderer3D20.isSeriesVisible(1);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray71 = new java.lang.Number[][] { numberArray35, numberArray42, numberArray49, numberArray56, numberArray63, numberArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray71);
        org.jfree.data.Range range73 = stackedBarRenderer3D20.findRangeBounds(categoryDataset72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape77 = numberAxis76.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset72, categoryAxis74, (org.jfree.chart.axis.ValueAxis) numberAxis76, categoryItemRenderer78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        java.awt.geom.Point2D point2D83 = null;
        categoryPlot79.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo82, point2D83);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = categoryPlot79.getDomainAxisEdge();
        double double86 = numberAxis12.valueToJava2D((double) (short) 10, rectangle2D16, rectangleEdge85);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = null;
        double double88 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor8, (-1), (int) (short) 10, rectangle2D16, rectangleEdge87);
        try {
            boolean boolean89 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        double double57 = stackedBarRenderer3D3.getBase();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        categoryAxis0.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis0.getTickLabelInsets();
        java.awt.Paint paint6 = categoryAxis0.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D14.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = stackedBarRenderer3D14.getLegendItems();
        boolean boolean20 = stackedBarRenderer3D14.isSeriesVisible(1);
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray65 = new java.lang.Number[][] { numberArray29, numberArray36, numberArray43, numberArray50, numberArray57, numberArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray65);
        org.jfree.data.Range range67 = stackedBarRenderer3D14.findRangeBounds(categoryDataset66);
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape71 = numberAxis70.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis68, (org.jfree.chart.axis.ValueAxis) numberAxis70, categoryItemRenderer72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        java.awt.geom.Point2D point2D77 = null;
        categoryPlot73.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo76, point2D77);
        categoryPlot73.setWeight((int) (short) -1);
        boolean boolean81 = categoryPlot73.getDrawSharedDomainAxis();
        java.awt.Stroke stroke82 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot73.setOutlineStroke(stroke82);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = categoryPlot73.getDomainAxisEdge(8);
        try {
            double double86 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor7, 3, (int) (byte) 100, rectangle2D10, rectangleEdge85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(rectangleEdge85);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = ringPlot0.getLegendLabelURLGenerator();
        boolean boolean2 = ringPlot0.isCircular();
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue((double) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        try {
            xYPlot4.setDomainAxis((-8388480), valueAxis8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 15, "hi!");
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0E-8d);
        java.lang.String str6 = categoryAxis0.getLabel();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE12" + "'", str1.equals("ItemLabelAnchor.INSIDE12"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {2}", graphics2D1, (float) 7, (float) 255, (double) 4, (float) 10L, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType2 = stackedAreaRenderer1.getEndType();
        boolean boolean3 = stackedAreaRenderer1.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(areaRendererEndType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        numberAxis10.setAutoTickUnitSelection(false);
        boolean boolean14 = numberAxis10.getAutoRangeIncludesZero();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        numberAxis10.setRangeWithMargins(1.0E-8d, (double) ' ');
        numberAxis10.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("({0}, {1}) = {2}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedBarRenderer3D3.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("({0}, {1}) = {2}", "GradientPaintTransformType.VERTICAL", "Category 3", "", "hi!");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.util.Iterator iterator8 = legendItemCollection7.iterator();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D18.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = stackedBarRenderer3D18.getLegendItems();
        boolean boolean24 = stackedBarRenderer3D18.isSeriesVisible(1);
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray69 = new java.lang.Number[][] { numberArray33, numberArray40, numberArray47, numberArray54, numberArray61, numberArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray69);
        org.jfree.data.Range range71 = stackedBarRenderer3D18.findRangeBounds(categoryDataset70);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape75 = numberAxis74.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot(categoryDataset70, categoryAxis72, (org.jfree.chart.axis.ValueAxis) numberAxis74, categoryItemRenderer76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        java.awt.geom.Point2D point2D81 = null;
        categoryPlot77.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo80, point2D81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = categoryPlot77.getDomainAxisEdge();
        double double84 = numberAxis10.valueToJava2D((double) (short) 10, rectangle2D14, rectangleEdge83);
        boolean boolean85 = legendItemCollection7.equals((java.lang.Object) rectangleEdge83);
        org.jfree.chart.LegendItem legendItem86 = null;
        legendItemCollection7.add(legendItem86);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(iterator8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean6 = categoryAxis4.equals((java.lang.Object) chartChangeEventType5);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "Oct", "hi!");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis4, shape7, "", "{0}");
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis17.setCategoryLabelPositions(categoryLabelPositions18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis17.setAxisLineStroke(stroke20);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint16, stroke20);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer24 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean25 = stackedBarRenderer24.getRenderAsPercentages();
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer24.setBaseItemLabelPaint(paint26, false);
        try {
            org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem(attributedString0, "UnitType.RELATIVE", "({0}, {1}) = {2}", "ItemLabelAnchor.INSIDE12", shape7, paint14, stroke20, paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setRangeCrosshairLockedOnData(false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.setValue((double) (-1.0f), (java.lang.Comparable) (-8388480), comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        double double6 = intervalMarker2.getStartValue();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-1L));
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range2, 0.0d, (double) 0);
        double double7 = range2.constrain((double) (byte) 1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        java.awt.Font font3 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot62.setRangeAxisLocation((int) '4', axisLocation72);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(axisLocation72);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.lang.Comparable comparable4 = taskSeries1.getKey();
        int int5 = taskSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "{0}" + "'", comparable4.equals("{0}"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) 100);
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D0.removeValue(comparable3, (java.lang.Comparable) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        boolean boolean12 = stackedBarRenderer3D3.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint1, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D12.setSeriesItemLabelPaint(100, paint14, false);
        categoryMarker7.setOutlinePaint(paint14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = categoryMarker7.getLabelOffsetType();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D22.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedBarRenderer3D22.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D30.setSeriesItemLabelPaint(100, paint32, false);
        stackedBarRenderer3D22.setBaseItemLabelPaint(paint32);
        org.jfree.chart.LegendItem legendItem38 = stackedBarRenderer3D22.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator39 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D22.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator39, true);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.Marker marker45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        stackedBarRenderer3D22.drawRangeMarker(graphics2D42, categoryPlot43, valueAxis44, marker45, rectangle2D46);
        boolean boolean48 = lengthAdjustmentType18.equals((java.lang.Object) valueAxis44);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(legendItem38);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        stackedBarRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D22.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = stackedBarRenderer3D22.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D30.setSeriesItemLabelPaint(100, paint32, false);
        stackedBarRenderer3D22.setBaseItemLabelPaint(paint32);
        org.jfree.chart.LegendItem legendItem38 = stackedBarRenderer3D22.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D22.setMaximumBarWidth((double) '4');
        java.awt.Paint paint43 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions45 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis44.setCategoryLabelPositions(categoryLabelPositions45);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis44.setAxisLineStroke(stroke47);
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint43, stroke47);
        stackedBarRenderer3D22.setSeriesOutlineStroke(7, stroke47);
        try {
            stackedBarRenderer1.setSeriesStroke((-8388480), stroke47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(legendItem38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(categoryLabelPositions45);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14, (double) 900000L);
        try {
            java.lang.Comparable comparable19 = taskSeriesCollection14.getSeriesKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint5 = intervalMarker4.getLabelPaint();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) intervalMarker4);
        java.lang.Object obj7 = chartRenderingInfo0.clone();
        chartRenderingInfo0.clear();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        java.lang.Class class0 = null;
//        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//        java.util.ResourceBundle.clearCache(classLoader1);
//        org.junit.Assert.assertNotNull(classLoader1);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint5 = intervalMarker4.getLabelPaint();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) intervalMarker4);
        java.lang.Object obj7 = intervalMarker4.clone();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator61 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Oct", "", "hi!");
        stackedBarRenderer3D3.setSeriesURLGenerator(0, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator61);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection63 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean64 = standardCategoryURLGenerator61.equals((java.lang.Object) taskSeriesCollection63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        try {
            java.lang.Number number68 = taskSeriesCollection63.getStartValue((java.lang.Comparable) 100.0d, (java.lang.Comparable) year66, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint8 = intervalMarker7.getLabelPaint();
        boolean boolean9 = chartRenderingInfo3.equals((java.lang.Object) intervalMarker7);
        java.lang.Object obj10 = chartRenderingInfo3.clone();
        boolean boolean11 = textAnchor2.equals(obj10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions12.getLabelPosition(rectangleEdge13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = categoryLabelPositions15.getLabelPosition(rectangleEdge16);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions12, categoryLabelPosition17);
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryLabelPosition17.getRotationAnchor();
        try {
            org.jfree.chart.axis.DateTick dateTick21 = new org.jfree.chart.axis.DateTick(date0, "Range[0.0,600.0]", textAnchor2, textAnchor19, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(categoryLabelPosition17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D();
        int int4 = defaultKeyedValues2D2.getRowIndex((java.lang.Comparable) (short) 100);
        boolean boolean5 = taskSeries1.equals((java.lang.Object) (short) 100);
        org.jfree.data.gantt.Task task6 = null;
        taskSeries1.remove(task6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("ChartChangeEventType.DATASET_UPDATED");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean3 = statisticalLineAndShapeRenderer0.getBaseShapesVisible();
        boolean boolean4 = statisticalLineAndShapeRenderer0.getBaseLinesVisible();
        statisticalLineAndShapeRenderer0.setBaseShapesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Oct");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        double double4 = ringPlot0.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        ringPlot0.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color7 = color5.brighter();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        textTitle2.setFont(font4);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle2.getHorizontalAlignment();
        java.lang.Object obj10 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = categoryLabelPositions3.getLabelPosition(rectangleEdge4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = categoryLabelPosition5.getCategoryAnchor();
        double double8 = categoryLabelPosition5.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPosition2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(categoryLabelPosition5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("({0}, {1}) = {2}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        polarPlot0.clearCornerTextItems();
        polarPlot0.setAngleGridlinesVisible(true);
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        polarPlot0.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot0.zoomRangeAxes(0.0d, Double.NaN, plotRenderingInfo10, point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot4 = categoryAxis3D1.getPlot();
        java.awt.Paint paint5 = categoryAxis3D1.getTickMarkPaint();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer12);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = null;
        intervalMarker11.setGradientPaintTransformer(gradientPaintTransformer14);
        boolean boolean16 = numberTickUnit0.equals((java.lang.Object) gradientPaintTransformer14);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Oct", "Oct", "hi!", "({0}, {1}) = {2}", "");
        java.lang.String str6 = basicProjectInfo5.getName();
        basicProjectInfo5.setName("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        basicProjectInfo5.addOptionalLibrary("hi!");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oct" + "'", str6.equals("Oct"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("{0}", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis5.setAxisLineStroke(stroke8);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint4, stroke8);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font2, paint4, (float) 0L);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D16.setSeriesItemLabelPaint(100, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D16.setBaseStroke(stroke21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-33), paint4, stroke21, paint23, stroke24, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot4.getRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape17 = numberAxis16.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo19.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D24.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = stackedBarRenderer3D24.getLegendItems();
        boolean boolean30 = stackedBarRenderer3D24.isSeriesVisible(1);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray67 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray39, numberArray46, numberArray53, numberArray60, numberArray67, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray75);
        org.jfree.data.Range range77 = stackedBarRenderer3D24.findRangeBounds(categoryDataset76);
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape81 = numberAxis80.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset76, categoryAxis78, (org.jfree.chart.axis.ValueAxis) numberAxis80, categoryItemRenderer82);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
        java.awt.geom.Point2D point2D87 = null;
        categoryPlot83.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo86, point2D87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = categoryPlot83.getDomainAxisEdge();
        double double90 = numberAxis16.valueToJava2D((double) (short) 10, rectangle2D20, rectangleEdge89);
        java.util.List list91 = null;
        xYPlot4.drawDomainTickBands(graphics2D14, rectangle2D20, list91);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        numberAxis11.setAutoTickUnitSelection(false);
        boolean boolean15 = numberAxis11.getAutoRangeIncludesZero();
        xYPlot5.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 100, (java.lang.Number) (short) 10, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) (-1), (java.lang.Number) 100.0f, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinRegularValue();
        java.lang.Number number11 = boxAndWhiskerItem9.getMinRegularValue();
        java.lang.String str12 = boxAndWhiskerItem9.toString();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) -1 + "'", number11.equals((short) -1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        statisticalBarRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator5, false);
        boolean boolean8 = stackedBarRenderer1.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D20.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = stackedBarRenderer3D20.getLegendItems();
        java.lang.Boolean boolean26 = stackedBarRenderer3D20.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font28 = null;
        stackedBarRenderer3D20.setSeriesItemLabelFont(255, font28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D20);
        legendTitle30.setWidth((double) (-1.0f));
        try {
            jFreeChart14.addSubtitle((-33), (org.jfree.chart.title.Title) legendTitle30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNull(boolean26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent63);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D68 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint70 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D68.setSeriesItemLabelPaint(100, paint70, false);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D68.setBaseStroke(stroke73);
        categoryPlot62.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D68);
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset77, valueAxis78, valueAxis79, xYItemRenderer80);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo84 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo84);
        java.awt.geom.Point2D point2D86 = null;
        xYPlot81.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo85, point2D86);
        java.awt.geom.Rectangle2D rectangle2D88 = plotRenderingInfo85.getPlotArea();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType89 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        boolean boolean90 = plotRenderingInfo85.equals((java.lang.Object) gradientPaintTransformType89);
        java.awt.geom.Point2D point2D91 = null;
        categoryPlot62.zoomDomainAxes((double) 10.0f, plotRenderingInfo85, point2D91);
        java.awt.geom.Rectangle2D rectangle2D93 = plotRenderingInfo85.getPlotArea();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNull(rectangle2D88);
        org.junit.Assert.assertNotNull(gradientPaintTransformType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(rectangle2D93);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ChartChangeEventType.DATASET_UPDATED", graphics2D1, 0.0f, (float) 1, (double) 10L, (float) (byte) -1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        categoryPlot62.mapDatasetToRangeAxis((int) (short) 0, 0);
        categoryPlot62.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis78 = categoryPlot62.getRangeAxis(3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(valueAxis78);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot5.setRenderer(xYItemRenderer6);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        try {
            xYPlot5.setRenderer((-1), xYItemRenderer10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Oct", "hi!");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "Oct", "hi!");
        chartEntity3.setArea(shape4);
        java.lang.String str9 = chartEntity3.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "poly" + "'", str9.equals("poly"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(0, axisLocation10, true);
        int int13 = xYPlot4.getWeight();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        org.jfree.data.category.CategoryDataset categoryDataset68 = categoryPlot62.getDataset();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(categoryDataset68);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getEndValue((-1), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        java.awt.Color color10 = java.awt.Color.getColor("hi!", 0);
        java.awt.Color color11 = color10.brighter();
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) 1.0E-8d, (java.lang.Comparable) (byte) 100);
        int int7 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor6);
        try {
            intervalMarker2.setAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        java.awt.Color color2 = java.awt.Color.YELLOW;
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color2);
        boolean boolean5 = color2.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        int int63 = categoryPlot62.getDatasetCount();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        java.awt.Font font12 = textFragment11.getFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "Oct", "hi!");
        stackedBarRenderer3D16.setSeriesShape(10, shape18);
        boolean boolean23 = textFragment11.equals((java.lang.Object) shape18);
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot24.getRenderer();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color26);
        java.awt.Paint paint29 = legendGraphic28.getOutlinePaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("ThreadContext", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Image image17 = null;
        jFreeChart14.setBackgroundImage(image17);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        java.awt.Shape shape9 = stackedBarRenderer3D3.getItemShape((int) (short) -1, 0);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer11 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean12 = stackedBarRenderer11.getRenderAsPercentages();
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer11.setBaseItemLabelPaint(paint13, false);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(paint13);
        stackedBarRenderer3D3.setWallPaint(paint13);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        boolean boolean11 = stackedBarRenderer3D5.isSeriesVisible(1);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray56);
        org.jfree.data.Range range58 = stackedBarRenderer3D5.findRangeBounds(categoryDataset57);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape62 = numberAxis61.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis59, (org.jfree.chart.axis.ValueAxis) numberAxis61, categoryItemRenderer63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        categoryPlot64.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo67, point2D68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot64.getDomainAxisEdge();
        boolean boolean71 = chartRenderingInfo0.equals((java.lang.Object) categoryPlot64);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (byte) 0);
        java.util.List list3 = defaultKeyedValues2D0.getRowKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(100.0d, (double) (short) 10, (double) 4, (double) (short) 10);
        double double6 = rectangleInsets4.calculateTopOutset((double) (-1L));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13, false);
        stackedBarRenderer3D3.setBaseCreateEntities(true);
        try {
            stackedBarRenderer3D3.setSeriesVisible((-33), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke4 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = ringPlot0.getLabelGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke4 = ringPlot0.getOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieDataset5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        try {
            keyedObjects2D0.removeRow(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot62.setFixedDomainAxisSpace(axisSpace65);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation67 = null;
        try {
            boolean boolean68 = categoryPlot62.removeAnnotation(categoryAnnotation67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) '4', (-8388480));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        xYPlot4.setDomainCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        java.awt.Paint paint19 = intervalMarker18.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker18.setLabelAnchor(rectangleAnchor20);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer22);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot4.getRangeAxisLocation(13);
        xYPlot4.setForegroundAlpha(0.0f);
        boolean boolean10 = xYPlot4.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        numberAxis1.setAutoTickUnitSelection(true, false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        int int68 = plotRenderingInfo67.getSubplotCount();
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot62.zoomDomainAxes((double) (byte) 10, (double) '#', plotRenderingInfo67, point2D69);
        categoryPlot62.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D7.setSeriesItemLabelPaint(100, paint9, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D7.setBaseStroke(stroke12);
        stackedBarRenderer1.setSeriesOutlineStroke(8, stroke12, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint29 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D27.setSeriesItemLabelPaint(100, paint29, false);
        stackedBarRenderer3D19.setBaseItemLabelPaint(paint29);
        org.jfree.chart.LegendItem legendItem35 = stackedBarRenderer3D19.getLegendItem((int) (short) -1, 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator36 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D19.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36, true);
        stackedBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator36);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator40 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        stackedBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator40);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(legendItem35);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean14 = categoryAxis12.equals((java.lang.Object) chartChangeEventType13);
        chartChangeEvent11.setType(chartChangeEventType13);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        boolean boolean24 = stackedBarRenderer3D3.isItemLabelVisible((int) (byte) 10, (int) (short) 0);
        stackedBarRenderer3D3.setSeriesVisibleInLegend(2, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint1, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D12.setSeriesItemLabelPaint(100, paint14, false);
        categoryMarker7.setOutlinePaint(paint14);
        java.awt.Paint paint18 = categoryMarker7.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D3.setBaseStroke(stroke8);
        stackedBarRenderer3D3.setAutoPopulateSeriesFillPaint(false);
        boolean boolean12 = stackedBarRenderer3D3.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        java.awt.Paint paint23 = stackedBarRenderer3D3.getSeriesItemLabelPaint(5);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(255);
        try {
            keyedObjects0.removeValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedDomainAxisSpace(axisSpace11);
        double double13 = axisSpace11.getRight();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 12, (java.lang.Comparable) "poly", 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        ringPlot0.setOuterSeparatorExtension((double) 3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        categoryAxis5.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis5.getTickLabelInsets();
        java.awt.Paint paint11 = categoryAxis5.getTickMarkPaint();
        ringPlot0.setLabelShadowPaint(paint11);
        java.awt.Paint paint13 = ringPlot0.getLabelOutlinePaint();
        org.jfree.chart.util.Rotation rotation14 = null;
        try {
            ringPlot0.setDirection(rotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        categoryAxis5.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis5.getTickLabelInsets();
        java.awt.Paint paint11 = categoryAxis5.getTickMarkPaint();
        ringPlot0.setLabelShadowPaint(paint11);
        java.awt.Paint paint13 = ringPlot0.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        xYPlot22.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo26, point2D27);
        java.awt.geom.Point2D point2D29 = xYPlot22.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState30 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        try {
            ringPlot0.draw(graphics2D14, rectangle2D16, point2D29, plotState30, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) year1);
        java.lang.Double double4 = task3.getPercentComplete();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNull(double4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("UnitType.RELATIVE");
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        stackedBarRenderer3D3.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D13.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = stackedBarRenderer3D13.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        int int19 = polarPlot18.getBackgroundImageAlignment();
        boolean boolean20 = stackedBarRenderer3D13.hasListener((java.util.EventListener) polarPlot18);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        stackedBarRenderer3D13.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator23, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = stackedBarRenderer3D13.getBaseItemLabelGenerator();
        java.awt.Color color27 = java.awt.Color.cyan;
        stackedBarRenderer3D13.setBaseOutlinePaint((java.awt.Paint) color27, false);
        stackedBarRenderer3D3.setWallPaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoTickUnitSelection(false);
        double double5 = numberAxis1.getAutoRangeMinimumSize();
        double double6 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelURL("");
        double double6 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Paint paint5 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot4.getRangeAxisLocation(13);
        xYPlot4.setForegroundAlpha(0.0f);
        boolean boolean10 = xYPlot4.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset(xYDataset11);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        java.awt.RenderingHints renderingHints16 = null;
        try {
            jFreeChart14.setRenderingHints(renderingHints16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        xYPlot17.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo21, point2D22);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        xYPlot4.setQuadrantOrigin(point2D24);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLabelGenerator();
        double double2 = ringPlot0.getSectionDepth();
        boolean boolean3 = ringPlot0.getIgnoreNullValues();
        double double4 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) 1);
        try {
            defaultCategoryDataset0.removeColumn(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.lang.String str2 = dateTickUnit0.dateToString(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        stackedBarRenderer3D3.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = stackedBarRenderer3D3.getBaseItemLabelGenerator();
        java.awt.Color color17 = java.awt.Color.cyan;
        stackedBarRenderer3D3.setBaseOutlinePaint((java.awt.Paint) color17, false);
        java.io.ObjectOutputStream objectOutputStream20 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color17, objectOutputStream20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        float float3 = categoryLabelPosition2.getWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPosition2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.3f + "'", float3 == 0.3f);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot4.getRangeMarkers(layer13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = null;
        try {
            xYPlot4.setDatasetRenderingOrder(datasetRenderingOrder15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot62.setFixedDomainAxisSpace(axisSpace65);
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape70 = numberAxis69.getLeftArrow();
        numberAxis69.setAutoTickUnitSelection(false);
        categoryPlot62.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis69, false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(shape70);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        try {
            java.lang.Number number5 = taskSeriesCollection0.getValue((java.lang.Comparable) 900000L, (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint1, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D12.setSeriesItemLabelPaint(100, paint14, false);
        categoryMarker7.setOutlinePaint(paint14);
        java.lang.String str18 = categoryMarker7.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        float float12 = textFragment11.getBaselineOffset();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            float float15 = textFragment11.calculateBaselineOffset(graphics2D13, textAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        xYPlot4.setDomainCrosshairValue((double) (byte) 100, false);
        xYPlot4.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot4.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = null;
        try {
            jFreeChart50.plotChanged(plotChangeEvent51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        boolean boolean3 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.centerRange((double) 12);
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setInverted(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14, (double) 900000L);
        try {
            java.lang.Number number21 = taskSeriesCollection14.getPercentComplete((java.lang.Comparable) 900000L, (java.lang.Comparable) 86400000L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(255, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D11.setSeriesItemLabelPaint(100, paint13, false);
        stackedBarRenderer3D3.setBaseItemLabelPaint(paint13);
        org.jfree.chart.LegendItem legendItem19 = stackedBarRenderer3D3.getLegendItem((int) (short) -1, 0);
        stackedBarRenderer3D3.setMaximumBarWidth((double) '4');
        stackedBarRenderer3D3.setSeriesCreateEntities(5, (java.lang.Boolean) false);
        stackedBarRenderer3D3.setMaximumBarWidth((double) 86400000L);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem19);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot13.setRangeAxisLocation((int) ' ', axisLocation15);
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation15, true);
        xYPlot4.setDomainCrosshairValue(100.0d);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        textTitle53.setFont(font55);
        java.awt.Paint paint58 = textTitle53.getBackgroundPaint();
        jFreeChart50.setTitle(textTitle53);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer61 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean62 = stackedBarRenderer61.getRenderAsPercentages();
        java.awt.Paint paint63 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer61.setBaseItemLabelPaint(paint63, false);
        org.jfree.chart.block.BlockBorder blockBorder66 = new org.jfree.chart.block.BlockBorder(paint63);
        textTitle53.setPaint(paint63);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(paint3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 8, (double) (-8388480));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.0) <= upper (-8388480.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray90 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray91 = new java.lang.Number[][] { numberArray55, numberArray62, numberArray69, numberArray76, numberArray83, numberArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset93 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray45, numberArray91);
        java.lang.Number number94 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset93);
        java.lang.Comparable comparable96 = defaultIntervalCategoryDataset93.getColumnKey(2);
        java.lang.Comparable comparable97 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer98 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset93, comparable97);
        java.util.List list99 = legendItemBlockContainer98.getBlocks();
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 1.0d + "'", number94.equals(1.0d));
        org.junit.Assert.assertTrue("'" + comparable96 + "' != '" + "Category 3" + "'", comparable96.equals("Category 3"));
        org.junit.Assert.assertNotNull(list99);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double[] doubleArray9 = new double[] { 1, 86400000L, 3, 900000L, 12.0d };
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ChartChangeEventType.DATASET_UPDATED", doubleArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ItemLabelAnchor.OUTSIDE1", "Category 3", doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot62.setOutlineStroke(stroke71);
        boolean boolean73 = categoryPlot62.isSubplot();
        boolean boolean74 = categoryPlot62.isRangeGridlinesVisible();
        categoryPlot62.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Number[][] numberArray2 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray11, numberArray18, numberArray25, numberArray32, numberArray39, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray47);
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray78 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray85 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray92 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray93 = new java.lang.Number[][] { numberArray57, numberArray64, numberArray71, numberArray78, numberArray85, numberArray92 };
        org.jfree.data.category.CategoryDataset categoryDataset94 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray93);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset95 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray47, numberArray93);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset96 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray2, numberArray47);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset97 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ItemLabelAnchor.INSIDE12", "Category 3", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(numberArray85);
        org.junit.Assert.assertNotNull(numberArray92);
        org.junit.Assert.assertNotNull(numberArray93);
        org.junit.Assert.assertNotNull(categoryDataset94);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        legendTitle13.setWidth((double) (-1.0f));
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis16.setCategoryLabelPositions(categoryLabelPositions17);
        categoryAxis16.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis16.getTickLabelInsets();
        legendTitle13.setLegendItemGraphicPadding(rectangleInsets21);
        double double24 = rectangleInsets21.trimHeight((double) 10);
        double double26 = rectangleInsets21.calculateTopOutset((double) 15);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.0d + "'", double24 == 6.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot62.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot62.getDomainAxisLocation();
        java.awt.Stroke stroke70 = null;
        try {
            categoryPlot62.setDomainGridlineStroke(stroke70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(axisLocation69);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot4.setRenderer(xYItemRenderer5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot4.getAxisOffset();
        boolean boolean8 = xYPlot4.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis4.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis4.setAxisLineStroke(stroke7);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint3, stroke7);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font1, paint3, (float) 0L);
        float float12 = textFragment11.getBaselineOffset();
        java.lang.String str13 = textFragment11.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle18 = null;
        jFreeChart14.setTitle(textTitle18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        try {
            jFreeChart14.plotChanged(plotChangeEvent20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        boolean boolean70 = categoryPlot62.getDrawSharedDomainAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = categoryPlot62.getRenderer((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset73, valueAxis74, valueAxis75, xYItemRenderer76);
        java.awt.Paint paint78 = xYPlot77.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation80 = xYPlot77.getRangeAxisLocation(13);
        categoryPlot62.setRangeAxisLocation(axisLocation80, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation80, plotOrientation83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(categoryItemRenderer72);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(axisLocation80);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "Oct", "hi!");
        java.lang.String str4 = chartEntity3.getShapeCoords();
        java.awt.Shape shape5 = chartEntity3.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        jFreeChart14.setBorderPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean12 = taskSeriesCollection10.equals((java.lang.Object) (-33));
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection10, 10);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = stackedBarRenderer3D3.hasListener((java.util.EventListener) piePlot15);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        textTitle2.setFont(font4);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle2.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) 15, (double) 5);
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, (double) 255, (double) 100L);
        java.lang.Object obj18 = null;
        boolean boolean19 = flowArrangement17.equals(obj18);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.OUTSIDE1");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D5.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D5.getLegendItems();
        boolean boolean11 = stackedBarRenderer3D5.isSeriesVisible(1);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray56);
        org.jfree.data.Range range58 = stackedBarRenderer3D5.findRangeBounds(categoryDataset57);
        java.awt.Font font60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        stackedBarRenderer3D5.setSeriesItemLabelFont((int) (short) 100, font60, true);
        labelBlock1.setFont(font60);
        java.lang.Object obj64 = labelBlock1.clone();
        java.awt.Graphics2D graphics2D65 = null;
        try {
            org.jfree.chart.util.Size2D size2D66 = labelBlock1.arrange(graphics2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(obj64);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        textTitle2.setFont(font4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot12.setRenderer(xYItemRenderer13);
        categoryAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot12);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape18 = numberAxis17.getLeftArrow();
        numberAxis17.setAutoTickUnitSelection(false);
        boolean boolean21 = numberAxis17.getAutoRangeIncludesZero();
        xYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis17);
        double double23 = numberAxis17.getFixedAutoRange();
        boolean boolean24 = textTitle2.equals((java.lang.Object) numberAxis17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        int int9 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean10 = stackedBarRenderer3D3.hasListener((java.util.EventListener) polarPlot8);
        boolean boolean11 = polarPlot8.isAngleLabelsVisible();
        polarPlot8.removeCornerTextItem("{0}");
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer3D3.setSeriesItemLabelPaint(100, paint5, false);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible(2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D3.getLegendItems();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        boolean boolean20 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) 15);
        int int22 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) "GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        numberAxis59.configure();
        double double64 = numberAxis59.getFixedDimension();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-1L));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (-1L));
        org.jfree.data.Range range11 = org.jfree.data.Range.expand(range8, 0.0d, (double) 0);
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range8, (double) 2.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1, lengthConstraintType4, 4.0d, range8, lengthConstraintType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        java.awt.Paint paint14 = legendTitle13.getBackgroundPaint();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ItemLabelAnchor.INSIDE12");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ItemLabelAnchor.INSIDE12" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ItemLabelAnchor.INSIDE12"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1L, (double) 1546329600000L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLabelGenerator();
        double double2 = ringPlot0.getSectionDepth();
        boolean boolean3 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = barRenderer3D0.getLegendItem(4, 7);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        stackedBarRenderer1.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        stackedBarRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D12.setBaseSeriesVisible(true, false);
        java.awt.Shape shape18 = stackedBarRenderer3D12.getItemShape((int) (short) -1, 0);
        boolean boolean19 = stackedBarRenderer1.equals((java.lang.Object) shape18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D7.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = stackedBarRenderer3D7.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        int int13 = polarPlot12.getBackgroundImageAlignment();
        stackedBarRenderer3D7.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot12);
        java.awt.Stroke stroke15 = polarPlot12.getOutlineStroke();
        boolean boolean16 = defaultStatisticalCategoryDataset3.equals((java.lang.Object) stroke15);
        java.lang.Comparable comparable20 = null;
        defaultStatisticalCategoryDataset3.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (double) 10.0f);
        boolean boolean25 = range23.contains((double) 60000L);
        dateAxis2.setRange(range23, false, false);
        java.util.Date date29 = dateAxis2.getMaximumDate();
        java.util.Date date30 = dateTickUnit0.addToDate(date29);
        int int31 = dateTickUnit0.getUnit();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        taskSeriesCollection14.removeAll();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.lang.Comparable comparable17 = null;
        defaultStatisticalCategoryDataset0.add((double) 100L, (double) 10.0f, (java.lang.Comparable) (short) 100, comparable17);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) 10.0f);
        double double21 = range20.getLength();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot62.getRowRenderingOrder();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        int int68 = plotRenderingInfo67.getSubplotCount();
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot62.zoomDomainAxes((double) (byte) 10, (double) '#', plotRenderingInfo67, point2D69);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent71 = null;
        categoryPlot62.notifyListeners(plotChangeEvent71);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedDomainAxisSpace(axisSpace11);
        axisSpace11.setTop((double) 86400000L);
        double double15 = axisSpace11.getTop();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.64E7d + "'", double15 == 8.64E7d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("{0}");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.gantt.Task task5 = taskSeries1.get("{0}");
        org.junit.Assert.assertNull(task5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        java.awt.Stroke stroke13 = xYPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
        categoryAxis0.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis0.getTickLabelInsets();
        java.awt.Paint paint6 = categoryAxis0.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape12 = numberAxis11.getLeftArrow();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D19.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedBarRenderer3D19.getLegendItems();
        boolean boolean25 = stackedBarRenderer3D19.isSeriesVisible(1);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray34, numberArray41, numberArray48, numberArray55, numberArray62, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray70);
        org.jfree.data.Range range72 = stackedBarRenderer3D19.findRangeBounds(categoryDataset71);
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape76 = numberAxis75.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer77 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis73, (org.jfree.chart.axis.ValueAxis) numberAxis75, categoryItemRenderer77);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        java.awt.geom.Point2D point2D82 = null;
        categoryPlot78.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo81, point2D82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = categoryPlot78.getDomainAxisEdge();
        double double85 = numberAxis11.valueToJava2D((double) (short) 10, rectangle2D15, rectangleEdge84);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor7, (-1), (int) (short) 10, rectangle2D15, rectangleEdge86);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions88 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions90 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis89.setCategoryLabelPositions(categoryLabelPositions90);
        java.awt.Stroke stroke92 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis89.setAxisLineStroke(stroke92);
        boolean boolean94 = categoryLabelPositions88.equals((java.lang.Object) stroke92);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions88);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions88);
        org.junit.Assert.assertNotNull(categoryLabelPositions90);
        org.junit.Assert.assertNotNull(stroke92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Point2D point2D9 = null;
        xYPlot4.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo8, point2D9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo8.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo8.getPlotArea();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo8);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertNull(rectangle2D12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setWeight((int) (short) -1);
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot62.setDomainAxisLocation(axisLocation70);
        java.awt.Paint paint72 = categoryPlot62.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getDomainAxisEdge(7);
        java.awt.Stroke stroke65 = categoryPlot62.getDomainGridlineStroke();
        categoryPlot62.clearRangeMarkers();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) (-8388480), 0.0d, (double) (-1L));
        double double5 = rectangleInsets4.getRight();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Oct");
        double double2 = numberAxis1.getLowerMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D6.setBaseSeriesVisible(true, false);
        java.awt.Shape shape12 = stackedBarRenderer3D6.getItemShape((int) (short) -1, 0);
        numberAxis1.setDownArrow(shape12);
        boolean boolean14 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray83 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray90 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray91 = new java.lang.Number[][] { numberArray55, numberArray62, numberArray69, numberArray76, numberArray83, numberArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray91);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset93 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray45, numberArray91);
        boolean boolean94 = unitType0.equals((java.lang.Object) numberArray45);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray83);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset3 = polarPlot0.getDataset();
        org.junit.Assert.assertNull(xYDataset3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setLabelLinksVisible(false);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        categoryAxis5.setLabel("Oct");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis5.getTickLabelInsets();
        java.awt.Paint paint11 = categoryAxis5.getTickMarkPaint();
        ringPlot0.setLabelShadowPaint(paint11);
        ringPlot0.setShadowYOffset((double) 'a');
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        java.awt.Paint paint4 = stackedBarRenderer1.getSeriesOutlinePaint(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis73.setCategoryLabelPositions(categoryLabelPositions74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis73.setAxisLineStroke(stroke76);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint72, stroke76);
        categoryPlot62.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78);
        categoryMarker78.setDrawAsLine(false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot62.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo65, point2D66);
        categoryPlot62.setAnchorValue((double) 10, false);
        java.awt.Paint paint72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis73.setCategoryLabelPositions(categoryLabelPositions74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis73.setAxisLineStroke(stroke76);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0f, paint72, stroke76);
        categoryPlot62.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent80 = null;
        categoryPlot62.datasetChanged(datasetChangeEvent80);
        org.jfree.data.xy.XYDataset xYDataset83 = null;
        org.jfree.chart.axis.ValueAxis valueAxis84 = null;
        org.jfree.chart.axis.ValueAxis valueAxis85 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer86 = null;
        org.jfree.chart.plot.XYPlot xYPlot87 = new org.jfree.chart.plot.XYPlot(xYDataset83, valueAxis84, valueAxis85, xYItemRenderer86);
        org.jfree.chart.axis.AxisLocation axisLocation89 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot87.setRangeAxisLocation((int) ' ', axisLocation89);
        categoryPlot62.setRangeAxisLocation((int) (byte) 1, axisLocation89);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(axisLocation89);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        double double2 = ringPlot0.getInteriorGap();
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke4 = ringPlot0.getBaseSectionOutlineStroke();
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Paint paint6 = ringPlot0.getSectionPaint(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape60 = numberAxis59.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis59, categoryItemRenderer61);
        java.awt.Stroke stroke63 = categoryPlot62.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation65 = categoryPlot62.getRangeAxisLocation(1);
        boolean boolean66 = categoryPlot62.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        java.awt.Stroke stroke15 = stackedBarRenderer3D3.getItemOutlineStroke(5, (int) (byte) 100);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        boolean boolean2 = polarPlot0.isAngleLabelsVisible();
        polarPlot0.setNoDataMessage("{0}");
        polarPlot0.clearCornerTextItems();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean2 = taskSeriesCollection0.equals((java.lang.Object) (-33));
        try {
            int int5 = taskSeriesCollection0.getSubIntervalCount((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setHeight(6.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean3 = jFreeChartResources1.containsKey("Oct");
        boolean boolean5 = jFreeChartResources1.containsKey("ItemLabelAnchor.OUTSIDE1");
        java.lang.Object obj7 = jFreeChartResources1.handleGetObject("TextAnchor.HALF_ASCENT_RIGHT");
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) "TextAnchor.HALF_ASCENT_RIGHT");
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        boolean boolean59 = range56.intersects(0.0d, (double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset60, valueAxis61, valueAxis62, xYItemRenderer63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot64.setRangeAxisLocation((int) ' ', axisLocation66);
        org.jfree.chart.plot.IntervalMarker intervalMarker70 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer71 = null;
        xYPlot64.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker70, layer71);
        org.jfree.chart.util.Layer layer73 = null;
        java.util.Collection collection74 = xYPlot64.getRangeMarkers(layer73);
        boolean boolean75 = range56.equals((java.lang.Object) layer73);
        org.jfree.data.time.DateRange dateRange76 = new org.jfree.data.time.DateRange(range56);
        org.jfree.data.Range range78 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange76, 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNull(collection74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(range78);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        defaultStatisticalCategoryDataset0.validateObject();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer11);
        xYPlot4.setDomainCrosshairValue((double) (byte) 100, false);
        xYPlot4.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Point2D point2D31 = null;
        xYPlot26.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo30, point2D31);
        java.awt.geom.Point2D point2D33 = xYPlot26.getQuadrantOrigin();
        xYPlot4.zoomRangeAxes((double) 10L, plotRenderingInfo21, point2D33);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(point2D33);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke6 = intervalMarker2.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("WMAP_Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        textTitle53.setFont(font55);
        java.awt.Paint paint58 = textTitle53.getBackgroundPaint();
        jFreeChart50.setTitle(textTitle53);
        int int60 = jFreeChart50.getSubtitleCount();
        java.awt.Image image61 = jFreeChart50.getBackgroundImage();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot62 = jFreeChart50.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(image61);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        stackedBarRenderer3D3.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D4.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D4.getLegendItems();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        int int10 = polarPlot9.getBackgroundImageAlignment();
        stackedBarRenderer3D4.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Stroke stroke12 = polarPlot9.getOutlineStroke();
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) stroke12);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot20.getDomainMarkers((int) (short) 0, layer25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) xYPlot20, true);
        boolean boolean29 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) xYPlot20);
        java.awt.Font font31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot36.setRangeAxisLocation((int) ' ', axisLocation38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot36.getDomainMarkers((int) (short) 0, layer41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font31, (org.jfree.chart.plot.Plot) xYPlot36, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener45 = null;
        jFreeChart44.removeProgressListener(chartProgressListener45);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        xYPlot20.setRangeCrosshairValue((double) 2.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot20);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("", font55);
        textTitle53.setFont(font55);
        java.awt.Paint paint58 = textTitle53.getBackgroundPaint();
        jFreeChart50.setTitle(textTitle53);
        int int60 = jFreeChart50.getSubtitleCount();
        java.awt.Image image61 = jFreeChart50.getBackgroundImage();
        int int62 = jFreeChart50.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(image61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 15 + "'", int62 == 15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Point2D point2D9 = null;
        xYPlot4.zoomDomainAxes(0.0d, (double) (byte) 100, plotRenderingInfo8, point2D9);
        java.awt.geom.Point2D point2D11 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D16.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = stackedBarRenderer3D16.getLegendItems();
        boolean boolean22 = stackedBarRenderer3D16.isSeriesVisible(1);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray31, numberArray38, numberArray45, numberArray52, numberArray59, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray67);
        org.jfree.data.Range range69 = stackedBarRenderer3D16.findRangeBounds(categoryDataset68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("Oct");
        java.awt.Shape shape73 = numberAxis72.getLeftArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, categoryAxis70, (org.jfree.chart.axis.ValueAxis) numberAxis72, categoryItemRenderer74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot75.zoomDomainAxes((double) (-1L), (double) (byte) 10, plotRenderingInfo78, point2D79);
        categoryPlot75.setWeight((int) (short) -1);
        boolean boolean83 = categoryPlot75.getDrawSharedDomainAxis();
        java.awt.Stroke stroke84 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot75.setOutlineStroke(stroke84);
        boolean boolean86 = categoryPlot75.isSubplot();
        boolean boolean87 = categoryPlot75.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer88 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection89 = categoryPlot75.getDomainMarkers(layer88);
        java.util.Collection collection90 = xYPlot4.getDomainMarkers(255, layer88);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(layer88);
        org.junit.Assert.assertNull(collection89);
        org.junit.Assert.assertNull(collection90);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation((int) ' ', axisLocation6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setDomainAxisLocation(0, axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        xYPlot4.setFixedDomainAxisSpace(axisSpace11);
        axisSpace11.setTop((double) 86400000L);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = axisSpace11.reserved(rectangle2D15, rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(rectangle2D17);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot7.setRangeAxisLocation((int) ' ', axisLocation9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot7.getDomainMarkers((int) (short) 0, layer12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) xYPlot7, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = jFreeChart15.getPadding();
        categoryAxis0.setTickLabelInsets(rectangleInsets16);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = null;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint1);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        statisticalBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator3, true);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer0.setSeriesOutlineStroke(1, stroke8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = statisticalBarRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        java.lang.Boolean boolean9 = stackedBarRenderer3D3.getSeriesCreateEntities((int) (byte) 100);
        java.awt.Font font11 = null;
        stackedBarRenderer3D3.setSeriesItemLabelFont(255, font11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        legendTitle13.setWidth((double) (-1.0f));
        double double16 = legendTitle13.getContentXOffset();
        boolean boolean17 = legendTitle13.getNotify();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 1, (double) (short) -1, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedBarRenderer3D3.getLegendItems();
        boolean boolean9 = stackedBarRenderer3D3.isSeriesVisible(1);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0f, 10L, 100.0d, 100.0f, (short) 1, 1.0f };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray18, numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = stackedBarRenderer3D3.findRangeBounds(categoryDataset55);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator61 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Oct", "", "hi!");
        stackedBarRenderer3D3.setSeriesURLGenerator(0, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator61);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection63 = new org.jfree.data.gantt.TaskSeriesCollection();
        boolean boolean64 = standardCategoryURLGenerator61.equals((java.lang.Object) taskSeriesCollection63);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset65, valueAxis66, valueAxis67, xYItemRenderer68);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot69.setRenderer(xYItemRenderer70);
        boolean boolean72 = xYPlot69.isRangeZeroBaselineVisible();
        boolean boolean73 = taskSeriesCollection63.hasListener((java.util.EventListener) xYPlot69);
        int int74 = taskSeriesCollection63.getRowCount();
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Category 3");
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot6.setRangeAxisLocation((int) ' ', axisLocation8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot6.getDomainMarkers((int) (short) 0, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) xYPlot6, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart14.getPadding();
        boolean boolean16 = jFreeChart14.isNotify();
        jFreeChart14.setTitle("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }
}

