import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        boolean boolean5 = week0.equals((java.lang.Object) '#');
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Year year5 = week3.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
//        int int11 = week0.compareTo((java.lang.Object) timeZone9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year19 = week18.getYear();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 10, year19);
        java.util.Date date21 = week20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date9, timeZone22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone25);
        try {
            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date0, timeZone25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable5 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        java.util.Date date43 = week42.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date43);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
//        int int11 = week0.compareTo((java.lang.Object) timeZone9);
//        java.lang.String str12 = week0.toString();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.lang.String str4 = week3.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        java.util.Calendar calendar12 = null;
//        try {
//            week6.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        java.util.Date date18 = week17.getStart();
        long long19 = week17.getSerialIndex();
        long long20 = week17.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107061L + "'", long19 == 107061L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1578211199999L + "'", long20 == 1578211199999L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getFirstMillisecond();
//        java.util.Date date5 = week1.getStart();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.lang.String str4 = week3.toString();
        java.util.Date date5 = week3.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year11 = week10.getYear();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year22 = week21.getYear();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 10, year22);
        java.util.Date date24 = week23.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date12, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone25);
        java.util.Locale locale29 = null;
        try {
            org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone25, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        java.lang.String str24 = timePeriodFormatException15.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        long long4 = week3.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            week3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577908799999L + "'", long4 == 1577908799999L);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        int int3 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week19.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1551600000000L + "'", long6 == 1551600000000L);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        long long4 = week3.getMiddleMillisecond();
        long long5 = week3.getSerialIndex();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577908799999L + "'", long4 == 1577908799999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107061L + "'", long5 == 107061L);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        java.lang.String str20 = week19.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        int int4 = week2.getWeek();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-13) + "'", int4 == (-13));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1259L + "'", long5 == 1259L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        long long27 = week26.getLastMillisecond();
//        long long28 = week26.getFirstMillisecond();
//        long long29 = week26.getFirstMillisecond();
//        java.util.Date date30 = week26.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        long long32 = week31.getLastMillisecond();
//        long long33 = week31.getFirstMillisecond();
//        long long34 = week31.getLastMillisecond();
//        java.util.Date date35 = week31.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        java.util.Date date38 = year37.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
//        java.util.Date date43 = null;
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year48 = week47.getYear();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) (short) 10, year48);
//        java.util.Date date50 = week49.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date50, timeZone51);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date38, timeZone51);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date35, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date30, timeZone51);
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560668399999L + "'", long32 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560063600000L + "'", long33 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560668399999L + "'", long34 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(class56);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.lang.String str4 = week3.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        int int6 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Date date5 = regularTimePeriod4.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = week6.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass14 = timePeriodFormatException13.getClass();
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 10, year20);
//        java.util.Date date22 = week21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date11, timeZone23);
//        java.util.Locale locale26 = null;
//        try {
//            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date5, timeZone23, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        java.util.Date date10 = week9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 10, year22);
//        java.util.Date date24 = week23.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date24, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        long long30 = week28.getFirstMillisecond();
//        long long31 = week28.getFirstMillisecond();
//        java.util.Date date32 = week28.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        long long34 = week33.getLastMillisecond();
//        long long35 = week33.getFirstMillisecond();
//        long long36 = week33.getLastMillisecond();
//        java.util.Date date37 = week33.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year39 = week38.getYear();
//        java.util.Date date40 = year39.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass44 = timePeriodFormatException43.getClass();
//        java.util.Date date45 = null;
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year50 = week49.getYear();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) (short) 10, year50);
//        java.util.Date date52 = week51.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date52, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date40, timeZone53);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date37, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date32, timeZone53);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass61 = timePeriodFormatException60.getClass();
//        java.util.Date date62 = null;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year64 = week63.getYear();
//        java.util.Date date65 = year64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException68 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass69 = timePeriodFormatException68.getClass();
//        java.util.Date date70 = null;
//        java.util.TimeZone timeZone71 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date70, timeZone71);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year75 = week74.getYear();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week((int) (short) 10, year75);
//        java.util.Date date77 = week76.getEnd();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date77, timeZone78);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date65, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date32, timeZone78);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week();
//        long long84 = week83.getLastMillisecond();
//        long long85 = week83.getFirstMillisecond();
//        long long86 = week83.getSerialIndex();
//        long long87 = week83.getFirstMillisecond();
//        java.util.Date date88 = week83.getEnd();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date88, timeZone89);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date88);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560063600000L + "'", long31 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560668399999L + "'", long34 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year75);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560668399999L + "'", long84 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560063600000L + "'", long85 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 107031L + "'", long86 == 107031L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1560063600000L + "'", long87 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Year year5 = week3.getYear();
        java.util.Date date6 = year5.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61418966400000L) + "'", long4 == (-61418966400000L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year9 = week8.getYear();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException13.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year20 = week19.getYear();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 10, year20);
        java.util.Date date22 = week21.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date10, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone23);
        java.util.Locale locale27 = null;
        try {
            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date2, timeZone23, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        long long4 = regularTimePeriod2.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559761199999L + "'", long4 == 1559761199999L);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', (-13));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.lang.String str2 = week0.toString();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Year year6 = week4.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 1, year6);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) (byte) 1);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
//        java.util.Date date14 = week13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        int int19 = week17.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getLastMillisecond();
//        long long24 = week22.getFirstMillisecond();
//        long long25 = week22.getSerialIndex();
//        org.jfree.data.time.Year year26 = week22.getYear();
//        java.lang.Class<?> wildcardClass27 = year26.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (byte) 10, year26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (byte) 1, year26);
//        boolean boolean30 = week17.equals((java.lang.Object) year26);
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = week17.getFirstMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560668399999L + "'", long23 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61418361600001L) + "'", long5 == (-61418361600001L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        long long12 = week3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1552204799999L + "'", long12 == 1552204799999L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        long long12 = week6.getFirstMillisecond();
//        long long13 = week6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        long long23 = week22.getFirstMillisecond();
//        int int24 = week0.compareTo((java.lang.Object) week22);
//        long long25 = week22.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577606400000L + "'", long23 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107061L + "'", long25 == 107061L);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        long long4 = week2.getFirstMillisecond();
//        long long5 = week2.getSerialIndex();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.lang.Class<?> wildcardClass7 = year6.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 10, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        java.util.Calendar calendar11 = null;
//        try {
//            week9.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
//        java.util.Date date11 = null;
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year16 = week15.getYear();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) 10, year16);
//        java.util.Date date18 = week17.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone19);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException22.getClass();
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year28 = week27.getYear();
//        java.util.Date date29 = year28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException32.getClass();
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year39 = week38.getYear();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 10, year39);
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date41, timeZone42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date29, timeZone42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date18, timeZone45);
//        java.util.Locale locale48 = null;
//        try {
//            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date6, timeZone45, locale48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week19.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week17.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        long long44 = week43.getLastMillisecond();
//        long long45 = week43.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week43.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week43.previous();
//        long long48 = week43.getLastMillisecond();
//        java.lang.Class<?> wildcardClass49 = week43.getClass();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        long long51 = week50.getLastMillisecond();
//        long long52 = week50.getFirstMillisecond();
//        long long53 = week50.getLastMillisecond();
//        java.util.Date date54 = week50.getStart();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        long long56 = week55.getLastMillisecond();
//        long long57 = week55.getFirstMillisecond();
//        long long58 = week55.getLastMillisecond();
//        java.util.Date date59 = week55.getStart();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year61 = week60.getYear();
//        java.util.Date date62 = year61.getEnd();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date62);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException65 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass66 = timePeriodFormatException65.getClass();
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year72 = week71.getYear();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week((int) (short) 10, year72);
//        java.util.Date date74 = week73.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date74, timeZone75);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date62, timeZone75);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date59, timeZone75);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year80 = week79.getYear();
//        java.util.Date date81 = year80.getEnd();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date81);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException84 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass85 = timePeriodFormatException84.getClass();
//        java.util.Date date86 = null;
//        java.util.TimeZone timeZone87 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date86, timeZone87);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year91 = week90.getYear();
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week((int) (short) 10, year91);
//        java.util.Date date93 = week92.getEnd();
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date93, timeZone94);
//        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date81, timeZone94);
//        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date59, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date54, timeZone94);
//        org.jfree.data.time.Week week99 = new org.jfree.data.time.Week(date4, timeZone94);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560668399999L + "'", long44 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560063600000L + "'", long45 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560668399999L + "'", long48 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560668399999L + "'", long51 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560063600000L + "'", long52 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560668399999L + "'", long53 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560668399999L + "'", long56 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560063600000L + "'", long57 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560668399999L + "'", long58 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(year91);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod98);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.lang.String str6 = week2.toString();
//        int int7 = week0.compareTo((java.lang.Object) str6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 10, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        java.lang.String str31 = week0.toString();
//        org.jfree.data.time.Year year32 = week0.getYear();
//        java.util.Calendar calendar33 = null;
//        try {
//            long long34 = week0.getMiddleMillisecond(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year32);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62164987200001L) + "'", long4 == (-62164987200001L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, year3);
        long long6 = week5.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1553410799999L + "'", long6 == 1553410799999L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = week0.equals(obj3);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        java.util.Date date13 = year12.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 10, year23);
//        java.util.Date date25 = week24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date13, timeZone26);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        long long32 = week31.getLastMillisecond();
//        long long33 = week31.getFirstMillisecond();
//        long long34 = week31.getFirstMillisecond();
//        java.util.Date date35 = week31.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getLastMillisecond();
//        long long38 = week36.getFirstMillisecond();
//        long long39 = week36.getLastMillisecond();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        java.util.Date date43 = year42.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass47 = timePeriodFormatException46.getClass();
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year53 = week52.getYear();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 10, year53);
//        java.util.Date date55 = week54.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date55, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date43, timeZone56);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date40, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date35, timeZone56);
//        boolean boolean61 = week0.equals((java.lang.Object) date35);
//        java.util.TimeZone timeZone62 = null;
//        try {
//            org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date35, timeZone62);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560668399999L + "'", long32 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560063600000L + "'", long33 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560668399999L + "'", long37 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560063600000L + "'", long38 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.lang.String str4 = week3.toString();
        long long5 = week3.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str11 = timePeriodFormatException8.toString();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException8.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
//        java.util.Date date14 = week13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
//        java.util.Date date18 = week17.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass21 = timePeriodFormatException20.getClass();
//        java.util.Date date22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        java.util.Date date25 = year24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) 10, year35);
//        java.util.Date date37 = week36.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date37, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date25, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date18, timeZone38);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass45 = timePeriodFormatException44.getClass();
//        java.util.Date date46 = null;
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone47);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year51 = week50.getYear();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 10, year51);
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date53, timeZone54);
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        long long58 = week57.getLastMillisecond();
//        long long59 = week57.getFirstMillisecond();
//        long long60 = week57.getFirstMillisecond();
//        java.util.Date date61 = week57.getStart();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        long long63 = week62.getLastMillisecond();
//        long long64 = week62.getFirstMillisecond();
//        long long65 = week62.getLastMillisecond();
//        java.util.Date date66 = week62.getStart();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year68 = week67.getYear();
//        java.util.Date date69 = year68.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException72 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass73 = timePeriodFormatException72.getClass();
//        java.util.Date date74 = null;
//        java.util.TimeZone timeZone75 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date74, timeZone75);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year79 = week78.getYear();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week((int) (short) 10, year79);
//        java.util.Date date81 = week80.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date81, timeZone82);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date69, timeZone82);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date66, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date61, timeZone82);
//        java.util.Locale locale87 = null;
//        try {
//            org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date18, timeZone82, locale87);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560668399999L + "'", long58 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560063600000L + "'", long59 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560063600000L + "'", long60 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560668399999L + "'", long63 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560063600000L + "'", long64 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560668399999L + "'", long65 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(year79);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        int int6 = week0.compareTo((java.lang.Object) (byte) 1);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(10, year5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        java.util.Date date10 = week9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getLastMillisecond();
//        long long16 = week14.getFirstMillisecond();
//        long long17 = week14.getFirstMillisecond();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getLastMillisecond();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getLastMillisecond();
//        java.util.Date date23 = week19.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date23, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone39);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        java.util.Date date18 = week17.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass21 = timePeriodFormatException20.getClass();
        java.util.Date date22 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year24 = week23.getYear();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year35 = week34.getYear();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) 10, year35);
        java.util.Date date37 = week36.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date25, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date18, timeZone38);
        long long43 = week42.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1578211199999L + "'", long43 == 1578211199999L);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        long long23 = week22.getFirstMillisecond();
//        int int24 = week0.compareTo((java.lang.Object) week22);
//        java.util.Calendar calendar25 = null;
//        try {
//            long long26 = week0.getLastMillisecond(calendar25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577606400000L + "'", long23 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        int int18 = week17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week17.next();
        java.lang.String str20 = week17.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2020 + "'", int18 == 2020);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 1, 2020" + "'", str20.equals("Week 1, 2020"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 2, 35" + "'", str3.equals("Week 2, 35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61062134400001L) + "'", long5 == (-61062134400001L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str15 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getLastMillisecond();
//        java.util.Date date5 = week1.getStart();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(10, year6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        long long44 = week43.getLastMillisecond();
//        int int45 = week43.getYearValue();
//        long long46 = week43.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week43.previous();
//        boolean boolean48 = week42.equals((java.lang.Object) week43);
//        int int49 = week42.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560668399999L + "'", long44 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560668399999L + "'", long46 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getWeek();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2020");
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        long long12 = week6.getFirstMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        java.util.Date date15 = year14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 10, year25);
//        java.util.Date date27 = week26.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date27, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date15, timeZone28);
//        int int31 = week6.compareTo((java.lang.Object) week30);
//        java.lang.String str32 = week6.toString();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 24, 2019" + "'", str32.equals("Week 24, 2019"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year18 = week17.getYear();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
        java.util.Date date20 = week19.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year27 = week26.getYear();
        java.util.Date date28 = year27.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass32 = timePeriodFormatException31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year38 = week37.getYear();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 10, year38);
        java.util.Date date40 = week39.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date28, timeZone41);
        java.util.Date date44 = week43.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass47 = timePeriodFormatException46.getClass();
        java.util.Date date48 = null;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year50 = week49.getYear();
        java.util.Date date51 = year50.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass55 = timePeriodFormatException54.getClass();
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year61 = week60.getYear();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 10, year61);
        java.util.Date date63 = week62.getEnd();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date51, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date44, timeZone64);
        java.util.Locale locale69 = null;
        try {
            org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date8, timeZone64, locale69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        long long9 = week7.getFirstMillisecond();
//        long long10 = week7.getFirstMillisecond();
//        java.util.Date date11 = week7.getStart();
//        java.util.Date date12 = week7.getEnd();
//        org.jfree.data.time.Year year13 = week7.getYear();
//        boolean boolean14 = week0.equals((java.lang.Object) week7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.lang.String str6 = week2.toString();
//        int int7 = week0.compareTo((java.lang.Object) str6);
//        long long8 = week0.getMiddleMillisecond();
//        java.lang.String str9 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        long long4 = week2.getFirstMillisecond();
//        long long5 = week2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(9, year7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        java.lang.String str12 = week6.toString();
//        long long13 = week6.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getFirstMillisecond();
//        int int7 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date23, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year28 = week27.getYear();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (short) 10, year28);
//        java.util.Date date30 = week29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date30, timeZone31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        long long35 = week34.getLastMillisecond();
//        long long36 = week34.getFirstMillisecond();
//        long long37 = week34.getFirstMillisecond();
//        java.util.Date date38 = week34.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        long long40 = week39.getLastMillisecond();
//        long long41 = week39.getFirstMillisecond();
//        long long42 = week39.getLastMillisecond();
//        java.util.Date date43 = week39.getStart();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        java.util.Date date46 = year45.getEnd();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass50 = timePeriodFormatException49.getClass();
//        java.util.Date date51 = null;
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) (short) 10, year56);
//        java.util.Date date58 = week57.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date58, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date46, timeZone59);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date43, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date38, timeZone59);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date38);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass67 = timePeriodFormatException66.getClass();
//        java.util.Date date68 = null;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year70 = week69.getYear();
//        java.util.Date date71 = year70.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date71);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass75 = timePeriodFormatException74.getClass();
//        java.util.Date date76 = null;
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date76, timeZone77);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year81 = week80.getYear();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week((int) (short) 10, year81);
//        java.util.Date date83 = week82.getEnd();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date83, timeZone84);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date71, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date68, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date38, timeZone84);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week();
//        long long90 = week89.getLastMillisecond();
//        long long91 = week89.getFirstMillisecond();
//        long long92 = week89.getSerialIndex();
//        long long93 = week89.getFirstMillisecond();
//        java.util.Date date94 = week89.getEnd();
//        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date94, timeZone95);
//        boolean boolean97 = week0.equals((java.lang.Object) date94);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560668399999L + "'", long35 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560063600000L + "'", long36 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560063600000L + "'", long37 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560668399999L + "'", long40 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560063600000L + "'", long41 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560668399999L + "'", long90 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560063600000L + "'", long91 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 107031L + "'", long92 == 107031L);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1560063600000L + "'", long93 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date94);
//        org.junit.Assert.assertNotNull(timeZone95);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        java.lang.Throwable[] throwableArray39 = timePeriodFormatException22.getSuppressed();
//        java.lang.Class<?> wildcardClass40 = timePeriodFormatException22.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray36);
//        org.junit.Assert.assertNotNull(throwableArray39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getLastMillisecond();
//        long long6 = week4.getFirstMillisecond();
//        long long7 = week4.getSerialIndex();
//        int int8 = week0.compareTo((java.lang.Object) week4);
//        boolean boolean10 = week4.equals((java.lang.Object) 10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException29.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException36.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray47);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        int int18 = week17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.next();
        long long21 = week17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2020 + "'", int18 == 2020);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577606400000L + "'", long21 == 1577606400000L);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.util.Date date6 = year5.getStart();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str11 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getLastMillisecond();
//        long long6 = week4.getFirstMillisecond();
//        long long7 = week4.getSerialIndex();
//        int int8 = week0.compareTo((java.lang.Object) week4);
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year6);
        java.util.Date date8 = week7.getEnd();
        java.lang.String str9 = week7.toString();
        boolean boolean10 = week2.equals((java.lang.Object) str9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week -13, 24" + "'", str3.equals("Week -13, 24"));
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getFirstMillisecond();
//        java.util.Date date5 = week1.getStart();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year6);
//        java.util.Calendar calendar8 = null;
//        try {
//            week7.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 10, year11);
//        java.util.Date date13 = week12.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date13, timeZone14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 10, year25);
//        java.util.Date date27 = week26.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date27, timeZone28);
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        long long32 = week31.getLastMillisecond();
//        long long33 = week31.getFirstMillisecond();
//        long long34 = week31.getFirstMillisecond();
//        java.util.Date date35 = week31.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getLastMillisecond();
//        long long38 = week36.getFirstMillisecond();
//        long long39 = week36.getLastMillisecond();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        java.util.Date date43 = year42.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass47 = timePeriodFormatException46.getClass();
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year53 = week52.getYear();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 10, year53);
//        java.util.Date date55 = week54.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date55, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date43, timeZone56);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date40, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date35, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date35);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass64 = timePeriodFormatException63.getClass();
//        java.util.Date date65 = null;
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year67 = week66.getYear();
//        java.util.Date date68 = year67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException71 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass72 = timePeriodFormatException71.getClass();
//        java.util.Date date73 = null;
//        java.util.TimeZone timeZone74 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date73, timeZone74);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year78 = week77.getYear();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week((int) (short) 10, year78);
//        java.util.Date date80 = week79.getEnd();
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date80, timeZone81);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date68, timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date65, timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date35, timeZone81);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week();
//        long long87 = week86.getLastMillisecond();
//        long long88 = week86.getFirstMillisecond();
//        long long89 = week86.getSerialIndex();
//        long long90 = week86.getFirstMillisecond();
//        java.util.Date date91 = week86.getEnd();
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date91, timeZone92);
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date2, timeZone92);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560668399999L + "'", long32 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560063600000L + "'", long33 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560668399999L + "'", long37 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560063600000L + "'", long38 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(year78);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1560668399999L + "'", long87 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560063600000L + "'", long88 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 107031L + "'", long89 == 107031L);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560063600000L + "'", long90 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 2, 35");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        java.lang.String str12 = week6.toString();
//        long long13 = week6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        int int8 = week7.getYearValue();
//        int int9 = week7.getWeek();
//        long long10 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1551600000000L + "'", long10 == 1551600000000L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str26 = timePeriodFormatException25.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException29.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException36.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException43.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray51);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        java.lang.String str7 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getLastMillisecond();
//        java.util.Date date10 = week6.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        java.util.Date date13 = year12.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 10, year23);
//        java.util.Date date25 = week24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date13, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date10, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass36 = timePeriodFormatException35.getClass();
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) 10, year42);
//        java.util.Date date44 = week43.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date32, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date10, timeZone45);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        long long50 = week49.getLastMillisecond();
//        int int51 = week49.getYearValue();
//        long long52 = week49.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week49.previous();
//        boolean boolean54 = week48.equals((java.lang.Object) week49);
//        int int55 = week0.compareTo((java.lang.Object) boolean54);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560668399999L + "'", long50 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560668399999L + "'", long52 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        int int8 = week7.getYearValue();
//        long long9 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1551600000000L + "'", long9 == 1551600000000L);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        int int6 = week0.getWeek();
//        long long7 = week0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getLastMillisecond();
//        long long22 = week20.getFirstMillisecond();
//        long long23 = week20.getFirstMillisecond();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getLastMillisecond();
//        long long27 = week25.getFirstMillisecond();
//        long long28 = week25.getLastMillisecond();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass36 = timePeriodFormatException35.getClass();
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) 10, year42);
//        java.util.Date date44 = week43.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date32, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date29, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date24, timeZone45);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass52 = timePeriodFormatException51.getClass();
//        java.util.Date date53 = null;
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year57 = week56.getYear();
//        java.util.Date date58 = year57.getEnd();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date58);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException61 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass62 = timePeriodFormatException61.getClass();
//        java.util.Date date63 = null;
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date63, timeZone64);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year68 = week67.getYear();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) (short) 10, year68);
//        java.util.Date date70 = week69.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date70, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date58, timeZone71);
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date58, timeZone74);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date24, timeZone74);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date2, timeZone74);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date2);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560063600000L + "'", long23 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException27.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray38 = timePeriodFormatException37.getSuppressed();
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException44.getSuppressed();
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
        timePeriodFormatException51.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 0");
        timePeriodFormatException51.addSuppressed((java.lang.Throwable) timePeriodFormatException58);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Year year5 = week3.getYear();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Date date8 = week7.getEnd();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) 'a');
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getLastMillisecond();
//        long long6 = week4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week4.previous();
//        long long9 = week4.getLastMillisecond();
//        java.lang.Class<?> wildcardClass10 = week4.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getLastMillisecond();
//        long long13 = week11.getFirstMillisecond();
//        long long14 = week11.getLastMillisecond();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getLastMillisecond();
//        long long18 = week16.getFirstMillisecond();
//        long long19 = week16.getLastMillisecond();
//        java.util.Date date20 = week16.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        java.util.Date date23 = year22.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass27 = timePeriodFormatException26.getClass();
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 10, year33);
//        java.util.Date date35 = week34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date35, timeZone36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date23, timeZone36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date20, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year41 = week40.getYear();
//        java.util.Date date42 = year41.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass46 = timePeriodFormatException45.getClass();
//        java.util.Date date47 = null;
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone48);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year52 = week51.getYear();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) (short) 10, year52);
//        java.util.Date date54 = week53.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date54, timeZone55);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date42, timeZone55);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date20, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone55);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        long long61 = week60.getLastMillisecond();
//        long long62 = week60.getFirstMillisecond();
//        long long63 = week60.getLastMillisecond();
//        java.util.Date date64 = week60.getStart();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year66 = week65.getYear();
//        java.util.Date date67 = year66.getEnd();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date67);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass71 = timePeriodFormatException70.getClass();
//        java.util.Date date72 = null;
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date72, timeZone73);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year77 = week76.getYear();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) (short) 10, year77);
//        java.util.Date date79 = week78.getEnd();
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date79, timeZone80);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date67, timeZone80);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date64, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date15, timeZone80);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560668399999L + "'", long61 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560063600000L + "'", long62 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560668399999L + "'", long63 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(year77);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, year3);
        long long6 = week5.getLastMillisecond();
        int int7 = week5.getWeek();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1553410799999L + "'", long6 == 1553410799999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week0.equals(obj6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getLastMillisecond();
//        java.util.Date date5 = week1.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date5, timeZone21);
//        org.jfree.data.time.Year year25 = week24.getYear();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 1, year25);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year25);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.lang.String str2 = week0.toString();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        java.util.Date date0 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year9);
//        java.util.Date date11 = week10.getEnd();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date11, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getLastMillisecond();
//        long long17 = week15.getFirstMillisecond();
//        long long18 = week15.getFirstMillisecond();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getLastMillisecond();
//        long long22 = week20.getFirstMillisecond();
//        long long23 = week20.getLastMillisecond();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        java.util.Date date27 = year26.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException30.getClass();
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date32, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (short) 10, year37);
//        java.util.Date date39 = week38.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date39, timeZone40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date27, timeZone40);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date24, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date19, timeZone40);
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date0, timeZone40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560668399999L + "'", long23 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 0);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 53L + "'", long3 == 53L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62135654400001L) + "'", long4 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 53L + "'", long5 == 53L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 0);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 53L + "'", long3 == 53L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        int int11 = week3.compareTo((java.lang.Object) class10);
//        int int12 = week3.getYearValue();
//        int int13 = week3.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577908799999L + "'", long4 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2020 + "'", int12 == 2020);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2020 + "'", int13 == 2020);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year9);
//        java.util.Date date11 = week10.getEnd();
//        boolean boolean12 = week0.equals((java.lang.Object) date11);
//        int int13 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year13 = week12.getYear();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 10, year13);
        java.util.Date date15 = week14.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date15, timeZone16);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date3, timeZone16);
        java.util.Date date19 = week18.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
        java.util.Date date23 = null;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year25 = week24.getYear();
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year36 = week35.getYear();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
        java.util.Date date38 = week37.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date23, timeZone39);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date19, timeZone39);
        try {
            org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date0, timeZone39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 2019"));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        long long11 = week6.getLastMillisecond();
//        java.lang.Class<?> wildcardClass12 = week6.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getLastMillisecond();
//        long long15 = week13.getFirstMillisecond();
//        long long16 = week13.getLastMillisecond();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        long long19 = week18.getLastMillisecond();
//        long long20 = week18.getFirstMillisecond();
//        long long21 = week18.getLastMillisecond();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        java.util.Date date25 = year24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) 10, year35);
//        java.util.Date date37 = week36.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date37, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date25, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date22, timeZone38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        java.util.Date date44 = year43.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass48 = timePeriodFormatException47.getClass();
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date49, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year54 = week53.getYear();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 10, year54);
//        java.util.Date date56 = week55.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date56, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date44, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date22, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone57);
//        java.util.Locale locale62 = null;
//        try {
//            org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date2, timeZone57, locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24L + "'", long3 == 24L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year23 = week22.getYear();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 10, year23);
        java.util.Date date25 = week24.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year29 = week28.getYear();
        java.util.Date date30 = year29.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date30, timeZone31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass35 = timePeriodFormatException34.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year41 = week40.getYear();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 10, year41);
        java.util.Date date43 = week42.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year47 = week46.getYear();
        java.util.Date date48 = year47.getStart();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date48, timeZone49);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass53 = timePeriodFormatException52.getClass();
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year59 = week58.getYear();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) (short) 10, year59);
        java.util.Date date61 = week60.getEnd();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date61, timeZone62);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException65 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass66 = timePeriodFormatException65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year71 = week70.getYear();
        java.util.Date date72 = year71.getEnd();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date72);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException75 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass76 = timePeriodFormatException75.getClass();
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date77, timeZone78);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year82 = week81.getYear();
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) (short) 10, year82);
        java.util.Date date84 = week83.getEnd();
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date84, timeZone85);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date72, timeZone85);
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone88);
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date61, timeZone88);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date48, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date30, timeZone88);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(year59);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(year71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(year82);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNull(regularTimePeriod92);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        long long4 = week3.getLastMillisecond();
        long long5 = week3.getFirstMillisecond();
        int int6 = week3.getWeek();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546156799999L + "'", long4 == 1546156799999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1545552000000L + "'", long5 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        int int8 = week7.getYearValue();
//        long long9 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1551902399999L + "'", long9 == 1551902399999L);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException8.getSuppressed();
//        java.lang.String str12 = timePeriodFormatException8.toString();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getLastMillisecond();
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week13.previous();
//        long long18 = week13.getLastMillisecond();
//        java.lang.Class<?> wildcardClass19 = week13.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
//        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray39 = timePeriodFormatException38.getSuppressed();
//        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        boolean boolean43 = week13.equals((java.lang.Object) timePeriodFormatException35);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray46 = timePeriodFormatException45.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray49 = timePeriodFormatException48.getSuppressed();
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
//        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray54 = timePeriodFormatException53.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray57 = timePeriodFormatException56.getSuppressed();
//        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray61 = timePeriodFormatException60.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray64 = timePeriodFormatException63.getSuppressed();
//        timePeriodFormatException60.addSuppressed((java.lang.Throwable) timePeriodFormatException63);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException67 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray68 = timePeriodFormatException67.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray71 = timePeriodFormatException70.getSuppressed();
//        timePeriodFormatException67.addSuppressed((java.lang.Throwable) timePeriodFormatException70);
//        timePeriodFormatException60.addSuppressed((java.lang.Throwable) timePeriodFormatException67);
//        timePeriodFormatException56.addSuppressed((java.lang.Throwable) timePeriodFormatException67);
//        java.lang.Throwable[] throwableArray75 = timePeriodFormatException67.getSuppressed();
//        java.lang.Throwable[] throwableArray76 = timePeriodFormatException67.getSuppressed();
//        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException67);
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException67);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(throwableArray22);
//        org.junit.Assert.assertNotNull(throwableArray25);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(throwableArray36);
//        org.junit.Assert.assertNotNull(throwableArray39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(throwableArray46);
//        org.junit.Assert.assertNotNull(throwableArray49);
//        org.junit.Assert.assertNotNull(throwableArray54);
//        org.junit.Assert.assertNotNull(throwableArray57);
//        org.junit.Assert.assertNotNull(throwableArray61);
//        org.junit.Assert.assertNotNull(throwableArray64);
//        org.junit.Assert.assertNotNull(throwableArray68);
//        org.junit.Assert.assertNotNull(throwableArray71);
//        org.junit.Assert.assertNotNull(throwableArray75);
//        org.junit.Assert.assertNotNull(throwableArray76);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date15, timeZone16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year26 = week25.getYear();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 10, year26);
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date28, timeZone29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException32.getClass();
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year38 = week37.getYear();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass43 = timePeriodFormatException42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year49 = week48.getYear();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) 10, year49);
        java.util.Date date51 = week50.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date51, timeZone52);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date39, timeZone52);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date28, timeZone55);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date15, timeZone55);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale60 = null;
        try {
            org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date15, timeZone59, locale60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(timeZone59);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 2020");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        int int4 = week2.compareTo((java.lang.Object) 24L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
//        java.util.Date date14 = week13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        int int19 = week17.getWeek();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getLastMillisecond();
//        long long24 = week22.getFirstMillisecond();
//        long long25 = week22.getSerialIndex();
//        org.jfree.data.time.Year year26 = week22.getYear();
//        java.lang.Class<?> wildcardClass27 = year26.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (byte) 10, year26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (byte) 1, year26);
//        boolean boolean30 = week17.equals((java.lang.Object) year26);
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = year26.getMiddleMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560668399999L + "'", long23 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getLastMillisecond();
//        long long25 = week23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week23.previous();
//        long long28 = week23.getLastMillisecond();
//        java.lang.Class<?> wildcardClass29 = week23.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
//        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray39 = timePeriodFormatException38.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
//        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray46 = timePeriodFormatException45.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray49 = timePeriodFormatException48.getSuppressed();
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
//        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        boolean boolean53 = week23.equals((java.lang.Object) timePeriodFormatException45);
//        java.lang.Throwable[] throwableArray54 = timePeriodFormatException45.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray58 = timePeriodFormatException57.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray61 = timePeriodFormatException60.getSuppressed();
//        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException60);
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNotNull(throwableArray39);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertNotNull(throwableArray46);
//        org.junit.Assert.assertNotNull(throwableArray49);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(throwableArray54);
//        org.junit.Assert.assertNotNull(throwableArray58);
//        org.junit.Assert.assertNotNull(throwableArray61);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str20 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        java.lang.String str12 = week6.toString();
//        long long13 = week6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        java.util.Date date3 = year2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) 0, year2);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        long long23 = week22.getFirstMillisecond();
//        int int24 = week0.compareTo((java.lang.Object) week22);
//        long long25 = week0.getLastMillisecond();
//        java.lang.String str26 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577606400000L + "'", long23 == 1577606400000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray38 = timePeriodFormatException37.getSuppressed();
//        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray45 = timePeriodFormatException44.getSuppressed();
//        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray49 = timePeriodFormatException48.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
//        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
//        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
//        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
//        java.lang.Throwable[] throwableArray56 = timePeriodFormatException48.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str59 = timePeriodFormatException58.toString();
//        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException58);
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNotNull(throwableArray38);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertNotNull(throwableArray45);
//        org.junit.Assert.assertNotNull(throwableArray49);
//        org.junit.Assert.assertNotNull(throwableArray52);
//        org.junit.Assert.assertNotNull(throwableArray56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str59.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        int int5 = week4.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) 10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year18 = week17.getYear();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
        java.util.Date date20 = week19.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date8);
        long long27 = week26.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 107061L + "'", long27 == 107061L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.util.Date date4 = week3.getEnd();
        int int5 = week3.getWeek();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 0");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 6, 0" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 6, 0"));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.util.Date date6 = null;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 10, year19);
//        java.util.Date date21 = week20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date9, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone22);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        boolean boolean28 = week0.equals((java.lang.Object) class26);
//        org.jfree.data.time.Year year29 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(year29);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        java.util.Date date4 = regularTimePeriod2.getEnd();
//        java.util.Date date5 = regularTimePeriod2.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) 'a');
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = week0.equals(obj3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getLastMillisecond();
//        long long12 = week10.getFirstMillisecond();
//        long long13 = week10.getFirstMillisecond();
//        java.util.Date date14 = week10.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone15);
//        boolean boolean17 = week0.equals((java.lang.Object) date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week0.previous();
//        int int19 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        long long8 = year5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = week6.equals(obj12);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        int int8 = week7.getYearValue();
//        java.lang.String str9 = week7.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        int int20 = week19.getYearValue();
//        boolean boolean22 = week19.equals((java.lang.Object) (short) -1);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24L + "'", long3 == 24L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date15, timeZone16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year26 = week25.getYear();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 10, year26);
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date28, timeZone29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException32.getClass();
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year38 = week37.getYear();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass43 = timePeriodFormatException42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year49 = week48.getYear();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) 10, year49);
        java.util.Date date51 = week50.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date51, timeZone52);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date39, timeZone52);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date28, timeZone55);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date15, timeZone55);
        long long59 = week58.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 107008L + "'", long59 == 107008L);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        int int20 = week19.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean23 = week19.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        org.jfree.data.time.Year year4 = week3.getYear();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
//        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        java.util.Date date18 = week17.getStart();
        long long19 = week17.getLastMillisecond();
        long long20 = week17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1578211199999L + "'", long19 == 1578211199999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1578211199999L + "'", long20 == 1578211199999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        java.lang.String str5 = week4.toString();
        java.lang.Class<?> wildcardClass6 = week4.getClass();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 1, 2020" + "'", str5.equals("Week 1, 2020"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        java.lang.String str31 = week0.toString();
//        org.jfree.data.time.Year year32 = week0.getYear();
//        long long33 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = week0.equals(obj3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getLastMillisecond();
//        long long12 = week10.getFirstMillisecond();
//        long long13 = week10.getFirstMillisecond();
//        java.util.Date date14 = week10.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone15);
//        boolean boolean17 = week0.equals((java.lang.Object) date14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        long long5 = week2.getFirstMillisecond();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61418966400000L) + "'", long5 == (-61418966400000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getLastMillisecond();
//        java.lang.String str5 = week3.toString();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        int int8 = week2.compareTo((java.lang.Object) class7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, 24);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException1.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.lang.Class<?> wildcardClass6 = year5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        java.util.Date date8 = week7.getStart();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (short) -1);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62184643200001L) + "'", long3 == (-62184643200001L));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Year year24 = week23.getYear();
//        java.util.Date date25 = year24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        java.util.Date date28 = year27.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass32 = timePeriodFormatException31.getClass();
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 10, year38);
//        java.util.Date date40 = week39.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date40, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date28, timeZone41);
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass47 = timePeriodFormatException46.getClass();
//        java.util.Date date48 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year50 = week49.getYear();
//        java.util.Date date51 = year50.getEnd();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass55 = timePeriodFormatException54.getClass();
//        java.util.Date date56 = null;
//        java.util.TimeZone timeZone57 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year61 = week60.getYear();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 10, year61);
//        java.util.Date date63 = week62.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date63, timeZone64);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date51, timeZone64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone64);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date44, timeZone64);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date25, timeZone64);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 0);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 53L + "'", long3 == 53L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        java.lang.String str43 = week42.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        long long7 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week -13, 24" + "'", str3.equals("Week -13, 24"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61418664000001L) + "'", long7 == (-61418664000001L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str26 = timePeriodFormatException25.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.String str28 = timePeriodFormatException25.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date4);
//        java.util.Date date44 = week43.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date44);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getYearValue();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Year year24 = week23.getYear();
//        java.lang.Object obj25 = null;
//        int int26 = week23.compareTo(obj25);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod3.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        java.util.Date date10 = week9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getLastMillisecond();
//        long long16 = week14.getFirstMillisecond();
//        long long17 = week14.getFirstMillisecond();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getLastMillisecond();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getLastMillisecond();
//        java.util.Date date23 = week19.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date23, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone39);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date18);
//        long long45 = week44.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560063600000L + "'", long45 == 1560063600000L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        long long7 = week5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        int int9 = week3.compareTo((java.lang.Object) regularTimePeriod8);
//        long long10 = week3.getSerialIndex();
//        long long11 = week3.getFirstMillisecond();
//        long long12 = week3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-13) + "'", int9 == (-13));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107017L + "'", long10 == 107017L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1551600000000L + "'", long11 == 1551600000000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1552204799999L + "'", long12 == 1552204799999L);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        java.lang.String str31 = week0.toString();
//        org.jfree.data.time.Year year32 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week0.previous();
//        java.util.Calendar calendar34 = null;
//        try {
//            long long35 = week0.getLastMillisecond(calendar34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = week0.equals(obj3);
//        long long5 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week3.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException15.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        int int6 = week0.getWeek();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 0);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getFirstMillisecond();
//        int int7 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        long long9 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException1.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year19 = week18.getYear();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 10, year19);
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Year year22 = week20.getYear();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException25.getClass();
        java.util.Date date27 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year29 = week28.getYear();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException33.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year40 = week39.getYear();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 10, year40);
        java.util.Date date42 = week41.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date30, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date23, timeZone43);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod47);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (-1));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Year year6 = week4.getYear();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2019, year6);
        long long9 = week8.getFirstMillisecond();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1528009200000L + "'", long9 == 1528009200000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1528311599999L + "'", long10 == 1528311599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
//        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray51 = timePeriodFormatException50.getSuppressed();
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray58 = timePeriodFormatException57.getSuppressed();
//        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.Throwable[] throwableArray62 = timePeriodFormatException54.getSuppressed();
//        java.lang.Throwable[] throwableArray63 = timePeriodFormatException54.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.String str65 = timePeriodFormatException54.toString();
//        java.lang.Throwable[] throwableArray66 = timePeriodFormatException54.getSuppressed();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray36);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(throwableArray44);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertNotNull(throwableArray51);
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertNotNull(throwableArray58);
//        org.junit.Assert.assertNotNull(throwableArray62);
//        org.junit.Assert.assertNotNull(throwableArray63);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str65.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray66);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        long long28 = week27.getLastMillisecond();
//        int int29 = week27.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week27.next();
//        java.lang.Class<?> wildcardClass31 = week27.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getLastMillisecond();
//        long long34 = week32.getFirstMillisecond();
//        long long35 = week32.getFirstMillisecond();
//        java.util.Date date36 = week32.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date36, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date8, timeZone37);
//        long long40 = week39.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week39.previous();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560668399999L + "'", long33 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1578211199999L + "'", long40 == 1578211199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 0");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException11.getSuppressed();
        java.lang.String str15 = timePeriodFormatException11.toString();
        java.lang.String str16 = timePeriodFormatException11.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168313600001L) + "'", long3 == (-62168313600001L));
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week1.previous();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
//        long long8 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1545552000000L + "'", long8 == 1545552000000L);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 2, 35");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 2, 35" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 2, 35"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (byte) 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getWeek();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 2, 35");
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean26 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.lang.String str3 = week2.toString();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 2, 35" + "'", str3.equals("Week 2, 35"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        long long7 = week5.getFirstMillisecond();
//        long long8 = week5.getFirstMillisecond();
//        java.util.Date date9 = week5.getStart();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.lang.String str2 = week0.toString();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        java.util.Date date18 = week17.getStart();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = week17.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', (int) (short) 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        int int21 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getLastMillisecond();
//        long long24 = week22.getFirstMillisecond();
//        long long25 = week22.getSerialIndex();
//        org.jfree.data.time.Year year26 = week22.getYear();
//        java.util.Date date27 = week22.getStart();
//        boolean boolean28 = week0.equals((java.lang.Object) date27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560668399999L + "'", long23 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 2, 35" + "'", str3.equals("Week 2, 35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        long long6 = week0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        java.lang.String str7 = week0.toString();
//        long long8 = week0.getMiddleMillisecond();
//        long long9 = week0.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            week0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        java.lang.String str31 = week0.toString();
//        org.jfree.data.time.Year year32 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray38 = timePeriodFormatException37.getSuppressed();
//        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray45 = timePeriodFormatException44.getSuppressed();
//        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
//        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
//        java.lang.Class<?> wildcardClass48 = timePeriodFormatException34.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        boolean boolean50 = week0.equals((java.lang.Object) class49);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNotNull(throwableArray38);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertNotNull(throwableArray45);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getFirstMillisecond();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
//        boolean boolean11 = week3.equals((java.lang.Object) week6);
//        org.jfree.data.time.Year year12 = week6.getYear();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week6.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(year12);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Year year24 = week23.getYear();
//        java.util.Date date25 = year24.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass28 = timePeriodFormatException27.getClass();
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year34 = week33.getYear();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 10, year34);
//        java.util.Date date36 = week35.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date36, timeZone37);
//        java.util.Locale locale39 = null;
//        try {
//            org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date25, timeZone37, locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        java.lang.Class<?> wildcardClass20 = timeZone17.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 6, 0" + "'", str4.equals("Week 6, 0"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 6, 0");
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        int int11 = week3.compareTo((java.lang.Object) class10);
//        long long12 = week3.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577908799999L + "'", long4 == 1577908799999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577908799999L + "'", long12 == 1577908799999L);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        int int6 = week0.getYearValue();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        long long44 = week43.getLastMillisecond();
//        int int45 = week43.getYearValue();
//        long long46 = week43.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week43.previous();
//        boolean boolean48 = week42.equals((java.lang.Object) week43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week43.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560668399999L + "'", long44 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560668399999L + "'", long46 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        int int6 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        int int21 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
//        long long22 = week0.getLastMillisecond();
//        java.lang.String str23 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        boolean boolean27 = week23.equals((java.lang.Object) date26);
//        java.util.Calendar calendar28 = null;
//        try {
//            week23.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Year year6 = week4.getYear();
        java.util.Date date7 = year6.getEnd();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) -1, year6);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        int int18 = week17.getYearValue();
        java.util.Date date19 = week17.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.previous();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2020 + "'", int18 == 2020);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 10, year17);
//        java.util.Date date19 = week18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date4, timeZone20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date4, timeZone39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date4);
//        boolean boolean45 = week43.equals((java.lang.Object) 1551902399999L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        java.util.Date date4 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 10, year19);
//        java.util.Date date21 = week20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date21, timeZone22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getLastMillisecond();
//        long long27 = week25.getFirstMillisecond();
//        long long28 = week25.getFirstMillisecond();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        long long31 = week30.getLastMillisecond();
//        long long32 = week30.getFirstMillisecond();
//        long long33 = week30.getLastMillisecond();
//        java.util.Date date34 = week30.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        java.util.Date date37 = year36.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException40.getClass();
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 10, year47);
//        java.util.Date date49 = week48.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date37, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date34, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date29, timeZone50);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass57 = timePeriodFormatException56.getClass();
//        java.util.Date date58 = null;
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year62 = week61.getYear();
//        java.util.Date date63 = year62.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass67 = timePeriodFormatException66.getClass();
//        java.util.Date date68 = null;
//        java.util.TimeZone timeZone69 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date68, timeZone69);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year73 = week72.getYear();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) 10, year73);
//        java.util.Date date75 = week74.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date63, timeZone76);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date63, timeZone79);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date29, timeZone79);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date7, timeZone79);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date4, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = week83.previous();
//        int int85 = week83.getWeek();
//        long long86 = week83.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560668399999L + "'", long31 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560668399999L + "'", long33 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 23 + "'", int85 == 23);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 107030L + "'", long86 == 107030L);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        int int21 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
//        long long22 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
//        java.lang.String str4 = week3.toString();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        long long7 = week5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        int int9 = week3.compareTo((java.lang.Object) regularTimePeriod8);
//        long long10 = week3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-13) + "'", int9 == (-13));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1552204799999L + "'", long10 == 1552204799999L);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
//        long long7 = year4.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, year4);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getLastMillisecond();
//        long long12 = week10.getFirstMillisecond();
//        long long13 = week10.getSerialIndex();
//        org.jfree.data.time.Year year14 = week10.getYear();
//        java.lang.Class<?> wildcardClass15 = year14.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (byte) 10, year14);
//        int int17 = week8.compareTo((java.lang.Object) (byte) 10);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week -13, 24" + "'", str3.equals("Week -13, 24"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 6);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61977196800001L) + "'", long3 == (-61977196800001L));
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        java.lang.String str31 = timePeriodFormatException22.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
//        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray51 = timePeriodFormatException50.getSuppressed();
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray58 = timePeriodFormatException57.getSuppressed();
//        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        long long63 = week62.getLastMillisecond();
//        long long64 = week62.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week62.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week62.previous();
//        long long67 = week62.getLastMillisecond();
//        java.lang.Class<?> wildcardClass68 = week62.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray71 = timePeriodFormatException70.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException73 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray74 = timePeriodFormatException73.getSuppressed();
//        timePeriodFormatException70.addSuppressed((java.lang.Throwable) timePeriodFormatException73);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException77 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray78 = timePeriodFormatException77.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException80 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray81 = timePeriodFormatException80.getSuppressed();
//        timePeriodFormatException77.addSuppressed((java.lang.Throwable) timePeriodFormatException80);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException84 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray85 = timePeriodFormatException84.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException87 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray88 = timePeriodFormatException87.getSuppressed();
//        timePeriodFormatException84.addSuppressed((java.lang.Throwable) timePeriodFormatException87);
//        timePeriodFormatException77.addSuppressed((java.lang.Throwable) timePeriodFormatException84);
//        timePeriodFormatException73.addSuppressed((java.lang.Throwable) timePeriodFormatException84);
//        boolean boolean92 = week62.equals((java.lang.Object) timePeriodFormatException84);
//        java.lang.Throwable[] throwableArray93 = timePeriodFormatException84.getSuppressed();
//        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException84);
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.String str96 = timePeriodFormatException32.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray36);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(throwableArray44);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertNotNull(throwableArray51);
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertNotNull(throwableArray58);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560668399999L + "'", long63 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560063600000L + "'", long64 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560668399999L + "'", long67 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(throwableArray71);
//        org.junit.Assert.assertNotNull(throwableArray74);
//        org.junit.Assert.assertNotNull(throwableArray78);
//        org.junit.Assert.assertNotNull(throwableArray81);
//        org.junit.Assert.assertNotNull(throwableArray85);
//        org.junit.Assert.assertNotNull(throwableArray88);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNotNull(throwableArray93);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str96.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        boolean boolean30 = week0.equals((java.lang.Object) timePeriodFormatException22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
//        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray51 = timePeriodFormatException50.getSuppressed();
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray58 = timePeriodFormatException57.getSuppressed();
//        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.Throwable[] throwableArray62 = timePeriodFormatException54.getSuppressed();
//        java.lang.Throwable[] throwableArray63 = timePeriodFormatException54.getSuppressed();
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.Throwable throwable65 = null;
//        try {
//            timePeriodFormatException54.addSuppressed(throwable65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertNotNull(throwableArray19);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray36);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(throwableArray44);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertNotNull(throwableArray51);
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertNotNull(throwableArray58);
//        org.junit.Assert.assertNotNull(throwableArray62);
//        org.junit.Assert.assertNotNull(throwableArray63);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        long long27 = week26.getLastMillisecond();
//        long long28 = week26.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week26.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week26.previous();
//        long long31 = week26.getLastMillisecond();
//        java.lang.Class<?> wildcardClass32 = week26.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        long long34 = week33.getLastMillisecond();
//        long long35 = week33.getFirstMillisecond();
//        long long36 = week33.getLastMillisecond();
//        java.util.Date date37 = week33.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        long long39 = week38.getLastMillisecond();
//        long long40 = week38.getFirstMillisecond();
//        long long41 = week38.getLastMillisecond();
//        java.util.Date date42 = week38.getStart();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year44 = week43.getYear();
//        java.util.Date date45 = year44.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date45);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass49 = timePeriodFormatException48.getClass();
//        java.util.Date date50 = null;
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date50, timeZone51);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year55 = week54.getYear();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) (short) 10, year55);
//        java.util.Date date57 = week56.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date57, timeZone58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date45, timeZone58);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date42, timeZone58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year63 = week62.getYear();
//        java.util.Date date64 = year63.getEnd();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date64);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException67 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass68 = timePeriodFormatException67.getClass();
//        java.util.Date date69 = null;
//        java.util.TimeZone timeZone70 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date69, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year74 = week73.getYear();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) 10, year74);
//        java.util.Date date76 = week75.getEnd();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date76, timeZone77);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date64, timeZone77);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date42, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone77);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date8, timeZone77);
//        java.lang.String str83 = week82.toString();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560668399999L + "'", long31 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560668399999L + "'", long34 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560063600000L + "'", long40 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560668399999L + "'", long41 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "Week 1, 2020" + "'", str83.equals("Week 1, 2020"));
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.String str4 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.lang.String str3 = week2.toString();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 2, 35" + "'", str3.equals("Week 2, 35"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61062436800001L) + "'", long4 == (-61062436800001L));
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getLastMillisecond();
//        long long22 = week20.getFirstMillisecond();
//        long long23 = week20.getFirstMillisecond();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getLastMillisecond();
//        long long27 = week25.getFirstMillisecond();
//        long long28 = week25.getLastMillisecond();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        java.util.Date date32 = year31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass36 = timePeriodFormatException35.getClass();
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) 10, year42);
//        java.util.Date date44 = week43.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date32, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date29, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date24, timeZone45);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass52 = timePeriodFormatException51.getClass();
//        java.util.Date date53 = null;
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year57 = week56.getYear();
//        java.util.Date date58 = year57.getEnd();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date58);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException61 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass62 = timePeriodFormatException61.getClass();
//        java.util.Date date63 = null;
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date63, timeZone64);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year68 = week67.getYear();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) (short) 10, year68);
//        java.util.Date date70 = week69.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date70, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date58, timeZone71);
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date58, timeZone74);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date24, timeZone74);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date2, timeZone74);
//        java.util.Date date78 = week77.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560063600000L + "'", long23 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date78);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year16 = week15.getYear();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) 10, year16);
        java.util.Date date18 = week17.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date6, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone19);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize(class24);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(class25);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        java.util.Date date4 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 10, year19);
//        java.util.Date date21 = week20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date21, timeZone22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getLastMillisecond();
//        long long27 = week25.getFirstMillisecond();
//        long long28 = week25.getFirstMillisecond();
//        java.util.Date date29 = week25.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        long long31 = week30.getLastMillisecond();
//        long long32 = week30.getFirstMillisecond();
//        long long33 = week30.getLastMillisecond();
//        java.util.Date date34 = week30.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        java.util.Date date37 = year36.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException40.getClass();
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 10, year47);
//        java.util.Date date49 = week48.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date37, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date34, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date29, timeZone50);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass57 = timePeriodFormatException56.getClass();
//        java.util.Date date58 = null;
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year62 = week61.getYear();
//        java.util.Date date63 = year62.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass67 = timePeriodFormatException66.getClass();
//        java.util.Date date68 = null;
//        java.util.TimeZone timeZone69 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date68, timeZone69);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year73 = week72.getYear();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) 10, year73);
//        java.util.Date date75 = week74.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date63, timeZone76);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date63, timeZone79);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date29, timeZone79);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date7, timeZone79);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date4, timeZone79);
//        java.lang.Class<?> wildcardClass84 = date4.getClass();
//        java.lang.Class class85 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass84);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560668399999L + "'", long31 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560668399999L + "'", long33 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//        org.junit.Assert.assertNotNull(class85);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62164684800000L) + "'", long4 == (-62164684800000L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '4', year4);
        int int9 = week8.getYearValue();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        java.lang.Class<?> wildcardClass4 = week2.getClass();
//        java.util.Date date5 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) 10, year24);
//        java.util.Date date26 = week25.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date14, timeZone27);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getLastMillisecond();
//        long long34 = week32.getFirstMillisecond();
//        long long35 = week32.getFirstMillisecond();
//        java.util.Date date36 = week32.getStart();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        long long38 = week37.getLastMillisecond();
//        long long39 = week37.getFirstMillisecond();
//        long long40 = week37.getLastMillisecond();
//        java.util.Date date41 = week37.getStart();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        java.util.Date date44 = year43.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass48 = timePeriodFormatException47.getClass();
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date49, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year54 = week53.getYear();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 10, year54);
//        java.util.Date date56 = week55.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date56, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date44, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date41, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date36, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560668399999L + "'", long33 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560668399999L + "'", long38 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560668399999L + "'", long40 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 10, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Year year6 = week4.getYear();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(2019, year6);
        long long9 = week8.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week8.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1528009200000L + "'", long9 == 1528009200000L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getFirstMillisecond();
//        java.util.Date date5 = week1.getStart();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year6);
//        long long8 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546156800000L + "'", long8 == 1546156800000L);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 10, year18);
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date8, timeZone21);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        long long28 = week27.getLastMillisecond();
//        int int29 = week27.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week27.next();
//        java.lang.Class<?> wildcardClass31 = week27.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        long long33 = week32.getLastMillisecond();
//        long long34 = week32.getFirstMillisecond();
//        long long35 = week32.getFirstMillisecond();
//        java.util.Date date36 = week32.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date36, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date8, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date8);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560668399999L + "'", long33 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        long long6 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107032L + "'", long6 == 107032L);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        long long5 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577606400000L + "'", long5 == 1577606400000L);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        int int6 = week0.getWeek();
//        long long7 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        java.util.Date date18 = week17.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass21 = timePeriodFormatException20.getClass();
        java.util.Date date22 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year24 = week23.getYear();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year35 = week34.getYear();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) 10, year35);
        java.util.Date date37 = week36.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date25, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date18, timeZone38);
        java.util.Calendar calendar43 = null;
        try {
            week42.peg(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        int int4 = week2.getWeek();
        long long5 = week2.getFirstMillisecond();
        int int6 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62164684800000L) + "'", long5 == (-62164684800000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week1.previous();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546156799999L + "'", long9 == 1546156799999L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        int int4 = week2.getWeek();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-13) + "'", int4 == (-13));
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (short) 100);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59011257600000L) + "'", long3 == (-59011257600000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (24) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 2019);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168918400000L) + "'", long4 == (-62168918400000L));
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        int int5 = week0.getWeek();
//        java.util.Date date6 = week0.getEnd();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 0);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.util.Date date8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        java.util.Date date11 = year10.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year21 = week20.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 10, year21);
//        java.util.Date date23 = week22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date4, timeZone24);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year14);
//        java.util.Date date16 = week15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date16, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date23, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year28 = week27.getYear();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (short) 10, year28);
//        java.util.Date date30 = week29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date30, timeZone31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        long long35 = week34.getLastMillisecond();
//        long long36 = week34.getFirstMillisecond();
//        long long37 = week34.getFirstMillisecond();
//        java.util.Date date38 = week34.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        long long40 = week39.getLastMillisecond();
//        long long41 = week39.getFirstMillisecond();
//        long long42 = week39.getLastMillisecond();
//        java.util.Date date43 = week39.getStart();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        java.util.Date date46 = year45.getEnd();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass50 = timePeriodFormatException49.getClass();
//        java.util.Date date51 = null;
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) (short) 10, year56);
//        java.util.Date date58 = week57.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date58, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date46, timeZone59);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date43, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date38, timeZone59);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date38);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass67 = timePeriodFormatException66.getClass();
//        java.util.Date date68 = null;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year70 = week69.getYear();
//        java.util.Date date71 = year70.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date71);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass75 = timePeriodFormatException74.getClass();
//        java.util.Date date76 = null;
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date76, timeZone77);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year81 = week80.getYear();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week((int) (short) 10, year81);
//        java.util.Date date83 = week82.getEnd();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date83, timeZone84);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date71, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date68, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date38, timeZone84);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date5, timeZone84);
//        long long90 = week89.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560668399999L + "'", long35 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560063600000L + "'", long36 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560063600000L + "'", long37 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560668399999L + "'", long40 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560063600000L + "'", long41 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560365999999L + "'", long90 == 1560365999999L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-13), 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getSerialIndex();
//        long long5 = week1.getLastMillisecond();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, year6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(23, 0);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (byte) 1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getLastMillisecond();
//        long long5 = week3.getFirstMillisecond();
//        long long6 = week3.getSerialIndex();
//        boolean boolean7 = week2.equals((java.lang.Object) long6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
//        int int11 = week0.compareTo((java.lang.Object) timeZone9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = week0.equals(obj3);
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 6, 0" + "'", str4.equals("Week 6, 0"));
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getSerialIndex();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        long long7 = week5.getFirstMillisecond();
//        long long8 = week5.getLastMillisecond();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 10, year22);
//        java.util.Date date24 = week23.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date12, timeZone25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date9, timeZone25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        java.util.Date date31 = year30.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException34.getClass();
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year41 = week40.getYear();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 10, year41);
//        java.util.Date date43 = week42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date43, timeZone44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date31, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date9, timeZone44);
//        int int48 = week3.compareTo((java.lang.Object) date9);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107061L + "'", long4 == 107061L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) '#');
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 2, 35" + "'", str3.equals("Week 2, 35"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61062436800001L) + "'", long5 == (-61062436800001L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException8.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = year1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
//        java.util.Date date14 = week13.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
//        java.util.Date date18 = week17.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getLastMillisecond();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getSerialIndex();
//        org.jfree.data.time.Year year23 = week19.getYear();
//        java.util.Date date24 = week19.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass27 = timePeriodFormatException26.getClass();
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 10, year33);
//        java.util.Date date35 = week34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date35, timeZone36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date24, timeZone36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date18, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week39.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 107031L + "'", long22 == 107031L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        long long3 = week1.getFirstMillisecond();
//        long long4 = week1.getFirstMillisecond();
//        java.util.Date date5 = week1.getStart();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(1, year6);
//        java.util.Date date8 = year6.getEnd();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week0.equals(obj6);
//        java.lang.String str8 = week0.toString();
//        int int9 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        int int7 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.lang.String str2 = week0.toString();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        long long19 = week17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577606400000L + "'", long19 == 1577606400000L);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        java.util.Date date10 = week9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date10, timeZone11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getLastMillisecond();
//        long long16 = week14.getFirstMillisecond();
//        long long17 = week14.getFirstMillisecond();
//        java.util.Date date18 = week14.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getLastMillisecond();
//        long long21 = week19.getFirstMillisecond();
//        long long22 = week19.getLastMillisecond();
//        java.util.Date date23 = week19.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        java.util.Date date26 = year25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass30 = timePeriodFormatException29.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 10, year36);
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date26, timeZone39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date23, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone39);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date18);
//        java.lang.Class<?> wildcardClass45 = date18.getClass();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 10, year2);
        java.lang.String str4 = week3.toString();
        long long5 = week3.getMiddleMillisecond();
        java.util.Date date6 = week3.getEnd();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 10, 2019" + "'", str4.equals("Week 10, 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1551902399999L + "'", long5 == 1551902399999L);
        org.junit.Assert.assertNotNull(date6);
    }
}

