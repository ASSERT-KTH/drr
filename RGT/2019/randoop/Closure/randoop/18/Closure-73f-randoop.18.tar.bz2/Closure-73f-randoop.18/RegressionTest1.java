import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        boolean boolean7 = compilerOptions0.inlineVariables;
        compilerOptions0.closurePass = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.lineBreak = true;
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node12 = node5.getAncestor(43);
        node5.putBooleanProp(15, true);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node19.addChildrenToBack(node21);
        java.lang.Object obj24 = node21.getProp((int) (short) 100);
        java.lang.String str25 = node17.checkTreeEquals(node21);
        try {
            com.google.javascript.rhino.Node node26 = node5.removeChildAfter(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str25.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.rhino.Node node14 = null;
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int18 = node16.getIntProp(2);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean24 = node23.isOptionalArg();
        boolean boolean25 = node23.isLocalResultCall();
        boolean boolean26 = node16.isEquivalentToTyped(node23);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node14, node16);
        com.google.javascript.rhino.Context context28 = com.google.javascript.rhino.Context.enter();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node32.addChildrenToBack(node34);
        java.lang.Object obj37 = node34.getProp((int) (short) 100);
        java.lang.String str38 = node30.checkTreeEquals(node34);
        node34.addSuppression("Unknown class name");
        com.google.javascript.rhino.JSDocInfo jSDocInfo41 = node34.getJSDocInfo();
        context28.removeThreadLocal((java.lang.Object) node34);
        java.lang.String str43 = closureCodingConvention0.identifyTypeDefAssign(node34);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention44 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean46 = closureCodingConvention44.isValidEnumKey("error reporter");
        java.lang.String str47 = closureCodingConvention44.getAbstractMethodName();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        node49.setJSType(jSType50);
        boolean boolean52 = node49.isVarArgs();
        boolean boolean53 = node49.hasChildren();
        boolean boolean54 = closureCodingConvention44.isOptionalParameter(node49);
        boolean boolean55 = node49.hasChildren();
        try {
            java.lang.String str56 = closureCodingConvention0.getSingletonGetterClassName(node49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(context28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str38.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(jSDocInfo41);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "goog.abstractMethod" + "'", str47.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.rhino.Node node14 = null;
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int18 = node16.getIntProp(2);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean24 = node23.isOptionalArg();
        boolean boolean25 = node23.isLocalResultCall();
        boolean boolean26 = node16.isEquivalentToTyped(node23);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node14, node16);
        java.lang.String str28 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.abstractMethod" + "'", str28.equals("goog.abstractMethod"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str11 = node7.toString(true, false, true);
        com.google.javascript.rhino.Node node12 = node7.getFirstChild();
        com.google.javascript.rhino.Node node13 = node2.copyInformationFromForTree(node7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler17 = null;
        compilerOptions14.setAliasTransformationHandler(aliasTransformationHandler17);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkMethods;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = null;
        java.lang.String[] strArray23 = new java.lang.String[] { "name", ": hi!" };
        try {
            com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", node7, checkLevel19, diagnosticType20, strArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "EOF" + "'", str11.equals("EOF"));
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.lang.Object obj1 = null;
        context0.seal(obj1);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
        java.lang.Object obj6 = null;
        try {
            context0.unseal(obj6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        boolean boolean23 = closureCodingConvention0.isConstantKey("goog.exportSymbol");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean26 = closureCodingConvention24.isValidEnumKey("error reporter");
        java.lang.String str27 = closureCodingConvention24.getExportPropertyFunction();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node29.setJSType(jSType30);
        boolean boolean32 = node29.isVarArgs();
        boolean boolean33 = closureCodingConvention24.isOptionalParameter(node29);
        boolean boolean35 = closureCodingConvention24.isExported("");
        boolean boolean38 = closureCodingConvention24.isExported("", true);
        com.google.javascript.rhino.Node node39 = null;
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str45 = closureCodingConvention24.extractClassNameIfProvide(node39, node44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str51 = node47.toString(false, true, false);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        node53.setJSType(jSType54);
        boolean boolean56 = node53.isVarArgs();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        node58.setJSType(jSType59);
        boolean boolean61 = node58.isVarArgs();
        boolean boolean62 = node53.hasChild(node58);
        node53.removeProp(2);
        node47.addChildToFront(node53);
        boolean boolean66 = closureCodingConvention24.isOptionalParameter(node47);
        java.lang.String str67 = closureCodingConvention0.getSingletonGetterClassName(node47);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention68 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean70 = closureCodingConvention68.isValidEnumKey("error reporter");
        boolean boolean72 = closureCodingConvention68.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType73 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType74 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType75 = null;
        closureCodingConvention68.applySubclassRelationship(functionType73, functionType74, subclassType75);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean81 = closureCodingConvention68.isVarArgsParameter(node80);
        boolean boolean82 = closureCodingConvention0.isOptionalParameter(node80);
        java.lang.String str83 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportProperty" + "'", str27.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "EOF" + "'", str51.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "goog.exportSymbol" + "'", str83.equals("goog.exportSymbol"));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        java.util.logging.Logger logger5 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
//        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker8 = null;
//        compiler7.tracker = performanceTracker8;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str14 = jSSourceFile12.getLine((int) (short) 100);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12 };
//        java.io.PrintStream printStream16 = null;
//        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23, false);
//        java.lang.String str26 = jSSourceFile23.getName();
//        java.nio.charset.Charset charset28 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset28);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region40 = jSSourceFile38.getRegion(26);
//        java.lang.String str41 = jSSourceFile38.getName();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str45 = jSSourceFile44.toString();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray46 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile20, jSSourceFile23, jSSourceFile29, jSSourceFile32, jSSourceFile38, jSSourceFile44 };
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile49, false);
//        java.lang.String str52 = jSSourceFile49.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput53 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile49);
//        java.lang.String str54 = compilerInput53.getName();
//        java.io.PrintStream printStream55 = null;
//        com.google.javascript.jscomp.Compiler compiler56 = new com.google.javascript.jscomp.Compiler(printStream55);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions57.inlineConstantVars = false;
//        compilerOptions57.instrumentationTemplate = "eof";
//        boolean boolean62 = compilerOptions57.moveFunctionDeclarations;
//        compiler56.initOptions(compilerOptions57);
//        compilerInput53.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler56);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile67 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region69 = jSSourceFile67.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray70 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions71.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy74 = compilerOptions71.variableRenaming;
//        com.google.javascript.jscomp.Result result75 = compiler56.compile(jSSourceFile67, jSModuleArray70, compilerOptions71);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions76.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler79 = null;
//        compilerOptions76.setAliasTransformationHandler(aliasTransformationHandler79);
//        com.google.javascript.jscomp.Result result81 = compiler17.compile(jSSourceFileArray46, jSModuleArray70, compilerOptions76);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions82 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean83 = compilerOptions82.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig84 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions82);
//        compiler7.init(jSSourceFileArray15, jSSourceFileArray46, compilerOptions82);
//        java.lang.Object obj86 = context0.getThreadLocal((java.lang.Object) jSSourceFileArray15);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(jSSourceFileArray15);
//        org.junit.Assert.assertNotNull(jSSourceFile20);
//        org.junit.Assert.assertNotNull(jSSourceFile23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile29);
//        org.junit.Assert.assertNotNull(jSSourceFile32);
//        org.junit.Assert.assertNotNull(jSSourceFile38);
//        org.junit.Assert.assertNull(region40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFileArray46);
//        org.junit.Assert.assertNotNull(jSSourceFile49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile67);
//        org.junit.Assert.assertNull(region69);
//        org.junit.Assert.assertNotNull(jSModuleArray70);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy74 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy74.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result75);
//        org.junit.Assert.assertNotNull(result81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNull(obj86);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean12 = compilerOptions0.optimizeCalls;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean15 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.sourceMapOutputPath = "eof";
        compilerOptions0.aliasStringsBlacklist = "goog.global";
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, true);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.extractPrototypeMemberDeclarations = true;
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("TypeError: hi!");
        java.lang.String str2 = sourceFile1.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("eof");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property eof");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel1, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel6, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        int int10 = diagnosticType3.compareTo(diagnosticType8);
        java.lang.String str11 = diagnosticType3.toString();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.inlineConstantVars = false;
        compilerOptions14.instrumentationTemplate = "eof";
        boolean boolean19 = compilerOptions14.moveFunctionDeclarations;
        compiler13.initOptions(compilerOptions14);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMethods;
        diagnosticType3.level = checkLevel21;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNull(checkLevel4);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ": hi!" + "'", str11.equals(": hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(intermediateState4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        try {
            java.io.Reader reader3 = jSSourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.disambiguateProperties = true;
        boolean boolean9 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node26 = node20.copyInformationFromForTree(node25);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection27 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node25);
        boolean boolean28 = node25.isSyntheticBlock();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeCollection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getErrorMessage();
        java.lang.String str4 = ecmaError1.sourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        int int55 = node50.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
        java.lang.String str65 = lightweightMessageFormatter45.formatError(jSError64);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node68.addChildrenToBack(node70);
        java.lang.Object obj73 = node70.getProp((int) (short) 100);
        int int75 = node70.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat77 = diagnosticType76.format;
        java.lang.String[] strArray83 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node70, diagnosticType76, strArray83);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy88 = null;
        compilerOptions85.variableRenaming = variableRenamingPolicy88;
        java.util.Set<java.lang.String> strSet90 = compilerOptions85.stripNameSuffixes;
        boolean boolean91 = compilerOptions85.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel92 = null;
        compilerOptions85.reportMissingOverride = checkLevel92;
        boolean boolean94 = jSError84.equals((java.lang.Object) compilerOptions85);
        java.lang.String str95 = lightweightMessageFormatter45.formatError(jSError84);
        java.util.logging.Logger logger96 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager97 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter45, logger96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(messageFormat57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str65.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertNull(obj73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(diagnosticType76);
        org.junit.Assert.assertNotNull(messageFormat77);
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertNotNull(jSError84);
        org.junit.Assert.assertNotNull(strSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str95.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        boolean boolean4 = node3.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel2, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.checkControlStructures;
        compilerOptions19.setRemoveClosureAsserts(false);
        compilerOptions19.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result26 = compiler7.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions19);
        compilerOptions19.generatePseudoNames = false;
        boolean boolean29 = compilerOptions19.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions19.brokenClosureRequiresLevel;
        diagnosticType4.level = checkLevel30;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions32.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = compilerOptions32.checkUndefinedProperties;
        diagnosticType4.level = checkLevel36;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = diagnosticType4.level;
        boolean boolean39 = diagnosticGroup0.matches(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNull(checkLevel5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        boolean boolean9 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean7 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(detailLevel6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition13 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation14 = aliasTransformationHandler11.logAliasTransformation("", aliasTransformationSourcePosition13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("()");
        java.lang.String str2 = ecmaError1.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("EOF [synthetic: 1]", "EOF");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        boolean boolean9 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions10);
        boolean boolean13 = compilerOptions10.shouldColorizeErrorOutput();
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        java.lang.String str15 = compilerOptions10.jsOutputFile;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy16 = compilerOptions10.anonymousFunctionNaming;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy16;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy16 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy16.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        java.lang.String str5 = compilerOptions0.jsOutputFile;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", true);
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap12 = compilerOptions0.customPasses;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap12);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            com.google.javascript.rhino.Context.reportWarning("error reporter", ": hi!", (int) (short) 100, "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        int int55 = node50.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
        java.lang.String str65 = lightweightMessageFormatter45.formatError(jSError64);
        int int66 = jSError64.getCharno();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(messageFormat57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str65.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        java.lang.String str45 = jSSourceFile5.getCode();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.setErrorReporter(errorReporter2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.MessageBundle messageBundle4 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(messageBundle4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        boolean boolean23 = closureCodingConvention0.isConstantKey("goog.exportSymbol");
        java.lang.String str24 = closureCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        node17.setJSType(jSType18);
        boolean boolean20 = node17.isVarArgs();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        node22.setJSType(jSType23);
        boolean boolean25 = node22.isVarArgs();
        boolean boolean26 = node17.hasChild(node22);
        node17.removeProp(2);
        node17.setIsSyntheticBlock(false);
        java.lang.String str31 = closureCodingConvention0.identifyTypeDefAssign(node17);
        com.google.javascript.rhino.Node node32 = null;
        try {
            java.lang.String str33 = closureCodingConvention0.getSingletonGetterClassName(node32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int2 = node1.getLineno();
        node1.putBooleanProp(26, true);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        boolean boolean12 = node11.isVarArgs();
        node7.addChildrenToFront(node11);
        try {
            com.google.javascript.rhino.Node node14 = node1.clonePropsFrom(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Node has existing properties.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "TypeError: hi!", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder5.append("TypeError");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean12 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.toString();
        java.io.Reader reader4 = jSSourceFile2.getCodeReader();
        java.lang.String str5 = jSSourceFile2.getCode();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(38, (int) '4', 28);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        int int11 = node5.getLineno();
        boolean boolean12 = node5.isQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str6 = node2.toString(true, false, true);
        com.google.javascript.rhino.Node node7 = node2.getFirstChild();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node11.addChildrenToBack(node13);
        java.lang.Object obj16 = node13.getProp((int) (short) 100);
        java.lang.String str17 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node18 = node2.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node22.addChildrenToBack(node24);
        java.lang.Object obj27 = node24.getProp((int) (short) 100);
        java.lang.String str28 = node20.checkTreeEquals(node24);
        node20.setLineno(47);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node34.addChildrenToBack(node36);
        java.lang.Object obj39 = node36.getProp((int) (short) 100);
        java.lang.String str40 = node32.checkTreeEquals(node36);
        int int41 = node32.getSourcePosition();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node18, node20, node32, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(21, nodeArray44);
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = node45.getJSDocInfo();
        node45.setLineno((int) 'a');
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EOF" + "'", str6.equals("EOF"));
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str17.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str28.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str40.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNull(jSDocInfo46);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        compilerOptions10.instrumentationTemplate = "eof";
        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
        compiler9.initOptions(compilerOptions10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.SourceFile sourceFile18 = compilerInput6.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(sourceFile18);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 43);
//        boolean boolean7 = context0.isGeneratingSource();
//        boolean boolean8 = context0.isGeneratingDebug();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.smartNameRemoval;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.checkControlStructures;
        compilerOptions5.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions5.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions5.prettyPrint;
        compilerOptions5.setPropertyAffinity(true);
        compilerOptions5.locale = "eof";
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig17 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions15);
        boolean boolean18 = compilerOptions15.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat19 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions15.errorFormat = errorFormat19;
        java.lang.String str21 = compilerOptions15.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions15.checkMissingReturn;
        compilerOptions5.checkProvides = checkLevel22;
        compilerOptions0.checkUndefinedProperties = checkLevel22;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(errorFormat19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        try {
            node4.setSideEffectFlags(33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.checkSymbols = true;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        java.lang.Object obj6 = node3.getProp((int) (short) 100);
        node3.setType((int) ' ');
        node3.setLineno(52);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        int int55 = node50.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
        java.lang.String str65 = lightweightMessageFormatter45.formatError(jSError64);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node68.addChildrenToBack(node70);
        java.lang.Object obj73 = node70.getProp((int) (short) 100);
        int int75 = node70.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat77 = diagnosticType76.format;
        java.lang.String[] strArray83 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node70, diagnosticType76, strArray83);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy88 = null;
        compilerOptions85.variableRenaming = variableRenamingPolicy88;
        java.util.Set<java.lang.String> strSet90 = compilerOptions85.stripNameSuffixes;
        boolean boolean91 = compilerOptions85.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel92 = null;
        compilerOptions85.reportMissingOverride = checkLevel92;
        boolean boolean94 = jSError84.equals((java.lang.Object) compilerOptions85);
        java.lang.String str95 = lightweightMessageFormatter45.formatError(jSError84);
        java.lang.String str96 = jSError84.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(messageFormat57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str65.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertNull(obj73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(diagnosticType76);
        org.junit.Assert.assertNotNull(messageFormat77);
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertNotNull(jSError84);
        org.junit.Assert.assertNotNull(strSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str95.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)" + "'", str96.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        boolean boolean5 = node1.hasChildren();
        node1.setIsSyntheticBlock(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.optimizeReturns = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int2 = node1.getLineno();
        node1.putBooleanProp(26, true);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags6 = null;
        try {
            node1.setSideEffectFlags(sideEffectFlags6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.enableRuntimeTypeCheck("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions5.sourceMapDetailLevel = detailLevel8;
        compilerOptions0.sourceMapDetailLevel = detailLevel8;
        compilerOptions0.moveFunctionDeclarations = true;
        org.junit.Assert.assertNotNull(detailLevel8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str11 = node7.toString(true, false, true);
        com.google.javascript.rhino.Node node12 = node7.getFirstChild();
        com.google.javascript.rhino.Node node13 = node2.copyInformationFromForTree(node7);
        boolean boolean14 = detailLevel0.apply(node13);
        node13.detachChildren();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "EOF" + "'", str11.equals("EOF"));
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getErrorMessage();
        int int3 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.unaliasableGlobals = "com.google.javascript.rhino.EcmaError: TypeError: hi!";
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.inlineConstantVars = false;
        compilerOptions4.instrumentationTemplate = "eof";
        boolean boolean9 = compilerOptions4.moveFunctionDeclarations;
        compiler3.initOptions(compilerOptions4);
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler3.getErrorManager();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19, false);
        java.lang.String str22 = jSSourceFile19.getName();
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset24);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region36 = jSSourceFile34.getRegion(26);
        java.lang.String str37 = jSSourceFile34.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str41 = jSSourceFile40.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray42 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile16, jSSourceFile19, jSSourceFile25, jSSourceFile28, jSSourceFile34, jSSourceFile40 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45, false);
        java.lang.String str48 = jSSourceFile45.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45);
        java.lang.String str50 = compilerInput49.getName();
        java.io.PrintStream printStream51 = null;
        com.google.javascript.jscomp.Compiler compiler52 = new com.google.javascript.jscomp.Compiler(printStream51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions53.inlineConstantVars = false;
        compilerOptions53.instrumentationTemplate = "eof";
        boolean boolean58 = compilerOptions53.moveFunctionDeclarations;
        compiler52.initOptions(compilerOptions53);
        compilerInput49.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler52);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile63 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region65 = jSSourceFile63.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray66 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions67.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy70 = compilerOptions67.variableRenaming;
        com.google.javascript.jscomp.Result result71 = compiler52.compile(jSSourceFile63, jSModuleArray66, compilerOptions67);
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions72.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler75 = null;
        compilerOptions72.setAliasTransformationHandler(aliasTransformationHandler75);
        com.google.javascript.jscomp.Result result77 = compiler13.compile(jSSourceFileArray42, jSModuleArray66, compilerOptions72);
        java.lang.Object obj78 = null;
        try {
            java.lang.String str79 = com.google.javascript.rhino.ScriptRuntime.getMessage4("", (java.lang.Object) diagnosticGroup1, (java.lang.Object) errorManager11, (java.lang.Object) compilerOptions72, obj78);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(region36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray42);
        org.junit.Assert.assertNotNull(jSSourceFile45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSSourceFile63);
        org.junit.Assert.assertNull(region65);
        org.junit.Assert.assertNotNull(jSModuleArray66);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy70 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy70.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result71);
        org.junit.Assert.assertNotNull(result77);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.unaliasableGlobals = "com.google.javascript.rhino.EcmaError: TypeError: hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel6;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean3 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean6 = closureCodingConvention0.isConstant("goog.exportProperty");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        boolean boolean9 = node8.isVarArgs();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node8);
        boolean boolean12 = closureCodingConvention0.isSuperClassReference("name");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder26 = node25.getJsDocBuilderForNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean29 = closureCodingConvention27.isValidEnumKey("error reporter");
        java.lang.String str30 = closureCodingConvention27.getExportPropertyFunction();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        node32.setJSType(jSType33);
        boolean boolean35 = node32.isVarArgs();
        boolean boolean36 = closureCodingConvention27.isOptionalParameter(node32);
        boolean boolean38 = closureCodingConvention27.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType41 = null;
        closureCodingConvention27.applySubclassRelationship(functionType39, functionType40, subclassType41);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        node44.setJSType(jSType45);
        boolean boolean47 = node44.isVarArgs();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        node49.setJSType(jSType50);
        boolean boolean52 = node49.isVarArgs();
        boolean boolean53 = node44.hasChild(node49);
        node44.removeProp(2);
        node44.setIsSyntheticBlock(false);
        java.lang.String str58 = closureCodingConvention27.identifyTypeDefAssign(node44);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(16, node25, node44, 130, 6);
        boolean boolean62 = node1.isEquivalentTo(node25);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode(": hi!", "COLONCOLON", "com.google.javascript.rhino.EvaluatorException: goog.exportProperty");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = null;
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset7);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str13 = jSSourceFile11.getLine((int) (short) 100);
        jSSourceFile11.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str18 = jSSourceFile17.getOriginalPath();
        java.lang.String str20 = jSSourceFile17.getLine(0);
        jSSourceFile17.setOriginalPath("EOF");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile11, jSSourceFile17 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.checkControlStructures;
        compilerOptions24.setRemoveClosureAsserts(false);
        compilerOptions24.setTweakToBooleanLiteral("", false);
        java.lang.String str31 = compilerOptions24.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap32 = compilerOptions24.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode33 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions24.tracer = tracerMode33;
        compilerOptions24.reserveRawExports = false;
        try {
            compiler1.init(jSSourceFileArray5, jSSourceFileArray23, compilerOptions24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(cssRenamingMap32);
        org.junit.Assert.assertTrue("'" + tracerMode33 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode33.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        com.google.javascript.rhino.Node node4 = node3.cloneNode();
        java.lang.String str5 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NUMBER 10.0 48" + "'", str5.equals("NUMBER 10.0 48"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        node3.setIsSyntheticBlock(false);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        java.lang.String str9 = node1.checkTreeEquals(node5);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags11 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 0);
        try {
            node1.setSideEffectFlags(sideEffectFlags11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str9.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.inlineConstantVars = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        java.lang.String str12 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.global" + "'", str12.equals("goog.global"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        java.lang.Object obj6 = node3.getProp((int) (short) 100);
        node3.setType((int) ' ');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str16 = node12.toString(true, false, true);
        int int17 = node12.getSourcePosition();
        node12.setIsSyntheticBlock(true);
        node3.addChildAfter(node10, node12);
        java.lang.String str21 = node10.toStringTree();
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EOF" + "'", str16.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "EOF\n" + "'", str21.equals("EOF\n"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkSymbols = false;
        compilerOptions0.reportPath = "";
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.MessageBundle messageBundle3 = compilerOptions0.messageBundle;
        boolean boolean4 = compilerOptions0.optimizeArgumentsArray;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.checkControlStructures;
        compilerOptions18.setRemoveClosureAsserts(false);
        compilerOptions18.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result25 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions18);
        compilerOptions18.generatePseudoNames = false;
        boolean boolean28 = compilerOptions18.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions18.brokenClosureRequiresLevel;
        compilerOptions18.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions32.aggressiveVarCheck;
        compilerOptions18.checkUndefinedProperties = checkLevel35;
        compilerOptions0.aggressiveVarCheck = checkLevel35;
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertNull(messageBundle3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(result25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("com.google.javascript.rhino.EcmaError: TypeError: hi!", "()");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: hi!" + "'", str3.equals("com.google.javascript.rhino.EcmaError: TypeError: hi!"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str24 = jSSourceFile23.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str31 = jSSourceFile30.toString();
        java.io.Reader reader32 = jSSourceFile30.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str36 = jSSourceFile35.getOriginalPath();
        java.lang.String str38 = jSSourceFile35.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region43 = jSSourceFile41.getRegion(26);
        java.lang.String str44 = jSSourceFile41.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile27, jSSourceFile30, jSSourceFile35, jSSourceFile41 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str48 = compilerOptions47.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format49 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions47.sourceMapFormat = format49;
        boolean boolean51 = compilerOptions47.crossModuleMethodMotion;
        compilerOptions47.setLooseTypes(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap54 = null;
        compilerOptions47.cssRenamingMap = cssRenamingMap54;
        compiler1.init(jSSourceFileArray45, jSModuleArray46, compilerOptions47);
        compilerOptions47.renamePrefix = "goog.global";
        compilerOptions47.inlineLocalVariables = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(reader32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNull(region43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(format49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.WARNING;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        compilerOptions0.debugFunctionSideEffectsPath = "";
        boolean boolean7 = compilerOptions0.optimizeReturns;
        boolean boolean8 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.decomposeExpressions = true;
        boolean boolean12 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compilerOptions13.generatePseudoNames = false;
        boolean boolean23 = compilerOptions13.removeUnusedVars;
        boolean boolean24 = compilerOptions13.groupVariableDeclarations;
        boolean boolean25 = compilerOptions13.inlineAnonymousFunctionExpressions;
        compilerOptions13.printInputDelimiter = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node1.setJSType(jSType6);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region4 = jSSourceFile2.getRegion(26);
        java.lang.String str5 = jSSourceFile2.getName();
        jSSourceFile2.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean5 = closureCodingConvention0.isConstantKey("goog.exportProperty");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.inlineConstantVars = false;
//        java.lang.String str5 = compilerOptions2.jsOutputFile;
//        boolean boolean6 = compilerOptions2.smartNameRemoval;
//        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.brokenClosureRequiresLevel;
//        try {
//            context0.unseal((java.lang.Object) compilerOptions2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "Named type with empty name component", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 18, 100, 4);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        java.lang.String str7 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel8;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context0.setLocale(locale3);
//        context0.setLanguageVersion(110);
//        boolean boolean7 = context0.isGeneratingSource();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region4 = jSSourceFile2.getRegion(26);
        com.google.javascript.jscomp.Region region6 = jSSourceFile2.getRegion(110);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region4);
        org.junit.Assert.assertNull(region6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        java.lang.Object obj7 = node4.getProp((int) (short) 100);
        int int9 = node4.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node4, diagnosticType10, strArray17);
        boolean boolean19 = node4.isOnlyModifiesThisCall();
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.removeUnusedVars = true;
        compilerOptions21.setManageClosureDependencies(true);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.setDefineToStringLiteral("or", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n");
        compilerOptions0.inlineFunctions = true;
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.ideMode;
        compilerOptions0.setDefineToStringLiteral("hi!", "");
        boolean boolean11 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.checkControlStructures;
        java.util.Set<java.lang.String> strSet14 = compilerOptions12.aliasableStrings;
        compilerOptions0.stripTypes = strSet14;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strSet14);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 43);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = context0.getErrorReporter();
//        com.google.javascript.rhino.Context context8 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger9 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
//        context8.removeThreadLocal((java.lang.Object) loggerErrorManager10);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context8, (long) 8);
//        com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter();
//        context14.addActivationName("TypeError: hi!");
//        java.util.Locale locale17 = context14.getLocale();
//        java.util.Locale locale18 = context8.setLocale(locale17);
//        java.util.Locale locale19 = context0.setLocale(locale17);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNull(errorReporter7);
//        org.junit.Assert.assertNotNull(context8);
//        org.junit.Assert.assertNotNull(context14);
//        org.junit.Assert.assertNotNull(locale17);
//        org.junit.Assert.assertNull(locale18);
//        org.junit.Assert.assertNull(locale19);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.optimizeParameters = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        boolean boolean2 = compilerOptions0.ignoreCajaProperties;
        boolean boolean3 = compilerOptions0.ambiguateProperties;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.checkControlStructures;
        compilerOptions18.setRemoveClosureAsserts(false);
        compilerOptions18.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result25 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions18);
        compilerOptions18.generatePseudoNames = false;
        boolean boolean28 = compilerOptions18.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions18.brokenClosureRequiresLevel;
        compilerOptions18.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions32.aggressiveVarCheck;
        compilerOptions18.checkUndefinedProperties = checkLevel35;
        compilerOptions0.reportUnknownTypes = checkLevel35;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(result25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        java.lang.String str9 = node1.checkTreeEquals(node5);
        node1.setLineno(47);
        boolean boolean13 = node1.getBooleanProp(0);
        int int14 = node1.getCharno();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str9.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("<No stack trace available>");
        int int2 = evaluatorException1.columnNumber();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        int int55 = node50.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
        java.lang.String str65 = lightweightMessageFormatter45.formatError(jSError64);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node68.addChildrenToBack(node70);
        java.lang.Object obj73 = node70.getProp((int) (short) 100);
        int int75 = node70.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat77 = diagnosticType76.format;
        java.lang.String[] strArray83 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node70, diagnosticType76, strArray83);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy88 = null;
        compilerOptions85.variableRenaming = variableRenamingPolicy88;
        java.util.Set<java.lang.String> strSet90 = compilerOptions85.stripNameSuffixes;
        boolean boolean91 = compilerOptions85.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel92 = null;
        compilerOptions85.reportMissingOverride = checkLevel92;
        boolean boolean94 = jSError84.equals((java.lang.Object) compilerOptions85);
        java.lang.String str95 = lightweightMessageFormatter45.formatError(jSError84);
        java.lang.String str96 = jSError84.description;
        java.lang.String str97 = jSError84.description;
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(messageFormat57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str65.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertNull(obj73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(diagnosticType76);
        org.junit.Assert.assertNotNull(messageFormat77);
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertNotNull(jSError84);
        org.junit.Assert.assertNotNull(strSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str95.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "Exceeded max number of optimization iterations: TypeError: hi!" + "'", str96.equals("Exceeded max number of optimization iterations: TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "Exceeded max number of optimization iterations: TypeError: hi!" + "'", str97.equals("Exceeded max number of optimization iterations: TypeError: hi!"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        try {
            boolean boolean3 = compiler1.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7, false);
        java.lang.String str10 = jSSourceFile7.getName();
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16, false);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region24 = jSSourceFile22.getRegion(26);
        java.lang.String str25 = jSSourceFile22.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str29 = jSSourceFile28.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile13, jSSourceFile16, jSSourceFile22, jSSourceFile28 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33, false);
        java.lang.String str36 = jSSourceFile33.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        java.lang.String str38 = compilerInput37.getName();
        java.io.PrintStream printStream39 = null;
        com.google.javascript.jscomp.Compiler compiler40 = new com.google.javascript.jscomp.Compiler(printStream39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.inlineConstantVars = false;
        compilerOptions41.instrumentationTemplate = "eof";
        boolean boolean46 = compilerOptions41.moveFunctionDeclarations;
        compiler40.initOptions(compilerOptions41);
        compilerInput37.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler40);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region53 = jSSourceFile51.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray54 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions55.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy58 = compilerOptions55.variableRenaming;
        com.google.javascript.jscomp.Result result59 = compiler40.compile(jSSourceFile51, jSModuleArray54, compilerOptions55);
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler63 = null;
        compilerOptions60.setAliasTransformationHandler(aliasTransformationHandler63);
        com.google.javascript.jscomp.Result result65 = compiler1.compile(jSSourceFileArray30, jSModuleArray54, compilerOptions60);
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNull(region53);
        org.junit.Assert.assertNotNull(jSModuleArray54);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy58 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy58.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(result65);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.aggressiveVarCheck;
        java.lang.String str10 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.inlineConstantVars = false;
        compilerOptions3.instrumentationTemplate = "eof";
        boolean boolean8 = compilerOptions3.moveFunctionDeclarations;
        compiler2.initOptions(compilerOptions3);
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        java.lang.String str14 = compiler13.getAstDotGraph();
        compiler13.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState16 = compiler13.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.JSModule jSModule19 = null;
        try {
            java.lang.String[] strArray20 = compiler13.toSourceArray(jSModule19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(messageFormatter11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(intermediateState16);
        org.junit.Assert.assertNotNull(messageFormatter18);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        java.lang.String[] strArray12 = new java.lang.String[] { "or", "EOF", "EOF", "or", "error reporter", "" };
        java.util.ArrayList<java.lang.String> strList13 = new java.util.ArrayList<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList13, strArray12);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList13);
        java.lang.String str16 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "error reporter" + "'", str16.equals("error reporter"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        boolean boolean13 = closureCodingConvention0.isExported("TypeError: hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention0.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node21.addChildrenToBack(node23);
        java.lang.Object obj26 = node23.getProp((int) (short) 100);
        java.lang.String str27 = node19.checkTreeEquals(node23);
        try {
            java.lang.String str28 = closureCodingConvention0.getSingletonGetterClassName(node23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str27.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.ideMode;
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager2.getWarnings();
        double double6 = loggerErrorManager2.getTypedPercent();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertNotNull(jSErrorArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean11 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str17 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportSymbol" + "'", str17.equals("goog.exportSymbol"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        java.lang.String str9 = compilerOptions0.reportPath;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel10;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.inlineConstantVars = false;
        compilerOptions3.unaliasableGlobals = "";
        compilerOptions3.generatePseudoNames = false;
        boolean boolean10 = compilerOptions3.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions3.checkMissingReturn;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = null;
        java.lang.String[] strArray13 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        try {
            com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("NUMBER 10.0 48", (int) (short) 100, 36, checkLevel11, diagnosticType12, strArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getWarnings();
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions7.setAliasTransformationHandler(aliasTransformationHandler10);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkMethods;
        boolean boolean13 = compilerOptions7.inlineLocalFunctions;
        java.lang.RuntimeException runtimeException14 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) loggerErrorManager2, (java.lang.Object) compilerOptions7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(runtimeException14);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
//        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
//        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
//        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
//        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
//        com.google.javascript.rhino.Node node14 = null;
//        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        int int18 = node16.getIntProp(2);
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
//        boolean boolean24 = node23.isOptionalArg();
//        boolean boolean25 = node23.isLocalResultCall();
//        boolean boolean26 = node16.isEquivalentToTyped(node23);
//        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node14, node16);
//        com.google.javascript.rhino.Context context28 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node32.addChildrenToBack(node34);
//        java.lang.Object obj37 = node34.getProp((int) (short) 100);
//        java.lang.String str38 = node30.checkTreeEquals(node34);
//        node34.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo41 = node34.getJSDocInfo();
//        context28.removeThreadLocal((java.lang.Object) node34);
//        java.lang.String str43 = closureCodingConvention0.identifyTypeDefAssign(node34);
//        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        java.lang.String str49 = node45.toString(true, false, true);
//        com.google.javascript.rhino.Node node50 = node45.getFirstChild();
//        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node54.addChildrenToBack(node56);
//        java.lang.Object obj59 = node56.getProp((int) (short) 100);
//        java.lang.String str60 = node52.checkTreeEquals(node56);
//        com.google.javascript.rhino.Node node61 = node45.clonePropsFrom(node52);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention62 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean64 = closureCodingConvention62.isValidEnumKey("error reporter");
//        java.lang.String str65 = closureCodingConvention62.getAbstractMethodName();
//        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.jstype.JSType jSType68 = null;
//        node67.setJSType(jSType68);
//        boolean boolean70 = node67.isVarArgs();
//        boolean boolean71 = node67.hasChildren();
//        boolean boolean72 = closureCodingConvention62.isOptionalParameter(node67);
//        com.google.javascript.rhino.Node node74 = node67.getAncestor(43);
//        node67.putBooleanProp(15, true);
//        java.lang.String str78 = closureCodingConvention0.extractClassNameIfProvide(node52, node67);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(node12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNotNull(context28);
//        org.junit.Assert.assertNotNull(node30);
//        org.junit.Assert.assertNull(obj37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str38.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo41);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "EOF" + "'", str49.equals("EOF"));
//        org.junit.Assert.assertNull(node50);
//        org.junit.Assert.assertNotNull(node52);
//        org.junit.Assert.assertNull(obj59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str60.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(node61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "goog.abstractMethod" + "'", str65.equals("goog.abstractMethod"));
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNull(node74);
//        org.junit.Assert.assertNull(str78);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        java.lang.String str7 = compilerOptions0.renamePrefix;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.checkControlStructures;
        java.util.Set<java.lang.String> strSet6 = compilerOptions4.aliasableStrings;
        compilerOptions0.aliasableStrings = strSet6;
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0);
        compilerOptions0.setRemoveAbstractMethods(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
//        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
//        java.lang.Object obj6 = context0.getDebuggerContextData();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(obj6);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions9.aggressiveVarCheck;
        boolean boolean13 = compilerOptions9.printInputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.checkProvides;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel14;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler19 = null;
        compilerOptions16.setAliasTransformationHandler(aliasTransformationHandler19);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy21 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy22 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions16.setRenamingPolicy(variableRenamingPolicy21, propertyRenamingPolicy22);
        compilerOptions0.propertyRenaming = propertyRenamingPolicy22;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy21 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy21.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy22.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        compilerOptions10.instrumentationTemplate = "eof";
        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
        compiler9.initOptions(compilerOptions10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
        java.lang.String[] strArray37 = new java.lang.String[] { "TypeError: hi!", "eof", "or", "eof", "or", "hi!", "TypeError", "TypeError: hi!" };
        java.util.ArrayList<java.lang.String> strList38 = new java.util.ArrayList<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList38, strArray37);
        compilerOptions24.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
        boolean boolean41 = compilerOptions24.ideMode;
        compilerOptions24.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(region22);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = null;
        compilerOptions0.setCodingConvention(codingConvention7);
        boolean boolean9 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkProvides;
        compilerOptions0.exportTestFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getErrorMessage();
        int int4 = ecmaError1.lineNumber();
        int int5 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)", '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        compilerOptions0.setTweakToBooleanLiteral("eol", false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.optimizeReturns = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripNameSuffixes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy15 = compilerOptions13.anonymousFunctionNaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy16 = compilerOptions13.propertyRenaming;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy16;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy15 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy15.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy16.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        boolean boolean7 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean8 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str10 = node6.toString(true, false, true);
        com.google.javascript.rhino.Node node11 = node6.getFirstChild();
        com.google.javascript.rhino.Node node12 = node1.copyInformationFromForTree(node6);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node14.addChildrenToBack(node16);
        boolean boolean18 = node16.isLocalResultCall();
        int int19 = node16.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str26 = node22.toString(true, false, true);
        com.google.javascript.rhino.Node node27 = node22.getFirstChild();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node31.addChildrenToBack(node33);
        java.lang.Object obj36 = node33.getProp((int) (short) 100);
        java.lang.String str37 = node29.checkTreeEquals(node33);
        com.google.javascript.rhino.Node node38 = node22.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node42.addChildrenToBack(node44);
        java.lang.Object obj47 = node44.getProp((int) (short) 100);
        java.lang.String str48 = node40.checkTreeEquals(node44);
        node40.setLineno(47);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node54.addChildrenToBack(node56);
        java.lang.Object obj59 = node56.getProp((int) (short) 100);
        java.lang.String str60 = node52.checkTreeEquals(node56);
        int int61 = node52.getSourcePosition();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray64 = new com.google.javascript.rhino.Node[] { node38, node40, node52, node63 };
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(21, nodeArray64);
        com.google.javascript.rhino.Node node66 = node16.copyInformationFromForTree(node65);
        node65.setVarArgs(true);
        com.google.javascript.rhino.jstype.JSType jSType69 = node65.getJSType();
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        node71.setJSType(jSType72);
        boolean boolean74 = node71.isVarArgs();
        boolean boolean75 = node71.hasChildren();
        try {
            node1.replaceChild(node65, node71);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "EOF" + "'", str10.equals("EOF"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "EOF" + "'", str26.equals("EOF"));
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str37.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str48.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str60.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeArray64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("EOF [synthetic: 1]", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = compilerOptions0.propertyRenaming;
        compilerOptions0.ideMode = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.appNameStr;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeEmptyFunctions = true;
        compilerOptions9.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel15, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList30, jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean33 = compilerOptions32.checkControlStructures;
        compilerOptions32.setRemoveClosureAsserts(false);
        compilerOptions32.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result39 = compiler20.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList30, compilerOptions32);
        compilerOptions32.generatePseudoNames = false;
        boolean boolean42 = compilerOptions32.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions32.brokenClosureRequiresLevel;
        diagnosticType17.level = checkLevel43;
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions45.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions45.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions45.checkUndefinedProperties;
        diagnosticType17.level = checkLevel49;
        compilerOptions9.checkGlobalThisLevel = checkLevel49;
        compilerOptions0.setWarningLevel(diagnosticGroup8, checkLevel49);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup8;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNull(checkLevel18);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compilerOptions13.generatePseudoNames = false;
        boolean boolean23 = compilerOptions13.removeUnusedVars;
        boolean boolean24 = compilerOptions13.groupVariableDeclarations;
        java.util.Set<java.lang.String> strSet25 = compilerOptions13.stripNamePrefixes;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strSet25);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard4 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, false, false);
        boolean boolean6 = node1.isLocalResultCall();
        node1.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node10 = node1.getAncestor(37);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("eof");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine((int) (short) -1);
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
        java.lang.String str17 = jSSourceFile14.getName();
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23, false);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region31 = jSSourceFile29.getRegion(26);
        java.lang.String str32 = jSSourceFile29.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str36 = jSSourceFile35.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile20, jSSourceFile23, jSSourceFile29, jSSourceFile35 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40, false);
        java.lang.String str43 = jSSourceFile40.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40);
        java.lang.String str45 = compilerInput44.getName();
        java.io.PrintStream printStream46 = null;
        com.google.javascript.jscomp.Compiler compiler47 = new com.google.javascript.jscomp.Compiler(printStream46);
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.inlineConstantVars = false;
        compilerOptions48.instrumentationTemplate = "eof";
        boolean boolean53 = compilerOptions48.moveFunctionDeclarations;
        compiler47.initOptions(compilerOptions48);
        compilerInput44.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler47);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile58 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region60 = jSSourceFile58.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray61 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions62.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy65 = compilerOptions62.variableRenaming;
        com.google.javascript.jscomp.Result result66 = compiler47.compile(jSSourceFile58, jSModuleArray61, compilerOptions62);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions67.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler70 = null;
        compilerOptions67.setAliasTransformationHandler(aliasTransformationHandler70);
        com.google.javascript.jscomp.Result result72 = compiler8.compile(jSSourceFileArray37, jSModuleArray61, compilerOptions67);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker73 = compiler8.tracker;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromFile("EOF [synthetic: 1]");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile78 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput80 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile78, false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions81 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions81.removeEmptyFunctions = true;
        java.lang.String str84 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions81);
        java.lang.String str85 = compilerOptions81.jsOutputFile;
        com.google.javascript.jscomp.Result result86 = compiler8.compile(jSSourceFile75, jSSourceFile78, compilerOptions81);
        java.lang.String[] strArray87 = compiler8.toSourceArray();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler8);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNull(region31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(jSSourceFile58);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSModuleArray61);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy65 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy65.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result66);
        org.junit.Assert.assertNotNull(result72);
        org.junit.Assert.assertNull(performanceTracker73);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertNotNull(jSSourceFile78);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "" + "'", str85.equals(""));
        org.junit.Assert.assertNotNull(result86);
        org.junit.Assert.assertNotNull(strArray87);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        node1.removeProp(2);
        try {
            node1.setSideEffectFlags((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        com.google.javascript.rhino.Node node12 = node6.getAncestor(0);
        try {
            int int14 = node12.getExistingIntProp(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compilerOptions13.inferTypesInGlobalScope = false;
        compilerOptions13.removeEmptyFunctions = false;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt1);
        lightweightMessageFormatter2.setColorize(false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.closurePass = true;
        boolean boolean11 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.removeUnusedVars = true;
        compilerOptions21.setTweakToStringLiteral("hi!", "eof");
        boolean boolean39 = compilerOptions21.computeFunctionSideEffects;
        java.lang.String str40 = compilerOptions21.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions21.reportUnknownTypes;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkSymbols = false;
        boolean boolean7 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean8 = compilerOptions0.prettyPrint;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.inlineConstantVars = false;
        compilerOptions2.unaliasableGlobals = "";
        compilerOptions2.generatePseudoNames = false;
        boolean boolean9 = compilerOptions2.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions2.checkMissingReturn;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat15 = diagnosticType14.format;
        boolean boolean16 = diagnosticGroup12.matches(diagnosticType14);
        boolean boolean17 = diagnosticGroupWarningsGuard11.enables(diagnosticGroup12);
        java.lang.String str18 = diagnosticGroupWarningsGuard11.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(messageFormat15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DiagnosticGroup<uselessCode>(OFF)" + "'", str18.equals("DiagnosticGroup<uselessCode>(OFF)"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            com.google.javascript.rhino.Context.reportWarning("EOF\n", "com.google.javascript.rhino.EcmaError: TypeError: hi!", (int) (byte) 100, "com.google.javascript.rhino.EvaluatorException: goog.exportProperty", 44);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions0.getCodingConvention();
        compilerOptions0.gatherCssNames = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(codingConvention9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions8.aggressiveVarCheck;
        boolean boolean12 = compilerOptions8.checkUnusedPropertiesEarly;
        java.util.Set<java.lang.String> strSet13 = compilerOptions8.stripTypes;
        compilerOptions0.stripTypePrefixes = strSet13;
        boolean boolean15 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy18 = compilerOptions16.anonymousFunctionNaming;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy18;
        boolean boolean20 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy18 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy18.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        compilerOptions0.inlineLocalFunctions = false;
        java.lang.String[] strArray17 = new java.lang.String[] { "JSC_OPTIMIZE_LOOP_ERROR", "eol", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "EOF [synthetic: 1]", ": hi!", "Named type with empty name component", "goog.exportSymbol" };
        java.util.ArrayList<java.lang.String> strList18 = new java.util.ArrayList<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList18, strArray17);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList18);
        java.lang.String str21 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.sourceMapFormat = format2;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setLooseTypes(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap7 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap7;
        boolean boolean9 = compilerOptions0.ideMode;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        node8.setJSType(jSType9);
        boolean boolean11 = node8.isVarArgs();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node13.setJSType(jSType14);
        boolean boolean16 = node13.isVarArgs();
        boolean boolean17 = node8.hasChild(node13);
        com.google.javascript.rhino.Node node19 = node13.getAncestor(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean22 = closureCodingConvention20.isValidEnumKey("error reporter");
        java.lang.String str23 = closureCodingConvention20.getExportPropertyFunction();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        node25.setJSType(jSType26);
        boolean boolean28 = node25.isVarArgs();
        boolean boolean29 = closureCodingConvention20.isOptionalParameter(node25);
        boolean boolean31 = closureCodingConvention20.isExported("");
        boolean boolean34 = closureCodingConvention20.isExported("", true);
        com.google.javascript.rhino.Node node35 = null;
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str41 = closureCodingConvention20.extractClassNameIfProvide(node35, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        node44.setJSType(jSType45);
        int int47 = node44.getSideEffectFlags();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(43, node44, 140, 45);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention51 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean53 = closureCodingConvention51.isValidEnumKey("error reporter");
        java.lang.String str54 = closureCodingConvention51.getExportPropertyFunction();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        node56.setJSType(jSType57);
        boolean boolean59 = node56.isVarArgs();
        boolean boolean60 = closureCodingConvention51.isOptionalParameter(node56);
        boolean boolean62 = closureCodingConvention51.isExported("");
        boolean boolean65 = closureCodingConvention51.isExported("", true);
        com.google.javascript.rhino.Node node66 = null;
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str72 = closureCodingConvention51.extractClassNameIfProvide(node66, node71);
        com.google.javascript.rhino.Node node73 = node71.getFirstChild();
        java.lang.String str74 = closureCodingConvention20.extractClassNameIfRequire(node50, node71);
        java.lang.String str75 = closureCodingConvention0.extractClassNameIfRequire(node19, node50);
        com.google.javascript.rhino.Node node76 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship77 = closureCodingConvention0.getDelegateRelationship(node76);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.exportProperty" + "'", str23.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "goog.exportProperty" + "'", str54.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNull(node73);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(delegateRelationship77);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context0.setLocale(locale3);
//        boolean boolean5 = context0.isGeneratingDebug();
//        boolean boolean6 = context0.isGeneratingDebugChanged();
//        java.lang.Object obj7 = context0.getDebuggerContextData();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(obj7);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        java.io.PrintStream printStream3 = null;
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler(printStream3);
        java.lang.String str5 = compiler4.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
        java.lang.String str16 = jSSourceFile13.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        java.lang.String str18 = compilerInput17.getName();
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        compilerOptions21.instrumentationTemplate = "eof";
        boolean boolean26 = compilerOptions21.moveFunctionDeclarations;
        compiler20.initOptions(compilerOptions21);
        compilerInput17.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler20);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region33 = jSSourceFile31.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray34 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy38 = compilerOptions35.variableRenaming;
        com.google.javascript.jscomp.Result result39 = compiler20.compile(jSSourceFile31, jSModuleArray34, compilerOptions35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy43 = null;
        compilerOptions40.variableRenaming = variableRenamingPolicy43;
        java.util.Set<java.lang.String> strSet45 = compilerOptions40.stripNameSuffixes;
        boolean boolean46 = compilerOptions40.labelRenaming;
        com.google.javascript.jscomp.Result result47 = compiler4.compile(jSSourceFile8, jSModuleArray34, compilerOptions40);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter48 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node51.addChildrenToBack(node53);
        java.lang.Object obj56 = node53.getProp((int) (short) 100);
        int int58 = node53.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat60 = diagnosticType59.format;
        java.lang.String[] strArray66 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError67 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node53, diagnosticType59, strArray66);
        java.lang.String str68 = lightweightMessageFormatter48.formatError(jSError67);
        boolean boolean69 = diagnosticGroup0.matches(jSError67);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNull(region33);
        org.junit.Assert.assertNotNull(jSModuleArray34);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy38 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy38.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(strSet45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(result47);
        org.junit.Assert.assertNull(obj56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(messageFormat60);
        org.junit.Assert.assertNotNull(strArray66);
        org.junit.Assert.assertNotNull(jSError67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str68.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        java.lang.Object obj7 = node4.getProp((int) (short) 100);
        int int9 = node4.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node4, diagnosticType10, strArray17);
        int int19 = node4.getChildCount();
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("", "hi!", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 0);
        compilerOptions0.closurePass = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean12 = compilerOptions0.prettyPrint;
        boolean boolean13 = compilerOptions0.rewriteFunctionExpressions;
        boolean boolean14 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.setManageClosureDependencies(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkMethods;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        compilerOptions0.setPropertyAffinity(true);
        compilerOptions0.locale = "eof";
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap10 = compilerOptions0.customPasses;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap10);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context0.setLocale(locale3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context0.getErrorReporter();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.checkControlStructures;
//        compilerOptions6.setRemoveClosureAsserts(false);
//        compilerOptions6.setTweakToBooleanLiteral("", false);
//        java.lang.String str13 = compilerOptions6.appNameStr;
//        compilerOptions6.skipAllCompilerPasses();
//        boolean boolean15 = compilerOptions6.inlineFunctions;
//        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions6.checkShadowVars;
//        java.lang.Object obj17 = null;
//        try {
//            context0.putThreadLocal((java.lang.Object) checkLevel16, obj17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertNull(errorReporter5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compilerOptions13.generatePseudoNames = false;
        boolean boolean23 = compilerOptions13.removeUnusedVars;
        boolean boolean24 = compilerOptions13.prettyPrint;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getErrorMessage();
        int int3 = ecmaError1.getColumnNumber();
        java.lang.String str4 = ecmaError1.getSourceName();
        java.lang.String str5 = ecmaError1.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context0.setLocale(locale3);
//        context0.setCompileFunctionsWithDynamicScope(false);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(locale4);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node4.addChildrenToBack(node6);
//        java.lang.Object obj9 = node6.getProp((int) (short) 100);
//        java.lang.String str10 = node2.checkTreeEquals(node6);
//        node6.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = node6.getJSDocInfo();
//        context0.removeThreadLocal((java.lang.Object) node6);
//        boolean boolean15 = node6.isVarArgs();
//        com.google.javascript.rhino.Node node16 = null;
//        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node18.addChildrenToBack(node20);
//        boolean boolean22 = node20.isLocalResultCall();
//        try {
//            node6.replaceChild(node16, node20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str10.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy5, propertyRenamingPolicy6);
        compilerOptions0.ignoreCajaProperties = false;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.aliasableStrings;
        boolean boolean11 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        jSModuleGraph2.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph2.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setShadowVariables(false);
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        boolean boolean13 = closureCodingConvention0.isConstant("error reporter");
        java.lang.String str14 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) "error reporter");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "error reporter" + "'", str14.equals("error reporter"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setColorizeErrorOutput(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        compilerOptions0.setPropertyAffinity(true);
        boolean boolean8 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean9 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        boolean boolean6 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.checkControlStructures;
        compilerOptions7.setRemoveClosureAsserts(false);
        compilerOptions7.setTweakToBooleanLiteral("", false);
        java.lang.String str14 = compilerOptions7.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode15 = compilerOptions7.tracer;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = null;
        compilerOptions16.variableRenaming = variableRenamingPolicy19;
        java.util.Set<java.lang.String> strSet21 = compilerOptions16.stripNameSuffixes;
        compilerOptions16.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet24 = compilerOptions16.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions16.checkShadowVars;
        compilerOptions7.checkUnreachableCode = checkLevel25;
        compilerOptions0.checkGlobalThisLevel = checkLevel25;
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + tracerMode15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode15.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.appNameStr = "hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.inlineLocalVariables;
        boolean boolean7 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(cssRenamingMap8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7, false);
        java.lang.String str10 = jSSourceFile7.getName();
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16, false);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region24 = jSSourceFile22.getRegion(26);
        java.lang.String str25 = jSSourceFile22.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str29 = jSSourceFile28.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile13, jSSourceFile16, jSSourceFile22, jSSourceFile28 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33, false);
        java.lang.String str36 = jSSourceFile33.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        java.lang.String str38 = compilerInput37.getName();
        java.io.PrintStream printStream39 = null;
        com.google.javascript.jscomp.Compiler compiler40 = new com.google.javascript.jscomp.Compiler(printStream39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.inlineConstantVars = false;
        compilerOptions41.instrumentationTemplate = "eof";
        boolean boolean46 = compilerOptions41.moveFunctionDeclarations;
        compiler40.initOptions(compilerOptions41);
        compilerInput37.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler40);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region53 = jSSourceFile51.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray54 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions55.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy58 = compilerOptions55.variableRenaming;
        com.google.javascript.jscomp.Result result59 = compiler40.compile(jSSourceFile51, jSModuleArray54, compilerOptions55);
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler63 = null;
        compilerOptions60.setAliasTransformationHandler(aliasTransformationHandler63);
        com.google.javascript.jscomp.Result result65 = compiler1.compile(jSSourceFileArray30, jSModuleArray54, compilerOptions60);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = compiler1.tracker;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromFile("EOF [synthetic: 1]");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile71 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput73 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile71, false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions74.removeEmptyFunctions = true;
        java.lang.String str77 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions74);
        java.lang.String str78 = compilerOptions74.jsOutputFile;
        com.google.javascript.jscomp.Result result79 = compiler1.compile(jSSourceFile68, jSSourceFile71, compilerOptions74);
        java.lang.String[] strArray80 = compiler1.toSourceArray();
        java.io.PrintStream printStream81 = null;
        com.google.javascript.jscomp.Compiler compiler82 = new com.google.javascript.jscomp.Compiler(printStream81);
        com.google.javascript.jscomp.CompilerOptions compilerOptions83 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions83.inlineConstantVars = false;
        compilerOptions83.instrumentationTemplate = "eof";
        boolean boolean88 = compilerOptions83.moveFunctionDeclarations;
        compiler82.initOptions(compilerOptions83);
        com.google.javascript.jscomp.ErrorManager errorManager90 = compiler82.getErrorManager();
        compiler1.setErrorManager(errorManager90);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNull(region53);
        org.junit.Assert.assertNotNull(jSModuleArray54);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy58 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy58.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(result65);
        org.junit.Assert.assertNull(performanceTracker66);
        org.junit.Assert.assertNotNull(jSSourceFile68);
        org.junit.Assert.assertNotNull(jSSourceFile71);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "" + "'", str78.equals(""));
        org.junit.Assert.assertNotNull(result79);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(errorManager90);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.setDefineToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: hi!", (double) 'a');
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.removeEmptyFunctions = true;
        java.lang.String str13 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions10);
        boolean boolean14 = compilerOptions10.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel16, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.defaultLevel;
        java.io.PrintStream printStream20 = null;
        com.google.javascript.jscomp.Compiler compiler21 = new com.google.javascript.jscomp.Compiler(printStream20);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile24, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList28 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList28, jSSourceFileArray27);
        com.google.javascript.jscomp.JSModule[] jSModuleArray30 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList31 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList31, jSModuleArray30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean34 = compilerOptions33.checkControlStructures;
        compilerOptions33.setRemoveClosureAsserts(false);
        compilerOptions33.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result40 = compiler21.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList28, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList31, compilerOptions33);
        compilerOptions33.generatePseudoNames = false;
        boolean boolean43 = compilerOptions33.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions33.brokenClosureRequiresLevel;
        diagnosticType18.level = checkLevel44;
        compilerOptions10.checkGlobalThisLevel = checkLevel44;
        compilerOptions0.checkMethods = checkLevel44;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNull(checkLevel19);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFileArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSModuleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(result40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        boolean boolean13 = closureCodingConvention0.isPrivate("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        int int6 = node1.getSourcePosition();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getExportPropertyFunction();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = closureCodingConvention7.isOptionalParameter(node12);
        boolean boolean18 = closureCodingConvention7.isExported("");
        boolean boolean21 = closureCodingConvention7.isExported("", true);
        com.google.javascript.rhino.Node node22 = null;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str28 = closureCodingConvention7.extractClassNameIfProvide(node22, node27);
        boolean boolean30 = closureCodingConvention7.isConstantKey("goog.exportSymbol");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention31 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean33 = closureCodingConvention31.isValidEnumKey("error reporter");
        java.lang.String str34 = closureCodingConvention31.getExportPropertyFunction();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        node36.setJSType(jSType37);
        boolean boolean39 = node36.isVarArgs();
        boolean boolean40 = closureCodingConvention31.isOptionalParameter(node36);
        boolean boolean42 = closureCodingConvention31.isExported("");
        boolean boolean45 = closureCodingConvention31.isExported("", true);
        com.google.javascript.rhino.Node node46 = null;
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str52 = closureCodingConvention31.extractClassNameIfProvide(node46, node51);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str58 = node54.toString(false, true, false);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        node60.setJSType(jSType61);
        boolean boolean63 = node60.isVarArgs();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        node65.setJSType(jSType66);
        boolean boolean68 = node65.isVarArgs();
        boolean boolean69 = node60.hasChild(node65);
        node60.removeProp(2);
        node54.addChildToFront(node60);
        boolean boolean73 = closureCodingConvention31.isOptionalParameter(node54);
        java.lang.String str74 = closureCodingConvention7.getSingletonGetterClassName(node54);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention75 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean77 = closureCodingConvention75.isValidEnumKey("error reporter");
        boolean boolean79 = closureCodingConvention75.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType80 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType81 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType82 = null;
        closureCodingConvention75.applySubclassRelationship(functionType80, functionType81, subclassType82);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean88 = closureCodingConvention75.isVarArgsParameter(node87);
        boolean boolean89 = closureCodingConvention7.isOptionalParameter(node87);
        boolean boolean90 = node1.isEquivalentTo(node87);
        com.google.javascript.rhino.Node node91 = node87.cloneNode();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "goog.exportProperty" + "'", str34.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "EOF" + "'", str58.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(node91);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        boolean boolean4 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        com.google.javascript.rhino.Node node20 = node1.getLastChild();
        boolean boolean21 = node20.isQuotedString();
        try {
            com.google.javascript.rhino.Node node23 = node20.getChildAtIndex(21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        compilerInput6.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.gatherCssNames;
        boolean boolean5 = compilerOptions0.tightenTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler9 = null;
        compilerOptions6.setAliasTransformationHandler(aliasTransformationHandler9);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions6.setRenamingPolicy(variableRenamingPolicy11, propertyRenamingPolicy12);
        compilerOptions0.variableRenaming = variableRenamingPolicy11;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy11.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy12.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.setPropertyAffinity(false);
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) -1, (byte) 100, (byte) 1, (byte) 0 };
        compilerOptions21.inputVariableMapSerialized = byteArray41;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions21.reportUnknownTypes;
        compilerOptions21.disambiguateProperties = false;
        boolean boolean46 = compilerOptions21.convertToDottedProperties;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        java.lang.Object obj9 = null;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, obj9);
        boolean boolean11 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker22 = null;
        compiler1.tracker = performanceTracker22;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions1.variableRenaming = variableRenamingPolicy4;
        java.util.Set<java.lang.String> strSet6 = compilerOptions1.stripNameSuffixes;
        compilerOptions1.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet9 = compilerOptions1.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions1.checkShadowVars;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.make("()", checkLevel10, "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = null;
        try {
            int int14 = diagnosticType12.compareTo(diagnosticType13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportSymbol", "or");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.setPropertyAffinity(false);
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) -1, (byte) 100, (byte) 1, (byte) 0 };
        compilerOptions21.inputVariableMapSerialized = byteArray41;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions21.reportUnknownTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = null;
        compilerOptions21.checkShadowVars = checkLevel44;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0(": hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property : hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean11 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        node15.setJSType(jSType16);
        int int18 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node22.setType(11);
        java.lang.String str25 = closureCodingConvention0.extractClassNameIfProvide(node15, node22);
        boolean boolean27 = closureCodingConvention0.isExported("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isSuperClassReference("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType5, functionType6, objectType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setChainCalls(true);
        compilerOptions0.syntheticBlockStartMarker = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        boolean boolean7 = compilerOptions0.disambiguateProperties;
        boolean boolean8 = compilerOptions0.aliasExternals;
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        java.lang.String[] strArray25 = new java.lang.String[] { "EOF", "TypeError: hi!", "goog.abstractMethod", "goog.global", "com.google.javascript.rhino.EcmaError: TypeError: hi!", "or", "name", "goog.abstractMethod", "", "hi!", "goog.abstractMethod", "goog.abstractMethod", "hi!" };
        java.util.ArrayList<java.lang.String> strList26 = new java.util.ArrayList<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList26, strArray25);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList26);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("EOF");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean14 = closureCodingConvention0.isConstantKey("Named type with empty name component");
        com.google.javascript.rhino.Node node15 = null;
        boolean boolean16 = closureCodingConvention0.isOptionalParameter(node15);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node18.setJSType(jSType19);
        boolean boolean21 = node18.isVarArgs();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        node23.setJSType(jSType24);
        boolean boolean26 = node23.isVarArgs();
        boolean boolean27 = node18.hasChild(node23);
        boolean boolean28 = node23.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.checkControlStructures;
        compilerOptions29.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy33 = compilerOptions29.anonymousFunctionNaming;
        boolean boolean34 = compilerOptions29.checkUnusedPropertiesEarly;
        compilerOptions29.collapseProperties = true;
        compilerOptions29.aliasStringsBlacklist = "EOF";
        boolean boolean39 = compilerOptions29.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler40 = compilerOptions29.getAliasTransformationHandler();
        java.lang.RuntimeException runtimeException41 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) node15, (java.lang.Object) boolean28, (java.lang.Object) compilerOptions29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy33 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy33.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler40);
        org.junit.Assert.assertNotNull(runtimeException41);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.appNameStr = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = compilerOptions0.variableRenaming;
        boolean boolean6 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        try {
//            com.google.javascript.rhino.Context.reportError("COLONCOLON", "", 4095, "", 4095);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: COLONCOLON (#4095)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.inlineConstantVars = false;
        compilerOptions3.instrumentationTemplate = "eof";
        boolean boolean8 = compilerOptions3.moveFunctionDeclarations;
        compiler2.initOptions(compilerOptions3);
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str15 = jSSourceFile14.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str25 = jSSourceFile24.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str29 = jSSourceFile28.getOriginalPath();
        java.lang.String str31 = jSSourceFile28.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.global");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str37 = jSSourceFile36.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str41 = jSSourceFile40.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
        java.lang.String str47 = jSSourceFile44.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str51 = jSSourceFile50.getOriginalPath();
        java.lang.String str53 = jSSourceFile50.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str57 = jSSourceFile56.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput62 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60, false);
        com.google.javascript.jscomp.CompilerInput compilerInput63 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray64 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14, jSSourceFile18, jSSourceFile21, jSSourceFile24, jSSourceFile28, jSSourceFile33, jSSourceFile36, jSSourceFile40, jSSourceFile44, jSSourceFile50, jSSourceFile56, jSSourceFile60 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList65, jSSourceFileArray64);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str70 = jSSourceFile69.getOriginalPath();
        java.lang.String str72 = jSSourceFile69.getLine(0);
        java.nio.charset.Charset charset74 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset74);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray76 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile69, jSSourceFile75 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList77 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList77, jSSourceFileArray76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions79.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler82 = null;
        compilerOptions79.setAliasTransformationHandler(aliasTransformationHandler82);
        com.google.javascript.jscomp.CheckLevel checkLevel84 = compilerOptions79.checkMethods;
        compiler2.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList65, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList77, compilerOptions79);
        try {
            compiler2.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(messageFormatter11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSSourceFileArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(jSSourceFile69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertNotNull(jSSourceFileArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + checkLevel84 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel84.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler2.tracker = performanceTracker3;
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = compiler2.getErrors();
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            java.lang.String[] strArray7 = compiler2.toSourceArray(jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkProvides;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.strictMessageReplacement = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        compilerOptions0.reserveRawExports = true;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray7 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList8 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8, warningsGuardArray7);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        java.lang.String str14 = compiler13.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22, false);
        java.lang.String str25 = jSSourceFile22.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22);
        java.lang.String str27 = compilerInput26.getName();
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.inlineConstantVars = false;
        compilerOptions30.instrumentationTemplate = "eof";
        boolean boolean35 = compilerOptions30.moveFunctionDeclarations;
        compiler29.initOptions(compilerOptions30);
        compilerInput26.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region42 = jSSourceFile40.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray43 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy47 = compilerOptions44.variableRenaming;
        com.google.javascript.jscomp.Result result48 = compiler29.compile(jSSourceFile40, jSModuleArray43, compilerOptions44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions49.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy52 = null;
        compilerOptions49.variableRenaming = variableRenamingPolicy52;
        java.util.Set<java.lang.String> strSet54 = compilerOptions49.stripNameSuffixes;
        boolean boolean55 = compilerOptions49.labelRenaming;
        com.google.javascript.jscomp.Result result56 = compiler13.compile(jSSourceFile17, jSModuleArray43, compilerOptions49);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter57 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node60.addChildrenToBack(node62);
        java.lang.Object obj65 = node62.getProp((int) (short) 100);
        int int67 = node62.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat69 = diagnosticType68.format;
        java.lang.String[] strArray75 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node62, diagnosticType68, strArray75);
        java.lang.String str77 = lightweightMessageFormatter57.formatError(jSError76);
        java.lang.String str78 = jSError76.description;
        com.google.javascript.jscomp.CheckLevel checkLevel79 = composeWarningsGuard10.level(jSError76);
        org.junit.Assert.assertNotNull(warningsGuardArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNull(region42);
        org.junit.Assert.assertNotNull(jSModuleArray43);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy47 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy47.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result48);
        org.junit.Assert.assertNotNull(strSet54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(result56);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(diagnosticType68);
        org.junit.Assert.assertNotNull(messageFormat69);
        org.junit.Assert.assertNotNull(strArray75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str77.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Exceeded max number of optimization iterations: TypeError: hi!" + "'", str78.equals("Exceeded max number of optimization iterations: TypeError: hi!"));
        org.junit.Assert.assertNull(checkLevel79);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        java.lang.String str7 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions8);
        boolean boolean11 = compilerOptions8.shouldColorizeErrorOutput();
        compilerOptions8.setShadowVariables(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap14 = compilerOptions8.cssRenamingMap;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        compilerOptions8.errorFormat = errorFormat15;
        compilerOptions0.errorFormat = errorFormat15;
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(cssRenamingMap14);
        org.junit.Assert.assertNotNull(errorFormat15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.rhino.Node node14 = null;
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int18 = node16.getIntProp(2);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean24 = node23.isOptionalArg();
        boolean boolean25 = node23.isLocalResultCall();
        boolean boolean26 = node16.isEquivalentToTyped(node23);
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfProvide(node14, node16);
        try {
            node16.setString("EOF\n");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.inlineConstantVars = false;
        compilerOptions2.unaliasableGlobals = "";
        compilerOptions2.generatePseudoNames = false;
        boolean boolean9 = compilerOptions2.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions2.checkMissingReturn;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup16;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray18 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup13, diagnosticGroup14, diagnosticGroup16 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = new com.google.javascript.jscomp.DiagnosticGroup("", diagnosticGroupArray18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray18);
        boolean boolean21 = diagnosticGroupWarningsGuard11.enables(diagnosticGroup20);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup13);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroup16);
        org.junit.Assert.assertNotNull(diagnosticGroupArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 8);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions6);
//        boolean boolean9 = compilerOptions6.shouldColorizeErrorOutput();
//        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
//        compilerOptions6.errorFormat = errorFormat10;
//        java.lang.String str12 = compilerOptions6.syntheticBlockStartMarker;
//        boolean boolean13 = compilerOptions6.flowSensitiveInlineVariables;
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean16 = closureCodingConvention14.isValidEnumKey("error reporter");
//        boolean boolean18 = closureCodingConvention14.isPrivate("eof");
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType21 = null;
//        closureCodingConvention14.applySubclassRelationship(functionType19, functionType20, subclassType21);
//        boolean boolean25 = closureCodingConvention14.isExported("goog.abstractMethod", true);
//        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection26 = closureCodingConvention14.getAssertionFunctions();
//        java.lang.String str27 = closureCodingConvention14.getExportSymbolFunction();
//        context0.putThreadLocal((java.lang.Object) boolean13, (java.lang.Object) str27);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(errorFormat10);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportSymbol" + "'", str27.equals("goog.exportSymbol"));
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.MessageBundle messageBundle3 = compilerOptions0.messageBundle;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertNull(messageBundle3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("<unknown=160>", "goog.global");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.setPropertyAffinity(false);
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) -1, (byte) 100, (byte) 1, (byte) 0 };
        compilerOptions21.inputVariableMapSerialized = byteArray41;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions21.reportUnknownTypes;
        compilerOptions21.disambiguateProperties = false;
        boolean boolean46 = compilerOptions21.moveFunctionDeclarations;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setThrows();
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        boolean boolean6 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        java.lang.Object obj6 = node3.getProp((int) (short) 100);
        node3.setType((int) ' ');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str16 = node12.toString(true, false, true);
        int int17 = node12.getSourcePosition();
        node12.setIsSyntheticBlock(true);
        node3.addChildAfter(node10, node12);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node10.children();
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EOF" + "'", str16.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(nodeIterable21);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        compilerOptions0.checkTypedPropertyCalls = true;
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.sourceMapFormat = format2;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseVariableDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.lang.String str9 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str10 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.exportProperty" + "'", str9.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        compilerInput4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.lineLengthThreshold(0);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode11 = compilerOptions0.tracer;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkShadowVars;
        boolean boolean13 = compilerOptions0.smartNameRemoval;
        compilerOptions0.inlineGetters = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode11.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.Region region13 = compiler9.getSourceRegion("DiagnosticGroup<uselessCode>(OFF)", 0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(region13);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setGenerateExports(true);
        boolean boolean7 = compilerOptions0.generateExports;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.checkTypes = false;
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean11 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean4 = compilerOptions0.checkUnusedPropertiesEarly;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.labelRenaming = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy5, propertyRenamingPolicy6);
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.collapseProperties = true;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, false, false);
        node1.detachChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node1.getJsDocBuilderForNode();
        fileLevelJsDocBuilder7.append("eol");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
//        context0.removeThreadLocal((java.lang.Object) node3);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean7 = closureCodingConvention5.isValidEnumKey("error reporter");
//        boolean boolean9 = closureCodingConvention5.isPrivate("eof");
//        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType12 = null;
//        closureCodingConvention5.applySubclassRelationship(functionType10, functionType11, subclassType12);
//        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
//        boolean boolean18 = closureCodingConvention5.isVarArgsParameter(node17);
//        com.google.javascript.rhino.Node node19 = null;
//        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        int int23 = node21.getIntProp(2);
//        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
//        boolean boolean29 = node28.isOptionalArg();
//        boolean boolean30 = node28.isLocalResultCall();
//        boolean boolean31 = node21.isEquivalentToTyped(node28);
//        java.lang.String str32 = closureCodingConvention5.extractClassNameIfProvide(node19, node21);
//        com.google.javascript.rhino.Context context33 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node37.addChildrenToBack(node39);
//        java.lang.Object obj42 = node39.getProp((int) (short) 100);
//        java.lang.String str43 = node35.checkTreeEquals(node39);
//        node39.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = node39.getJSDocInfo();
//        context33.removeThreadLocal((java.lang.Object) node39);
//        java.lang.String str48 = closureCodingConvention5.identifyTypeDefAssign(node39);
//        boolean boolean49 = node3.isEquivalentTo(node39);
//        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node3.addChildrenToBack(node51);
//        try {
//            com.google.javascript.rhino.Node node54 = node51.getAncestor((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(node3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(context33);
//        org.junit.Assert.assertNotNull(node35);
//        org.junit.Assert.assertNull(obj42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str43.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo46);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context0.setLocale(locale3);
//        java.lang.Object obj5 = null;
//        context0.seal(obj5);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(locale4);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.checkControlStructures;
        compilerOptions6.setCollapsePropertiesOnExternTypes(true);
        compilerOptions6.checkSuspiciousCode = true;
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) -1, (byte) -1 };
        compilerOptions6.inputPropertyMapSerialized = byteArray15;
        compilerOptions0.inputPropertyMapSerialized = byteArray15;
        compilerOptions0.disambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setThrows();
        int int5 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setThrows();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 21 + "'", int5 == 21);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        compilerOptions0.optimizeParameters = true;
        compilerOptions0.checkTypedPropertyCalls = true;
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.MessageBundle messageBundle3 = compilerOptions0.messageBundle;
        boolean boolean4 = compilerOptions0.optimizeArgumentsArray;
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.checkControlStructures;
        compilerOptions18.setRemoveClosureAsserts(false);
        compilerOptions18.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result25 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions18);
        compilerOptions18.generatePseudoNames = false;
        boolean boolean28 = compilerOptions18.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions18.brokenClosureRequiresLevel;
        compilerOptions18.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions32.aggressiveVarCheck;
        compilerOptions18.checkUndefinedProperties = checkLevel35;
        compilerOptions0.aggressiveVarCheck = checkLevel35;
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.inlineLocalVariables = false;
        org.junit.Assert.assertNull(messageBundle3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(result25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.enableExternExports(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        boolean boolean3 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        boolean boolean20 = node7.isSyntheticBlock();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node22.addChildrenToBack(node24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        node24.setJSType(jSType26);
        try {
            node7.addChildrenToBack(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        java.lang.Object obj7 = node4.getProp((int) (short) 100);
        int int9 = node4.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node4, diagnosticType10, strArray17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = null;
        compilerOptions19.variableRenaming = variableRenamingPolicy22;
        java.util.Set<java.lang.String> strSet24 = compilerOptions19.stripNameSuffixes;
        boolean boolean25 = compilerOptions19.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        compilerOptions19.reportMissingOverride = checkLevel26;
        boolean boolean28 = jSError18.equals((java.lang.Object) compilerOptions19);
        int int29 = jSError18.getCharno();
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportProperty");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str13 = node9.toString(true, false, true);
        com.google.javascript.rhino.Node node14 = node9.getFirstChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node18.addChildrenToBack(node20);
        java.lang.Object obj23 = node20.getProp((int) (short) 100);
        java.lang.String str24 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node25 = node9.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        node27.setLineno(47);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        int int48 = node39.getSourcePosition();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node25, node27, node39, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(21, nodeArray51);
        com.google.javascript.rhino.Node node53 = node3.copyInformationFromForTree(node52);
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean56 = compilerOptions55.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig57 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions55);
        boolean boolean58 = compilerOptions55.convertToDottedProperties;
        compilerOptions55.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy61 = compilerOptions55.propertyRenaming;
        node3.putProp(0, (java.lang.Object) propertyRenamingPolicy61);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF" + "'", str13.equals("EOF"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy61 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy61.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        int int5 = context0.getOptimizationLevel();
//        try {
//            context0.setLanguageVersion((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 32");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.smartNameRemoval;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.checkControlStructures;
        compilerOptions5.setRemoveClosureAsserts(false);
        compilerOptions5.setTweakToBooleanLiteral("", false);
        java.lang.String str12 = compilerOptions5.instrumentationTemplate;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = compilerOptions5.variableRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy16 = compilerOptions14.anonymousFunctionNaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = compilerOptions14.propertyRenaming;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy13, propertyRenamingPolicy17);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy16 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy16.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str5 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str6 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str7 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportSymbol" + "'", str7.equals("goog.exportSymbol"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("EOF [synthetic: 1]", 22);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("EOF\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(EOF\n)" + "'", str1.equals("(EOF\n)"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 0);
        boolean boolean2 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str17 = node13.toString(true, false, true);
        com.google.javascript.rhino.Node node18 = node13.getFirstChild();
        com.google.javascript.rhino.Node node19 = node8.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable20 = node13.getAncestors();
        try {
            com.google.javascript.rhino.Node node21 = node6.getChildBefore(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "EOF" + "'", str17.equals("EOF"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(ancestorIterable20);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean7 = node6.isOptionalArg();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node9.addChildrenToBack(node11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str18 = node14.toString(true, false, true);
        com.google.javascript.rhino.Node node19 = node14.getFirstChild();
        com.google.javascript.rhino.Node node20 = node9.copyInformationFromForTree(node14);
        boolean boolean21 = node9.isOptionalArg();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        node23.setJSType(jSType24);
        boolean boolean26 = node23.isVarArgs();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        node28.setJSType(jSType29);
        boolean boolean31 = node28.isVarArgs();
        boolean boolean32 = node23.hasChild(node28);
        boolean boolean33 = node28.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node6, node9, node28 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(29, nodeArray34, (int) '#', 19);
        try {
            com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) 1, nodeArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EOF" + "'", str18.equals("EOF"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.setPropertyAffinity(false);
        compilerOptions21.checkControlStructures = false;
        boolean boolean38 = compilerOptions21.deadAssignmentElimination;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig11 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions9);
        compilerOptions9.reportPath = "error reporter";
        compilerOptions9.setLooseTypes(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean18 = closureCodingConvention16.isValidEnumKey("error reporter");
        java.lang.String str19 = closureCodingConvention16.getAbstractMethodName();
        java.lang.String str20 = closureCodingConvention16.getExportPropertyFunction();
        boolean boolean22 = closureCodingConvention16.isConstant("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention16.applySubclassRelationship(functionType23, functionType24, subclassType25);
        compilerOptions9.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention16);
        boolean boolean28 = compilerOptions9.labelRenaming;
        java.lang.RuntimeException runtimeException29 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) boolean8, (java.lang.Object) compilerOptions9);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "goog.abstractMethod" + "'", str19.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportProperty" + "'", str20.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(runtimeException29);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions0.getCodingConvention();
        compilerOptions0.sourceMapOutputPath = "name";
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(codingConvention9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str6 = node2.toString(true, false, true);
        com.google.javascript.rhino.Node node7 = node2.getFirstChild();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node11.addChildrenToBack(node13);
        java.lang.Object obj16 = node13.getProp((int) (short) 100);
        java.lang.String str17 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node18 = node2.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node22.addChildrenToBack(node24);
        java.lang.Object obj27 = node24.getProp((int) (short) 100);
        java.lang.String str28 = node20.checkTreeEquals(node24);
        node20.setLineno(47);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node34.addChildrenToBack(node36);
        java.lang.Object obj39 = node36.getProp((int) (short) 100);
        java.lang.String str40 = node32.checkTreeEquals(node36);
        int int41 = node32.getSourcePosition();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node18, node20, node32, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(21, nodeArray44);
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = node45.getJSDocInfo();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable49 = node48.getAncestors();
        java.lang.String str50 = node45.checkTreeEquals(node48);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EOF" + "'", str6.equals("EOF"));
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str17.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str28.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str40.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNull(jSDocInfo46);
        org.junit.Assert.assertNotNull(ancestorIterable49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Node tree inequality:\nTree1:\nADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nTree2:\nEOF\n\n\nSubtree1: ADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nSubtree2: EOF\n" + "'", str50.equals("Node tree inequality:\nTree1:\nADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nTree2:\nEOF\n\n\nSubtree1: ADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nSubtree2: EOF\n"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        compilerInput4.clearAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, false);
        try {
            java.lang.String str11 = compilerInput10.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        node3.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getExportPropertyFunction();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = closureCodingConvention7.isOptionalParameter(node12);
        boolean boolean18 = closureCodingConvention7.isExported("");
        boolean boolean21 = closureCodingConvention7.isExported("", true);
        com.google.javascript.rhino.Node node22 = null;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str28 = closureCodingConvention7.extractClassNameIfProvide(node22, node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node33 = node27.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node34 = node33.removeFirstChild();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        boolean boolean37 = node36.isVarArgs();
        try {
            node3.addChildBefore(node34, node36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        compilerOptions0.debugFunctionSideEffectsPath = "";
        boolean boolean7 = compilerOptions0.optimizeReturns;
        boolean boolean8 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = compilerOptions0.getCodingConvention();
        compilerOptions0.groupVariableDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(codingConvention10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        java.lang.String str7 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions8);
        boolean boolean11 = compilerOptions8.shouldColorizeErrorOutput();
        compilerOptions8.setShadowVariables(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap14 = compilerOptions8.cssRenamingMap;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        compilerOptions8.errorFormat = errorFormat15;
        compilerOptions0.errorFormat = errorFormat15;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(cssRenamingMap14);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Node tree inequality:\\nTree1:\\nNUMBER -1.0\\n\\n\\nTree2:\\nEOF\\n\\n\\nSubtree1: NUMBER -1.0\\n\\n\\nSubtree2: EOF\\n" + "'", str1.equals("Node tree inequality:\\nTree1:\\nNUMBER -1.0\\n\\n\\nTree2:\\nEOF\\n\\n\\nSubtree1: NUMBER -1.0\\n\\n\\nSubtree2: EOF\\n"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel6, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.checkControlStructures;
        compilerOptions23.setRemoveClosureAsserts(false);
        compilerOptions23.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result30 = compiler11.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        compilerOptions23.generatePseudoNames = false;
        boolean boolean33 = compilerOptions23.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions23.brokenClosureRequiresLevel;
        diagnosticType8.level = checkLevel34;
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions36.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions36.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions36.checkUndefinedProperties;
        diagnosticType8.level = checkLevel40;
        compilerOptions0.checkGlobalThisLevel = checkLevel40;
        compilerOptions0.jsOutputFile = "com.google.javascript.rhino.EcmaError: TypeError: hi!";
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        compiler1.parse();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy5, propertyRenamingPolicy6);
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getExportPropertyFunction();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = closureCodingConvention7.isOptionalParameter(node12);
        boolean boolean18 = closureCodingConvention7.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType21 = null;
        closureCodingConvention7.applySubclassRelationship(functionType19, functionType20, subclassType21);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        node24.setJSType(jSType25);
        boolean boolean27 = node24.isVarArgs();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node29.setJSType(jSType30);
        boolean boolean32 = node29.isVarArgs();
        boolean boolean33 = node24.hasChild(node29);
        node24.removeProp(2);
        node24.setIsSyntheticBlock(false);
        java.lang.String str38 = closureCodingConvention7.identifyTypeDefAssign(node24);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(16, node5, node24, 130, 6);
        boolean boolean42 = node41.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.nameReferenceGraphPath = "hi!";
        java.lang.String str10 = compilerOptions7.instrumentationTemplate;
        compilerOptions7.labelRenaming = false;
        java.util.Set<java.lang.String> strSet13 = compilerOptions7.stripNamePrefixes;
        compilerOptions0.stripTypes = strSet13;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler18 = null;
        compilerOptions15.setAliasTransformationHandler(aliasTransformationHandler18);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.checkMethods;
        compilerOptions0.checkMethods = checkLevel20;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compiler1.disableThreads();
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("eof");
        boolean boolean7 = closureCodingConvention0.isSuperClassReference("TypeError: hi!");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node9.setJSType(jSType10);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node9.setJSType(jSType12);
        boolean boolean14 = closureCodingConvention0.isOptionalParameter(node9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean17 = closureCodingConvention15.isValidEnumKey("error reporter");
        java.lang.String str18 = closureCodingConvention15.getAbstractMethodName();
        boolean boolean20 = closureCodingConvention15.isSuperClassReference("eof");
        boolean boolean22 = closureCodingConvention15.isSuperClassReference("TypeError: hi!");
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        node24.setJSType(jSType25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        node24.setJSType(jSType27);
        boolean boolean29 = closureCodingConvention15.isOptionalParameter(node24);
        node24.setOptionalArg(false);
        java.lang.String str32 = closureCodingConvention0.identifyTypeDefAssign(node24);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int36 = node34.getIntProp(2);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean42 = node41.isOptionalArg();
        boolean boolean43 = node41.isLocalResultCall();
        boolean boolean44 = node34.isEquivalentToTyped(node41);
        try {
            java.util.List<java.lang.String> strList45 = closureCodingConvention0.identifyTypeDeclarationCall(node34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "goog.abstractMethod" + "'", str18.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node26 = node20.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str37 = node33.toString(true, false, true);
        com.google.javascript.rhino.Node node38 = node33.getFirstChild();
        com.google.javascript.rhino.Node node39 = node28.copyInformationFromForTree(node33);
        node28.setVarArgs(false);
        boolean boolean42 = node26.isEquivalentTo(node28);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable43 = node28.children();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "EOF" + "'", str37.equals("EOF"));
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(nodeIterable43);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        boolean boolean9 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean11 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.foldConstants = false;
        compilerOptions0.computeFunctionSideEffects = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean7 = node6.isOptionalArg();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node9.addChildrenToBack(node11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str18 = node14.toString(true, false, true);
        com.google.javascript.rhino.Node node19 = node14.getFirstChild();
        com.google.javascript.rhino.Node node20 = node9.copyInformationFromForTree(node14);
        boolean boolean21 = node9.isOptionalArg();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        node23.setJSType(jSType24);
        boolean boolean26 = node23.isVarArgs();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        node28.setJSType(jSType29);
        boolean boolean31 = node28.isVarArgs();
        boolean boolean32 = node23.hasChild(node28);
        boolean boolean33 = node28.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node6, node9, node28 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(29, nodeArray34, (int) '#', 19);
        try {
            com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(1, nodeArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EOF" + "'", str18.equals("EOF"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode2 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config4 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode2, false);
        com.google.javascript.jscomp.parsing.Config config6 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode2, true);
        org.junit.Assert.assertTrue("'" + languageMode2 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode2.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config4);
        org.junit.Assert.assertNotNull(config6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "eof");
        boolean boolean6 = diagnosticGroup0.matches(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("TypeError: hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(33);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "getprop" + "'", str1.equals("getprop"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        boolean boolean7 = node3.isUnscopedQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.foldConstants;
        compilerOptions0.renamePrefix = "";
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.lineLengthThreshold(0);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode11 = compilerOptions0.tracer;
        boolean boolean12 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode11.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.removeUnusedVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = compilerOptions21.checkUnreachableCode;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.optimizeReturns = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.gatherCssNames = true;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        java.lang.String str8 = compilerInput5.getLine(48);
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput5.getSourceAst();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str13 = jSSourceFile12.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        compilerInput5.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(sourceAst9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        boolean boolean7 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str7 = compilerOptions0.reportPath;
        java.lang.String str8 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMethods;
        boolean boolean6 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.syntheticBlockEndMarker = "goog.abstractMethod";
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.appNameStr;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean9 = compilerOptions0.inlineFunctions;
        boolean boolean10 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str13 = node9.toString(true, false, true);
        com.google.javascript.rhino.Node node14 = node9.getFirstChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node18.addChildrenToBack(node20);
        java.lang.Object obj23 = node20.getProp((int) (short) 100);
        java.lang.String str24 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node25 = node9.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        node27.setLineno(47);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        int int48 = node39.getSourcePosition();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node25, node27, node39, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(21, nodeArray51);
        com.google.javascript.rhino.Node node53 = node3.copyInformationFromForTree(node52);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable54 = node53.children();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF" + "'", str13.equals("EOF"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeIterable54);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "hi!", 43, 44);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node11.setType(11);
        boolean boolean14 = node11.hasSideEffects();
        java.lang.String str15 = closureCodingConvention0.identifyTypeDefAssign(node11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.crossModuleCodeMotion = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.enableRuntimeTypeCheck("goog.global");
        compilerOptions0.renamePrefix = "goog.global";
        boolean boolean11 = compilerOptions0.removeUnusedPrototypeProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.unaliasableGlobals = "<No stack trace available>";
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("<No stack trace available>");
        evaluatorException1.initLineNumber(33);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(140);
        java.lang.String str5 = node1.toString(true, true, false);
        com.google.javascript.rhino.Node node6 = node1.getParent();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "COLONCOLON" + "'", str5.equals("COLONCOLON"));
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        boolean boolean8 = compilerOptions0.closurePass;
        compilerOptions0.setManageClosureDependencies(true);
        boolean boolean11 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        java.lang.Object obj13 = node10.getProp((int) (short) 100);
        java.lang.String str14 = node6.checkTreeEquals(node10);
        node10.addSuppression("Unknown class name");
        try {
            node1.addChildToFront(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str14.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("com.google.javascript.rhino.EvaluatorException: goog.exportProperty", "EOF");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean4 = closureCodingConvention2.isValidEnumKey("error reporter");
        java.lang.String str5 = closureCodingConvention2.getAbstractMethodName();
        java.lang.String str6 = closureCodingConvention2.getExportPropertyFunction();
        boolean boolean8 = closureCodingConvention2.isConstant("goog.exportProperty");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        boolean boolean11 = node10.isVarArgs();
        boolean boolean12 = closureCodingConvention2.isOptionalParameter(node10);
        try {
            com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(46, node1, node10, (int) '4', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.abstractMethod" + "'", str5.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.inlineConstantVars = false;
        compilerOptions3.instrumentationTemplate = "eof";
        boolean boolean8 = compilerOptions3.moveFunctionDeclarations;
        compiler2.initOptions(compilerOptions3);
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str15 = jSSourceFile14.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str25 = jSSourceFile24.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str29 = jSSourceFile28.getOriginalPath();
        java.lang.String str31 = jSSourceFile28.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.global");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str37 = jSSourceFile36.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str41 = jSSourceFile40.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
        java.lang.String str47 = jSSourceFile44.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str51 = jSSourceFile50.getOriginalPath();
        java.lang.String str53 = jSSourceFile50.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str57 = jSSourceFile56.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput62 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60, false);
        com.google.javascript.jscomp.CompilerInput compilerInput63 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray64 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14, jSSourceFile18, jSSourceFile21, jSSourceFile24, jSSourceFile28, jSSourceFile33, jSSourceFile36, jSSourceFile40, jSSourceFile44, jSSourceFile50, jSSourceFile56, jSSourceFile60 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList65, jSSourceFileArray64);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str70 = jSSourceFile69.getOriginalPath();
        java.lang.String str72 = jSSourceFile69.getLine(0);
        java.nio.charset.Charset charset74 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset74);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray76 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile69, jSSourceFile75 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList77 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList77, jSSourceFileArray76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions79.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler82 = null;
        compilerOptions79.setAliasTransformationHandler(aliasTransformationHandler82);
        com.google.javascript.jscomp.CheckLevel checkLevel84 = compilerOptions79.checkMethods;
        compiler2.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList65, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList77, compilerOptions79);
        compiler2.parse();
        com.google.javascript.jscomp.JSModule jSModule87 = null;
        try {
            java.lang.String str88 = compiler2.toSource(jSModule87);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(messageFormatter11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSSourceFileArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(jSSourceFile69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertNotNull(jSSourceFileArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + checkLevel84 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel84.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        java.lang.String str6 = compilerOptions0.reportPath;
        compilerOptions0.jsOutputFile = "error reporter";
        boolean boolean9 = compilerOptions0.removeUnusedVars;
        com.google.javascript.jscomp.MessageBundle messageBundle10 = null;
        compilerOptions0.messageBundle = messageBundle10;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("<unknown=160>", ": hi!", "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean3 = closureCodingConvention1.isValidEnumKey("error reporter");
//        boolean boolean5 = closureCodingConvention1.isPrivate("eof");
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
//        closureCodingConvention1.applySubclassRelationship(functionType6, functionType7, subclassType8);
//        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
//        boolean boolean14 = closureCodingConvention1.isVarArgsParameter(node13);
//        com.google.javascript.rhino.Node node15 = null;
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        int int19 = node17.getIntProp(2);
//        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
//        boolean boolean25 = node24.isOptionalArg();
//        boolean boolean26 = node24.isLocalResultCall();
//        boolean boolean27 = node17.isEquivalentToTyped(node24);
//        java.lang.String str28 = closureCodingConvention1.extractClassNameIfProvide(node15, node17);
//        com.google.javascript.rhino.Context context29 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node33.addChildrenToBack(node35);
//        java.lang.Object obj38 = node35.getProp((int) (short) 100);
//        java.lang.String str39 = node31.checkTreeEquals(node35);
//        node35.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo42 = node35.getJSDocInfo();
//        context29.removeThreadLocal((java.lang.Object) node35);
//        java.lang.String str44 = closureCodingConvention1.identifyTypeDefAssign(node35);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node48.addChildrenToBack(node50);
//        java.lang.Object obj53 = node50.getProp((int) (short) 100);
//        int int55 = node50.getIntProp(0);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
//        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
//        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
//        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("eof", node35, diagnosticType45, strArray63);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(node13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNotNull(context29);
//        org.junit.Assert.assertNotNull(node31);
//        org.junit.Assert.assertNull(obj38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str39.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo42);
//        org.junit.Assert.assertNull(str44);
//        org.junit.Assert.assertNotNull(diagnosticType45);
//        org.junit.Assert.assertNull(obj53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(diagnosticType56);
//        org.junit.Assert.assertNotNull(messageFormat57);
//        org.junit.Assert.assertNotNull(strArray63);
//        org.junit.Assert.assertNotNull(jSError64);
//        org.junit.Assert.assertNotNull(jSError65);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.toString();
        java.io.Reader reader4 = jSSourceFile2.getCodeReader();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(reader4);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode7 = compilerOptions0.tracer;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.inlineVariables = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode7.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = null;
        compilerOptions0.setCodingConvention(codingConvention7);
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        java.lang.Object obj6 = node3.getProp((int) (short) 100);
        node3.setType((int) ' ');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str16 = node12.toString(true, false, true);
        int int17 = node12.getSourcePosition();
        node12.setIsSyntheticBlock(true);
        node3.addChildAfter(node10, node12);
        java.lang.String str21 = node3.getQualifiedName();
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EOF" + "'", str16.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(4);
        java.util.Set<java.lang.String> strSet2 = node1.getDirectives();
        org.junit.Assert.assertNull(strSet2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean7 = closureCodingConvention0.isExported("COLONCOLON", true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.lang.String str11 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportSymbol" + "'", str11.equals("goog.exportSymbol"));
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        boolean boolean5 = composeWarningsGuard3.enables(diagnosticGroup4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup6;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup6;
//        boolean boolean9 = composeWarningsGuard3.enables(diagnosticGroup6);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(diagnosticGroup4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(diagnosticGroup6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compiler1.reportCodeChange();
        java.lang.String[] strArray32 = compiler1.toSourceArray();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(strArray32);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.coalesceVariableNames = true;
        java.lang.String str7 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        node1.setWasEmptyNode(false);
        node1.setLineno(0);
        org.junit.Assert.assertNotNull(ancestorIterable2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        loggerErrorManager1.generateReport();
        double double4 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean7 = node6.isOptionalArg();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node9.addChildrenToBack(node11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str18 = node14.toString(true, false, true);
        com.google.javascript.rhino.Node node19 = node14.getFirstChild();
        com.google.javascript.rhino.Node node20 = node9.copyInformationFromForTree(node14);
        boolean boolean21 = node9.isOptionalArg();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        node23.setJSType(jSType24);
        boolean boolean26 = node23.isVarArgs();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        node28.setJSType(jSType29);
        boolean boolean31 = node28.isVarArgs();
        boolean boolean32 = node23.hasChild(node28);
        boolean boolean33 = node28.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node6, node9, node28 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(29, nodeArray34, (int) '#', 19);
        try {
            com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, nodeArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EOF" + "'", str18.equals("EOF"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(nodeArray34);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter45.setColorize(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "hi!", 43, 44);
        java.lang.String str8 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.abstractMethod" + "'", str8.equals("goog.abstractMethod"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.checkEs5Strict = false;
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("Exceeded max number of optimization iterations: TypeError: hi!", "", 38);
        int int4 = evaluatorException3.lineNumber();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.enableRuntimeTypeCheck("hi!");
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.prettyPrint = false;
        java.lang.String str8 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions11.sourceMapDetailLevel = detailLevel14;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing16 = compilerOptions11.getTweakProcessing();
        compilerOptions0.setTweakProcessing(tweakProcessing16);
        boolean boolean18 = tweakProcessing16.isOn();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertTrue("'" + tweakProcessing16 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing16.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        boolean boolean7 = compilerOptions0.inlineVariables;
        compilerOptions0.setTweakToNumberLiteral("Exceeded max number of optimization iterations: TypeError: hi!", 160);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean14 = closureCodingConvention0.isPrivate("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node6 = null;
        try {
            nodeTraversal5.traverse(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        boolean boolean23 = closureCodingConvention0.isConstantKey("goog.exportSymbol");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean26 = closureCodingConvention24.isValidEnumKey("error reporter");
        java.lang.String str27 = closureCodingConvention24.getExportPropertyFunction();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node29.setJSType(jSType30);
        boolean boolean32 = node29.isVarArgs();
        boolean boolean33 = closureCodingConvention24.isOptionalParameter(node29);
        boolean boolean35 = closureCodingConvention24.isExported("");
        boolean boolean38 = closureCodingConvention24.isExported("", true);
        com.google.javascript.rhino.Node node39 = null;
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str45 = closureCodingConvention24.extractClassNameIfProvide(node39, node44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str51 = node47.toString(false, true, false);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        node53.setJSType(jSType54);
        boolean boolean56 = node53.isVarArgs();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        node58.setJSType(jSType59);
        boolean boolean61 = node58.isVarArgs();
        boolean boolean62 = node53.hasChild(node58);
        node53.removeProp(2);
        node47.addChildToFront(node53);
        boolean boolean66 = closureCodingConvention24.isOptionalParameter(node47);
        java.lang.String str67 = closureCodingConvention0.getSingletonGetterClassName(node47);
        boolean boolean68 = node47.isOptionalArg();
        try {
            int int70 = node47.getExistingIntProp(48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportProperty" + "'", str27.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "EOF" + "'", str51.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        java.lang.Object obj6 = node3.getProp((int) (short) 100);
        node3.setType((int) ' ');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str16 = node12.toString(true, false, true);
        int int17 = node12.getSourcePosition();
        node12.setIsSyntheticBlock(true);
        node3.addChildAfter(node10, node12);
        com.google.javascript.rhino.Node node22 = node12.getAncestor((int) '#');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str28 = node24.toString(true, false, true);
        int int29 = node24.getSourcePosition();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        try {
            node22.replaceChild(node24, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EOF" + "'", str16.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "EOF" + "'", str28.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.removeUnusedVars = true;
        compilerOptions21.setTweakToStringLiteral("hi!", "eof");
        boolean boolean39 = compilerOptions21.computeFunctionSideEffects;
        compilerOptions21.debugFunctionSideEffectsPath = "com.google.javascript.rhino.EcmaError: TypeError: hi!";
        compilerOptions21.checkSymbols = false;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = jSSourceFile2.getOriginalPath();
        java.lang.String str8 = jSSourceFile2.toString();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        boolean boolean23 = closureCodingConvention0.isConstantKey("goog.exportSymbol");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean26 = closureCodingConvention24.isValidEnumKey("error reporter");
        java.lang.String str27 = closureCodingConvention24.getExportPropertyFunction();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node29.setJSType(jSType30);
        boolean boolean32 = node29.isVarArgs();
        boolean boolean33 = closureCodingConvention24.isOptionalParameter(node29);
        boolean boolean35 = closureCodingConvention24.isExported("");
        boolean boolean38 = closureCodingConvention24.isExported("", true);
        com.google.javascript.rhino.Node node39 = null;
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str45 = closureCodingConvention24.extractClassNameIfProvide(node39, node44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str51 = node47.toString(false, true, false);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        node53.setJSType(jSType54);
        boolean boolean56 = node53.isVarArgs();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        node58.setJSType(jSType59);
        boolean boolean61 = node58.isVarArgs();
        boolean boolean62 = node53.hasChild(node58);
        node53.removeProp(2);
        node47.addChildToFront(node53);
        boolean boolean66 = closureCodingConvention24.isOptionalParameter(node47);
        java.lang.String str67 = closureCodingConvention0.getSingletonGetterClassName(node47);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection68 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportProperty" + "'", str27.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "EOF" + "'", str51.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection68);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        double double4 = loggerErrorManager2.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler2.tracker = performanceTracker3;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str9 = jSSourceFile7.getLine((int) (short) 100);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7 };
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18, false);
        java.lang.String str21 = jSSourceFile18.getName();
        java.nio.charset.Charset charset23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27, false);
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region35 = jSSourceFile33.getRegion(26);
        java.lang.String str36 = jSSourceFile33.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str40 = jSSourceFile39.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile24, jSSourceFile27, jSSourceFile33, jSSourceFile39 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
        java.lang.String str47 = jSSourceFile44.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
        java.lang.String str49 = compilerInput48.getName();
        java.io.PrintStream printStream50 = null;
        com.google.javascript.jscomp.Compiler compiler51 = new com.google.javascript.jscomp.Compiler(printStream50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.inlineConstantVars = false;
        compilerOptions52.instrumentationTemplate = "eof";
        boolean boolean57 = compilerOptions52.moveFunctionDeclarations;
        compiler51.initOptions(compilerOptions52);
        compilerInput48.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region64 = jSSourceFile62.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray65 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions66.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy69 = compilerOptions66.variableRenaming;
        com.google.javascript.jscomp.Result result70 = compiler51.compile(jSSourceFile62, jSModuleArray65, compilerOptions66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler74 = null;
        compilerOptions71.setAliasTransformationHandler(aliasTransformationHandler74);
        com.google.javascript.jscomp.Result result76 = compiler12.compile(jSSourceFileArray41, jSModuleArray65, compilerOptions71);
        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean78 = compilerOptions77.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig79 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions77);
        compiler2.init(jSSourceFileArray10, jSSourceFileArray41, compilerOptions77);
        com.google.javascript.jscomp.CheckLevel checkLevel81 = compilerOptions77.checkMethods;
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNull(region35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNull(region64);
        org.junit.Assert.assertNotNull(jSModuleArray65);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy69 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy69.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result70);
        org.junit.Assert.assertNotNull(result76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + checkLevel81 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel81.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("or", "TypeError");
        java.lang.String[] strArray6 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("", (int) '#', 110, diagnosticType5, strArray6);
        java.lang.String str8 = jSError7.description;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = jSError7.level;
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TypeError" + "'", str8.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int3 = node2.getLineno();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        int int9 = node6.getSideEffectFlags();
        com.google.javascript.rhino.Node node10 = node6.cloneNode();
        node6.putProp(43, (java.lang.Object) 47);
        node2.putProp(1, (java.lang.Object) 47);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(12, node20, 43, 160);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(150, node2, node23);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean4 = compilerOptions0.checkUnusedPropertiesEarly;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.checkCaja = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.removeEmptyFunctions = true;
        compilerOptions3.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean8 = compilerOptions3.deadAssignmentElimination;
        compiler2.initOptions(compilerOptions3);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions3.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList20 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList20, jSSourceFileArray19);
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList23 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList23, jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean26 = compilerOptions25.checkControlStructures;
        compilerOptions25.setRemoveClosureAsserts(false);
        compilerOptions25.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result32 = compiler13.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList20, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList23, compilerOptions25);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker33 = null;
        compiler13.tracker = performanceTracker33;
        compiler13.reportCodeChange();
        com.google.javascript.jscomp.SourceMap sourceMap36 = compiler13.getSourceMap();
        try {
            java.lang.String str37 = com.google.javascript.rhino.ScriptRuntime.getMessage2("goog.exportProperty", (java.lang.Object) anonymousFunctionNamingPolicy10, (java.lang.Object) sourceMap36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy10 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy10.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result32);
        org.junit.Assert.assertNull(sourceMap36);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        boolean boolean23 = closureCodingConvention0.isConstantKey("goog.exportSymbol");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean26 = closureCodingConvention24.isValidEnumKey("error reporter");
        java.lang.String str27 = closureCodingConvention24.getExportPropertyFunction();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node29.setJSType(jSType30);
        boolean boolean32 = node29.isVarArgs();
        boolean boolean33 = closureCodingConvention24.isOptionalParameter(node29);
        boolean boolean35 = closureCodingConvention24.isExported("");
        boolean boolean38 = closureCodingConvention24.isExported("", true);
        com.google.javascript.rhino.Node node39 = null;
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str45 = closureCodingConvention24.extractClassNameIfProvide(node39, node44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str51 = node47.toString(false, true, false);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        node53.setJSType(jSType54);
        boolean boolean56 = node53.isVarArgs();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        node58.setJSType(jSType59);
        boolean boolean61 = node58.isVarArgs();
        boolean boolean62 = node53.hasChild(node58);
        node53.removeProp(2);
        node47.addChildToFront(node53);
        boolean boolean66 = closureCodingConvention24.isOptionalParameter(node47);
        java.lang.String str67 = closureCodingConvention0.getSingletonGetterClassName(node47);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention68 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean70 = closureCodingConvention68.isValidEnumKey("error reporter");
        boolean boolean72 = closureCodingConvention68.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType73 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType74 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType75 = null;
        closureCodingConvention68.applySubclassRelationship(functionType73, functionType74, subclassType75);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean81 = closureCodingConvention68.isVarArgsParameter(node80);
        boolean boolean82 = closureCodingConvention0.isOptionalParameter(node80);
        boolean boolean83 = node80.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportProperty" + "'", str27.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "EOF" + "'", str51.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        try {
//            com.google.javascript.rhino.Context.reportError("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 8);
//        com.google.javascript.rhino.Context context6 = com.google.javascript.rhino.Context.enter();
//        context6.addActivationName("TypeError: hi!");
//        java.util.Locale locale9 = context6.getLocale();
//        java.util.Locale locale10 = context0.setLocale(locale9);
//        context0.addActivationName("<No stack trace available>");
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(context6);
//        org.junit.Assert.assertNotNull(locale9);
//        org.junit.Assert.assertNull(locale10);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str24 = jSSourceFile23.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str31 = jSSourceFile30.toString();
        java.io.Reader reader32 = jSSourceFile30.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str36 = jSSourceFile35.getOriginalPath();
        java.lang.String str38 = jSSourceFile35.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region43 = jSSourceFile41.getRegion(26);
        java.lang.String str44 = jSSourceFile41.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile27, jSSourceFile30, jSSourceFile35, jSSourceFile41 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str48 = compilerOptions47.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format49 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions47.sourceMapFormat = format49;
        boolean boolean51 = compilerOptions47.crossModuleMethodMotion;
        compilerOptions47.setLooseTypes(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap54 = null;
        compilerOptions47.cssRenamingMap = cssRenamingMap54;
        compiler1.init(jSSourceFileArray45, jSModuleArray46, compilerOptions47);
        com.google.javascript.jscomp.Scope scope57 = compiler1.getTopScope();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList58 = null;
        java.io.PrintStream printStream59 = null;
        com.google.javascript.jscomp.Compiler compiler60 = new com.google.javascript.jscomp.Compiler(printStream59);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile63 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput65 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile63, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray66 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile63 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList67 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList67, jSSourceFileArray66);
        com.google.javascript.jscomp.JSModule[] jSModuleArray69 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList70 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList70, jSModuleArray69);
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean73 = compilerOptions72.checkControlStructures;
        compilerOptions72.setRemoveClosureAsserts(false);
        compilerOptions72.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result79 = compiler60.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList67, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList70, compilerOptions72);
        com.google.javascript.jscomp.CompilerOptions compilerOptions80 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean81 = compilerOptions80.checkControlStructures;
        compilerOptions80.setRemoveClosureAsserts(false);
        compilerOptions80.setTweakToBooleanLiteral("", false);
        boolean boolean87 = compilerOptions80.optimizeCalls;
        boolean boolean88 = compilerOptions80.shouldColorizeErrorOutput();
        java.lang.Object obj89 = null;
        java.lang.RuntimeException runtimeException90 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions80, obj89);
        try {
            com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileList58, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList67, compilerOptions80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(reader32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNull(region43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(format49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(scope57);
        org.junit.Assert.assertNotNull(jSSourceFile63);
        org.junit.Assert.assertNotNull(jSSourceFileArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(jSModuleArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(result79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(runtimeException90);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        node1.setType((int) 'a');
        boolean boolean8 = node1.hasOneChild();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        boolean boolean1 = context0.isGeneratingDebugChanged();
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.getErrorReporter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(errorReporter4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node10.addChildrenToBack(node12);
        java.lang.Object obj15 = node12.getProp((int) (short) 100);
        java.lang.String str16 = node8.checkTreeEquals(node12);
        com.google.javascript.rhino.Node node17 = node1.clonePropsFrom(node8);
        try {
            int int19 = node1.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str16.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str13 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.exportSymbol" + "'", str13.equals("goog.exportSymbol"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        java.lang.String str2 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        compilerOptions0.optimizeParameters = true;
        boolean boolean7 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.inlineConstantVars = false;
        compilerOptions2.unaliasableGlobals = "";
        compilerOptions2.generatePseudoNames = false;
        boolean boolean9 = compilerOptions2.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions2.checkMissingReturn;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat15 = diagnosticType14.format;
        boolean boolean16 = diagnosticGroup12.matches(diagnosticType14);
        boolean boolean17 = diagnosticGroupWarningsGuard11.enables(diagnosticGroup12);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup12;
        org.junit.Assert.assertNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(messageFormat15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        compilerOptions0.aliasableGlobals = "error reporter";
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel10;
        boolean boolean12 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.inlineConstantVars = false;
        compilerOptions3.instrumentationTemplate = "eof";
        boolean boolean8 = compilerOptions3.moveFunctionDeclarations;
        compiler2.initOptions(compilerOptions3);
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str15 = jSSourceFile14.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str25 = jSSourceFile24.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str29 = jSSourceFile28.getOriginalPath();
        java.lang.String str31 = jSSourceFile28.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.global");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str37 = jSSourceFile36.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str41 = jSSourceFile40.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
        java.lang.String str47 = jSSourceFile44.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str51 = jSSourceFile50.getOriginalPath();
        java.lang.String str53 = jSSourceFile50.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str57 = jSSourceFile56.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput62 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60, false);
        com.google.javascript.jscomp.CompilerInput compilerInput63 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray64 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14, jSSourceFile18, jSSourceFile21, jSSourceFile24, jSSourceFile28, jSSourceFile33, jSSourceFile36, jSSourceFile40, jSSourceFile44, jSSourceFile50, jSSourceFile56, jSSourceFile60 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList65, jSSourceFileArray64);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str70 = jSSourceFile69.getOriginalPath();
        java.lang.String str72 = jSSourceFile69.getLine(0);
        java.nio.charset.Charset charset74 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset74);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray76 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile69, jSSourceFile75 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList77 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList77, jSSourceFileArray76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions79.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler82 = null;
        compilerOptions79.setAliasTransformationHandler(aliasTransformationHandler82);
        com.google.javascript.jscomp.CheckLevel checkLevel84 = compilerOptions79.checkMethods;
        compiler2.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList65, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList77, compilerOptions79);
        compiler2.parse();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker87 = compiler2.tracker;
        java.lang.String str88 = compiler2.toSource();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(messageFormatter11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSSourceFileArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(jSSourceFile69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertNotNull(jSSourceFileArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + checkLevel84 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel84.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(performanceTracker87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "" + "'", str88.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        compilerOptions10.instrumentationTemplate = "eof";
        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
        compiler9.initOptions(compilerOptions10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        java.lang.String str19 = compilerInput6.getLine(22);
        java.lang.String str20 = compilerInput6.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.disambiguateProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.reportMissingOverride;
        boolean boolean18 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkSymbols = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition10 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation11 = aliasTransformationHandler8.logAliasTransformation("goog.exportProperty", aliasTransformationSourcePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("eol", "EOF");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean12 = node11.isOptionalArg();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str23 = node19.toString(true, false, true);
        com.google.javascript.rhino.Node node24 = node19.getFirstChild();
        com.google.javascript.rhino.Node node25 = node14.copyInformationFromForTree(node19);
        boolean boolean26 = node14.isOptionalArg();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        node28.setJSType(jSType29);
        boolean boolean31 = node28.isVarArgs();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        node33.setJSType(jSType34);
        boolean boolean36 = node33.isVarArgs();
        boolean boolean37 = node28.hasChild(node33);
        boolean boolean38 = node33.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node11, node14, node33 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(29, nodeArray39, (int) '#', 19);
        try {
            nodeTraversal5.traverseRoots(nodeArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "EOF" + "'", str23.equals("EOF"));
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(nodeArray39);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str24 = jSSourceFile23.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str31 = jSSourceFile30.toString();
        java.io.Reader reader32 = jSSourceFile30.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str36 = jSSourceFile35.getOriginalPath();
        java.lang.String str38 = jSSourceFile35.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region43 = jSSourceFile41.getRegion(26);
        java.lang.String str44 = jSSourceFile41.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile27, jSSourceFile30, jSSourceFile35, jSSourceFile41 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str48 = compilerOptions47.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format49 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions47.sourceMapFormat = format49;
        boolean boolean51 = compilerOptions47.crossModuleMethodMotion;
        compilerOptions47.setLooseTypes(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap54 = null;
        compilerOptions47.cssRenamingMap = cssRenamingMap54;
        compiler1.init(jSSourceFileArray45, jSModuleArray46, compilerOptions47);
        compilerOptions47.renamePrefix = "goog.global";
        compilerOptions47.inlineConstantVars = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(reader32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNull(region43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(format49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        java.lang.Object obj8 = node3.getProp(110);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable17 = node16.getAncestors();
        node5.addChildAfter(node14, node16);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(25, "goog.exportProperty", (int) (byte) 0, 31);
        boolean boolean24 = node23.isOptionalArg();
        boolean boolean25 = node5.isEquivalentTo(node23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(ancestorIterable17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.removeEmptyFunctions = true;
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        compilerOptions0.setPropertyAffinity(true);
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMissingReturn;
        boolean boolean12 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        node8.setJSType(jSType9);
        boolean boolean11 = node8.isVarArgs();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node13.setJSType(jSType14);
        boolean boolean16 = node13.isVarArgs();
        boolean boolean17 = node8.hasChild(node13);
        com.google.javascript.rhino.Node node19 = node13.getAncestor(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean22 = closureCodingConvention20.isValidEnumKey("error reporter");
        java.lang.String str23 = closureCodingConvention20.getExportPropertyFunction();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        node25.setJSType(jSType26);
        boolean boolean28 = node25.isVarArgs();
        boolean boolean29 = closureCodingConvention20.isOptionalParameter(node25);
        boolean boolean31 = closureCodingConvention20.isExported("");
        boolean boolean34 = closureCodingConvention20.isExported("", true);
        com.google.javascript.rhino.Node node35 = null;
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str41 = closureCodingConvention20.extractClassNameIfProvide(node35, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        node44.setJSType(jSType45);
        int int47 = node44.getSideEffectFlags();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(43, node44, 140, 45);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention51 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean53 = closureCodingConvention51.isValidEnumKey("error reporter");
        java.lang.String str54 = closureCodingConvention51.getExportPropertyFunction();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        node56.setJSType(jSType57);
        boolean boolean59 = node56.isVarArgs();
        boolean boolean60 = closureCodingConvention51.isOptionalParameter(node56);
        boolean boolean62 = closureCodingConvention51.isExported("");
        boolean boolean65 = closureCodingConvention51.isExported("", true);
        com.google.javascript.rhino.Node node66 = null;
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str72 = closureCodingConvention51.extractClassNameIfProvide(node66, node71);
        com.google.javascript.rhino.Node node73 = node71.getFirstChild();
        java.lang.String str74 = closureCodingConvention20.extractClassNameIfRequire(node50, node71);
        java.lang.String str75 = closureCodingConvention0.extractClassNameIfRequire(node19, node50);
        java.util.Set<java.lang.String> strSet76 = node19.getDirectives();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.exportProperty" + "'", str23.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "goog.exportProperty" + "'", str54.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNull(node73);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNull(strSet76);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean6 = closureCodingConvention0.isExported("error reporter", true);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType9 = null;
        closureCodingConvention0.applySubclassRelationship(functionType7, functionType8, subclassType9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        boolean boolean6 = compilerOptions0.aliasExternals;
        compilerOptions0.reportPath = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        java.lang.String[] strArray12 = new java.lang.String[] { "or", "EOF", "EOF", "or", "error reporter", "" };
        java.util.ArrayList<java.lang.String> strList13 = new java.util.ArrayList<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList13, strArray12);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.removeEmptyFunctions = true;
        compilerOptions16.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel22, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel25 = diagnosticType24.defaultLevel;
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile30 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList34 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList34, jSSourceFileArray33);
        com.google.javascript.jscomp.JSModule[] jSModuleArray36 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList37 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList37, jSModuleArray36);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean40 = compilerOptions39.checkControlStructures;
        compilerOptions39.setRemoveClosureAsserts(false);
        compilerOptions39.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result46 = compiler27.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList34, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList37, compilerOptions39);
        compilerOptions39.generatePseudoNames = false;
        boolean boolean49 = compilerOptions39.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel50 = compilerOptions39.brokenClosureRequiresLevel;
        diagnosticType24.level = checkLevel50;
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions52.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel56 = compilerOptions52.checkUndefinedProperties;
        diagnosticType24.level = checkLevel56;
        compilerOptions16.checkGlobalThisLevel = checkLevel56;
        compilerOptions0.checkShadowVars = checkLevel56;
        boolean boolean60 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNull(checkLevel25);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(jSModuleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(result46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + checkLevel50 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel50.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel56 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel56.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        boolean boolean31 = compilerOptions21.tightenTypes;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        boolean boolean10 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(11, "TypeError: hi!", 7, (int) (short) 10);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node4.setJSType(jSType5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node4.setJSType(jSType7);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.setPropertyAffinity(false);
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) -1, (byte) 100, (byte) 1, (byte) 0 };
        compilerOptions21.inputVariableMapSerialized = byteArray41;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions21.reportUnknownTypes;
        compilerOptions21.disambiguateProperties = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat46 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        java.io.PrintStream printStream47 = null;
        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler(printStream47);
        java.lang.String str49 = compiler48.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile52, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput59 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57, false);
        java.lang.String str60 = jSSourceFile57.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput61 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        java.lang.String str62 = compilerInput61.getName();
        java.io.PrintStream printStream63 = null;
        com.google.javascript.jscomp.Compiler compiler64 = new com.google.javascript.jscomp.Compiler(printStream63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.inlineConstantVars = false;
        compilerOptions65.instrumentationTemplate = "eof";
        boolean boolean70 = compilerOptions65.moveFunctionDeclarations;
        compiler64.initOptions(compilerOptions65);
        compilerInput61.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler64);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region77 = jSSourceFile75.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray78 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions79 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions79.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy82 = compilerOptions79.variableRenaming;
        com.google.javascript.jscomp.Result result83 = compiler64.compile(jSSourceFile75, jSModuleArray78, compilerOptions79);
        com.google.javascript.jscomp.CompilerOptions compilerOptions84 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions84.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy87 = null;
        compilerOptions84.variableRenaming = variableRenamingPolicy87;
        java.util.Set<java.lang.String> strSet89 = compilerOptions84.stripNameSuffixes;
        boolean boolean90 = compilerOptions84.labelRenaming;
        com.google.javascript.jscomp.Result result91 = compiler48.compile(jSSourceFile52, jSModuleArray78, compilerOptions84);
        int int92 = compiler48.getErrorCount();
        com.google.javascript.jscomp.CompilerInput compilerInput94 = compiler48.getInput("");
        com.google.javascript.jscomp.MessageFormatter messageFormatter96 = errorFormat46.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler48, true);
        compilerOptions21.errorFormat = errorFormat46;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertNull(region77);
        org.junit.Assert.assertNotNull(jSModuleArray78);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy82 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy82.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result83);
        org.junit.Assert.assertNotNull(strSet89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(result91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(compilerInput94);
        org.junit.Assert.assertNotNull(messageFormatter96);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.io.PrintStream printStream3 = null;
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler(printStream3);
        java.lang.String str5 = compiler4.getAstDotGraph();
        compiler4.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler4.getState();
        compiler2.setState(intermediateState7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(intermediateState7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("error reporter", "EOF [synthetic: 1]");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = compilerOptions0.variableRenaming;
        boolean boolean10 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.inlineVariables = false;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        compilerOptions0.inlineFunctions = false;
        boolean boolean7 = compilerOptions0.checkDuplicateMessages;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getTweakReplacements();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strMap8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        jSModuleGraph1.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        try {
            boolean boolean8 = jSModuleGraph1.dependsOn(jSModule6, jSModule7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        compilerOptions0.aliasableGlobals = "error reporter";
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel10;
        compilerOptions0.reserveRawExports = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.checkGlobalNamesLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        compilerOptions0.aliasableGlobals = "Unknown class name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingReturn;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.enableRuntimeTypeCheck("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        compilerOptions21.setPropertyAffinity(false);
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) -1, (byte) 100, (byte) 1, (byte) 0 };
        compilerOptions21.inputVariableMapSerialized = byteArray41;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions21.reportUnknownTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions21.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions21.checkGlobalThisLevel;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("EOF", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("eof");
        boolean boolean7 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node5 = node1.getFirstChild();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean8 = closureCodingConvention6.isValidEnumKey("error reporter");
        java.lang.String str9 = closureCodingConvention6.getAbstractMethodName();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node11.setJSType(jSType12);
        boolean boolean14 = node11.isVarArgs();
        boolean boolean15 = node11.hasChildren();
        boolean boolean16 = closureCodingConvention6.isOptionalParameter(node11);
        int int17 = node11.getLineno();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        try {
            node1.replaceChild(node11, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.abstractMethod" + "'", str9.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkControlStructures = true;
        boolean boolean7 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("()", "name");
        java.lang.String str3 = diagnosticType2.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(): name" + "'", str3.equals("(): name"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isSuperClassReference("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int7 = node6.getLineno();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node10.setJSType(jSType11);
        int int13 = node10.getSideEffectFlags();
        com.google.javascript.rhino.Node node14 = node10.cloneNode();
        node10.putProp(43, (java.lang.Object) 47);
        node6.putProp(1, (java.lang.Object) 47);
        try {
            boolean boolean19 = closureCodingConvention0.isPropertyTestFunction(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray7 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList8 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8, warningsGuardArray7);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard10);
        boolean boolean12 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(warningsGuardArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.toString();
        java.lang.Throwable[] throwableArray4 = ecmaError1.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: hi!" + "'", str3.equals("com.google.javascript.rhino.EcmaError: TypeError: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test418");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        boolean boolean5 = composeWarningsGuard3.enables(diagnosticGroup4);
//        java.lang.String str6 = composeWarningsGuard3.toString();
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(diagnosticGroup4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.enableRuntimeTypeCheck("hi!");
        boolean boolean5 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.generatePseudoNames = true;
        compilerOptions0.locale = "com.google.javascript.rhino.EcmaError: TypeError: hi!";
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = null;
        com.google.javascript.jscomp.Scope scope17 = null;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention18 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean20 = closureCodingConvention18.isValidEnumKey("error reporter");
        java.lang.String str21 = closureCodingConvention18.getAbstractMethodName();
        java.lang.String str22 = closureCodingConvention18.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = null;
        com.google.javascript.jscomp.Scope scope24 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray25 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList26, objectTypeArray25);
        closureCodingConvention18.defineDelegateProxyPrototypeProperties(jSTypeRegistry23, scope24, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList26);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry16, scope17, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "goog.abstractMethod" + "'", str21.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "goog.exportProperty" + "'", str22.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(objectTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        java.lang.String str5 = jSSourceFile2.getLine(0);
        java.io.Reader reader6 = jSSourceFile2.getCodeReader();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(reader6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        compilerOptions10.instrumentationTemplate = "eof";
        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
        compiler9.initOptions(compilerOptions10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
        com.google.javascript.jscomp.Region region31 = compiler9.getSourceRegion("EOF", (int) (short) 0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(region22);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNull(region31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getSourceName();
        ecmaError1.initLineNumber(37);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.appNameStr;
        compilerOptions0.disambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        compilerOptions0.removeUnusedVars = true;
        boolean boolean11 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.foldConstants = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions14.aggressiveVarCheck;
        compilerOptions14.setDefineToDoubleLiteral("", (double) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.nameReferenceGraphPath = "hi!";
        java.lang.String str24 = compilerOptions21.instrumentationTemplate;
        compilerOptions21.labelRenaming = false;
        java.util.Set<java.lang.String> strSet27 = compilerOptions21.stripNamePrefixes;
        compilerOptions14.stripTypes = strSet27;
        compilerOptions0.stripTypePrefixes = strSet27;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(strSet27);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 0);
        compilerOptions0.collapseAnonymousFunctions = false;
        java.lang.String str9 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str10 = compilerOptions0.reportPath;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        java.lang.Object obj9 = null;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, obj9);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.prettyPrint = false;
        boolean boolean14 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 0);
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.checkCaja = true;
        boolean boolean11 = compilerOptions0.disambiguateProperties;
        compilerOptions0.debugFunctionSideEffectsPath = "(): name";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        node1.addChildToBack(node6);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getWarnings();
        loggerErrorManager2.generateReport();
        double double6 = loggerErrorManager2.getTypedPercent();
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.checkControlStructures;
        compilerOptions7.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy11 = compilerOptions7.anonymousFunctionNaming;
        boolean boolean12 = compilerOptions7.prettyPrint;
        compilerOptions7.setPropertyAffinity(true);
        compilerOptions7.locale = "eof";
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig19 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions17);
        boolean boolean20 = compilerOptions17.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat21 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions17.errorFormat = errorFormat21;
        java.lang.String str23 = compilerOptions17.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions17.checkMissingReturn;
        compilerOptions7.checkProvides = checkLevel24;
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        java.lang.String str28 = compiler27.getAstDotGraph();
        compiler27.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback30 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal31 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler27, callback30);
        boolean boolean32 = nodeTraversal31.hasScope();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node34.addChildrenToBack(node36);
        node36.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node43.addChildrenToBack(node45);
        java.lang.Object obj48 = node45.getProp((int) (short) 100);
        int int50 = node45.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat52 = diagnosticType51.format;
        java.lang.String[] strArray58 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node45, diagnosticType51, strArray58);
        com.google.javascript.jscomp.JSError jSError60 = nodeTraversal31.makeError(node36, diagnosticType40, strArray58);
        loggerErrorManager2.report(checkLevel24, jSError60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy11 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy11.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(errorFormat21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(messageFormat52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNotNull(jSError60);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkControlStructures = true;
        compilerOptions0.removeDeadCode = true;
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.String str7 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine((int) (short) -1);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getWarnings();
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        jSSourceFile9.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str14 = jSSourceFile13.getOriginalPath();
        java.lang.String str16 = jSSourceFile13.getLine(0);
        jSSourceFile13.setOriginalPath("EOF");
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler22 = null;
        compilerOptions19.setAliasTransformationHandler(aliasTransformationHandler22);
        compilerOptions19.debugFunctionSideEffectsPath = "";
        boolean boolean26 = compilerOptions19.optimizeReturns;
        boolean boolean27 = compilerOptions19.flowSensitiveInlineVariables;
        boolean boolean28 = compilerOptions19.collapseProperties;
        try {
            com.google.javascript.jscomp.Result result29 = compiler6.compile(jSSourceFile9, jSSourceFile13, compilerOptions19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.optimizeArgumentsArray = true;
        boolean boolean9 = compilerOptions0.reserveRawExports;
        boolean boolean10 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 31, 12, 13);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput6.setModule(jSModule7);
        java.lang.String str10 = compilerInput6.getLine(130);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        java.lang.String str7 = compilerOptions0.renamePrefix;
        boolean boolean8 = compilerOptions0.aliasAllStrings;
        compilerOptions0.crossModuleCodeMotion = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str10 = node6.toString(true, false, true);
        com.google.javascript.rhino.Node node11 = node6.getFirstChild();
        com.google.javascript.rhino.Node node12 = node1.copyInformationFromForTree(node6);
        com.google.javascript.rhino.Node node13 = node6.getFirstChild();
        java.lang.String str14 = node6.toString();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags15 = new com.google.javascript.rhino.Node.SideEffectFlags();
        try {
            node6.setSideEffectFlags(sideEffectFlags15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "EOF" + "'", str10.equals("EOF"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EOF" + "'", str14.equals("EOF"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel1, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType3.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNull(checkLevel4);
        org.junit.Assert.assertNull(checkLevel5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compilerOptions13.generatePseudoNames = false;
        boolean boolean23 = compilerOptions13.removeUnusedVars;
        boolean boolean24 = compilerOptions13.groupVariableDeclarations;
        boolean boolean25 = compilerOptions13.inlineAnonymousFunctionExpressions;
        compilerOptions13.setManageClosureDependencies(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.removeEmptyFunctions = true;
        compilerOptions28.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions28.checkSymbols = false;
        boolean boolean35 = compilerOptions28.flowSensitiveInlineVariables;
        boolean boolean36 = compilerOptions28.prettyPrint;
        compilerOptions28.convertToDottedProperties = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean40 = compilerOptions39.checkControlStructures;
        compilerOptions39.setRemoveClosureAsserts(false);
        compilerOptions39.setTweakToBooleanLiteral("", false);
        boolean boolean46 = compilerOptions39.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy47 = compilerOptions39.anonymousFunctionNaming;
        compilerOptions39.lineLengthThreshold(0);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode50 = compilerOptions39.tracer;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions39.checkShadowVars;
        compilerOptions28.checkGlobalThisLevel = checkLevel51;
        compilerOptions13.brokenClosureRequiresLevel = checkLevel51;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy47 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy47.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode50 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode50.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getSourceName();
        java.lang.String str4 = ecmaError1.getLineSource();
        java.lang.String str5 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError: hi!" + "'", str5.equals("TypeError: hi!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.disambiguateProperties = true;
        compilerOptions0.checkSymbols = true;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkShadowVars;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripTypes;
        boolean boolean11 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.crossModuleMethodMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.checkControlStructures;
        compilerOptions14.setCollapsePropertiesOnExternTypes(true);
        compilerOptions14.checkSuspiciousCode = true;
        byte[] byteArray23 = new byte[] { (byte) 100, (byte) -1, (byte) -1 };
        compilerOptions14.inputPropertyMapSerialized = byteArray23;
        compilerOptions0.inputPropertyMapSerialized = byteArray23;
        java.lang.String str26 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        boolean boolean4 = compilerOptions0.instrumentForCoverage;
        compilerOptions0.closurePass = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.setTweakToStringLiteral("Unknown class name", "Exceeded max number of optimization iterations: TypeError: hi!");
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        int int20 = node7.getType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToStringLiteral("goog.exportProperty", "");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel8;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.setMutatesThis();
        int int3 = sideEffectFlags1.valueOf();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.setReturnsTainted();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("EOF\n", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)", 44);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        java.lang.String str8 = compilerInput5.getLine(48);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 48);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(runtimeException9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("eol");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        jSModuleGraph1.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule6, jSModule7);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.enableRuntimeTypeCheck("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions5.sourceMapDetailLevel = detailLevel8;
        compilerOptions0.sourceMapDetailLevel = detailLevel8;
        compilerOptions0.nameReferenceReportPath = "Node tree inequality:\nTree1:\nADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nTree2:\nEOF\n\n\nSubtree1: ADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nSubtree2: EOF\n";
        org.junit.Assert.assertNotNull(detailLevel8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        int int4 = ecmaError1.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.ideMode;
        compilerOptions0.setDefineToStringLiteral("hi!", "");
        boolean boolean11 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        node2.setJSType(jSType3);
        int int5 = node2.getSideEffectFlags();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(43, node2, 140, 45);
        node8.setType(43);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node14.setType(11);
        boolean boolean17 = node14.hasSideEffects();
        node8.addChildToBack(node14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.lineLengthThreshold(0);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode11 = compilerOptions0.tracer;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkShadowVars;
        boolean boolean13 = compilerOptions0.smartNameRemoval;
        boolean boolean14 = compilerOptions0.smartNameRemoval;
        compilerOptions0.removeDeadCode = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode11.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.exportProperty");
        java.lang.String str2 = evaluatorException1.toString();
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = evaluatorException1.getScriptStackTrace(filenameFilter3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "com.google.javascript.rhino.EvaluatorException: goog.exportProperty" + "'", str2.equals("com.google.javascript.rhino.EvaluatorException: goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        compilerOptions0.checkUnusedPropertiesEarly = true;
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test464");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        double double4 = loggerErrorManager2.getTypedPercent();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("()");
        int int2 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        java.lang.String str2 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        try {
            com.google.javascript.rhino.Context.reportWarning("COLONCOLON", "(): name", 27, "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) 1.0f);
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.collapseVariableDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        jSModuleGraph2.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph2.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.reportPath = "error reporter";
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getAbstractMethodName();
        java.lang.String str11 = closureCodingConvention7.getExportPropertyFunction();
        boolean boolean13 = closureCodingConvention7.isConstant("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention7.applySubclassRelationship(functionType14, functionType15, subclassType16);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention7);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str24 = node20.toString(true, false, true);
        com.google.javascript.rhino.Node node25 = node20.getFirstChild();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        com.google.javascript.rhino.Node node36 = node20.clonePropsFrom(node27);
        boolean boolean37 = closureCodingConvention7.isOptionalParameter(node27);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        try {
            boolean boolean48 = closureCodingConvention7.isPropertyTestFunction(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "EOF" + "'", str24.equals("EOF"));
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.removeEmptyFunctions = true;
        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
        compiler1.initOptions(compilerOptions2);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler1.getErrors();
        java.lang.String str10 = compiler1.toSource();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getMessages();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray11);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState21 = compiler1.getState();
        boolean boolean22 = compiler1.isTypeCheckingEnabled();
        boolean boolean23 = compiler1.hasErrors();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(intermediateState21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        boolean boolean8 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.SourceMap.Format format9 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format9;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        boolean boolean7 = compilerOptions0.disambiguateProperties;
        boolean boolean8 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.removeEmptyFunctions = true;
        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
        compiler1.initOptions(compilerOptions2);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions2.anonymousFunctionNaming = anonymousFunctionNamingPolicy9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.checkControlStructures;
        compilerOptions11.setRemoveClosureAsserts(false);
        compilerOptions11.setTweakToBooleanLiteral("", false);
        java.lang.String str18 = compilerOptions11.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap19 = compilerOptions11.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode20 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions11.tracer = tracerMode20;
        compilerOptions2.tracer = tracerMode20;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(cssRenamingMap19);
        org.junit.Assert.assertTrue("'" + tracerMode20 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode20.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportSymbolFunction();
        boolean boolean5 = closureCodingConvention0.isConstantKey("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", false);
        java.lang.String str4 = compilerInput3.getName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, false, false);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node1.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor7 = ancestorIterable6.iterator();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertNotNull(nodeItor7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = null;
        compiler3.tracker = performanceTracker4;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str10 = jSSourceFile8.getLine((int) (short) 100);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray11 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8 };
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19, false);
        java.lang.String str22 = jSSourceFile19.getName();
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset24);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region36 = jSSourceFile34.getRegion(26);
        java.lang.String str37 = jSSourceFile34.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str41 = jSSourceFile40.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray42 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile16, jSSourceFile19, jSSourceFile25, jSSourceFile28, jSSourceFile34, jSSourceFile40 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45, false);
        java.lang.String str48 = jSSourceFile45.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45);
        java.lang.String str50 = compilerInput49.getName();
        java.io.PrintStream printStream51 = null;
        com.google.javascript.jscomp.Compiler compiler52 = new com.google.javascript.jscomp.Compiler(printStream51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions53.inlineConstantVars = false;
        compilerOptions53.instrumentationTemplate = "eof";
        boolean boolean58 = compilerOptions53.moveFunctionDeclarations;
        compiler52.initOptions(compilerOptions53);
        compilerInput49.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler52);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile63 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region65 = jSSourceFile63.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray66 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions67.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy70 = compilerOptions67.variableRenaming;
        com.google.javascript.jscomp.Result result71 = compiler52.compile(jSSourceFile63, jSModuleArray66, compilerOptions67);
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions72.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler75 = null;
        compilerOptions72.setAliasTransformationHandler(aliasTransformationHandler75);
        com.google.javascript.jscomp.Result result77 = compiler13.compile(jSSourceFileArray42, jSModuleArray66, compilerOptions72);
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean79 = compilerOptions78.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig80 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions78);
        compiler3.init(jSSourceFileArray11, jSSourceFileArray42, compilerOptions78);
        com.google.javascript.jscomp.MessageFormatter messageFormatter83 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, true);
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider84 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter86 = errorFormat0.toFormatter(sourceExcerptProvider84, false);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(jSSourceFileArray11);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(region36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray42);
        org.junit.Assert.assertNotNull(jSSourceFile45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSSourceFile63);
        org.junit.Assert.assertNull(region65);
        org.junit.Assert.assertNotNull(jSModuleArray66);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy70 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy70.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result71);
        org.junit.Assert.assertNotNull(result77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(messageFormatter83);
        org.junit.Assert.assertNotNull(messageFormatter86);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("goog.exportProperty", "JSC_OPTIMIZE_LOOP_ERROR", 36);
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = evaluatorException3.getScriptStackTrace(filenameFilter4);
        try {
            evaluatorException3.initSourceName("COLONCOLON");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node10 = node5.removeFirstChild();
        try {
            boolean boolean11 = node10.isOptionalArg();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(node10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node26 = node20.copyInformationFromForTree(node25);
        try {
            com.google.javascript.rhino.Node node28 = node26.getChildAtIndex(13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.JsAst jsAst46 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.jscomp.SourceFile sourceFile47 = jsAst46.getSourceFile();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(sourceFile47);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        boolean boolean6 = nodeTraversal5.hasScope();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        node10.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node17.addChildrenToBack(node19);
        java.lang.Object obj22 = node19.getProp((int) (short) 100);
        int int24 = node19.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat26 = diagnosticType25.format;
        java.lang.String[] strArray32 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node19, diagnosticType25, strArray32);
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal5.makeError(node10, diagnosticType14, strArray32);
        com.google.javascript.rhino.Node node35 = nodeTraversal5.getCurrentNode();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(messageFormat26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNull(node35);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test487");
//        java.lang.Object obj0 = null;
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean3 = closureCodingConvention1.isValidEnumKey("error reporter");
//        java.lang.String str4 = closureCodingConvention1.getAbstractMethodName();
//        java.lang.String str5 = closureCodingConvention1.getExportPropertyFunction();
//        boolean boolean7 = closureCodingConvention1.isConstant("goog.exportProperty");
//        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType10 = null;
//        closureCodingConvention1.applySubclassRelationship(functionType8, functionType9, subclassType10);
//        boolean boolean13 = closureCodingConvention1.isSuperClassReference("");
//        com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter();
//        context14.addActivationName("TypeError: hi!");
//        java.util.Locale locale17 = null;
//        java.util.Locale locale18 = context14.setLocale(locale17);
//        boolean boolean20 = context14.isActivationNeeded("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n");
//        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError(obj0, (java.lang.Object) boolean13, (java.lang.Object) boolean20);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.abstractMethod" + "'", str4.equals("goog.abstractMethod"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(context14);
//        org.junit.Assert.assertNull(locale18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(runtimeException21);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean11 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        node15.setJSType(jSType16);
        int int18 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node22.setType(11);
        java.lang.String str25 = closureCodingConvention0.extractClassNameIfProvide(node15, node22);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node27.addChildrenToBack(node29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node29.setJSType(jSType31);
        boolean boolean33 = node29.isQuotedString();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int36 = node35.getLineno();
        java.lang.String str37 = closureCodingConvention0.extractClassNameIfProvide(node29, node35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkProvides;
        compilerOptions0.exportTestFunctions = false;
        java.util.List<java.lang.String> strList8 = null;
        try {
            compilerOptions0.setManageClosureDependencies(strList8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node3.setType(11);
        boolean boolean6 = node3.hasSideEffects();
        boolean boolean7 = node3.isUnscopedQualifiedName();
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node3.setJSType(jSType8);
        boolean boolean10 = node3.hasOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, "Named type with empty name component", true);
        java.lang.String str10 = compilerInput5.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.MessageBundle messageBundle3 = compilerOptions0.messageBundle;
        compilerOptions0.setGenerateExports(true);
        java.lang.String[] strArray42 = new java.lang.String[] { "()", "goog.exportProperty", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)", "Exceeded max number of optimization iterations: TypeError: hi!", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "EOF", "goog.abstractMethod", "goog.exportProperty", "COLONCOLON", "Exceeded max number of optimization iterations: TypeError: hi!", "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR", "JSC_OPTIMIZE_LOOP_ERROR", "NUMBER 10.0 48", "language version", "com.google.javascript.rhino.EcmaError: TypeError: hi!", "DiagnosticGroup<uselessCode>(OFF)", "", "<unknown=160>", "com.google.javascript.rhino.EcmaError: TypeError: hi!", "eol", "goog.exportProperty", "com.google.javascript.rhino.EvaluatorException: goog.exportProperty", "getprop", "com.google.javascript.rhino.EcmaError: TypeError: hi!", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)", "TypeError: hi!", "Named type with empty name component", "error reporter", "Named type with empty name component", "eol", "goog.global", "EOF [synthetic: 1]", "com.google.javascript.rhino.EcmaError: TypeError: hi!", "or" };
        java.util.LinkedHashSet<java.lang.String> strSet43 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet43, strArray42);
        compilerOptions0.aliasableStrings = strSet43;
        org.junit.Assert.assertNull(messageBundle3);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        node2.setJSType(jSType3);
        boolean boolean5 = node2.isVarArgs();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        boolean boolean11 = node2.hasChild(node7);
        boolean boolean12 = node7.isUnscopedQualifiedName();
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.disabled("error reporter", "TypeError");
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel18, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel21 = diagnosticType20.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel23, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType25.defaultLevel;
        int int27 = diagnosticType20.compareTo(diagnosticType25);
        java.lang.String[] strArray28 = null;
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("(EOF\n)", node7, checkLevel16, diagnosticType25, strArray28);
        com.google.javascript.jscomp.CheckLevel checkLevel30 = diagnosticType25.level;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNull(checkLevel21);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNull(checkLevel26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNull(checkLevel30);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean4 = compilerOptions0.checkUnusedPropertiesEarly;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.prettyPrint = false;
        boolean boolean8 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.reportPath = "error reporter";
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getAbstractMethodName();
        java.lang.String str11 = closureCodingConvention7.getExportPropertyFunction();
        boolean boolean13 = closureCodingConvention7.isConstant("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention7.applySubclassRelationship(functionType14, functionType15, subclassType16);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention7);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str24 = node20.toString(true, false, true);
        com.google.javascript.rhino.Node node25 = node20.getFirstChild();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        com.google.javascript.rhino.Node node36 = node20.clonePropsFrom(node27);
        boolean boolean37 = closureCodingConvention7.isOptionalParameter(node27);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        node43.addSuppression("Unknown class name");
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = node43.getJSDocInfo();
        node27.setJSDocInfo(jSDocInfo50);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "EOF" + "'", str24.equals("EOF"));
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(jSDocInfo50);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node1.setJSType(jSType4);
        java.lang.String str6 = node1.getQualifiedName();
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode9;
        boolean boolean11 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        boolean boolean7 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.aliasExternals = false;
        boolean boolean10 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }
}

