import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        boolean boolean7 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node12 = null;
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node15.addChildrenToBack(node17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node17.setJSType(jSType19);
        boolean boolean21 = node17.hasSideEffects();
        java.lang.String str22 = closureCodingConvention0.identifyTypeDefAssign(node17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test003");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
//        compilerOptions2.anonymousFunctionNaming = anonymousFunctionNamingPolicy9;
//        compilerOptions2.setShadowVariables(false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        boolean boolean11 = node1.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node13.addChildrenToBack(node15);
        boolean boolean17 = node15.isLocalResultCall();
        int int18 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str25 = node21.toString(true, false, true);
        com.google.javascript.rhino.Node node26 = node21.getFirstChild();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node30.addChildrenToBack(node32);
        java.lang.Object obj35 = node32.getProp((int) (short) 100);
        java.lang.String str36 = node28.checkTreeEquals(node32);
        com.google.javascript.rhino.Node node37 = node21.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        node39.setLineno(47);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node53.addChildrenToBack(node55);
        java.lang.Object obj58 = node55.getProp((int) (short) 100);
        java.lang.String str59 = node51.checkTreeEquals(node55);
        int int60 = node51.getSourcePosition();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node37, node39, node51, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(21, nodeArray63);
        com.google.javascript.rhino.Node node65 = node15.copyInformationFromForTree(node64);
        node64.setVarArgs(true);
        com.google.javascript.rhino.jstype.JSType jSType68 = node64.getJSType();
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node70.addChildrenToBack(node72);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str79 = node75.toString(true, false, true);
        com.google.javascript.rhino.Node node80 = node75.getFirstChild();
        com.google.javascript.rhino.Node node81 = node70.copyInformationFromForTree(node75);
        node64.addChildToFront(node75);
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node(140);
        java.lang.String str88 = node84.toString(true, true, false);
        try {
            node1.addChildBefore(node64, node84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "EOF" + "'", str25.equals("EOF"));
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str36.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str59.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(jSType68);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "EOF" + "'", str79.equals("EOF"));
        org.junit.Assert.assertNull(node80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "COLONCOLON" + "'", str88.equals("COLONCOLON"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        boolean boolean8 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.SourceMap.Format format9 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format9;
        compilerOptions0.nameReferenceGraphPath = "Not declared as a type name";
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(format9);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, false);
//        java.lang.String str11 = jSSourceFile8.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
//        java.lang.String str13 = compilerInput12.getName();
//        java.io.PrintStream printStream14 = null;
//        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions16.inlineConstantVars = false;
//        compilerOptions16.instrumentationTemplate = "eof";
//        boolean boolean21 = compilerOptions16.moveFunctionDeclarations;
//        compiler15.initOptions(compilerOptions16);
//        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region28 = jSSourceFile26.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions30.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy33 = compilerOptions30.variableRenaming;
//        com.google.javascript.jscomp.Result result34 = compiler15.compile(jSSourceFile26, jSModuleArray29, compilerOptions30);
//        compilerInput4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile26);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str39 = jSSourceFile38.toString();
//        compilerInput4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(sourceFile5);
//        org.junit.Assert.assertNotNull(jSSourceFile8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile26);
//        org.junit.Assert.assertNull(region28);
//        org.junit.Assert.assertNotNull(jSModuleArray29);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy33 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy33.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result34);
//        org.junit.Assert.assertNotNull(jSSourceFile38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("<No stack trace available>", "goog.global");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node4.addChildrenToBack(node6);
//        java.lang.Object obj9 = node6.getProp((int) (short) 100);
//        java.lang.String str10 = node2.checkTreeEquals(node6);
//        node6.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = node6.getJSDocInfo();
//        context0.removeThreadLocal((java.lang.Object) node6);
//        boolean boolean15 = node6.isVarArgs();
//        boolean boolean16 = node6.isOptionalArg();
//        com.google.javascript.rhino.jstype.JSType jSType17 = null;
//        node6.setJSType(jSType17);
//        java.lang.String str19 = node6.toStringTree();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str10.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EOF [jsdoc_info: JSDocInfo]\n" + "'", str19.equals("EOF [jsdoc_info: JSDocInfo]\n"));
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.allowLegacyJsMessages = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.removeEmptyFunctions = true;
        java.lang.String str14 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions11);
        boolean boolean15 = compilerOptions11.removeUnusedPrototypePropertiesInExterns;
        boolean boolean16 = compilerOptions11.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel17 = null;
        compilerOptions11.sourceMapDetailLevel = detailLevel17;
        compilerOptions11.inlineLocalFunctions = false;
        java.lang.String[] strArray28 = new java.lang.String[] { "JSC_OPTIMIZE_LOOP_ERROR", "eol", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "EOF [synthetic: 1]", ": hi!", "Named type with empty name component", "goog.exportSymbol" };
        java.util.ArrayList<java.lang.String> strList29 = new java.util.ArrayList<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList29, strArray28);
        compilerOptions11.setManageClosureDependencies((java.util.List<java.lang.String>) strList29);
        compilerOptions0.setReplaceStringsConfiguration("Exceeded max number of optimization iterations: TypeError: hi!", (java.util.List<java.lang.String>) strList29);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        int int6 = node1.getSourcePosition();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getExportPropertyFunction();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = closureCodingConvention7.isOptionalParameter(node12);
        boolean boolean18 = closureCodingConvention7.isExported("");
        boolean boolean21 = closureCodingConvention7.isExported("", true);
        com.google.javascript.rhino.Node node22 = null;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str28 = closureCodingConvention7.extractClassNameIfProvide(node22, node27);
        boolean boolean30 = closureCodingConvention7.isConstantKey("goog.exportSymbol");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention31 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean33 = closureCodingConvention31.isValidEnumKey("error reporter");
        java.lang.String str34 = closureCodingConvention31.getExportPropertyFunction();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        node36.setJSType(jSType37);
        boolean boolean39 = node36.isVarArgs();
        boolean boolean40 = closureCodingConvention31.isOptionalParameter(node36);
        boolean boolean42 = closureCodingConvention31.isExported("");
        boolean boolean45 = closureCodingConvention31.isExported("", true);
        com.google.javascript.rhino.Node node46 = null;
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str52 = closureCodingConvention31.extractClassNameIfProvide(node46, node51);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str58 = node54.toString(false, true, false);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        node60.setJSType(jSType61);
        boolean boolean63 = node60.isVarArgs();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        node65.setJSType(jSType66);
        boolean boolean68 = node65.isVarArgs();
        boolean boolean69 = node60.hasChild(node65);
        node60.removeProp(2);
        node54.addChildToFront(node60);
        boolean boolean73 = closureCodingConvention31.isOptionalParameter(node54);
        java.lang.String str74 = closureCodingConvention7.getSingletonGetterClassName(node54);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention75 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean77 = closureCodingConvention75.isValidEnumKey("error reporter");
        boolean boolean79 = closureCodingConvention75.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType80 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType81 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType82 = null;
        closureCodingConvention75.applySubclassRelationship(functionType80, functionType81, subclassType82);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean88 = closureCodingConvention75.isVarArgsParameter(node87);
        boolean boolean89 = closureCodingConvention7.isOptionalParameter(node87);
        boolean boolean90 = node1.isEquivalentTo(node87);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags92 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags92.setMutatesThis();
        int int94 = sideEffectFlags92.valueOf();
        try {
            node87.setSideEffectFlags(sideEffectFlags92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "goog.exportProperty" + "'", str34.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "EOF" + "'", str58.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 8 + "'", int94 == 8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        java.lang.String str8 = compilerInput5.getLine(48);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput9, false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int3 = node2.getLineno();
        node2.putBooleanProp(26, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(25, "goog.exportProperty", (int) (byte) 0, 31);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(9, node2, node11, 12, 48);
        node14.setType((int) (short) 10);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("goog.exportProperty", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.checkUndefinedProperties = checkLevel6;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        boolean boolean9 = compilerOptions2.checkTypedPropertyCalls;
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        try {
            com.google.javascript.rhino.Context.reportWarning("com.google.javascript.rhino.EcmaError: TypeError: hi!", "(): name", 1, "Named type with empty name component", 130);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.appNameStr;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean9 = compilerOptions0.inlineFunctions;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) ' ');
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        boolean boolean7 = compilerInput5.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.optimizeArgumentsArray = true;
        boolean boolean9 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        int int10 = node5.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat12 = diagnosticType11.format;
        java.lang.String[] strArray18 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node5, diagnosticType11, strArray18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        node21.setJSType(jSType22);
        int int24 = node21.getSideEffectFlags();
        com.google.javascript.rhino.Node node25 = node21.cloneNode();
        node25.setVarArgs(true);
        try {
            com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(0, node5, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(messageFormat12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(12, node5, 43, 160);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable11 = node10.getAncestors();
        boolean boolean12 = node10.isUnscopedQualifiedName();
        boolean boolean13 = node8.isEquivalentTo(node10);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(ancestorIterable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, false, false);
        node1.detachChildren();
        int int7 = node1.getSourcePosition();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setPropertyAffinity(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler14 = null;
        compilerOptions11.setAliasTransformationHandler(aliasTransformationHandler14);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions11.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy17);
        compilerOptions11.ignoreCajaProperties = false;
        java.util.Set<java.lang.String> strSet21 = compilerOptions11.aliasableStrings;
        node1.setDirectives(strSet21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
        org.junit.Assert.assertNotNull(strSet21);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test027");
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node4.addChildrenToBack(node6);
//        java.lang.Object obj9 = node6.getProp((int) (short) 100);
//        java.lang.String str10 = node2.checkTreeEquals(node6);
//        node6.addSuppression("Unknown class name");
//        boolean boolean13 = node6.isOnlyModifiesThisCall();
//        node6.setVarArgs(false);
//        com.google.javascript.rhino.Node node16 = node6.cloneTree();
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
//        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(12, node22, 43, 160);
//        com.google.javascript.rhino.Context context26 = com.google.javascript.rhino.Context.enter();
//        long long27 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context26);
//        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
//        context26.removeThreadLocal((java.lang.Object) node29);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention31 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean33 = closureCodingConvention31.isValidEnumKey("error reporter");
//        boolean boolean35 = closureCodingConvention31.isPrivate("eof");
//        com.google.javascript.rhino.jstype.FunctionType functionType36 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType38 = null;
//        closureCodingConvention31.applySubclassRelationship(functionType36, functionType37, subclassType38);
//        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
//        boolean boolean44 = closureCodingConvention31.isVarArgsParameter(node43);
//        com.google.javascript.rhino.Node node45 = null;
//        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        int int49 = node47.getIntProp(2);
//        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
//        boolean boolean55 = node54.isOptionalArg();
//        boolean boolean56 = node54.isLocalResultCall();
//        boolean boolean57 = node47.isEquivalentToTyped(node54);
//        java.lang.String str58 = closureCodingConvention31.extractClassNameIfProvide(node45, node47);
//        com.google.javascript.rhino.Context context59 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node63.addChildrenToBack(node65);
//        java.lang.Object obj68 = node65.getProp((int) (short) 100);
//        java.lang.String str69 = node61.checkTreeEquals(node65);
//        node65.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo72 = node65.getJSDocInfo();
//        context59.removeThreadLocal((java.lang.Object) node65);
//        java.lang.String str74 = closureCodingConvention31.identifyTypeDefAssign(node65);
//        boolean boolean75 = node29.isEquivalentTo(node65);
//        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node29.addChildrenToBack(node77);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention79 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node81.addChildrenToBack(node83);
//        java.lang.Object obj86 = node83.getProp((int) (short) 100);
//        boolean boolean87 = closureCodingConvention79.isVarArgsParameter(node83);
//        try {
//            com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node(13, node16, node22, node77, node83, (int) (short) 100, 40);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str10.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNotNull(context26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(node43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(node54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNull(str58);
//        org.junit.Assert.assertNotNull(context59);
//        org.junit.Assert.assertNotNull(node61);
//        org.junit.Assert.assertNull(obj68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str69.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo72);
//        org.junit.Assert.assertNull(str74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNull(obj86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, false);
//        java.lang.String str11 = jSSourceFile8.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
//        java.lang.String str13 = compilerInput12.getName();
//        java.io.PrintStream printStream14 = null;
//        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions16.inlineConstantVars = false;
//        compilerOptions16.instrumentationTemplate = "eof";
//        boolean boolean21 = compilerOptions16.moveFunctionDeclarations;
//        compiler15.initOptions(compilerOptions16);
//        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region28 = jSSourceFile26.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions30.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy33 = compilerOptions30.variableRenaming;
//        com.google.javascript.jscomp.Result result34 = compiler15.compile(jSSourceFile26, jSModuleArray29, compilerOptions30);
//        compilerInput4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile26);
//        java.lang.String str36 = compilerInput4.getCode();
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNotNull(sourceFile5);
//        org.junit.Assert.assertNotNull(jSSourceFile8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile26);
//        org.junit.Assert.assertNull(region28);
//        org.junit.Assert.assertNotNull(jSModuleArray29);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy33 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy33.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        boolean boolean6 = nodeTraversal5.hasScope();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        node10.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node17.addChildrenToBack(node19);
        java.lang.Object obj22 = node19.getProp((int) (short) 100);
        int int24 = node19.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat26 = diagnosticType25.format;
        java.lang.String[] strArray32 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node19, diagnosticType25, strArray32);
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal5.makeError(node10, diagnosticType14, strArray32);
        boolean boolean35 = nodeTraversal5.hasScope();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(messageFormat26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap31 = compilerOptions21.customPasses;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions32.inlineConstantVars = false;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel35 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
//        compilerOptions32.sourceMapDetailLevel = detailLevel35;
//        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions32.checkMissingGetCssNameLevel;
//        compilerOptions21.aggressiveVarCheck = checkLevel37;
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNull(customPassExecutionTimeMultimap31);
//        org.junit.Assert.assertNotNull(detailLevel35);
//        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.setRemoveAbstractMethods(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.abstractMethod", generator1);
        try {
            java.lang.String str4 = jSSourceFile2.getLine(120);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str4 = jSSourceFile2.getLine((int) (short) 100);
        jSSourceFile2.clearCachedSource();
        java.lang.String str7 = jSSourceFile2.getLine(0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        boolean boolean5 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        boolean boolean8 = compilerOptions0.closurePass;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.jsOutputFile = "goog.abstractMethod";
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("(): name", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        java.util.logging.Logger logger0 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
//        compiler2.tracker = performanceTracker3;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str9 = jSSourceFile7.getLine((int) (short) 100);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7 };
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18, false);
//        java.lang.String str21 = jSSourceFile18.getName();
//        java.nio.charset.Charset charset23 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset23);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region35 = jSSourceFile33.getRegion(26);
//        java.lang.String str36 = jSSourceFile33.getName();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str40 = jSSourceFile39.toString();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile24, jSSourceFile27, jSSourceFile33, jSSourceFile39 };
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
//        java.lang.String str47 = jSSourceFile44.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
//        java.lang.String str49 = compilerInput48.getName();
//        java.io.PrintStream printStream50 = null;
//        com.google.javascript.jscomp.Compiler compiler51 = new com.google.javascript.jscomp.Compiler(printStream50);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions52.inlineConstantVars = false;
//        compilerOptions52.instrumentationTemplate = "eof";
//        boolean boolean57 = compilerOptions52.moveFunctionDeclarations;
//        compiler51.initOptions(compilerOptions52);
//        compilerInput48.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler51);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region64 = jSSourceFile62.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray65 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions66.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy69 = compilerOptions66.variableRenaming;
//        com.google.javascript.jscomp.Result result70 = compiler51.compile(jSSourceFile62, jSModuleArray65, compilerOptions66);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions71.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler74 = null;
//        compilerOptions71.setAliasTransformationHandler(aliasTransformationHandler74);
//        com.google.javascript.jscomp.Result result76 = compiler12.compile(jSSourceFileArray41, jSModuleArray65, compilerOptions71);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean78 = compilerOptions77.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig79 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions77);
//        compiler2.init(jSSourceFileArray10, jSSourceFileArray41, compilerOptions77);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter81 = null;
//        java.util.logging.Logger logger82 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager83 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter81, logger82);
//        int int84 = loggerErrorManager83.getErrorCount();
//        com.google.javascript.jscomp.JSError[] jSErrorArray85 = loggerErrorManager83.getWarnings();
//        loggerErrorManager83.generateReport();
//        compiler2.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager83);
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(jSSourceFileArray10);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile24);
//        org.junit.Assert.assertNotNull(jSSourceFile27);
//        org.junit.Assert.assertNotNull(jSSourceFile33);
//        org.junit.Assert.assertNull(region35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFileArray41);
//        org.junit.Assert.assertNotNull(jSSourceFile44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile62);
//        org.junit.Assert.assertNull(region64);
//        org.junit.Assert.assertNotNull(jSModuleArray65);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy69 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy69.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result70);
//        org.junit.Assert.assertNotNull(result76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//        org.junit.Assert.assertNotNull(jSErrorArray85);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
        node1.setSourcePositionForTree(52);
        org.junit.Assert.assertNotNull(node1);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.inlineConstantVars = false;
//        com.google.javascript.jscomp.MessageBundle messageBundle3 = compilerOptions0.messageBundle;
//        boolean boolean4 = compilerOptions0.optimizeArgumentsArray;
//        java.io.PrintStream printStream5 = null;
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean19 = compilerOptions18.checkControlStructures;
//        compilerOptions18.setRemoveClosureAsserts(false);
//        compilerOptions18.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result25 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions18);
//        compilerOptions18.generatePseudoNames = false;
//        boolean boolean28 = compilerOptions18.removeUnusedVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions18.brokenClosureRequiresLevel;
//        compilerOptions18.checkTypedPropertyCalls = true;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions32.inlineConstantVars = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions32.aggressiveVarCheck;
//        compilerOptions18.checkUndefinedProperties = checkLevel35;
//        compilerOptions0.aggressiveVarCheck = checkLevel35;
//        boolean boolean38 = compilerOptions0.inlineGetters;
//        org.junit.Assert.assertNull(messageBundle3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile9);
//        org.junit.Assert.assertNotNull(jSSourceFileArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(result25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.specializeInitialModule = true;
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean7 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Unknown class name");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        java.lang.Object obj9 = null;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, obj9);
        java.lang.String str11 = compilerOptions0.locale;
        boolean boolean12 = compilerOptions0.smartNameRemoval;
        compilerOptions0.enableRuntimeTypeCheck("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n");
        java.lang.String str15 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) 1.0f);
        compilerOptions0.reserveRawExports = false;
        boolean boolean10 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.inferTypesInGlobalScope = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.setMutatesGlobalState();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager2.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = loggerErrorManager2.getWarnings();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray5);
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("Named type with empty name component", false);
        boolean boolean17 = closureCodingConvention0.isPrivate("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler2.tracker = performanceTracker3;
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder5 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str6 = codeBuilder5.toString();
        int int7 = codeBuilder5.getLength();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node10.addChildrenToBack(node12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str19 = node15.toString(true, false, true);
        com.google.javascript.rhino.Node node20 = node15.getFirstChild();
        com.google.javascript.rhino.Node node21 = node10.copyInformationFromForTree(node15);
        boolean boolean22 = node10.isOptionalArg();
        try {
            compiler2.toSource(codeBuilder5, 5, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EOF" + "'", str19.equals("EOF"));
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = compilerOptions0.propertyRenaming;
        boolean boolean4 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
//        java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean9 = compilerOptions8.checkControlStructures;
//        compilerOptions8.setRemoveClosureAsserts(false);
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy12 = compilerOptions8.anonymousFunctionNaming;
//        boolean boolean13 = compilerOptions8.checkUnusedPropertiesEarly;
//        compilerOptions8.collapseProperties = true;
//        compilerOptions8.decomposeExpressions = false;
//        compilerOptions8.checkCaja = false;
//        context0.seal((java.lang.Object) compilerOptions8);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy12 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy12.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        boolean boolean5 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.nameReferenceGraphPath = "Node tree inequality:\nTree1:\nADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nTree2:\nEOF\n\n\nSubtree1: ADD 0\n    EOF\n    NUMBER -1.0 47\n    NUMBER -1.0\n    NUMBER -2.0\n\n\nSubtree2: EOF\n";
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        compilerOptions0.aliasableGlobals = "error reporter";
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test053");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        compilerOptions2.crossModuleCodeMotion = true;
//        boolean boolean11 = compilerOptions2.aliasExternals;
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.removeEmptyFunctions = true;
        compilerOptions7.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions7.checkSymbols = false;
        boolean boolean14 = compilerOptions7.checkTypes;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler15 = compilerOptions7.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        boolean boolean6 = nodeTraversal5.hasScope();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        node10.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node17.addChildrenToBack(node19);
        java.lang.Object obj22 = node19.getProp((int) (short) 100);
        int int24 = node19.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat26 = diagnosticType25.format;
        java.lang.String[] strArray32 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node19, diagnosticType25, strArray32);
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal5.makeError(node10, diagnosticType14, strArray32);
        com.google.javascript.jscomp.Scope scope35 = nodeTraversal5.getScope();
        java.lang.String str36 = nodeTraversal5.getSourceName();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        boolean boolean39 = node38.isVarArgs();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node38 };
        try {
            nodeTraversal5.traverseRoots(nodeArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(messageFormat26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNull(scope35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeArray40);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        boolean boolean1 = context0.isGeneratingDebugChanged();
        int int2 = context0.getOptimizationLevel();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        com.google.javascript.rhino.Context context4 = com.google.javascript.rhino.Context.enter(context0);
        try {
            context0.setLanguageVersion(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(errorReporter3);
        org.junit.Assert.assertNotNull(context4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions6);
        boolean boolean9 = compilerOptions6.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions6.errorFormat = errorFormat10;
        java.lang.String str12 = compilerOptions6.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions6.checkMissingReturn;
        compilerOptions0.reportUnknownTypes = checkLevel13;
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        java.lang.String str4 = jSSourceFile2.getOriginalPath();
        java.lang.String str5 = jSSourceFile2.toString();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        java.lang.Object obj9 = null;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, obj9);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.aggressiveVarCheck;
        boolean boolean12 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.convertToDottedProperties = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportSymbol", "");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions1.aggressiveVarCheck;
        boolean boolean5 = compilerOptions1.printInputDelimiter;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions1.checkProvides;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel6);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        java.lang.String str2 = compiler1.getAstDotGraph();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
//        java.lang.String str13 = jSSourceFile10.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
//        java.lang.String str15 = compilerInput14.getName();
//        java.io.PrintStream printStream16 = null;
//        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions18.inlineConstantVars = false;
//        compilerOptions18.instrumentationTemplate = "eof";
//        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
//        compiler17.initOptions(compilerOptions18);
//        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions32.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
//        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions37.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
//        compilerOptions37.variableRenaming = variableRenamingPolicy40;
//        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
//        boolean boolean43 = compilerOptions37.labelRenaming;
//        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
//        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
//        com.google.javascript.jscomp.JsAst jsAst46 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        jsAst46.clearAst();
//        java.io.PrintStream printStream48 = null;
//        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler(printStream48);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions50.removeEmptyFunctions = true;
//        compilerOptions50.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean55 = compilerOptions50.deadAssignmentElimination;
//        compiler49.initOptions(compilerOptions50);
//        com.google.javascript.rhino.Node node57 = jsAst46.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler49);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile28);
//        org.junit.Assert.assertNull(region30);
//        org.junit.Assert.assertNotNull(jSModuleArray31);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result36);
//        org.junit.Assert.assertNotNull(strSet42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(result44);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(node57);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        compilerInput4.clearAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, false);
        com.google.javascript.jscomp.JSModule jSModule11 = null;
        compilerInput10.setModule(jSModule11);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.labelRenaming = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        boolean boolean6 = compilerOptions0.labelRenaming;
        compilerOptions0.rewriteFunctionExpressions = false;
        java.lang.String str9 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.flowSensitiveInlineVariables = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.lineLengthThreshold((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 43);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = context0.getErrorReporter();
//        int int8 = context0.getLanguageVersion();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNull(errorReporter7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        int int31 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str41 = jSSourceFile40.getOriginalPath();
//        java.lang.String str43 = jSSourceFile40.getLine(0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile34, jSSourceFile37, jSSourceFile40, jSSourceFile46, jSSourceFile51 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray53 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions54.inlineConstantVars = false;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel57 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
//        compilerOptions54.sourceMapDetailLevel = detailLevel57;
//        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing59 = compilerOptions54.getTweakProcessing();
//        compiler1.init(jSSourceFileArray52, jSModuleArray53, compilerOptions54);
//        java.io.PrintStream printStream61 = null;
//        com.google.javascript.jscomp.Compiler compiler62 = new com.google.javascript.jscomp.Compiler(printStream61);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput67 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile65, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray68 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile65 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList69 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList69, jSSourceFileArray68);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray71 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList72 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList72, jSModuleArray71);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean75 = compilerOptions74.checkControlStructures;
//        compilerOptions74.setRemoveClosureAsserts(false);
//        compilerOptions74.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result81 = compiler62.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList69, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList72, compilerOptions74);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray82 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList83 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean84 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList83, jSModuleArray82);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean86 = compilerOptions85.checkControlStructures;
//        compilerOptions85.setRemoveClosureAsserts(false);
//        compilerOptions85.setTweakToBooleanLiteral("", false);
//        java.lang.String str92 = compilerOptions85.instrumentationTemplate;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap93 = compilerOptions85.cssRenamingMap;
//        boolean boolean94 = compilerOptions85.crossModuleCodeMotion;
//        java.lang.String str95 = compilerOptions85.syntheticBlockEndMarker;
//        boolean boolean96 = compilerOptions85.checkTypedPropertyCalls;
//        compilerOptions85.foldConstants = false;
//        com.google.javascript.jscomp.Result result99 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList69, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList83, compilerOptions85);
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(jSSourceFile34);
//        org.junit.Assert.assertNotNull(jSSourceFile37);
//        org.junit.Assert.assertNotNull(jSSourceFile40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertNotNull(jSSourceFile46);
//        org.junit.Assert.assertNotNull(jSSourceFile51);
//        org.junit.Assert.assertNotNull(jSSourceFileArray52);
//        org.junit.Assert.assertNotNull(jSModuleArray53);
//        org.junit.Assert.assertNotNull(detailLevel57);
//        org.junit.Assert.assertTrue("'" + tweakProcessing59 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing59.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
//        org.junit.Assert.assertNotNull(jSSourceFile65);
//        org.junit.Assert.assertNotNull(jSSourceFileArray68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray71);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(result81);
//        org.junit.Assert.assertNotNull(jSModuleArray82);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNull(str92);
//        org.junit.Assert.assertNull(cssRenamingMap93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertNull(str95);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//        org.junit.Assert.assertNotNull(result99);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.lang.String str8 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.nameReferenceReportPath = "Not declared as a constructor";
        compilerOptions0.ideMode = true;
        compilerOptions0.reportPath = "EOF [jsdoc_info: JSDocInfo]\n";
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        java.lang.String str9 = node1.checkTreeEquals(node5);
        node5.addSuppression("Unknown class name");
        boolean boolean12 = node5.isOnlyModifiesThisCall();
        node5.setVarArgs(false);
        java.lang.Object obj16 = node5.getProp(37);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str9.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.smartNameRemoval;
        compilerOptions0.tightenTypes = true;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToStringLiteral("goog.exportProperty", "");
        compilerOptions0.generateExports = false;
        boolean boolean10 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.enableRuntimeTypeCheck("hi!");
        boolean boolean5 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.generatePseudoNames = true;
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node2.addChildrenToBack(node4);
//        java.lang.Object obj7 = node4.getProp((int) (short) 100);
//        int int9 = node4.getIntProp(0);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
//        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
//        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node4, diagnosticType10, strArray17);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions19.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = null;
//        compilerOptions19.variableRenaming = variableRenamingPolicy22;
//        java.util.Set<java.lang.String> strSet24 = compilerOptions19.stripNameSuffixes;
//        boolean boolean25 = compilerOptions19.labelRenaming;
//        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
//        compilerOptions19.reportMissingOverride = checkLevel26;
//        boolean boolean28 = jSError18.equals((java.lang.Object) compilerOptions19);
//        java.lang.String str29 = jSError18.sourceName;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean31 = compilerOptions30.checkControlStructures;
//        compilerOptions30.setRemoveClosureAsserts(false);
//        compilerOptions30.setTweakToBooleanLiteral("", false);
//        java.lang.String str37 = compilerOptions30.appNameStr;
//        compilerOptions30.skipAllCompilerPasses();
//        boolean boolean39 = compilerOptions30.inlineFunctions;
//        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions30.checkShadowVars;
//        com.google.javascript.jscomp.ErrorFormat errorFormat41 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream42 = null;
//        com.google.javascript.jscomp.Compiler compiler43 = new com.google.javascript.jscomp.Compiler(printStream42);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions44.inlineConstantVars = false;
//        compilerOptions44.instrumentationTemplate = "eof";
//        boolean boolean49 = compilerOptions44.moveFunctionDeclarations;
//        compiler43.initOptions(compilerOptions44);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter52 = errorFormat41.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler43, false);
//        java.util.logging.Logger logger53 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager54 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter52, logger53);
//        java.lang.String str55 = jSError18.format(checkLevel40, messageFormatter52);
//        java.util.logging.Logger logger56 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager57 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter52, logger56);
//        org.junit.Assert.assertNull(obj7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(diagnosticType10);
//        org.junit.Assert.assertNotNull(messageFormat11);
//        org.junit.Assert.assertNotNull(strArray17);
//        org.junit.Assert.assertNotNull(jSError18);
//        org.junit.Assert.assertNotNull(strSet24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Not declared as a constructor" + "'", str29.equals("Not declared as a constructor"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(errorFormat41);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(messageFormatter52);
//        org.junit.Assert.assertNull(str55);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, false);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        boolean boolean13 = compilerOptions0.checkEs5Strict;
        boolean boolean14 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        int int6 = node1.getSourcePosition();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node1.children();
        java.lang.Object obj9 = node1.getProp(140);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(nodeIterable7);
        org.junit.Assert.assertNull(obj9);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str5 = jSSourceFile2.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        java.lang.String str7 = compilerInput6.getName();
//        java.io.PrintStream printStream8 = null;
//        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
//        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
//        try {
//            java.lang.String[] strArray11 = compiler9.toSourceArray();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean11 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        node15.setJSType(jSType16);
        int int18 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node22.setType(11);
        java.lang.String str25 = closureCodingConvention0.extractClassNameIfProvide(node15, node22);
        int int26 = node15.getCharno();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        compilerOptions0.setPropertyAffinity(true);
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.jsOutputFile = "goog.global";
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        boolean boolean20 = compilerOptions13.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy21 = compilerOptions13.anonymousFunctionNaming;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy21;
        char[] charArray23 = anonymousFunctionNamingPolicy21.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy21 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy21.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray23);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        java.lang.String str2 = compiler1.getAstDotGraph();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
//        java.lang.String str13 = jSSourceFile10.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
//        java.lang.String str15 = compilerInput14.getName();
//        java.io.PrintStream printStream16 = null;
//        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions18.inlineConstantVars = false;
//        compilerOptions18.instrumentationTemplate = "eof";
//        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
//        compiler17.initOptions(compilerOptions18);
//        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions32.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
//        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions37.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
//        compilerOptions37.variableRenaming = variableRenamingPolicy40;
//        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
//        boolean boolean43 = compilerOptions37.labelRenaming;
//        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
//        int int45 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.JSModule jSModule46 = null;
//        try {
//            java.lang.String str47 = compiler1.toSource(jSModule46);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile28);
//        org.junit.Assert.assertNull(region30);
//        org.junit.Assert.assertNotNull(jSModuleArray31);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result36);
//        org.junit.Assert.assertNotNull(strSet42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(result44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        compilerOptions13.generatePseudoNames = false;
//        boolean boolean23 = compilerOptions13.removeUnusedVars;
//        java.util.Set<java.lang.String> strSet24 = compilerOptions13.aliasableStrings;
//        boolean boolean25 = compilerOptions13.inlineAnonymousFunctionExpressions;
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(strSet24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        boolean boolean3 = compilerOptions0.checkTypes;
        boolean boolean4 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.inlineConstantVars = false;
//        compilerOptions0.instrumentationTemplate = "eof";
//        boolean boolean5 = compilerOptions0.moveFunctionDeclarations;
//        compilerOptions0.convertToDottedProperties = false;
//        java.io.PrintStream printStream8 = null;
//        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions10.inlineConstantVars = false;
//        compilerOptions10.instrumentationTemplate = "eof";
//        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
//        compiler9.initOptions(compilerOptions10);
//        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMethods;
//        compilerOptions0.checkFunctions = checkLevel17;
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 43);
//        context0.setGeneratingSource(false);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((-2));
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        java.lang.String str5 = compilerOptions0.jsOutputFile;
        boolean boolean6 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.jstype.JSType jSType5 = node1.getJSType();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags7 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags7.clearAllFlags();
        try {
            node1.setSideEffectFlags(sideEffectFlags7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(jSType5);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        java.util.logging.Logger logger0 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
//        compiler2.tracker = performanceTracker3;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str9 = jSSourceFile7.getLine((int) (short) 100);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7 };
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18, false);
//        java.lang.String str21 = jSSourceFile18.getName();
//        java.nio.charset.Charset charset23 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset23);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region35 = jSSourceFile33.getRegion(26);
//        java.lang.String str36 = jSSourceFile33.getName();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str40 = jSSourceFile39.toString();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile24, jSSourceFile27, jSSourceFile33, jSSourceFile39 };
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
//        java.lang.String str47 = jSSourceFile44.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
//        java.lang.String str49 = compilerInput48.getName();
//        java.io.PrintStream printStream50 = null;
//        com.google.javascript.jscomp.Compiler compiler51 = new com.google.javascript.jscomp.Compiler(printStream50);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions52.inlineConstantVars = false;
//        compilerOptions52.instrumentationTemplate = "eof";
//        boolean boolean57 = compilerOptions52.moveFunctionDeclarations;
//        compiler51.initOptions(compilerOptions52);
//        compilerInput48.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler51);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region64 = jSSourceFile62.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray65 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions66.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy69 = compilerOptions66.variableRenaming;
//        com.google.javascript.jscomp.Result result70 = compiler51.compile(jSSourceFile62, jSModuleArray65, compilerOptions66);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions71.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler74 = null;
//        compilerOptions71.setAliasTransformationHandler(aliasTransformationHandler74);
//        com.google.javascript.jscomp.Result result76 = compiler12.compile(jSSourceFileArray41, jSModuleArray65, compilerOptions71);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean78 = compilerOptions77.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig79 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions77);
//        compiler2.init(jSSourceFileArray10, jSSourceFileArray41, compilerOptions77);
//        com.google.javascript.jscomp.Region region83 = compiler2.getSourceRegion("hi!", 1);
//        com.google.javascript.jscomp.SourceMap sourceMap84 = compiler2.getSourceMap();
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(jSSourceFileArray10);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile24);
//        org.junit.Assert.assertNotNull(jSSourceFile27);
//        org.junit.Assert.assertNotNull(jSSourceFile33);
//        org.junit.Assert.assertNull(region35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFileArray41);
//        org.junit.Assert.assertNotNull(jSSourceFile44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile62);
//        org.junit.Assert.assertNull(region64);
//        org.junit.Assert.assertNotNull(jSModuleArray65);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy69 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy69.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result70);
//        org.junit.Assert.assertNotNull(result76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNull(region83);
//        org.junit.Assert.assertNull(sourceMap84);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        context0.addActivationName("");
//        boolean boolean7 = context0.isGeneratingDebugChanged();
//        context0.addActivationName("goog.exportProperty");
//        com.google.javascript.rhino.Context context10 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger11 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
//        context10.removeThreadLocal((java.lang.Object) loggerErrorManager12);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context10, (long) 8);
//        com.google.javascript.rhino.Context context16 = com.google.javascript.rhino.Context.enter();
//        context16.addActivationName("TypeError: hi!");
//        java.util.Locale locale19 = context16.getLocale();
//        java.util.Locale locale20 = context10.setLocale(locale19);
//        java.util.Locale locale21 = context0.setLocale(locale19);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(context10);
//        org.junit.Assert.assertNotNull(context16);
//        org.junit.Assert.assertNotNull(locale19);
//        org.junit.Assert.assertNull(locale20);
//        org.junit.Assert.assertNull(locale21);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.MessageBundle messageBundle3 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(messageBundle3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node12 = null;
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        java.lang.String str16 = compiler15.getAstDotGraph();
        compiler15.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int23 = node21.getIntProp(2);
        java.lang.String str24 = node21.toString();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast25 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal19, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "EOF" + "'", str24.equals("EOF"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.appNameStr = "hi!";
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap5 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNotNull(strMap5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        java.lang.String str2 = diagnosticType0.key;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str2.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.setMutatesThis();
        int int9 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 29 + "'", int9 == 29);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean12 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getSourceName();
        java.lang.String str4 = ecmaError1.getLineSource();
        java.lang.String str5 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.inlineConstantVars = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
//        compilerOptions0.sourceMapOutputPath = "TypeError";
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup6;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions8.inlineConstantVars = false;
//        compilerOptions8.unaliasableGlobals = "";
//        compilerOptions8.generatePseudoNames = false;
//        boolean boolean15 = compilerOptions8.shouldColorizeErrorOutput();
//        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions8.checkMissingReturn;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel16);
//        compilerOptions0.checkProvides = checkLevel16;
//        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNull(diagnosticGroup6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = compilerOptions0.tracer;
        compilerOptions0.inlineVariables = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + tracerMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode8.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 8);
//        try {
//            com.google.javascript.rhino.Context context6 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        boolean boolean6 = nodeTraversal5.hasScope();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        node10.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node17.addChildrenToBack(node19);
        java.lang.Object obj22 = node19.getProp((int) (short) 100);
        int int24 = node19.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat26 = diagnosticType25.format;
        java.lang.String[] strArray32 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node19, diagnosticType25, strArray32);
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal5.makeError(node10, diagnosticType14, strArray32);
        com.google.javascript.jscomp.Scope scope35 = nodeTraversal5.getScope();
        try {
            com.google.javascript.rhino.Node node36 = nodeTraversal5.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(messageFormat26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNull(scope35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        compilerOptions0.inferTypesInGlobalScope = true;
        boolean boolean7 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        compilerOptions0.aliasableGlobals = "";
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkShadowVars;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripTypes;
        java.lang.String[] strArray13 = new java.lang.String[] { "Named type with empty name component" };
        java.util.ArrayList<java.lang.String> strList14 = new java.util.ArrayList<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList14, strArray13);
        compilerOptions0.setReplaceStringsConfiguration("<No stack trace available>", (java.util.List<java.lang.String>) strList14);
        com.google.javascript.jscomp.MessageBundle messageBundle17 = compilerOptions0.messageBundle;
        boolean boolean18 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(messageBundle17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        java.lang.Object obj9 = null;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, obj9);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.disabled("error reporter", "TypeError");
        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType14.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel15;
        compilerOptions0.renamePrefix = ": hi!";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        node17.setJSType(jSType18);
        boolean boolean20 = node17.isVarArgs();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        node22.setJSType(jSType23);
        boolean boolean25 = node22.isVarArgs();
        boolean boolean26 = node17.hasChild(node22);
        node17.removeProp(2);
        node17.setIsSyntheticBlock(false);
        java.lang.String str31 = closureCodingConvention0.identifyTypeDefAssign(node17);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection32 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str33 = closureCodingConvention0.getGlobalObject();
        java.lang.String str34 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.global" + "'", str33.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "goog.abstractMethod" + "'", str34.equals("goog.abstractMethod"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        int int55 = node50.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
        java.lang.String str65 = lightweightMessageFormatter45.formatError(jSError64);
        int int66 = jSError64.lineNumber;
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(messageFormat57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str65.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode9;
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        int int6 = node1.getSourcePosition();
        node1.setIsSyntheticBlock(true);
        java.lang.String str9 = node1.toString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        boolean boolean11 = node10.isOnlyModifiesThisCall();
        java.lang.String str12 = node10.getQualifiedName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "EOF [synthetic: 1]" + "'", str9.equals("EOF [synthetic: 1]"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setShadowVariables(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        compilerOptions0.errorFormat = errorFormat7;
        boolean boolean9 = compilerOptions0.removeUnusedVars;
        byte[] byteArray10 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap6);
        org.junit.Assert.assertNotNull(errorFormat7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(byteArray10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0, 28, 3);
        java.lang.String str4 = node3.toStringTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NUMBER 0.0 28\n" + "'", str4.equals("NUMBER 0.0 28\n"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("eof");
        boolean boolean7 = closureCodingConvention0.isSuperClassReference("TypeError: hi!");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node9.setJSType(jSType10);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node9.setJSType(jSType12);
        boolean boolean14 = closureCodingConvention0.isOptionalParameter(node9);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType17 = null;
        closureCodingConvention0.applySubclassRelationship(functionType15, functionType16, subclassType17);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node20.addChildrenToBack(node22);
        java.lang.Object obj25 = node22.getProp((int) (short) 100);
        node22.setType((int) ' ');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str35 = node31.toString(true, false, true);
        int int36 = node31.getSourcePosition();
        node31.setIsSyntheticBlock(true);
        node22.addChildAfter(node29, node31);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship40 = closureCodingConvention0.getClassesDefinedByCall(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "EOF" + "'", str35.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel1, "hi!");
        java.text.MessageFormat messageFormat4 = diagnosticType3.format;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(messageFormat4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        java.lang.String str7 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions8);
        boolean boolean11 = compilerOptions8.shouldColorizeErrorOutput();
        compilerOptions8.setShadowVariables(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap14 = compilerOptions8.cssRenamingMap;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        compilerOptions8.errorFormat = errorFormat15;
        compilerOptions0.errorFormat = errorFormat15;
        boolean boolean18 = compilerOptions0.aliasExternals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(cssRenamingMap14);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.removeEmptyFunctions = true;
        java.lang.String str8 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions5);
        boolean boolean9 = compilerOptions5.removeUnusedPrototypePropertiesInExterns;
        boolean boolean10 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = null;
        compilerOptions5.sourceMapDetailLevel = detailLevel11;
        compilerOptions5.inlineLocalFunctions = false;
        java.lang.String[] strArray22 = new java.lang.String[] { "JSC_OPTIMIZE_LOOP_ERROR", "eol", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "EOF [synthetic: 1]", ": hi!", "Named type with empty name component", "goog.exportSymbol" };
        java.util.ArrayList<java.lang.String> strList23 = new java.util.ArrayList<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList23, strArray22);
        compilerOptions5.setManageClosureDependencies((java.util.List<java.lang.String>) strList23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.removeEmptyFunctions = true;
        compilerOptions26.enableRuntimeTypeCheck("hi!");
        boolean boolean31 = compilerOptions26.removeTryCatchFinally;
        compilerOptions26.prettyPrint = false;
        java.lang.String str34 = compilerOptions26.syntheticBlockEndMarker;
        compilerOptions26.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel40 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions37.sourceMapDetailLevel = detailLevel40;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing42 = compilerOptions37.getTweakProcessing();
        compilerOptions26.setTweakProcessing(tweakProcessing42);
        compilerOptions5.setTweakProcessing(tweakProcessing42);
        compilerOptions0.setTweakProcessing(tweakProcessing42);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(detailLevel40);
        org.junit.Assert.assertTrue("'" + tweakProcessing42 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing42.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        compilerOptions10.instrumentationTemplate = "eof";
        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
        compiler9.initOptions(compilerOptions10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput30 = compiler9.newExternInput("COLONCOLON");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(region22);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        int int4 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.setThrows();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        boolean boolean3 = context0.isGeneratingDebug();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setThrows();
        boolean boolean5 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean12 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy13 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy13 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy13.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str15 = compilerInput14.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.inlineConstantVars = false;
        compilerOptions18.instrumentationTemplate = "eof";
        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
        compiler17.initOptions(compilerOptions18);
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
        compilerOptions37.variableRenaming = variableRenamingPolicy40;
        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
        boolean boolean43 = compilerOptions37.labelRenaming;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        int int55 = node50.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat57 = diagnosticType56.format;
        java.lang.String[] strArray63 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node50, diagnosticType56, strArray63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy68 = null;
        compilerOptions65.variableRenaming = variableRenamingPolicy68;
        java.util.Set<java.lang.String> strSet70 = compilerOptions65.stripNameSuffixes;
        boolean boolean71 = compilerOptions65.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel72 = null;
        compilerOptions65.reportMissingOverride = checkLevel72;
        boolean boolean74 = jSError64.equals((java.lang.Object) compilerOptions65);
        java.lang.String str75 = jSError64.sourceName;
        java.lang.String str76 = lightweightMessageFormatter45.formatError(jSError64);
        java.lang.String str77 = jSError64.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNull(region30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertNotNull(strSet42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(messageFormat57);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "Not declared as a constructor" + "'", str75.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n" + "'", str76.equals("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n"));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)" + "'", str77.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        java.lang.String str4 = ecmaError1.sourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        node3.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean6 = closureCodingConvention0.isConstant("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType9 = null;
        closureCodingConvention0.applySubclassRelationship(functionType7, functionType8, subclassType9);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType13 = null;
        closureCodingConvention0.applySubclassRelationship(functionType11, functionType12, subclassType13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getErrors();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig7 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions5);
        boolean boolean8 = compilerOptions5.convertToDottedProperties;
        compilerOptions5.setChainCalls(false);
        java.lang.String str11 = compilerOptions5.nameReferenceReportPath;
        boolean boolean12 = compilerOptions5.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions5.checkFunctions;
        com.google.javascript.jscomp.JSError jSError14 = null;
        loggerErrorManager2.println(checkLevel13, jSError14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.aliasStringsBlacklist = "EOF";
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap11;
        compilerOptions0.moveFunctionDeclarations = true;
        boolean boolean15 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean8 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        compilerOptions0.debugFunctionSideEffectsPath = "";
        boolean boolean7 = compilerOptions0.optimizeReturns;
        boolean boolean8 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean10 = compilerOptions0.computeFunctionSideEffects;
        boolean boolean11 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getErrorMessage();
        int int3 = ecmaError1.getColumnNumber();
        ecmaError1.initLineNumber(8);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError1.getScriptStackTrace(filenameFilter6);
        try {
            ecmaError1.initLineNumber(21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getWarnings();
        loggerErrorManager2.generateReport();
        loggerErrorManager2.generateReport();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = null;
        compilerOptions0.setCodingConvention(codingConvention7);
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17, false);
        java.lang.String str20 = jSSourceFile17.getName();
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile26, false);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region34 = jSSourceFile32.getRegion(26);
        java.lang.String str35 = jSSourceFile32.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str39 = jSSourceFile38.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray40 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14, jSSourceFile17, jSSourceFile23, jSSourceFile26, jSSourceFile32, jSSourceFile38 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile43, false);
        java.lang.String str46 = jSSourceFile43.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile43);
        java.lang.String str48 = compilerInput47.getName();
        java.io.PrintStream printStream49 = null;
        com.google.javascript.jscomp.Compiler compiler50 = new com.google.javascript.jscomp.Compiler(printStream49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.inlineConstantVars = false;
        compilerOptions51.instrumentationTemplate = "eof";
        boolean boolean56 = compilerOptions51.moveFunctionDeclarations;
        compiler50.initOptions(compilerOptions51);
        compilerInput47.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler50);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region63 = jSSourceFile61.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy68 = compilerOptions65.variableRenaming;
        com.google.javascript.jscomp.Result result69 = compiler50.compile(jSSourceFile61, jSModuleArray64, compilerOptions65);
        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions70.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler73 = null;
        compilerOptions70.setAliasTransformationHandler(aliasTransformationHandler73);
        com.google.javascript.jscomp.Result result75 = compiler11.compile(jSSourceFileArray40, jSModuleArray64, compilerOptions70);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker76 = compiler11.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter78 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNull(region34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray40);
        org.junit.Assert.assertNotNull(jSSourceFile43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNull(region63);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy68 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy68.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result69);
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(performanceTracker76);
        org.junit.Assert.assertNotNull(messageFormatter78);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test142");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        context0.setLanguageVersion(110);
//        boolean boolean5 = context0.isGeneratingSource();
//        long long6 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        compilerOptions10.instrumentationTemplate = "eof";
        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
        compiler9.initOptions(compilerOptions10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
        java.lang.String[] strArray37 = new java.lang.String[] { "TypeError: hi!", "eof", "or", "eof", "or", "hi!", "TypeError", "TypeError: hi!" };
        java.util.ArrayList<java.lang.String> strList38 = new java.util.ArrayList<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList38, strArray37);
        compilerOptions24.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = null;
        compilerOptions24.checkUnreachableCode = checkLevel41;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = null;
        compilerOptions24.checkGlobalThisLevel = checkLevel43;
        boolean boolean45 = compilerOptions24.markAsCompiled;
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(region22);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        java.lang.String[] strArray25 = new java.lang.String[] { "EOF", "TypeError: hi!", "goog.abstractMethod", "goog.global", "com.google.javascript.rhino.EcmaError: TypeError: hi!", "or", "name", "goog.abstractMethod", "", "hi!", "goog.abstractMethod", "goog.abstractMethod", "hi!" };
        java.util.ArrayList<java.lang.String> strList26 = new java.util.ArrayList<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList26, strArray25);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList26);
        compilerOptions0.gatherCssNames = true;
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.sourceMapFormat = format2;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setLooseTypes(true);
        java.lang.String str7 = compilerOptions0.locale;
        compilerOptions0.nameReferenceReportPath = "TypeError";
        compilerOptions0.renamePrefix = "error reporter";
        compilerOptions0.checkSymbols = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.appNameStr;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean9 = compilerOptions0.inlineFunctions;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) ' ');
        com.google.javascript.jscomp.ErrorFormat errorFormat13 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(errorFormat13);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
//        java.lang.Object obj7 = null;
//        try {
//            context0.unseal(obj7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.setColorizeErrorOutput(false);
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.ideMode;
        compilerOptions0.setDefineToStringLiteral("hi!", "");
        compilerOptions0.setTweakToStringLiteral("NUMBER 10.0 48", "NUMBER 0.0 28\n");
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        try {
            node1.setSideEffectFlags(27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        java.lang.Object obj7 = node4.getProp((int) (short) 100);
        int int9 = node4.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node4, diagnosticType10, strArray17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = null;
        compilerOptions19.variableRenaming = variableRenamingPolicy22;
        java.util.Set<java.lang.String> strSet24 = compilerOptions19.stripNameSuffixes;
        boolean boolean25 = compilerOptions19.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        compilerOptions19.reportMissingOverride = checkLevel26;
        boolean boolean28 = jSError18.equals((java.lang.Object) compilerOptions19);
        java.lang.String str29 = jSError18.sourceName;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.inlineConstantVars = false;
        compilerOptions30.unaliasableGlobals = "";
        compilerOptions30.generatePseudoNames = false;
        boolean boolean37 = compilerOptions30.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions30.checkMissingReturn;
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        int int48 = node43.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat50 = diagnosticType49.format;
        java.lang.String[] strArray56 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node43, diagnosticType49, strArray56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions58.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy61 = null;
        compilerOptions58.variableRenaming = variableRenamingPolicy61;
        java.util.Set<java.lang.String> strSet63 = compilerOptions58.stripNameSuffixes;
        boolean boolean64 = compilerOptions58.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel65 = null;
        compilerOptions58.reportMissingOverride = checkLevel65;
        boolean boolean67 = jSError57.equals((java.lang.Object) compilerOptions58);
        java.lang.String str68 = jSError57.sourceName;
        com.google.javascript.jscomp.CompilerOptions compilerOptions69 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean70 = compilerOptions69.checkControlStructures;
        compilerOptions69.setRemoveClosureAsserts(false);
        compilerOptions69.setTweakToBooleanLiteral("", false);
        java.lang.String str76 = compilerOptions69.appNameStr;
        compilerOptions69.skipAllCompilerPasses();
        boolean boolean78 = compilerOptions69.inlineFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel79 = compilerOptions69.checkShadowVars;
        com.google.javascript.jscomp.ErrorFormat errorFormat80 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream81 = null;
        com.google.javascript.jscomp.Compiler compiler82 = new com.google.javascript.jscomp.Compiler(printStream81);
        com.google.javascript.jscomp.CompilerOptions compilerOptions83 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions83.inlineConstantVars = false;
        compilerOptions83.instrumentationTemplate = "eof";
        boolean boolean88 = compilerOptions83.moveFunctionDeclarations;
        compiler82.initOptions(compilerOptions83);
        com.google.javascript.jscomp.MessageFormatter messageFormatter91 = errorFormat80.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler82, false);
        java.util.logging.Logger logger92 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager93 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter91, logger92);
        java.lang.String str94 = jSError57.format(checkLevel79, messageFormatter91);
        java.lang.String str95 = jSError18.format(checkLevel38, messageFormatter91);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Not declared as a constructor" + "'", str29.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(messageFormat50);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertNotNull(strSet63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Not declared as a constructor" + "'", str68.equals("Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "" + "'", str76.equals(""));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + checkLevel79 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel79.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(errorFormat80);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(messageFormatter91);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNull(str95);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        boolean boolean20 = node7.isSyntheticBlock();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean23 = closureCodingConvention21.isValidEnumKey("error reporter");
        java.lang.String str24 = closureCodingConvention21.getExportPropertyFunction();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        node26.setJSType(jSType27);
        boolean boolean29 = node26.isVarArgs();
        boolean boolean30 = closureCodingConvention21.isOptionalParameter(node26);
        boolean boolean32 = closureCodingConvention21.isExported("");
        boolean boolean35 = closureCodingConvention21.isExported("", true);
        com.google.javascript.rhino.Node node36 = null;
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str42 = closureCodingConvention21.extractClassNameIfProvide(node36, node41);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node47 = node41.copyInformationFromForTree(node46);
        boolean boolean48 = node7.isEquivalentToTyped(node46);
        boolean boolean49 = node46.isQuotedString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "goog.exportProperty" + "'", str24.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        compilerOptions0.debugFunctionSideEffectsPath = "";
        boolean boolean7 = compilerOptions0.optimizeReturns;
        boolean boolean8 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean9 = compilerOptions0.collapseProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        boolean boolean13 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("error reporter", "TypeError");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.defaultLevel;
        java.lang.String str4 = diagnosticType2.key;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel6, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean24 = compilerOptions23.checkControlStructures;
        compilerOptions23.setRemoveClosureAsserts(false);
        compilerOptions23.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result30 = compiler11.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        compilerOptions23.generatePseudoNames = false;
        boolean boolean33 = compilerOptions23.removeUnusedVars;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions23.brokenClosureRequiresLevel;
        diagnosticType8.level = checkLevel34;
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions36.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions36.aggressiveVarCheck;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions36.checkUndefinedProperties;
        diagnosticType8.level = checkLevel40;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = diagnosticType8.level;
        int int43 = diagnosticType2.compareTo(diagnosticType8);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "error reporter" + "'", str4.equals("error reporter"));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 14 + "'", int43 == 14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.optimizeArgumentsArray = true;
        boolean boolean9 = compilerOptions0.reserveRawExports;
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean6 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        boolean boolean5 = node1.hasChildren();
        node1.addSuppression("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.ideMode;
        compilerOptions0.setDefineToStringLiteral("hi!", "");
        boolean boolean11 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.reportPath = "name";
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(11, "TypeError: hi!", 7, (int) (short) 10);
        boolean boolean10 = node4.hasChild(node9);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("TypeError: hi!", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: TypeError: hi! at Not declared as a constructor line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) 1.0f);
        java.lang.String str8 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.aliasExternals = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) 1.0f);
        compilerOptions0.reserveRawExports = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "()");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        int int3 = ecmaError1.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions21.checkMethods;
        compilerOptions21.setTweakToStringLiteral("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", "getprop");
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions21.checkMissingReturn;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getSourceName();
        int int4 = ecmaError1.getColumnNumber();
        int int5 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = null;
        compiler1.tracker = performanceTracker21;
        compiler1.reportCodeChange();
        compiler1.reportCodeChange();
        java.io.PrintStream printStream25 = null;
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler(printStream25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile29 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.JSModule[] jSModuleArray35 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList36 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList36, jSModuleArray35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean39 = compilerOptions38.checkControlStructures;
        compilerOptions38.setRemoveClosureAsserts(false);
        compilerOptions38.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result45 = compiler26.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList36, compilerOptions38);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str49 = jSSourceFile48.getOriginalPath();
        java.lang.String str51 = jSSourceFile48.getLine(0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str59 = jSSourceFile57.getLine((int) (short) 100);
        jSSourceFile57.clearCachedSource();
        java.lang.String str62 = jSSourceFile57.getLine(0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray63 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile48, jSSourceFile54, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList64 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList64, jSSourceFileArray63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = null;
        try {
            com.google.javascript.jscomp.Result result67 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList64, compilerOptions66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSModuleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(result45);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(jSSourceFileArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.foldConstants = false;
        java.lang.String str6 = compilerOptions0.jsOutputFile;
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        boolean boolean8 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = ecmaError1.getScriptStackTrace(filenameFilter4);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        compilerOptions0.aliasableGlobals = "error reporter";
        boolean boolean10 = compilerOptions0.gatherCssNames;
        boolean boolean11 = compilerOptions0.checkCaja;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a type name", "eof", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str7 = compilerInput6.getName();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.Region region16 = jSSourceFile14.getRegion(26);
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(region16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
        compilerOptions21.variableRenaming = variableRenamingPolicy24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
        compilerOptions21.aliasAllStrings = true;
        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
        compiler1.initOptions(compilerOptions21);
        compilerOptions21.setDefineToNumberLiteral("error reporter", (int) (short) 100);
        byte[] byteArray34 = compilerOptions21.inputVariableMapSerialized;
        compilerOptions21.setShadowVariables(false);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(byteArray34);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.appNameStr = "hi!";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = compilerOptions0.variableRenaming;
        compilerOptions0.generateExports = false;
        boolean boolean8 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.global");
        try {
            java.lang.String str2 = jSSourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: goog.global (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setDefineToDoubleLiteral("or", (double) 1.0f);
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.checkControlStructures;
        compilerOptions13.setRemoveClosureAsserts(false);
        compilerOptions13.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
        compiler1.disableThreads();
        com.google.javascript.jscomp.JSError[] jSErrorArray22 = compiler1.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray23 = compiler1.getWarnings();
        com.google.javascript.jscomp.ErrorManager errorManager24 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
        org.junit.Assert.assertNotNull(jSErrorArray22);
        org.junit.Assert.assertNotNull(jSErrorArray23);
        org.junit.Assert.assertNotNull(errorManager24);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int3 = node1.getIntProp(2);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean9 = node8.isOptionalArg();
        boolean boolean10 = node8.isLocalResultCall();
        boolean boolean11 = node1.isEquivalentToTyped(node8);
        boolean boolean12 = node1.isSyntheticBlock();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        node17.setJSType(jSType18);
        boolean boolean20 = node17.isVarArgs();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        node22.setJSType(jSType23);
        boolean boolean25 = node22.isVarArgs();
        boolean boolean26 = node17.hasChild(node22);
        node17.removeProp(2);
        node17.setIsSyntheticBlock(false);
        java.lang.String str31 = closureCodingConvention0.identifyTypeDefAssign(node17);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection32 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean35 = closureCodingConvention33.isValidEnumKey("error reporter");
        boolean boolean37 = closureCodingConvention33.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType38 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType40 = null;
        closureCodingConvention33.applySubclassRelationship(functionType38, functionType39, subclassType40);
        boolean boolean44 = closureCodingConvention33.isExported("goog.abstractMethod", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection45 = closureCodingConvention33.getAssertionFunctions();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection46 = closureCodingConvention33.getAssertionFunctions();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        node48.setJSType(jSType49);
        int int51 = node48.getSideEffectFlags();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newNumber((double) 1.0f, (int) '4', 30);
        node55.setType(11);
        java.lang.String str58 = closureCodingConvention33.extractClassNameIfProvide(node48, node55);
        com.google.javascript.rhino.Node node59 = node55.getLastSibling();
        try {
            boolean boolean60 = closureCodingConvention0.isPropertyTestFunction(node59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection45);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(node59);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing7);
        boolean boolean9 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("getprop", "DiagnosticGroup<uselessCode>(OFF)");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test184");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        context0.addActivationName("");
//        boolean boolean7 = context0.isGeneratingDebugChanged();
//        context0.addActivationName("goog.exportProperty");
//        context0.setInstructionObserverThreshold(22);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.foldConstants;
        compilerOptions0.foldConstants = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap10 = compilerOptions0.customPasses;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.lang.String str9 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean15 = node14.isOptionalArg();
        try {
            boolean boolean16 = closureCodingConvention0.isPropertyTestFunction(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.exportProperty" + "'", str9.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.checkSymbols = true;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean6 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node26 = node20.copyInformationFromForTree(node25);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection27 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node25);
        try {
            node25.setSideEffectFlags(39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeCollection27);
    }
}

