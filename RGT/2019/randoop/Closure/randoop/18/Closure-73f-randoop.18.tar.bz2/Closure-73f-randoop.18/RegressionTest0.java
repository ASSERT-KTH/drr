import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) (byte) 100, (java.lang.Object) true);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) ' ', node1, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "hi!", "hi!" };
        try {
            com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("", (java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test015");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "", (java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.JSError jSError1 = null;
        try {
            boolean boolean2 = diagnosticGroup0.matches(jSError1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "error reporter", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eof" + "'", str1.equals("eof"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("", (java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("eof", "error reporter", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(1, node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("eof", "hi!");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "or" + "'", str1.equals("or"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) ' ', node1, node2, node3, node4, 7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.decomposeExpressions = false;
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            java.lang.String str5 = compiler2.getSourceLine("TypeError: hi!", 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            compiler2.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.WarningsGuard warningsGuard4 = null;
        try {
            compilerOptions0.addWarningsGuard(warningsGuard4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.setThrows();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.prettyPrint;
        compilerOptions0.setPropertyAffinity(true);
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel10;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.appNameStr;
        com.google.javascript.jscomp.SourceMap.Format format8 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format8;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(format8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean4 = compilerOptions0.checkUnusedPropertiesEarly;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        com.google.javascript.jscomp.JSModule jSModule31 = null;
//        try {
//            java.lang.String str32 = compiler1.toSource(jSModule31);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        boolean boolean5 = compilerInput4.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("eof", "TypeError", "error reporter", "eof");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property eof");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.ERROR;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.beans.PropertyChangeListener propertyChangeListener1 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = null;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "TypeError: hi!", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config5);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        try {
//            compiler1.processDefines();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        com.google.javascript.jscomp.JSError jSError31 = null;
//        try {
//            com.google.javascript.jscomp.CheckLevel checkLevel32 = compiler1.getErrorLevel(jSError31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node6.addChildrenToBack(node8);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node11.addChildrenToBack(node13);
        try {
            node3.replaceChildAfter(node6, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "or");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.checkTypes = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean10 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        int int31 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState32 = null;
//        try {
//            compiler1.setState(intermediateState32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = null;
//        try {
//            compiler1.setState(intermediateState9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.JSModule jSModule9 = null;
//        try {
//            java.lang.String[] strArray10 = compiler1.toSourceArray(jSModule9);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.rewriteFunctionExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler2.tracker = performanceTracker3;
        try {
            boolean boolean5 = compiler2.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "TypeError: hi!", 26);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        compilerOptions13.generatePseudoNames = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy23 = compilerOptions13.variableRenaming;
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy23 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy23.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.putBooleanProp(22, false);
        try {
            com.google.javascript.rhino.Node node5 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str5 = jSSourceFile2.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        java.lang.String str7 = compilerInput6.getName();
//        java.io.PrintStream printStream8 = null;
//        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions10.inlineConstantVars = false;
//        compilerOptions10.instrumentationTemplate = "eof";
//        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
//        compiler9.initOptions(compilerOptions10);
//        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
//        java.lang.String str18 = compilerInput6.getName();
//        com.google.javascript.jscomp.SourceFile sourceFile19 = null;
//        try {
//            compilerInput6.setSourceFile(sourceFile19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        try {
//            context0.setInstructionObserverThreshold((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        try {
//            context0.setGeneratingSource(true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        com.google.javascript.rhino.Node node6 = null;
        com.google.javascript.rhino.Node node7 = null;
        try {
            com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(18, node4, node6, node7, 15, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean6 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node5.putBooleanProp(22, false);
        try {
            node1.replaceChildAfter(node3, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ancestorIterable2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("eof");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property eof");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
//        com.google.javascript.jscomp.JSError jSError1 = null;
//        try {
//            boolean boolean2 = diagnosticGroup0.matches(jSError1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        try {
            int int7 = node6.getCharno();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.checkTypes;
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        boolean boolean5 = compilerInput4.isExtern();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
//        java.lang.String str17 = jSSourceFile14.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
//        java.lang.String str19 = compilerInput18.getName();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22, false);
//        java.lang.String str25 = jSSourceFile22.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22);
//        java.lang.String str27 = compilerInput26.getName();
//        java.io.PrintStream printStream28 = null;
//        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions30.inlineConstantVars = false;
//        compilerOptions30.instrumentationTemplate = "eof";
//        boolean boolean35 = compilerOptions30.moveFunctionDeclarations;
//        compiler29.initOptions(compilerOptions30);
//        compilerInput26.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler29);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45, false);
//        java.lang.String str48 = jSSourceFile45.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile45);
//        java.lang.String str50 = compilerInput49.getName();
//        java.io.PrintStream printStream51 = null;
//        com.google.javascript.jscomp.Compiler compiler52 = new com.google.javascript.jscomp.Compiler(printStream51);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions53.inlineConstantVars = false;
//        compilerOptions53.instrumentationTemplate = "eof";
//        boolean boolean58 = compilerOptions53.moveFunctionDeclarations;
//        compiler52.initOptions(compilerOptions53);
//        compilerInput49.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler52);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile63 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput65 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile63, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput66 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile63);
//        com.google.javascript.jscomp.SourceFile sourceFile67 = compilerInput66.getSourceFile();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile70 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile70, false);
//        java.lang.String str73 = jSSourceFile70.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput74 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile70);
//        java.lang.String str75 = compilerInput74.getName();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray76 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput4, compilerInput11, compilerInput18, compilerInput26, compilerInput42, compilerInput49, compilerInput66, compilerInput74 };
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList77 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList77, compilerInputArray76);
//        try {
//            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies79 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile8);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile40);
//        org.junit.Assert.assertNotNull(jSSourceFile45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile63);
//        org.junit.Assert.assertNotNull(sourceFile67);
//        org.junit.Assert.assertNotNull(jSSourceFile70);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "" + "'", str73.equals(""));
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
//        org.junit.Assert.assertNotNull(compilerInputArray76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.lang.String str8 = compilerOptions0.unaliasableGlobals;
        boolean boolean9 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        try {
            java.util.Set<java.lang.String> strSet7 = node6.getDirectives();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        boolean boolean6 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        com.google.javascript.rhino.Node node12 = null;
        try {
            com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 100, node4, node8, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = compiler2.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.putBooleanProp(22, false);
        try {
            java.lang.String str5 = node1.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        boolean boolean6 = compilerOptions0.generateExports;
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = null;
        compilerOptions1.variableRenaming = variableRenamingPolicy4;
        java.util.Set<java.lang.String> strSet6 = compilerOptions1.stripNameSuffixes;
        compilerOptions1.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet9 = compilerOptions1.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions1.checkShadowVars;
        java.util.Set<java.lang.String> strSet11 = compilerOptions1.stripTypes;
        boolean boolean12 = compilerOptions1.checkUnusedPropertiesEarly;
        try {
            java.lang.String str13 = com.google.javascript.rhino.ScriptRuntime.getMessage1("TypeError: hi!", (java.lang.Object) boolean12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError: hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
//        try {
//            context0.addActivationName("eof");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        int int31 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str41 = jSSourceFile40.getOriginalPath();
//        java.lang.String str43 = jSSourceFile40.getLine(0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile34, jSSourceFile37, jSSourceFile40, jSSourceFile46, jSSourceFile51 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray53 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions54.inlineConstantVars = false;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel57 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
//        compilerOptions54.sourceMapDetailLevel = detailLevel57;
//        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing59 = compilerOptions54.getTweakProcessing();
//        compiler1.init(jSSourceFileArray52, jSModuleArray53, compilerOptions54);
//        compilerOptions54.setTweakToBooleanLiteral("", true);
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(jSSourceFile34);
//        org.junit.Assert.assertNotNull(jSSourceFile37);
//        org.junit.Assert.assertNotNull(jSSourceFile40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertNotNull(jSSourceFile46);
//        org.junit.Assert.assertNotNull(jSSourceFile51);
//        org.junit.Assert.assertNotNull(jSSourceFileArray52);
//        org.junit.Assert.assertNotNull(jSModuleArray53);
//        org.junit.Assert.assertNotNull(detailLevel57);
//        org.junit.Assert.assertTrue("'" + tweakProcessing59 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing59.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        int int31 = compiler1.getErrorCount();
//        try {
//            compiler1.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("()");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("Named type with empty name component");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Named type with empty name component");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = null;
//        try {
//            compiler1.initOptions(compilerOptions31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.reportPath = "error reporter";
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(codingConvention5);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream1 = null;
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions3.inlineConstantVars = false;
//        compilerOptions3.instrumentationTemplate = "eof";
//        boolean boolean8 = compilerOptions3.moveFunctionDeclarations;
//        compiler2.initOptions(compilerOptions3);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
//        try {
//            compiler2.processDefines();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(messageFormatter11);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        try {
            java.lang.String str5 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.decomposeExpressions = false;
        compilerOptions0.inlineVariables = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node1.setJSType(jSType4);
        try {
            node1.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        boolean boolean8 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        java.lang.String str9 = node1.checkTreeEquals(node5);
        int int10 = node1.getSourcePosition();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str9.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node10.setJSType(jSType11);
        boolean boolean13 = node10.isVarArgs();
        boolean boolean14 = node5.hasChild(node10);
        node5.removeProp(2);
        node5.setIsSyntheticBlock(false);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast19 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal3, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        java.util.logging.Logger logger0 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
//        compiler2.tracker = performanceTracker3;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str9 = jSSourceFile7.getLine((int) (short) 100);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7 };
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18, false);
//        java.lang.String str21 = jSSourceFile18.getName();
//        java.nio.charset.Charset charset23 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset23);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region35 = jSSourceFile33.getRegion(26);
//        java.lang.String str36 = jSSourceFile33.getName();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str40 = jSSourceFile39.toString();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile24, jSSourceFile27, jSSourceFile33, jSSourceFile39 };
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
//        java.lang.String str47 = jSSourceFile44.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
//        java.lang.String str49 = compilerInput48.getName();
//        java.io.PrintStream printStream50 = null;
//        com.google.javascript.jscomp.Compiler compiler51 = new com.google.javascript.jscomp.Compiler(printStream50);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions52.inlineConstantVars = false;
//        compilerOptions52.instrumentationTemplate = "eof";
//        boolean boolean57 = compilerOptions52.moveFunctionDeclarations;
//        compiler51.initOptions(compilerOptions52);
//        compilerInput48.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler51);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region64 = jSSourceFile62.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray65 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions66.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy69 = compilerOptions66.variableRenaming;
//        com.google.javascript.jscomp.Result result70 = compiler51.compile(jSSourceFile62, jSModuleArray65, compilerOptions66);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions71.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler74 = null;
//        compilerOptions71.setAliasTransformationHandler(aliasTransformationHandler74);
//        com.google.javascript.jscomp.Result result76 = compiler12.compile(jSSourceFileArray41, jSModuleArray65, compilerOptions71);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean78 = compilerOptions77.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig79 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions77);
//        compiler2.init(jSSourceFileArray10, jSSourceFileArray41, compilerOptions77);
//        com.google.javascript.jscomp.JSError jSError81 = null;
//        try {
//            compiler2.report(jSError81);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(jSSourceFileArray10);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile24);
//        org.junit.Assert.assertNotNull(jSSourceFile27);
//        org.junit.Assert.assertNotNull(jSSourceFile33);
//        org.junit.Assert.assertNull(region35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFileArray41);
//        org.junit.Assert.assertNotNull(jSSourceFile44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile62);
//        org.junit.Assert.assertNull(region64);
//        org.junit.Assert.assertNotNull(jSModuleArray65);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy69 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy69.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result70);
//        org.junit.Assert.assertNotNull(result76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        java.lang.String str9 = node1.checkTreeEquals(node5);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node15.addChildrenToBack(node17);
        try {
            node1.replaceChildAfter(node13, node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str9.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.appNameStr = "eof";
        boolean boolean8 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        int int31 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.JSModule jSModule32 = null;
//        try {
//            java.lang.String[] strArray33 = compiler1.toSourceArray(jSModule32);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule5, jSModule6);
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        try {
            boolean boolean10 = jSModuleGraph1.dependsOn(jSModule8, jSModule9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        boolean boolean5 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean8 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        node4.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean10 = closureCodingConvention8.isValidEnumKey("error reporter");
        java.lang.String str11 = closureCodingConvention8.getAbstractMethodName();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node13.setJSType(jSType14);
        boolean boolean16 = node13.isVarArgs();
        boolean boolean17 = node13.hasChildren();
        boolean boolean18 = closureCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.Node node20 = node13.getAncestor(43);
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(0, node4, node13, 130, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.abstractMethod" + "'", str11.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 0);
        sideEffectFlags1.setMutatesGlobalState();
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.smartNameRemoval;
        java.lang.String str4 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        boolean boolean3 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.lineBreak = false;
        boolean boolean4 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("TypeError: hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str5 = jSSourceFile2.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        java.lang.String str7 = compilerInput6.getName();
//        java.io.PrintStream printStream8 = null;
//        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions10.inlineConstantVars = false;
//        compilerOptions10.instrumentationTemplate = "eof";
//        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
//        compiler9.initOptions(compilerOptions10);
//        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions24.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
//        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
//        try {
//            compiler9.normalize();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile20);
//        org.junit.Assert.assertNull(region22);
//        org.junit.Assert.assertNotNull(jSModuleArray23);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result28);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        try {
            double double6 = node1.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str6 = node2.toString(false, false, false);
        try {
            java.lang.String str9 = com.google.javascript.rhino.ScriptRuntime.getMessage3("", (java.lang.Object) str6, (java.lang.Object) 2, (java.lang.Object) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EOF" + "'", str6.equals("EOF"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast7 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal4, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(130);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        context0.addActivationName("");
//        context0.setGeneratingSource(false);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = null;
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str23 = node19.toString(true, false, true);
        com.google.javascript.rhino.Node node24 = node19.getFirstChild();
        com.google.javascript.rhino.Node node25 = node14.copyInformationFromForTree(node19);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast26 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal12, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "EOF" + "'", str23.equals("EOF"));
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str4 = jSSourceFile3.toString();
        java.io.Reader reader5 = jSSourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("hi!", reader5);
        java.lang.String str7 = sourceFile6.toString();
        java.lang.String str9 = sourceFile6.getLine(11);
        java.lang.String str10 = sourceFile6.toString();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, true);
        try {
            boolean boolean6 = compiler3.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str11 = node7.toString(true, false, true);
        com.google.javascript.rhino.Node node12 = node7.getFirstChild();
        com.google.javascript.rhino.Node node13 = node2.copyInformationFromForTree(node7);
        boolean boolean14 = node2.isOptionalArg();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node16.addChildrenToBack(node18);
        boolean boolean20 = node18.isQualifiedName();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] { node2, node18, node22 };
        try {
            com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(22, nodeArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "EOF" + "'", str11.equals("EOF"));
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray23);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node12 = null;
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = null;
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node16.addChildrenToBack(node18);
        boolean boolean20 = node18.isLocalResultCall();
        int int21 = node18.getSideEffectFlags();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast22 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal14, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkUnusedPropertiesEarly;
        boolean boolean5 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(detailLevel6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean4 = compilerOptions3.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig5 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions3);
//        try {
//            context0.seal((java.lang.Object) defaultPassConfig5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            compiler2.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.setOutputCharset("TypeError: hi!");
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap31 = compilerOptions21.customPasses;
//        compilerOptions21.removeDeadCode = false;
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNull(customPassExecutionTimeMultimap31);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.enableRuntimeTypeCheck("Named type with empty name component");
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.checkControlStructures;
        compilerOptions9.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy13 = compilerOptions9.anonymousFunctionNaming;
        boolean boolean14 = compilerOptions9.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions9.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode16 = compilerOptions9.tracer;
        compilerOptions0.tracer = tracerMode16;
        java.lang.String str18 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy13 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy13.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode16 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode16.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean7 = closureCodingConvention5.isValidEnumKey("error reporter");
        java.lang.String str8 = closureCodingConvention5.getAbstractMethodName();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node10.setJSType(jSType11);
        boolean boolean13 = node10.isVarArgs();
        boolean boolean14 = node10.hasChildren();
        boolean boolean15 = closureCodingConvention5.isOptionalParameter(node10);
        com.google.javascript.rhino.Node node17 = node10.getAncestor(43);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node19.addChildrenToBack(node21);
        try {
            node1.replaceChild(node17, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.abstractMethod" + "'", str8.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.setGeneratingSource(false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.setErrorReporter(errorReporter3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        boolean boolean5 = node1.hasChildren();
        int int6 = node1.getCharno();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isQualifiedName();
        com.google.javascript.rhino.Node node7 = node3.getChildAtIndex((int) (byte) -1);
        try {
            node3.setDouble((double) 34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean6 = compilerOptions0.tightenTypes;
        boolean boolean7 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node8.addChildrenToBack(node10);
        boolean boolean12 = node10.isLocalResultCall();
        int int13 = node10.getSideEffectFlags();
        try {
            com.google.javascript.rhino.Node node14 = node6.clonePropsFrom(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str10 = node6.toString(true, false, true);
        com.google.javascript.rhino.Node node11 = node6.getFirstChild();
        com.google.javascript.rhino.Node node12 = node1.copyInformationFromForTree(node6);
        node1.setVarArgs(false);
        try {
            node1.setSideEffectFlags(22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "EOF" + "'", str10.equals("EOF"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        java.lang.Object obj6 = node3.getProp((int) (short) 100);
        node3.setType((int) ' ');
        try {
            int int10 = node3.getExistingIntProp(38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        ecmaError1.initLineSource("");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
//        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
//        try {
//            com.google.javascript.rhino.Context context6 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode7 = compilerOptions0.tracer;
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode7.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean6 = compilerOptions5.checkControlStructures;
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy7 = compilerOptions5.anonymousFunctionNaming;
//        char[] charArray8 = anonymousFunctionNamingPolicy7.getReservedCharacters();
//        try {
//            context0.seal((java.lang.Object) charArray8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy7 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy7.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
//        org.junit.Assert.assertNull(charArray8);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.checkControlStructures;
//        compilerOptions0.setRemoveClosureAsserts(false);
//        compilerOptions0.setTweakToBooleanLiteral("", false);
//        java.lang.String str7 = compilerOptions0.appNameStr;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions9.removeEmptyFunctions = true;
//        compilerOptions9.checkSuspiciousCode = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel15, "hi!");
//        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
//        java.io.PrintStream printStream19 = null;
//        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList30, jSModuleArray29);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean33 = compilerOptions32.checkControlStructures;
//        compilerOptions32.setRemoveClosureAsserts(false);
//        compilerOptions32.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result39 = compiler20.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList30, compilerOptions32);
//        compilerOptions32.generatePseudoNames = false;
//        boolean boolean42 = compilerOptions32.removeUnusedVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions32.brokenClosureRequiresLevel;
//        diagnosticType17.level = checkLevel43;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions45.inlineConstantVars = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions45.aggressiveVarCheck;
//        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions45.checkUndefinedProperties;
//        diagnosticType17.level = checkLevel49;
//        compilerOptions9.checkGlobalThisLevel = checkLevel49;
//        compilerOptions0.setWarningLevel(diagnosticGroup8, checkLevel49);
//        compilerOptions0.computeFunctionSideEffects = false;
//        boolean boolean55 = compilerOptions0.smartNameRemoval;
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertNotNull(diagnosticType17);
//        org.junit.Assert.assertNull(checkLevel18);
//        org.junit.Assert.assertNotNull(jSSourceFile23);
//        org.junit.Assert.assertNotNull(jSSourceFileArray26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(result39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        node2.setJSType(jSType3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node2.setJSType(jSType5);
        com.google.javascript.rhino.jstype.JSType jSType7 = node2.getJSType();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean10 = closureCodingConvention8.isValidEnumKey("error reporter");
        java.lang.String str11 = closureCodingConvention8.getAbstractMethodName();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node13.setJSType(jSType14);
        boolean boolean16 = node13.isVarArgs();
        boolean boolean17 = node13.hasChildren();
        boolean boolean18 = closureCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.Node node20 = node13.getAncestor(43);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node22.addChildrenToBack(node24);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str31 = node27.toString(true, false, true);
        com.google.javascript.rhino.Node node32 = node27.getFirstChild();
        com.google.javascript.rhino.Node node33 = node22.copyInformationFromForTree(node27);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        node35.setJSType(jSType36);
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] { node2, node20, node27, node35 };
        try {
            com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, nodeArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.abstractMethod" + "'", str11.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "EOF" + "'", str31.equals("EOF"));
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeArray38);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.checkControlStructures;
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
//        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
//        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
//        compilerOptions0.errorFormat = errorFormat4;
//        java.io.PrintStream printStream6 = null;
//        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean20 = compilerOptions19.checkControlStructures;
//        compilerOptions19.setRemoveClosureAsserts(false);
//        compilerOptions19.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result26 = compiler7.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions19);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions27.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = null;
//        compilerOptions27.variableRenaming = variableRenamingPolicy30;
//        java.util.Set<java.lang.String> strSet32 = compilerOptions27.stripNameSuffixes;
//        compilerOptions27.aliasAllStrings = true;
//        java.lang.String str35 = compilerOptions27.unaliasableGlobals;
//        compiler7.initOptions(compilerOptions27);
//        int int37 = compiler7.getErrorCount();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter39 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7, true);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(errorFormat4);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertNotNull(jSSourceFileArray13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(result26);
//        org.junit.Assert.assertNotNull(strSet32);
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(messageFormatter39);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.io.Reader reader6 = jSSourceFile2.getCodeReader();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(reader6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            boolean boolean7 = jSModuleGraph1.dependsOn(jSModule5, jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        int int31 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str41 = jSSourceFile40.getOriginalPath();
//        java.lang.String str43 = jSSourceFile40.getLine(0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile34, jSSourceFile37, jSSourceFile40, jSSourceFile46, jSSourceFile51 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray53 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions54.inlineConstantVars = false;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel57 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
//        compilerOptions54.sourceMapDetailLevel = detailLevel57;
//        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing59 = compilerOptions54.getTweakProcessing();
//        compiler1.init(jSSourceFileArray52, jSModuleArray53, compilerOptions54);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph61 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray53);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph62 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray53);
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(jSSourceFile34);
//        org.junit.Assert.assertNotNull(jSSourceFile37);
//        org.junit.Assert.assertNotNull(jSSourceFile40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertNotNull(jSSourceFile46);
//        org.junit.Assert.assertNotNull(jSSourceFile51);
//        org.junit.Assert.assertNotNull(jSSourceFileArray52);
//        org.junit.Assert.assertNotNull(jSModuleArray53);
//        org.junit.Assert.assertNotNull(detailLevel57);
//        org.junit.Assert.assertTrue("'" + tweakProcessing59 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing59.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node1.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = node1.getJSDocInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(jSDocInfo8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.util.List<com.google.javascript.jscomp.WarningsGuard> warningsGuardList0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
//        compilerOptions2.anonymousFunctionNaming = anonymousFunctionNamingPolicy9;
//        compilerOptions2.enableRuntimeTypeCheck("goog.global");
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getLineno();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node3.children();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(nodeIterable7);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.inlineConstantVars = false;
//        compilerOptions2.instrumentationTemplate = "eof";
//        boolean boolean7 = compilerOptions2.moveFunctionDeclarations;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions2.sourceMapDetailLevel;
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(detailLevel9);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.collapseProperties = true;
        compilerOptions0.decomposeExpressions = false;
        compilerOptions0.checkCaja = false;
        java.lang.String str12 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = null;
//        compilerOptions21.variableRenaming = variableRenamingPolicy24;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions21.stripNameSuffixes;
//        compilerOptions21.aliasAllStrings = true;
//        java.lang.String str29 = compilerOptions21.unaliasableGlobals;
//        compiler1.initOptions(compilerOptions21);
//        compiler1.reportCodeChange();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = null;
//        com.google.javascript.jscomp.JSModule[] jSModuleArray33 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions34.removeEmptyFunctions = true;
//        compilerOptions34.checkMissingGetCssNameBlacklist = "error reporter";
//        compilerOptions34.checkSymbols = false;
//        try {
//            com.google.javascript.jscomp.Result result41 = compiler1.compile(jSSourceFile32, jSModuleArray33, compilerOptions34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertNull(str29);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.setCompileFunctionsWithDynamicScope(true);
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        try {
//            context0.addPropertyChangeListener(propertyChangeListener3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        compilerOptions13.inferTypesInGlobalScope = false;
//        compilerOptions13.inlineGetters = true;
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str7 = node3.toString(true, false, true);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str13 = node9.toString(false, false, false);
        try {
            com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, node1, node3, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "EOF" + "'", str7.equals("EOF"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF" + "'", str13.equals("EOF"));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        java.lang.String str2 = compiler1.getAstDotGraph();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str6 = jSSourceFile5.toString();
//        java.io.Reader reader7 = jSSourceFile5.getCodeReader();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
//        java.io.Reader reader14 = jSSourceFile10.getCodeReader();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        java.lang.String str19 = jSSourceFile17.getLine((int) (short) 100);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22);
//        java.io.Reader reader26 = jSSourceFile22.getCodeReader();
//        java.io.PrintStream printStream27 = null;
//        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler(printStream27);
//        java.lang.String str29 = compiler28.getAstDotGraph();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37, false);
//        java.lang.String str40 = jSSourceFile37.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37);
//        java.lang.String str42 = compilerInput41.getName();
//        java.io.PrintStream printStream43 = null;
//        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions45.inlineConstantVars = false;
//        compilerOptions45.instrumentationTemplate = "eof";
//        boolean boolean50 = compilerOptions45.moveFunctionDeclarations;
//        compiler44.initOptions(compilerOptions45);
//        compilerInput41.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler44);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile55 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region57 = jSSourceFile55.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray58 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions59.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy62 = compilerOptions59.variableRenaming;
//        com.google.javascript.jscomp.Result result63 = compiler44.compile(jSSourceFile55, jSModuleArray58, compilerOptions59);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions64.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy67 = null;
//        compilerOptions64.variableRenaming = variableRenamingPolicy67;
//        java.util.Set<java.lang.String> strSet69 = compilerOptions64.stripNameSuffixes;
//        boolean boolean70 = compilerOptions64.labelRenaming;
//        com.google.javascript.jscomp.Result result71 = compiler28.compile(jSSourceFile32, jSModuleArray58, compilerOptions64);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray72 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile17, jSSourceFile22, jSSourceFile32 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions73 = null;
//        try {
//            com.google.javascript.jscomp.Result result74 = compiler1.compile(jSSourceFile5, jSSourceFileArray72, compilerOptions73);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNotNull(reader7);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertNotNull(reader14);
//        org.junit.Assert.assertNotNull(jSSourceFile17);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(jSSourceFile22);
//        org.junit.Assert.assertNotNull(reader26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile32);
//        org.junit.Assert.assertNotNull(jSSourceFile37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile55);
//        org.junit.Assert.assertNull(region57);
//        org.junit.Assert.assertNotNull(jSModuleArray58);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy62 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy62.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result63);
//        org.junit.Assert.assertNotNull(strSet69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(result71);
//        org.junit.Assert.assertNotNull(jSSourceFileArray72);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, true);
        try {
            compiler3.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node1.setJSType(jSType4);
        com.google.javascript.rhino.jstype.JSType jSType6 = node1.getJSType();
        try {
            node1.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(jSType6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean6 = compilerOptions0.tightenTypes;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean8 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
        closureCodingConvention0.applySubclassRelationship(functionType22, functionType23, subclassType24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing7);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("goog.exportProperty", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing7);
        boolean boolean9 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(38);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "name" + "'", str1.equals("name"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            boolean boolean4 = diagnosticGroup0.matches(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node12 = null;
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType14, functionType15, objectType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        compilerOptions13.generatePseudoNames = false;
//        boolean boolean23 = compilerOptions13.removeUnusedVars;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy24 = compilerOptions13.variableRenaming;
//        boolean boolean25 = compilerOptions13.checkTypedPropertyCalls;
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy24 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy24.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("com.google.javascript.rhino.EcmaError: TypeError: hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: hi!" + "'", str1.equals("com.google.javascript.rhino.EcmaError: TypeError: hi!"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        com.google.javascript.rhino.EvaluatorException evaluatorException7 = new com.google.javascript.rhino.EvaluatorException("hi!", "", (int) '4');
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException7);
        java.lang.String str9 = evaluatorException7.sourceName();
        java.lang.Throwable[] throwableArray10 = evaluatorException7.getSuppressed();
        int int11 = evaluatorException7.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        node12.setJSType(jSType15);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str22 = node18.toString(false, false, false);
        boolean boolean23 = node18.isLocalResultCall();
        node18.setIsSyntheticBlock(false);
        try {
            node6.replaceChildAfter(node12, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "EOF" + "'", str22.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str10 = node6.toString(true, false, true);
        com.google.javascript.rhino.Node node11 = node6.getFirstChild();
        com.google.javascript.rhino.Node node12 = node1.copyInformationFromForTree(node6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable13 = node6.getAncestors();
        try {
            node6.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "EOF" + "'", str10.equals("EOF"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(ancestorIterable13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getInstructionObserverThreshold();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "Unknown class name", 29, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("EOF", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "()", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property EOF");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.gatherCssNames;
        boolean boolean5 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("name", "TypeError", "Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setGenerateExports(true);
        boolean boolean7 = compilerOptions0.generateExports;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        java.lang.String[] strArray17 = new java.lang.String[] { "error reporter", "name", "Named type with empty name component", "hi!", "Named type with empty name component", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "error reporter", "goog.abstractMethod" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str20 = node16.toString(true, false, true);
        com.google.javascript.rhino.Node node21 = node16.getFirstChild();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node25.addChildrenToBack(node27);
        java.lang.Object obj30 = node27.getProp((int) (short) 100);
        java.lang.String str31 = node23.checkTreeEquals(node27);
        com.google.javascript.rhino.Node node32 = node16.clonePropsFrom(node23);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node36.addChildrenToBack(node38);
        java.lang.Object obj41 = node38.getProp((int) (short) 100);
        java.lang.String str42 = node34.checkTreeEquals(node38);
        node34.setLineno(47);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node48.addChildrenToBack(node50);
        java.lang.Object obj53 = node50.getProp((int) (short) 100);
        java.lang.String str54 = node46.checkTreeEquals(node50);
        int int55 = node46.getSourcePosition();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] { node32, node34, node46, node57 };
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(21, nodeArray58);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = node59.getJSDocInfo();
        try {
            boolean boolean61 = closureCodingConvention0.isPropertyTestFunction(node59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "EOF" + "'", str20.equals("EOF"));
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str31.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str42.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str54.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertNull(jSDocInfo60);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setColorizeErrorOutput(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap8;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((-3), 25, 25);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.instrumentForCoverageOnly = true;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("com.google.javascript.rhino.EcmaError: TypeError: hi!", "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: TypeError: hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel3 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel3;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        boolean boolean6 = tweakProcessing5.shouldStrip();
        org.junit.Assert.assertNotNull(detailLevel3);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.smartNameRemoval;
        boolean boolean5 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str6 = node2.toString(false, true, false);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        node8.setJSType(jSType9);
        boolean boolean11 = node8.isVarArgs();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node13.setJSType(jSType14);
        boolean boolean16 = node13.isVarArgs();
        boolean boolean17 = node8.hasChild(node13);
        node8.removeProp(2);
        node2.addChildToFront(node8);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node24.addChildrenToBack(node26);
        java.lang.Object obj29 = node26.getProp((int) (short) 100);
        java.lang.String str30 = node22.checkTreeEquals(node26);
        node26.addSuppression("Unknown class name");
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str38 = node34.toString(false, false, false);
        boolean boolean39 = node34.isLocalResultCall();
        node34.setIsSyntheticBlock(false);
        try {
            com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, node2, node26, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EOF" + "'", str6.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str30.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "EOF" + "'", str38.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "or" + "'", str1.equals("or"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        try {
            boolean boolean3 = compiler1.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, false, false);
        boolean boolean6 = node1.isLocalResultCall();
        node1.setIsSyntheticBlock(false);
        boolean boolean9 = node1.hasMoreThanOneChild();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.lang.String str8 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.ambiguateProperties = true;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        loggerErrorManager1.generateReport();
        int int4 = loggerErrorManager1.getWarningCount();
        int int5 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean11 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node14.addChildrenToBack(node16);
        boolean boolean18 = node16.isLocalResultCall();
        int int19 = node16.getSideEffectFlags();
        try {
            boolean boolean20 = closureCodingConvention0.isPropertyTestFunction(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        com.google.javascript.jscomp.WarningsGuard warningsGuard5 = null;
        try {
            compilerOptions0.addWarningsGuard(warningsGuard5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean5 = node4.isOptionalArg();
        boolean boolean6 = node4.isLocalResultCall();
        int int7 = node4.getLineno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node4.addChildrenToBack(node6);
//        java.lang.Object obj9 = node6.getProp((int) (short) 100);
//        java.lang.String str10 = node2.checkTreeEquals(node6);
//        node6.addSuppression("Unknown class name");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = node6.getJSDocInfo();
//        context0.removeThreadLocal((java.lang.Object) node6);
//        int int16 = node6.getIntProp((-3));
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str10.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(jSDocInfo13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.labelRenaming;
        java.lang.String str7 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node10.addChildrenToBack(node12);
        java.lang.Object obj15 = node12.getProp((int) (short) 100);
        java.lang.String str16 = node8.checkTreeEquals(node12);
        com.google.javascript.rhino.Node node17 = node1.clonePropsFrom(node8);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node19.addChildrenToBack(node21);
        boolean boolean23 = node21.isLocalResultCall();
        int int24 = node21.getLineno();
        try {
            node1.addChildrenToFront(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str16.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str4 = ecmaError3.details();
        java.lang.String str5 = ecmaError3.getName();
        com.google.javascript.rhino.EvaluatorException evaluatorException9 = new com.google.javascript.rhino.EvaluatorException("hi!", "", (int) '4');
        ecmaError3.addSuppressed((java.lang.Throwable) evaluatorException9);
        java.lang.String str11 = evaluatorException9.sourceName();
        java.lang.Throwable[] throwableArray12 = evaluatorException9.getSuppressed();
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException9);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(ecmaError3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError: hi!" + "'", str4.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError" + "'", str5.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean11 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean18 = closureCodingConvention0.isConstantKey("TypeError: hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("com.google.javascript.rhino.EcmaError: TypeError: hi!", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str4 = jSSourceFile3.toString();
        java.io.Reader reader5 = jSSourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("hi!", reader5);
        java.lang.String str7 = sourceFile6.toString();
        java.io.Reader reader8 = sourceFile6.getCodeReader();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(reader8);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.setCompileFunctionsWithDynamicScope(true);
//        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.disambiguateProperties = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = null;
        compilerOptions10.variableRenaming = variableRenamingPolicy13;
        java.util.Set<java.lang.String> strSet15 = compilerOptions10.stripNameSuffixes;
        compilerOptions10.aliasAllStrings = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap18 = compilerOptions10.getDefineReplacements();
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions10.aggressiveVarCheck;
        compilerOptions0.setWarningLevel(diagnosticGroup9, checkLevel19);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNotNull(strMap18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str13 = node9.toString(true, false, true);
        com.google.javascript.rhino.Node node14 = node9.getFirstChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node18.addChildrenToBack(node20);
        java.lang.Object obj23 = node20.getProp((int) (short) 100);
        java.lang.String str24 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node25 = node9.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        node27.setLineno(47);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        int int48 = node39.getSourcePosition();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node25, node27, node39, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(21, nodeArray51);
        com.google.javascript.rhino.Node node53 = node3.copyInformationFromForTree(node52);
        node52.setVarArgs(true);
        int int57 = node52.getIntProp(37);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF" + "'", str13.equals("EOF"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setRewriteNewDateGoogNow(false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.optimizeReturns = false;
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean8 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.aliasableGlobals = "<No stack trace available>";
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        compilerOptions0.removeUnusedPrototypeProperties = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strMap8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str6 = node2.toString(true, false, true);
        com.google.javascript.rhino.Node node7 = node2.getFirstChild();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node11.addChildrenToBack(node13);
        java.lang.Object obj16 = node13.getProp((int) (short) 100);
        java.lang.String str17 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node18 = node2.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node22.addChildrenToBack(node24);
        java.lang.Object obj27 = node24.getProp((int) (short) 100);
        java.lang.String str28 = node20.checkTreeEquals(node24);
        node20.setLineno(47);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node34.addChildrenToBack(node36);
        java.lang.Object obj39 = node36.getProp((int) (short) 100);
        java.lang.String str40 = node32.checkTreeEquals(node36);
        int int41 = node32.getSourcePosition();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node18, node20, node32, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(21, nodeArray44);
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = node45.getJSDocInfo();
        com.google.javascript.rhino.Node node48 = node45.getAncestor(18);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EOF" + "'", str6.equals("EOF"));
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str17.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str28.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str40.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNull(jSDocInfo46);
        org.junit.Assert.assertNull(node48);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        java.lang.Class<?> wildcardClass3 = context0.getClass();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput4.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        boolean boolean14 = closureCodingConvention0.isExported("", true);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node15, node20);
        java.lang.String str22 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "goog.global" + "'", str22.equals("goog.global"));
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter6 = context0.setErrorReporter(errorReporter5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str5 = jSSourceFile4.toString();
        java.io.Reader reader6 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromReader("hi!", reader6);
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromReader("error reporter", reader6);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, false, false);
        boolean boolean6 = node1.isLocalResultCall();
        boolean boolean7 = node1.isLocalResultCall();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("com.google.javascript.rhino.EcmaError: TypeError: hi!", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean4 = closureCodingConvention0.isPrivate("eof");
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("hi!");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler2.tracker = performanceTracker3;
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = compiler2.getErrors();
        try {
            boolean boolean6 = compiler2.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.appNameStr = "hi!";
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.inlineConstantVars = false;
        java.lang.String str8 = compilerOptions5.jsOutputFile;
        boolean boolean9 = compilerOptions5.smartNameRemoval;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions5.brokenClosureRequiresLevel;
        compilerOptions0.checkMissingReturn = checkLevel10;
        compilerOptions0.setShadowVariables(true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        java.util.Locale locale3 = null;
//        java.util.Locale locale4 = context0.setLocale(locale3);
//        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(locale4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        com.google.javascript.jscomp.MessageBundle messageBundle10 = null;
        compilerOptions0.messageBundle = messageBundle10;
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean7 = compilerOptions0.ideMode;
        compilerOptions0.setDefineToStringLiteral("hi!", "");
        boolean boolean11 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.reportPath = "name";
        compilerOptions0.removeUnusedPrototypeProperties = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        try {
            boolean boolean5 = jSModuleGraph2.dependsOn(jSModule3, jSModule4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        compilerOptions0.inlineFunctions = false;
        byte[] byteArray7 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertNull(byteArray7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("eof");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node9.addChildrenToBack(node11);
        java.lang.Object obj14 = node11.getProp((int) (short) 100);
        java.lang.String str15 = node7.checkTreeEquals(node11);
        node7.setLineno(47);
        boolean boolean19 = node7.getBooleanProp(0);
        try {
            boolean boolean20 = closureCodingConvention0.isPropertyTestFunction(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str15.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler2.tracker = performanceTracker3;
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = compiler2.getErrors();
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = compiler2.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager2.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager2.getWarnings();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        node2.setJSType(jSType3);
        int int5 = node2.getSideEffectFlags();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(43, node2, 140, 45);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node10.addChildrenToBack(node12);
        boolean boolean14 = node12.isLocalResultCall();
        int int15 = node12.getSideEffectFlags();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str22 = node18.toString(true, false, true);
        com.google.javascript.rhino.Node node23 = node18.getFirstChild();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node27.addChildrenToBack(node29);
        java.lang.Object obj32 = node29.getProp((int) (short) 100);
        java.lang.String str33 = node25.checkTreeEquals(node29);
        com.google.javascript.rhino.Node node34 = node18.clonePropsFrom(node25);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node38.addChildrenToBack(node40);
        java.lang.Object obj43 = node40.getProp((int) (short) 100);
        java.lang.String str44 = node36.checkTreeEquals(node40);
        node36.setLineno(47);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node50.addChildrenToBack(node52);
        java.lang.Object obj55 = node52.getProp((int) (short) 100);
        java.lang.String str56 = node48.checkTreeEquals(node52);
        int int57 = node48.getSourcePosition();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] { node34, node36, node48, node59 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(21, nodeArray60);
        com.google.javascript.rhino.Node node62 = node12.copyInformationFromForTree(node61);
        boolean boolean63 = node12.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        node66.setJSType(jSType67);
        int int69 = node66.getSideEffectFlags();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(43, node66, 140, 45);
        try {
            node2.replaceChildAfter(node12, node66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "EOF" + "'", str22.equals("EOF"));
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str33.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str44.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str56.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode7 = compilerOptions0.tracer;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode7.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setReturnsTainted();
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        com.google.javascript.rhino.Node node20 = null;
        try {
            node7.addChildToFront(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("error reporter", "name", 37);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        com.google.javascript.jscomp.WarningsGuard warningsGuard11 = null;
        try {
            compilerOptions0.addWarningsGuard(warningsGuard11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str1 = diagnosticType0.key;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str6 = node2.toString(true, false, true);
        int int7 = node2.getSourcePosition();
        node2.setIsSyntheticBlock(true);
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "Not declared as a constructor", (java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EOF" + "'", str6.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        boolean boolean6 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node4.addChildrenToBack(node6);
        java.lang.Object obj9 = node6.getProp((int) (short) 100);
        java.lang.String str10 = node2.checkTreeEquals(node6);
        node6.addSuppression("Unknown class name");
        boolean boolean13 = node6.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString(25, "goog.exportProperty", (int) (byte) 0, 31);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean21 = closureCodingConvention19.isValidEnumKey("error reporter");
        java.lang.String str22 = closureCodingConvention19.getAbstractMethodName();
        boolean boolean25 = closureCodingConvention19.isExported("error reporter", true);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str31 = node27.toString(true, false, true);
        com.google.javascript.rhino.Node node32 = node27.getFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder33 = node27.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node35.putBooleanProp(22, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = node35.getJSDocInfo();
        java.lang.String str40 = closureCodingConvention19.extractClassNameIfProvide(node27, node35);
        com.google.javascript.rhino.Node node41 = null;
        try {
            com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(29, node6, node18, node27, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str10.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "goog.abstractMethod" + "'", str22.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "EOF" + "'", str31.equals("EOF"));
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.checkControlStructures;
        compilerOptions4.setRemoveClosureAsserts(false);
        compilerOptions4.setTweakToBooleanLiteral("", false);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup11;
        java.lang.RuntimeException runtimeException13 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) false, (java.lang.Object) diagnosticGroup11);
        boolean boolean14 = composeWarningsGuard3.disables(diagnosticGroup11);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(runtimeException13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        java.lang.String str5 = compilerOptions0.jsOutputFile;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setShadowVariables(false);
        boolean boolean6 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str7 = compilerOptions0.reportPath;
        compilerOptions0.setShadowVariables(true);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        java.lang.String str3 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.labelRenaming = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        java.lang.String str7 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        compiler1.disableThreads();
        try {
            com.google.javascript.jscomp.Region region6 = compiler1.getSourceRegion("Unknown class name", 22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.setDefineToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: hi!", (double) 'a');
        boolean boolean10 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getErrorMessage();
        int int3 = ecmaError1.getColumnNumber();
        ecmaError1.initLineNumber(8);
        ecmaError1.initSourceName("<No stack trace available>");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup2, diagnosticGroup3, diagnosticGroup5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup("", diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = new com.google.javascript.jscomp.DiagnosticGroup("or", diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup9;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup9;
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler3);
        compilerOptions0.setGenerateExports(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode11 = compilerOptions0.tracer;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + tracerMode11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode11.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eol" + "'", str1.equals("eol"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("EOF [synthetic: 1]");
        try {
            compilerInput4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        boolean boolean13 = closureCodingConvention0.isExported("TypeError: hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        boolean boolean13 = closureCodingConvention0.isExported("TypeError: hi!");
        java.lang.String str14 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str13 = node9.toString(true, false, true);
        com.google.javascript.rhino.Node node14 = node9.getFirstChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node18.addChildrenToBack(node20);
        java.lang.Object obj23 = node20.getProp((int) (short) 100);
        java.lang.String str24 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node25 = node9.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        node27.setLineno(47);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        int int48 = node39.getSourcePosition();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node25, node27, node39, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(21, nodeArray51);
        com.google.javascript.rhino.Node node53 = node3.copyInformationFromForTree(node52);
        node52.setVarArgs(true);
        try {
            java.lang.String str56 = node52.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ADD 0 [jsdoc_info: 1] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF" + "'", str13.equals("EOF"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setShadowVariables(false);
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.tightenTypes = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.sourceMapFormat = format2;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.checkControlStructures;
        compilerOptions4.setCollapsePropertiesOnExternTypes(true);
        compilerOptions4.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions4.brokenClosureRequiresLevel;
        compilerOptions0.checkProvides = checkLevel10;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(38);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions0.sourceMapFormat = format2;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setLooseTypes(true);
        java.lang.String str7 = compilerOptions0.locale;
        boolean boolean8 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isExported("");
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean14 = closureCodingConvention0.isExported("");
        boolean boolean16 = closureCodingConvention0.isValidEnumKey("()");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.instrumentationTemplate = "eof";
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.setPropertyAffinity(false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.sourceMapOutputPath = "TypeError";
        compilerOptions0.labelRenaming = true;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.appNameStr = "eof";
        compilerOptions0.checkMissingGetCssNameBlacklist = "";
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("Unknown class name");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("JSC_OPTIMIZE_LOOP_ERROR", "Not declared as a constructor");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node3.addChildrenToBack(node5);
        java.lang.Object obj8 = node5.getProp((int) (short) 100);
        java.lang.String str9 = node1.checkTreeEquals(node5);
        node5.addSuppression("Unknown class name");
        boolean boolean12 = node5.isOnlyModifiesThisCall();
        try {
            node5.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str9.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        try {
            com.google.javascript.rhino.Node node5 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.enableExternExports(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType11, functionType12, objectType13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean6 = closureCodingConvention0.isConstant("goog.exportProperty");
        boolean boolean8 = closureCodingConvention0.isConstantKey("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str5 = jSSourceFile2.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        java.lang.String str7 = compilerInput6.getName();
//        java.io.PrintStream printStream8 = null;
//        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions10.inlineConstantVars = false;
//        compilerOptions10.instrumentationTemplate = "eof";
//        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
//        compiler9.initOptions(compilerOptions10);
//        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions24.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
//        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
//        java.lang.String[] strArray37 = new java.lang.String[] { "TypeError: hi!", "eof", "or", "eof", "or", "hi!", "TypeError", "TypeError: hi!" };
//        java.util.ArrayList<java.lang.String> strList38 = new java.util.ArrayList<java.lang.String>();
//        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList38, strArray37);
//        compilerOptions24.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
//        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap41 = compilerOptions24.getTweakReplacements();
//        compilerOptions24.inlineVariables = true;
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile20);
//        org.junit.Assert.assertNull(region22);
//        org.junit.Assert.assertNotNull(jSModuleArray23);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result28);
//        org.junit.Assert.assertNotNull(strArray37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(strMap41);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.removeEmptyFunctions = true;
//        compilerOptions0.checkSuspiciousCode = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel6, "hi!");
//        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
//        java.io.PrintStream printStream10 = null;
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean24 = compilerOptions23.checkControlStructures;
//        compilerOptions23.setRemoveClosureAsserts(false);
//        compilerOptions23.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result30 = compiler11.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
//        compilerOptions23.generatePseudoNames = false;
//        boolean boolean33 = compilerOptions23.removeUnusedVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions23.brokenClosureRequiresLevel;
//        diagnosticType8.level = checkLevel34;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions36.inlineConstantVars = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions36.aggressiveVarCheck;
//        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions36.checkUndefinedProperties;
//        diagnosticType8.level = checkLevel40;
//        compilerOptions0.checkGlobalThisLevel = checkLevel40;
//        compilerOptions0.gatherCssNames = false;
//        compilerOptions0.printInputDelimiter = false;
//        org.junit.Assert.assertNotNull(diagnosticType8);
//        org.junit.Assert.assertNull(checkLevel9);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNotNull(jSSourceFileArray17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(result30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(true, false, true);
        com.google.javascript.rhino.Node node6 = node1.getFirstChild();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node10.addChildrenToBack(node12);
        java.lang.Object obj15 = node12.getProp((int) (short) 100);
        java.lang.String str16 = node8.checkTreeEquals(node12);
        com.google.javascript.rhino.Node node17 = node1.clonePropsFrom(node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.removeEmptyFunctions = true;
        compilerOptions18.checkSuspiciousCode = false;
        compilerOptions18.setGenerateExports(true);
        boolean boolean25 = compilerOptions18.generateExports;
        java.lang.String str26 = compilerOptions18.nameReferenceReportPath;
        java.lang.String[] strArray35 = new java.lang.String[] { "error reporter", "name", "Named type with empty name component", "hi!", "Named type with empty name component", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "error reporter", "goog.abstractMethod" };
        java.util.LinkedHashSet<java.lang.String> strSet36 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet36, strArray35);
        compilerOptions18.aliasableStrings = strSet36;
        node8.setDirectives((java.util.Set<java.lang.String>) strSet36);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str16.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.toString();
        java.lang.String str4 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: hi!" + "'", str3.equals("com.google.javascript.rhino.EcmaError: TypeError: hi!"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("eol", "", "goog.global");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property eol");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: TypeError: hi!\n", "JSC_OPTIMIZE_LOOP_ERROR", (int) (byte) 1, "", 140);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isValidEnumKey("error reporter");
        java.lang.String str7 = closureCodingConvention4.getAbstractMethodName();
        boolean boolean9 = closureCodingConvention4.isSuperClassReference("eof");
        boolean boolean11 = closureCodingConvention4.isSuperClassReference("TypeError: hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        node13.setJSType(jSType14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        node13.setJSType(jSType16);
        boolean boolean18 = closureCodingConvention4.isOptionalParameter(node13);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship19 = closureCodingConvention0.getClassesDefinedByCall(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkSymbols = false;
        compilerOptions0.closurePass = true;
        boolean boolean9 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        int int12 = node6.getIntProp(42);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.nameReferenceGraphPath = "hi!";
        java.lang.String str10 = compilerOptions7.instrumentationTemplate;
        compilerOptions7.labelRenaming = false;
        java.util.Set<java.lang.String> strSet13 = compilerOptions7.stripNamePrefixes;
        compilerOptions0.stripTypes = strSet13;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strSet13);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        try {
//            com.google.javascript.rhino.Context.reportError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        java.lang.String str5 = compilerOptions0.jsOutputFile;
        boolean boolean6 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel2, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray6 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray6);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNull(checkLevel5);
        org.junit.Assert.assertNotNull(diagnosticTypeArray6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        com.google.javascript.rhino.Node node11 = null;
        try {
            node1.addChildrenToBack(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str5 = jSSourceFile2.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        java.lang.String str7 = compilerInput6.getName();
//        java.io.PrintStream printStream8 = null;
//        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions10.inlineConstantVars = false;
//        compilerOptions10.instrumentationTemplate = "eof";
//        boolean boolean15 = compilerOptions10.moveFunctionDeclarations;
//        compiler9.initOptions(compilerOptions10);
//        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region22 = jSSourceFile20.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions24.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy27 = compilerOptions24.variableRenaming;
//        com.google.javascript.jscomp.Result result28 = compiler9.compile(jSSourceFile20, jSModuleArray23, compilerOptions24);
//        java.lang.String[] strArray37 = new java.lang.String[] { "TypeError: hi!", "eof", "or", "eof", "or", "hi!", "TypeError", "TypeError: hi!" };
//        java.util.ArrayList<java.lang.String> strList38 = new java.util.ArrayList<java.lang.String>();
//        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList38, strArray37);
//        compilerOptions24.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
//        boolean boolean41 = compilerOptions24.ideMode;
//        compilerOptions24.moveFunctionDeclarations = true;
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile20);
//        org.junit.Assert.assertNull(region22);
//        org.junit.Assert.assertNotNull(jSModuleArray23);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy27.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result28);
//        org.junit.Assert.assertNotNull(strArray37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        boolean boolean6 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node8 = node4.getChildAtIndex((int) (byte) -1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.checkControlStructures;
        compilerOptions9.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy13 = compilerOptions9.anonymousFunctionNaming;
        boolean boolean14 = compilerOptions9.prettyPrint;
        compilerOptions9.setPropertyAffinity(true);
        compilerOptions9.locale = "eof";
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig21 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions19);
        boolean boolean22 = compilerOptions19.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat23 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions19.errorFormat = errorFormat23;
        java.lang.String str25 = compilerOptions19.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions19.checkMissingReturn;
        compilerOptions9.checkProvides = checkLevel26;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel29, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel32 = diagnosticType31.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel34, "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel37 = diagnosticType36.defaultLevel;
        int int38 = diagnosticType31.compareTo(diagnosticType36);
        java.lang.String[] strArray44 = new java.lang.String[] { "JSC_OPTIMIZE_LOOP_ERROR", "eof", "JSC_OPTIMIZE_LOOP_ERROR", "", "goog.global" };
        try {
            com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make("", node8, checkLevel26, diagnosticType36, strArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy13 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy13.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(errorFormat23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNull(checkLevel32);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNull(checkLevel37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(strArray44);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node5);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("TypeError");
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        node17.setJSType(jSType18);
        try {
            java.util.List<java.lang.String> strList20 = closureCodingConvention0.identifyTypeDeclarationCall(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.nameReferenceGraphPath = "hi!";
        compilerOptions0.exportTestFunctions = false;
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        compilerOptions0.removeEmptyFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        node2.setJSType(jSType3);
        boolean boolean5 = node2.isVarArgs();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        boolean boolean11 = node2.hasChild(node7);
        com.google.javascript.rhino.Node node13 = node7.getAncestor(0);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str19 = node15.toString(false, true, false);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        node21.setJSType(jSType22);
        boolean boolean24 = node21.isVarArgs();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        node26.setJSType(jSType27);
        boolean boolean29 = node26.isVarArgs();
        boolean boolean30 = node21.hasChild(node26);
        node21.removeProp(2);
        node15.addChildToFront(node21);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention34 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean36 = closureCodingConvention34.isValidEnumKey("error reporter");
        java.lang.String str37 = closureCodingConvention34.getAbstractMethodName();
        boolean boolean40 = closureCodingConvention34.isExported("error reporter", true);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str46 = node42.toString(true, false, true);
        com.google.javascript.rhino.Node node47 = node42.getFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder48 = node42.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node50.putBooleanProp(22, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo54 = node50.getJSDocInfo();
        java.lang.String str55 = closureCodingConvention34.extractClassNameIfProvide(node42, node50);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention56 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean58 = closureCodingConvention56.isValidEnumKey("error reporter");
        java.lang.String str59 = closureCodingConvention56.getExportPropertyFunction();
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        node61.setJSType(jSType62);
        boolean boolean64 = node61.isVarArgs();
        boolean boolean65 = closureCodingConvention56.isOptionalParameter(node61);
        try {
            com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(47, node13, node21, node50, node61, 100, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EOF" + "'", str19.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "goog.abstractMethod" + "'", str37.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "EOF" + "'", str46.equals("EOF"));
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertNull(jSDocInfo54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "goog.exportProperty" + "'", str59.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setGenerateExports(true);
        boolean boolean7 = compilerOptions0.generateExports;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        java.lang.String[] strArray17 = new java.lang.String[] { "error reporter", "name", "Named type with empty name component", "hi!", "Named type with empty name component", "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n", "error reporter", "goog.abstractMethod" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions0.aliasableStrings = strSet18;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        boolean boolean11 = node6.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node13.addChildrenToBack(node15);
        boolean boolean17 = node15.isLocalResultCall();
        int int18 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str25 = node21.toString(true, false, true);
        com.google.javascript.rhino.Node node26 = node21.getFirstChild();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node30.addChildrenToBack(node32);
        java.lang.Object obj35 = node32.getProp((int) (short) 100);
        java.lang.String str36 = node28.checkTreeEquals(node32);
        com.google.javascript.rhino.Node node37 = node21.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        node39.setLineno(47);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node53.addChildrenToBack(node55);
        java.lang.Object obj58 = node55.getProp((int) (short) 100);
        java.lang.String str59 = node51.checkTreeEquals(node55);
        int int60 = node51.getSourcePosition();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node37, node39, node51, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(21, nodeArray63);
        com.google.javascript.rhino.Node node65 = node15.copyInformationFromForTree(node64);
        int int66 = node15.getSourcePosition();
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int70 = node68.getIntProp(2);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean76 = node75.isOptionalArg();
        boolean boolean77 = node75.isLocalResultCall();
        boolean boolean78 = node68.isEquivalentToTyped(node75);
        try {
            node6.addChildBefore(node15, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "EOF" + "'", str25.equals("EOF"));
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str36.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str59.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean6 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("eof");
        boolean boolean7 = closureCodingConvention0.isSuperClassReference("TypeError: hi!");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        node9.setJSType(jSType10);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node9.setJSType(jSType12);
        boolean boolean14 = closureCodingConvention0.isOptionalParameter(node9);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node18.addChildrenToBack(node20);
        java.lang.Object obj23 = node20.getProp((int) (short) 100);
        java.lang.String str24 = node16.checkTreeEquals(node20);
        node20.addSuppression("Unknown class name");
        boolean boolean27 = node20.isOnlyModifiesThisCall();
        try {
            java.lang.String str28 = closureCodingConvention0.getSingletonGetterClassName(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("TypeError: hi!", "TypeError", "TypeError");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError: hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        compilerOptions13.generatePseudoNames = false;
//        boolean boolean23 = compilerOptions13.removeUnusedVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions13.brokenClosureRequiresLevel;
//        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap25 = compilerOptions13.getDefineReplacements();
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(strMap25);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        java.lang.String str3 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        compilerInput4.clearAst();
        try {
            java.lang.String str9 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        int int13 = node12.getLineno();
        boolean boolean14 = closureCodingConvention0.isVarArgsParameter(node12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        java.lang.String str2 = compiler1.getAstDotGraph();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
//        java.lang.String str13 = jSSourceFile10.getName();
//        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
//        java.lang.String str15 = compilerInput14.getName();
//        java.io.PrintStream printStream16 = null;
//        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions18.inlineConstantVars = false;
//        compilerOptions18.instrumentationTemplate = "eof";
//        boolean boolean23 = compilerOptions18.moveFunctionDeclarations;
//        compiler17.initOptions(compilerOptions18);
//        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.Region region30 = jSSourceFile28.getRegion(26);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions32.nameReferenceGraphPath = "hi!";
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy35 = compilerOptions32.variableRenaming;
//        com.google.javascript.jscomp.Result result36 = compiler17.compile(jSSourceFile28, jSModuleArray31, compilerOptions32);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions37.inlineConstantVars = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy40 = null;
//        compilerOptions37.variableRenaming = variableRenamingPolicy40;
//        java.util.Set<java.lang.String> strSet42 = compilerOptions37.stripNameSuffixes;
//        boolean boolean43 = compilerOptions37.labelRenaming;
//        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile5, jSModuleArray31, compilerOptions37);
//        int int45 = compiler1.getErrorCount();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = null;
//        try {
//            com.google.javascript.rhino.Node node47 = compiler1.parse(jSSourceFile46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile28);
//        org.junit.Assert.assertNull(region30);
//        org.junit.Assert.assertNotNull(jSModuleArray31);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy35.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(result36);
//        org.junit.Assert.assertNotNull(strSet42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(result44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setShadowVariables(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = compilerOptions0.cssRenamingMap;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node1.addChildrenToBack(node3);
        boolean boolean5 = node3.isLocalResultCall();
        int int6 = node3.getSideEffectFlags();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str13 = node9.toString(true, false, true);
        com.google.javascript.rhino.Node node14 = node9.getFirstChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node18.addChildrenToBack(node20);
        java.lang.Object obj23 = node20.getProp((int) (short) 100);
        java.lang.String str24 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node25 = node9.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node29.addChildrenToBack(node31);
        java.lang.Object obj34 = node31.getProp((int) (short) 100);
        java.lang.String str35 = node27.checkTreeEquals(node31);
        node27.setLineno(47);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node41.addChildrenToBack(node43);
        java.lang.Object obj46 = node43.getProp((int) (short) 100);
        java.lang.String str47 = node39.checkTreeEquals(node43);
        int int48 = node39.getSourcePosition();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node25, node27, node39, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(21, nodeArray51);
        com.google.javascript.rhino.Node node53 = node3.copyInformationFromForTree(node52);
        int int54 = node3.getSourcePosition();
        try {
            java.lang.String str55 = node3.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF" + "'", str13.equals("EOF"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str24.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str35.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str47.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = null;
        compilerOptions0.setCodingConvention(codingConvention7);
        boolean boolean9 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions0.getCodingConvention();
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(codingConvention9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
//        compilerOptions2.anonymousFunctionNaming = anonymousFunctionNamingPolicy9;
//        com.google.javascript.jscomp.SourceMap.Format format11 = compilerOptions2.sourceMapFormat;
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
//        org.junit.Assert.assertNotNull(format11);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.inlineConstantVars = false;
//        compilerOptions2.instrumentationTemplate = "eof";
//        boolean boolean7 = compilerOptions2.moveFunctionDeclarations;
//        compiler1.initOptions(compilerOptions2);
//        try {
//            compiler1.processDefines();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj1 = null;
//        context0.seal(obj1);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
//        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
//        boolean boolean6 = context0.hasCompileFunctionsWithDynamicScope();
//        try {
//            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (-2));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.global");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        java.lang.String str4 = jSSourceFile3.toString();
        java.io.Reader reader5 = jSSourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("hi!", reader5);
        java.lang.String str7 = sourceFile6.toString();
        java.lang.String str9 = sourceFile6.getLine(11);
        java.io.Reader reader10 = sourceFile6.getCodeReader();
        java.lang.String str11 = sourceFile6.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(reader10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.checkControlStructures;
//        compilerOptions0.setRemoveClosureAsserts(false);
//        compilerOptions0.setTweakToBooleanLiteral("", false);
//        boolean boolean7 = compilerOptions0.optimizeCalls;
//        compilerOptions0.instrumentForCoverage = false;
//        java.io.PrintStream printStream10 = null;
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean24 = compilerOptions23.checkControlStructures;
//        compilerOptions23.setRemoveClosureAsserts(false);
//        compilerOptions23.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result30 = compiler11.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
//        compilerOptions23.generatePseudoNames = false;
//        boolean boolean33 = compilerOptions23.removeUnusedVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions23.brokenClosureRequiresLevel;
//        compilerOptions0.checkMissingGetCssNameLevel = checkLevel34;
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertNotNull(jSSourceFileArray17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(result30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        boolean boolean6 = node4.isLocalResultCall();
        int int7 = node4.getSideEffectFlags();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str14 = node10.toString(true, false, true);
        com.google.javascript.rhino.Node node15 = node10.getFirstChild();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node19.addChildrenToBack(node21);
        java.lang.Object obj24 = node21.getProp((int) (short) 100);
        java.lang.String str25 = node17.checkTreeEquals(node21);
        com.google.javascript.rhino.Node node26 = node10.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node30.addChildrenToBack(node32);
        java.lang.Object obj35 = node32.getProp((int) (short) 100);
        java.lang.String str36 = node28.checkTreeEquals(node32);
        node28.setLineno(47);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((-1.0d));
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node42.addChildrenToBack(node44);
        java.lang.Object obj47 = node44.getProp((int) (short) 100);
        java.lang.String str48 = node40.checkTreeEquals(node44);
        int int49 = node40.getSourcePosition();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) (-2));
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node26, node28, node40, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(21, nodeArray52);
        com.google.javascript.rhino.Node node54 = node4.copyInformationFromForTree(node53);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str60 = node56.toString(true, false, true);
        int int61 = node56.getSourcePosition();
        node56.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (byte) 0);
        int int67 = node65.getIntProp(2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions68.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy71 = null;
        compilerOptions68.variableRenaming = variableRenamingPolicy71;
        java.util.Set<java.lang.String> strSet73 = compilerOptions68.stripNameSuffixes;
        compilerOptions68.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet76 = compilerOptions68.stripTypePrefixes;
        node65.setDirectives(strSet76);
        try {
            com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(18, node54, node56, node65, 19, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EOF" + "'", str14.equals("EOF"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str25.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str36.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str48.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "EOF" + "'", str60.equals("EOF"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(strSet73);
        org.junit.Assert.assertNotNull(strSet76);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        com.google.javascript.rhino.EvaluatorException evaluatorException7 = new com.google.javascript.rhino.EvaluatorException("hi!", "", (int) '4');
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException7);
        java.lang.String str9 = evaluatorException7.sourceName();
        int int10 = evaluatorException7.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: hi!" + "'", str2.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingReturn;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean10 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isValidEnumKey("error reporter");
        boolean boolean8 = closureCodingConvention4.isPrivate("eof");
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention4.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 48, 4);
        boolean boolean17 = closureCodingConvention4.isVarArgsParameter(node16);
        try {
            java.util.List<java.lang.String> strList18 = closureCodingConvention0.identifyTypeDeclarationCall(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        java.lang.String str6 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean14 = compilerOptions13.checkControlStructures;
//        compilerOptions13.setRemoveClosureAsserts(false);
//        compilerOptions13.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result20 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11, compilerOptions13);
//        java.lang.RuntimeException runtimeException22 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) result20, (java.lang.Object) 100);
//        java.lang.Throwable[] throwableArray23 = runtimeException22.getSuppressed();
//        java.lang.RuntimeException runtimeException25 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) throwableArray23, (java.lang.Object) 9);
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(result20);
//        org.junit.Assert.assertNotNull(runtimeException22);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(runtimeException25);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.appNameStr = "hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.inlineLocalVariables;
        boolean boolean7 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, false);
        java.lang.String str13 = jSSourceFile10.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) boolean7, (java.lang.Object) compilerInput14);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(runtimeException15);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.aliasAllStrings = true;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean9 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        boolean boolean20 = node7.isSyntheticBlock();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean23 = closureCodingConvention21.isValidEnumKey("error reporter");
        java.lang.String str24 = closureCodingConvention21.getExportPropertyFunction();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        node26.setJSType(jSType27);
        boolean boolean29 = node26.isVarArgs();
        boolean boolean30 = closureCodingConvention21.isOptionalParameter(node26);
        boolean boolean32 = closureCodingConvention21.isExported("");
        boolean boolean35 = closureCodingConvention21.isExported("", true);
        com.google.javascript.rhino.Node node36 = null;
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        java.lang.String str42 = closureCodingConvention21.extractClassNameIfProvide(node36, node41);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) ' ', 36, 0);
        com.google.javascript.rhino.Node node47 = node41.copyInformationFromForTree(node46);
        boolean boolean48 = node7.isEquivalentToTyped(node46);
        try {
            node7.setString("JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "goog.exportProperty" + "'", str24.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.removeEmptyFunctions = true;
//        compilerOptions2.checkMissingGetCssNameBlacklist = "error reporter";
//        boolean boolean7 = compilerOptions2.deadAssignmentElimination;
//        compiler1.initOptions(compilerOptions2);
//        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler1.getErrors();
//        try {
//            compiler1.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(jSErrorArray9);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node2.addChildrenToBack(node4);
        java.lang.Object obj7 = node4.getProp((int) (short) 100);
        int int9 = node4.getIntProp(0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: hi!", "()", "error reporter", "hi!", "EOF" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node4, diagnosticType10, strArray17);
        node4.setCharno(36);
        boolean boolean21 = node4.isOnlyModifiesThisCall();
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "goog.exportProperty", 31, 110);
        boolean boolean5 = node4.isOptionalArg();
        node4.setSourcePositionForTree(18);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("TypeError", "EOF [synthetic: 1]", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.inlineConstantVars = false;
//        compilerOptions0.checkSymbols = true;
//        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
//        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel7, "hi!");
//        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "");
//        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, jSSourceFileArray18);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray21 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList22 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList22, jSModuleArray21);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean25 = compilerOptions24.checkControlStructures;
//        compilerOptions24.setRemoveClosureAsserts(false);
//        compilerOptions24.setTweakToBooleanLiteral("", false);
//        com.google.javascript.jscomp.Result result31 = compiler12.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList22, compilerOptions24);
//        compilerOptions24.generatePseudoNames = false;
//        boolean boolean34 = compilerOptions24.removeUnusedVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions24.brokenClosureRequiresLevel;
//        diagnosticType9.level = checkLevel35;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions37.inlineConstantVars = false;
//        compilerOptions37.unaliasableGlobals = "";
//        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions37.reportUnknownTypes;
//        diagnosticType9.level = checkLevel42;
//        compilerOptions0.aggressiveVarCheck = checkLevel42;
//        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions0.brokenClosureRequiresLevel;
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(diagnosticType9);
//        org.junit.Assert.assertNull(checkLevel10);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertNotNull(jSSourceFileArray18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(result31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter();
//        long long2 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
//        context1.removeThreadLocal((java.lang.Object) node4);
//        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        java.lang.String str12 = node8.toString(true, false, true);
//        com.google.javascript.rhino.Node node13 = node8.getFirstChild();
//        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node17.addChildrenToBack(node19);
//        java.lang.Object obj22 = node19.getProp((int) (short) 100);
//        java.lang.String str23 = node15.checkTreeEquals(node19);
//        com.google.javascript.rhino.Node node24 = node8.clonePropsFrom(node15);
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node28.addChildrenToBack(node30);
//        java.lang.Object obj33 = node30.getProp((int) (short) 100);
//        java.lang.String str34 = node26.checkTreeEquals(node30);
//        node26.setLineno(47);
//        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((-1.0d));
//        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        node40.addChildrenToBack(node42);
//        java.lang.Object obj45 = node42.getProp((int) (short) 100);
//        java.lang.String str46 = node38.checkTreeEquals(node42);
//        int int47 = node38.getSourcePosition();
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber((double) (-2));
//        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node24, node26, node38, node49 };
//        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(21, nodeArray50);
//        com.google.javascript.rhino.Node node52 = null;
//        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) 0);
//        com.google.javascript.rhino.jstype.JSType jSType55 = null;
//        node54.setJSType(jSType55);
//        int int57 = node54.getSideEffectFlags();
//        com.google.javascript.rhino.Node node58 = node54.cloneNode();
//        try {
//            com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '#', node4, node51, node52, node58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(node4);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "EOF" + "'", str12.equals("EOF"));
//        org.junit.Assert.assertNull(node13);
//        org.junit.Assert.assertNotNull(node15);
//        org.junit.Assert.assertNull(obj22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str23.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNull(obj33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str34.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertNotNull(node38);
//        org.junit.Assert.assertNull(obj45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n" + "'", str46.equals("Node tree inequality:\nTree1:\nNUMBER -1.0\n\n\nTree2:\nEOF\n\n\nSubtree1: NUMBER -1.0\n\n\nSubtree2: EOF\n"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertNotNull(nodeArray50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(node58);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.addActivationName("TypeError: hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
//        java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) context0);
//        context0.setGeneratingSource(true);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.checkTypes;
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(160);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "<unknown=160>" + "'", str1.equals("<unknown=160>"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean5 = closureCodingConvention0.isSuperClassReference("eof");
        java.lang.String str6 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.optimizeParameters = true;
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.generatePseudoNames = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing7);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        compilerOptions0.collapseProperties = true;
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.setTweakToBooleanLiteral("error reporter", true);
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.closurePass = true;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasAllStrings = true;
        boolean boolean15 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        boolean boolean4 = node1.isVarArgs();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node6.setJSType(jSType7);
        boolean boolean9 = node6.isVarArgs();
        boolean boolean10 = node1.hasChild(node6);
        node1.removeProp(2);
        node1.setOptionalArg(true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean17 = closureCodingConvention15.isValidEnumKey("error reporter");
        java.lang.String str18 = closureCodingConvention15.getAbstractMethodName();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        boolean boolean23 = node20.isVarArgs();
        boolean boolean24 = node20.hasChildren();
        boolean boolean25 = closureCodingConvention15.isOptionalParameter(node20);
        try {
            com.google.javascript.rhino.Node node26 = node1.removeChildAfter(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "goog.abstractMethod" + "'", str18.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        compilerOptions0.checkSymbols = false;
        boolean boolean7 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.coalesceVariableNames = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.inlineConstantVars = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = null;
        compilerOptions4.variableRenaming = variableRenamingPolicy7;
        java.util.Set<java.lang.String> strSet9 = compilerOptions4.stripNameSuffixes;
        compilerOptions4.aliasAllStrings = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions4.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions4.checkShadowVars;
        java.util.Set<java.lang.String> strSet14 = compilerOptions4.stripTypes;
        java.lang.String[] strArray17 = new java.lang.String[] { "Named type with empty name component" };
        java.util.ArrayList<java.lang.String> strList18 = new java.util.ArrayList<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList18, strArray17);
        compilerOptions4.setReplaceStringsConfiguration("<No stack trace available>", (java.util.List<java.lang.String>) strList18);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList18);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        java.lang.String str6 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingReturn;
        compilerOptions0.setOutputCharset("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray9 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup4, diagnosticGroup5, diagnosticGroup7 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup("", diagnosticGroupArray9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup("or", diagnosticGroupArray9);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray14 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup11 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray14);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticGroupArray9);
        org.junit.Assert.assertNotNull(diagnosticGroupArray14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.exportTestFunctions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean12 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.syntheticBlockStartMarker = "EOF [synthetic: 1]";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        java.lang.Object obj9 = null;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, obj9);
        java.lang.String str11 = compilerOptions0.locale;
        compilerOptions0.setPropertyAffinity(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.aggressiveVarCheck;
        boolean boolean4 = compilerOptions0.checkUnusedPropertiesEarly;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        boolean boolean6 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        compilerOptions0.setRemoveClosureAsserts(false);
        compilerOptions0.setTweakToBooleanLiteral("", false);
        boolean boolean7 = compilerOptions0.optimizeCalls;
        boolean boolean8 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkProvides;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setGenerateExports(true);
        boolean boolean7 = compilerOptions0.checkCaja;
        boolean boolean8 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "error reporter";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions0.getCodingConvention();
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(codingConvention9);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.toString();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: hi!" + "'", str2.equals("com.google.javascript.rhino.EcmaError: TypeError: hi!"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkControlStructures;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig2 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.reportPath = "error reporter";
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isValidEnumKey("error reporter");
        java.lang.String str10 = closureCodingConvention7.getAbstractMethodName();
        java.lang.String str11 = closureCodingConvention7.getExportPropertyFunction();
        boolean boolean13 = closureCodingConvention7.isConstant("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention7.applySubclassRelationship(functionType14, functionType15, subclassType16);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention7);
        boolean boolean19 = compilerOptions0.labelRenaming;
        boolean boolean20 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
        java.lang.String str5 = node1.toString(false, true, false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        node7.setJSType(jSType8);
        boolean boolean10 = node7.isVarArgs();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node12.setJSType(jSType13);
        boolean boolean15 = node12.isVarArgs();
        boolean boolean16 = node7.hasChild(node12);
        node7.removeProp(2);
        node1.addChildToFront(node7);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (byte) 0);
        node21.addChildrenToBack(node23);
        boolean boolean25 = node23.isLocalResultCall();
        try {
            com.google.javascript.rhino.Node node26 = node7.removeChildAfter(node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EOF" + "'", str5.equals("EOF"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        node5.setJSType(jSType6);
        boolean boolean8 = node5.isVarArgs();
        boolean boolean9 = node5.hasChildren();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        node14.setJSType(jSType15);
        int int17 = node14.getSideEffectFlags();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(43, node14, 140, 45);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship21 = closureCodingConvention0.getClassesDefinedByCall(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        context0.removeThreadLocal((java.lang.Object) loggerErrorManager2);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 43);
//        try {
//            com.google.javascript.rhino.Context context7 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }
//}

