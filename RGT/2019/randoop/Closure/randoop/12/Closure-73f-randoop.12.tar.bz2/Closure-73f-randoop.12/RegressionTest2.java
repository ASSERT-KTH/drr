import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.inlineVariables = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        boolean boolean15 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test003");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str6 = compilerInput4.getLine(120);
//        boolean boolean7 = compilerInput4.isExtern();
//        java.lang.String str8 = compilerInput4.getName();
//        java.io.PrintStream printStream9 = null;
//        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
//        compiler10.disableThreads();
//        java.nio.charset.Charset charset13 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
//        java.lang.String str15 = jSSourceFile14.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst16 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile14);
//        com.google.javascript.rhino.Node node17 = compiler10.parse(jSSourceFile14);
//        java.nio.charset.Charset charset19 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset19);
//        com.google.javascript.rhino.Node node21 = compiler10.parse(jSSourceFile20);
//        com.google.javascript.jscomp.SourceMap sourceMap22 = compiler10.getSourceMap();
//        com.google.javascript.rhino.Context context23 = com.google.javascript.rhino.Context.enter();
//        int int24 = context23.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter25 = context23.getErrorReporter();
//        int int26 = context23.getInstructionObserverThreshold();
//        java.util.Locale locale27 = context23.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException29 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException29.initLineSource("Unknown class name");
//        int int32 = evaluatorException29.lineNumber();
//        context23.removeThreadLocal((java.lang.Object) int32);
//        java.io.PrintStream printStream34 = null;
//        com.google.javascript.jscomp.Compiler compiler35 = new com.google.javascript.jscomp.Compiler(printStream34);
//        compiler35.disableThreads();
//        context23.removeThreadLocal((java.lang.Object) compiler35);
//        com.google.javascript.jscomp.Scope scope38 = compiler35.getTopScope();
//        java.nio.charset.Charset charset40 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset40);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray42 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format44 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions43.sourceMapFormat = format44;
//        compilerOptions43.unaliasableGlobals = "";
//        boolean boolean48 = compilerOptions43.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet49 = compilerOptions43.stripTypePrefixes;
//        boolean boolean50 = compilerOptions43.devirtualizePrototypeMethods;
//        boolean boolean51 = compilerOptions43.gatherCssNames;
//        boolean boolean52 = compilerOptions43.prettyPrint;
//        compilerOptions43.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result55 = compiler35.compile(jSSourceFile41, jSSourceFileArray42, compilerOptions43);
//        java.io.PrintStream printStream56 = null;
//        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
//        compiler57.disableThreads();
//        java.nio.charset.Charset charset60 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset60);
//        java.lang.String str62 = jSSourceFile61.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst63 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile61);
//        com.google.javascript.rhino.Node node64 = compiler57.parse(jSSourceFile61);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray69 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile61, jSSourceFile66, jSSourceFile68 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions70.aliasKeywords = true;
//        boolean boolean73 = compilerOptions70.generateExports;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap74 = compilerOptions70.cssRenamingMap;
//        compiler10.init(jSSourceFileArray42, jSSourceFileArray69, compilerOptions70);
//        com.google.javascript.rhino.Node node76 = compiler10.getRoot();
//        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertNotNull(jSSourceFile14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNull(node17);
//        org.junit.Assert.assertNotNull(jSSourceFile20);
//        org.junit.Assert.assertNull(node21);
//        org.junit.Assert.assertNull(sourceMap22);
//        org.junit.Assert.assertNotNull(context23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNull(errorReporter25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(locale27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNull(scope38);
//        org.junit.Assert.assertNotNull(jSSourceFile41);
//        org.junit.Assert.assertNotNull(jSSourceFileArray42);
//        org.junit.Assert.assertNotNull(format44);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(strSet49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(result55);
//        org.junit.Assert.assertNotNull(jSSourceFile61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
//        org.junit.Assert.assertNull(node64);
//        org.junit.Assert.assertNotNull(jSSourceFile66);
//        org.junit.Assert.assertNotNull(jSSourceFile68);
//        org.junit.Assert.assertNotNull(jSSourceFileArray69);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNull(cssRenamingMap74);
//        org.junit.Assert.assertNull(node76);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            com.google.javascript.rhino.Context.reportWarning("TypeError");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.ErrorManager errorManager9 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = compiler1.getWarnings();
        boolean boolean11 = compiler1.acceptConstKeyword();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(errorManager9);
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.rhino.Node node15 = compiler1.parse(jSSourceFile12);
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler1.getSourceMap();
        com.google.javascript.jscomp.CodingConvention codingConvention17 = compiler1.getCodingConvention();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(codingConvention17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        java.lang.String str25 = diagnosticGroupWarningsGuard24.toString();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler26 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler26, callback27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        java.lang.String str43 = node41.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.aliasKeywords = true;
        boolean boolean47 = compilerOptions44.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap48 = null;
        compilerOptions44.cssRenamingMap = cssRenamingMap48;
        compilerOptions44.setRemoveAbstractMethods(false);
        boolean boolean52 = compilerOptions44.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions44.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray57 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError58 = nodeTraversal28.makeError(node41, checkLevel53, diagnosticType56, strArray57);
        java.lang.String str59 = jSError58.description;
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.aliasKeywords = true;
        compilerOptions60.markAsCompiled = false;
        compilerOptions60.setRemoveAbstractMethods(true);
        boolean boolean67 = compilerOptions60.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions68.aliasKeywords = true;
        compilerOptions68.markAsCompiled = false;
        compilerOptions68.setRemoveAbstractMethods(true);
        compilerOptions68.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel77 = compilerOptions68.checkUndefinedProperties;
        compilerOptions60.checkGlobalThisLevel = checkLevel77;
        compilerOptions60.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions60.groupVariableDeclarations = true;
        boolean boolean84 = jSError58.equals((java.lang.Object) true);
        com.google.javascript.jscomp.CheckLevel checkLevel85 = diagnosticGroupWarningsGuard24.level(jSError58);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup86 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup87 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup88 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup89 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup90 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray91 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup86, diagnosticGroup87, diagnosticGroup88, diagnosticGroup89, diagnosticGroup90 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup92 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray91);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup92;
        boolean boolean94 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup92);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup95 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup95;
        boolean boolean97 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup95);
        java.lang.RuntimeException runtimeException98 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) diagnosticGroupWarningsGuard24);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DiagnosticGroup<missingProperties>(OFF)" + "'", str25.equals("DiagnosticGroup<missingProperties>(OFF)"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(checkLevel85);
        org.junit.Assert.assertNotNull(diagnosticGroup86);
        org.junit.Assert.assertNotNull(diagnosticGroup87);
        org.junit.Assert.assertNotNull(diagnosticGroup88);
        org.junit.Assert.assertNotNull(diagnosticGroup89);
        org.junit.Assert.assertNotNull(diagnosticGroup90);
        org.junit.Assert.assertNotNull(diagnosticGroupArray91);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(runtimeException98);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean7 = compilerOptions0.tightenTypes;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        compilerOptions0.tracer = tracerMode8;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + tracerMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode8.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-3));
        java.lang.Appendable appendable2 = null;
        try {
            node1.appendStringTree(appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: -3");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.rhino.Node node22 = node19.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node19.getJSDocInfo();
        node19.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention4.getDelegateRelationship(node19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node19, diagnosticType29, strArray30);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput32 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(jSError31);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy11 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy11 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy11.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray3 = compiler1.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = compilerOptions0.propertyRenaming;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean14 = compilerOptions0.aliasKeywords;
        boolean boolean15 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        java.util.logging.Logger logger13 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager14 = new com.google.javascript.jscomp.LoggerErrorManager(logger13);
        loggerErrorManager14.setTypedPercent((double) 4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.aliasKeywords = true;
        boolean boolean20 = compilerOptions17.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = null;
        compilerOptions17.cssRenamingMap = cssRenamingMap21;
        compilerOptions17.setRemoveAbstractMethods(false);
        boolean boolean25 = compilerOptions17.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention26 = null;
        compilerOptions17.setCodingConvention(codingConvention26);
        boolean boolean28 = compilerOptions17.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions17.reportUnknownTypes;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler30 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback31 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal32 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler30, callback31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions48.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray61 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal32.makeError(node45, checkLevel57, diagnosticType60, strArray61);
        java.lang.String str63 = jSError62.description;
        loggerErrorManager14.println(checkLevel29, jSError62);
        int int65 = jSError62.getCharno();
        int int66 = jSError62.getCharno();
        com.google.javascript.jscomp.CheckLevel checkLevel67 = composeWarningsGuard11.level(jSError62);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNull(checkLevel67);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.reportUnknownTypes;
        boolean boolean13 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler14 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler14);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        compilerOptions0.instrumentForCoverage = true;
        org.junit.Assert.assertNotNull(format1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node6.getParent();
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = node14.getJSDocInfo();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean18 = closureCodingConvention16.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(40, node22, node25, node28, node31);
        java.lang.String str33 = node31.getString();
        com.google.javascript.rhino.Node node34 = node31.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo35 = node31.getJSDocInfo();
        node31.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = closureCodingConvention16.getDelegateRelationship(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(40, node42, node45, node48, node51);
        boolean boolean53 = node31.hasChild(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(40, node57, node60, node63, node66);
        com.google.javascript.rhino.Node node68 = node57.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable69 = node68.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions70.aliasKeywords = true;
        boolean boolean73 = compilerOptions70.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap74 = null;
        compilerOptions70.cssRenamingMap = cssRenamingMap74;
        compilerOptions70.setRemoveAbstractMethods(false);
        boolean boolean78 = compilerOptions70.lineBreak;
        boolean boolean79 = compilerOptions70.markNoSideEffectCalls;
        boolean boolean80 = compilerOptions70.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions81 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format82 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions81.sourceMapFormat = format82;
        compilerOptions81.unaliasableGlobals = "";
        boolean boolean86 = compilerOptions81.disambiguateProperties;
        java.util.Set<java.lang.String> strSet87 = compilerOptions81.stripTypePrefixes;
        compilerOptions70.stripNameSuffixes = strSet87;
        node68.setDirectives(strSet87);
        com.google.javascript.rhino.Node node90 = node51.copyInformationFromForTree(node68);
        try {
            node14.addChildrenToBack(node90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNull(jSDocInfo35);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeIterable69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(format82);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(strSet87);
        org.junit.Assert.assertNotNull(node90);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format6 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions5.sourceMapFormat = format6;
//        compilerOptions5.groupVariableDeclarations = true;
//        context0.removeThreadLocal((java.lang.Object) true);
//        java.lang.Object obj11 = context0.getDebuggerContextData();
//        context0.setInstructionObserverThreshold(2);
//        boolean boolean14 = context0.isGeneratingDebug();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(format6);
//        org.junit.Assert.assertNull(obj11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = compilerOptions0.cssRenamingMap;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap11 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(cssRenamingMap10);
        org.junit.Assert.assertNotNull(strMap11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean3 = closureCodingConvention1.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        java.lang.String str18 = node16.getString();
        com.google.javascript.rhino.Node node19 = node16.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = node16.getJSDocInfo();
        node16.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = closureCodingConvention1.getDelegateRelationship(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean28 = closureCodingConvention1.isOptionalParameter(node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1, "", (int) (byte) 1, (int) '#');
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString(20, "goog.global", (int) (byte) 0, 28);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        boolean boolean52 = node44.isLocalResultCall();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean57 = node56.hasSideEffects();
        com.google.javascript.rhino.Node node58 = com.google.javascript.jscomp.NodeUtil.newExpr(node56);
        try {
            com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(1, node32, node37, node44, node58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNull(jSDocInfo20);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        java.util.Set<java.lang.String> strSet14 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkMethods;
        compilerOptions0.strictMessageReplacement = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JsAst jsAst5 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        jsAst5.clearAst();
        jsAst5.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = compilerOptions0.customPasses;
        compilerOptions0.specializeInitialModule = true;
        boolean boolean9 = compilerOptions0.disambiguateProperties;
        compilerOptions0.checkEs5Strict = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(42);
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setMutatesGlobalState();
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        node14.setWasEmptyNode(false);
        boolean boolean17 = node14.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        int int4 = node3.getLineno();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions5.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention6);
        java.lang.String str8 = closureCodingConvention6.getDelegateSuperclassName();
        boolean boolean10 = closureCodingConvention6.isSuperClassReference("goog.global");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(40, node14, node17, node20, node23);
        java.lang.String str25 = node23.getString();
        com.google.javascript.rhino.Node node26 = node23.getLastChild();
        node23.putBooleanProp(24, true);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(40, node33, node36, node39, node42);
        boolean boolean44 = node33.isLocalResultCall();
        int int45 = node33.getSideEffectFlags();
        java.lang.String str46 = closureCodingConvention6.extractClassNameIfProvide(node23, node33);
        com.google.javascript.rhino.Node node47 = node3.copyInformationFrom(node23);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(node47);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        boolean boolean5 = closureCodingConvention1.isExported("Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler2 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler2, callback3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(40, node8, node11, node14, node17);
        java.lang.String str19 = node17.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.aliasKeywords = true;
        boolean boolean23 = compilerOptions20.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap24 = null;
        compilerOptions20.cssRenamingMap = cssRenamingMap24;
        compilerOptions20.setRemoveAbstractMethods(false);
        boolean boolean28 = compilerOptions20.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions20.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray33 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal4.makeError(node17, checkLevel29, diagnosticType32, strArray33);
        java.lang.String str35 = jSError34.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = composeWarningsGuard1.level(jSError34);
        int int37 = jSError34.lineNumber;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNull(checkLevel36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        boolean boolean24 = closureCodingConvention0.isSuperClassReference("instanceof");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(40, node28, node31, node34, node37);
        boolean boolean39 = node28.isLocalResultCall();
        boolean boolean40 = closureCodingConvention0.isOptionalParameter(node28);
        java.lang.String str41 = node28.getQualifiedName();
        boolean boolean42 = node28.isNoSideEffectsCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("error reporter", "goog.global", "false");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker14 = compiler1.tracker;
        com.google.javascript.jscomp.SourceMap sourceMap15 = compiler1.getSourceMap();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = compiler1.getTypeRegistry();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(performanceTracker14);
        org.junit.Assert.assertNull(sourceMap15);
        org.junit.Assert.assertNotNull(jSTypeRegistry16);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasableGlobals = "";
        compilerOptions0.checkEs5Strict = true;
        boolean boolean10 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.checkEs5Strict = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy11 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy11 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy11.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        node12.putBooleanProp(24, true);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler20 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler20, callback21);
        java.lang.String str23 = nodeTraversal22.getSourceName();
        node12.putProp((int) '4', (java.lang.Object) nodeTraversal22);
        java.lang.String str25 = node12.getString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        java.lang.String str3 = closureCodingConvention1.getDelegateSuperclassName();
        boolean boolean5 = closureCodingConvention1.isSuperClassReference("goog.global");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(40, node9, node12, node15, node18);
        java.lang.String str20 = node18.getString();
        com.google.javascript.rhino.Node node21 = node18.getLastChild();
        node18.setOptionalArg(false);
        com.google.javascript.rhino.Node node24 = node18.detachFromParent();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(40, node28, node31, node34, node37);
        node34.setType((int) '#');
        boolean boolean42 = node34.getBooleanProp((int) (short) -1);
        com.google.javascript.rhino.Node node43 = node34.removeFirstChild();
        java.lang.String str44 = closureCodingConvention1.extractClassNameIfProvide(node18, node34);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(40, node48, node51, node54, node57);
        com.google.javascript.rhino.Node node59 = node48.getLastSibling();
        boolean boolean60 = node48.isOptionalArg();
        java.lang.String str61 = closureCodingConvention1.identifyTypeDefAssign(node48);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str61);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = detailLevel0.apply(node10);
        boolean boolean16 = node10.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        com.google.javascript.rhino.Node node31 = node20.getLastSibling();
        boolean boolean32 = node20.isOptionalArg();
        try {
            node10.addChildToFront(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.setDefineToDoubleLiteral("Node tree inequality:\nTree1:\nSTRING eof 24\n\n\nTree2:\nOR hi!\n\n\nSubtree1: STRING eof 24\n\n\nSubtree2: OR hi!\n", (double) 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput7, "instanceof", true);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkTypes = true;
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup2;
        boolean boolean5 = composeWarningsGuard1.enables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = null;
        boolean boolean7 = diagnosticGroup2.matches(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup2;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(": ");
        java.lang.String str7 = closureCodingConvention0.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(40, node11, node14, node17, node20);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean24 = closureCodingConvention22.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(40, node28, node31, node34, node37);
        java.lang.String str39 = node37.getString();
        com.google.javascript.rhino.Node node40 = node37.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo41 = node37.getJSDocInfo();
        node37.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship44 = closureCodingConvention22.getDelegateRelationship(node37);
        com.google.javascript.rhino.Node node45 = node37.getLastChild();
        java.lang.String str46 = closureCodingConvention0.extractClassNameIfRequire(node21, node37);
        java.lang.String str47 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(node40);
        org.junit.Assert.assertNull(jSDocInfo41);
        org.junit.Assert.assertNull(delegateRelationship44);
        org.junit.Assert.assertNull(node45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "goog.abstractMethod" + "'", str47.equals("goog.abstractMethod"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        compilerOptions0.collapseProperties = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType31 = null;
        closureCodingConvention0.applySubclassRelationship(functionType29, functionType30, subclassType31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.rhino.Node node48 = node45.getLastChild();
        node45.putBooleanProp(24, true);
        node45.setWasEmptyNode(false);
        boolean boolean54 = closureCodingConvention0.isVarArgsParameter(node45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertNull(node48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        boolean boolean10 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setTweakToNumberLiteral("(Named type with empty name component)", 0);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(detailLevel16);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        boolean boolean7 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        com.google.javascript.rhino.Node node16 = node5.getLastSibling();
        node16.setWasEmptyNode(false);
        boolean boolean19 = node1.hasChild(node16);
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = node16.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node16.setJSType(jSType21);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(jSDocInfo20);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean3 = closureCodingConvention1.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        java.lang.String str18 = node16.getString();
        com.google.javascript.rhino.Node node19 = node16.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = node16.getJSDocInfo();
        node16.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = closureCodingConvention1.getDelegateRelationship(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean28 = closureCodingConvention1.isOptionalParameter(node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1, "", (int) (byte) 1, (int) '#');
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel33 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(40, node37, node40, node43, node46);
        boolean boolean48 = detailLevel33.apply(node43);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        node43.setJSType(jSType49);
        try {
            com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(33, node32, node43, 28, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNull(jSDocInfo20);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(detailLevel33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.generateExports = true;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.ambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean12 = compilerOptions0.checkCaja;
        compilerOptions0.optimizeCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.aliasKeywords = true;
        compilerOptions15.markAsCompiled = false;
        compilerOptions15.setRemoveAbstractMethods(true);
        boolean boolean22 = compilerOptions15.checkTypedPropertyCalls;
        compilerOptions15.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format26 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions25.sourceMapFormat = format26;
        compilerOptions25.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing30 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean31 = tweakProcessing30.shouldStrip();
        compilerOptions25.setTweakProcessing(tweakProcessing30);
        compilerOptions15.setTweakProcessing(tweakProcessing30);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions15.checkMissingGetCssNameLevel;
        compilerOptions0.checkMissingReturn = checkLevel34;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(format26);
        org.junit.Assert.assertTrue("'" + tweakProcessing30 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing30.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        boolean boolean17 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node18 = node3.getParent();
        com.google.javascript.rhino.Node node19 = node18.removeFirstChild();
        java.lang.String str20 = node19.toStringTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "OR hi!\n" + "'", str20.equals("OR hi!\n"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.aliasableGlobals;
        compilerOptions0.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler13 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(aliasTransformationHandler13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        boolean boolean14 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        compilerInput5.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        boolean boolean15 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.setDefineToBooleanLiteral("com.google.javascript.rhino.EcmaError: : ", true);
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.renamePrefix = "Unknown class name";
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        loggerErrorManager25.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.aliasKeywords = true;
        compilerOptions27.markAsCompiled = false;
        compilerOptions27.setRemoveAbstractMethods(true);
        boolean boolean34 = compilerOptions27.checkTypedPropertyCalls;
        compilerOptions27.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format38 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions37.sourceMapFormat = format38;
        compilerOptions37.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing42 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean43 = tweakProcessing42.shouldStrip();
        compilerOptions37.setTweakProcessing(tweakProcessing42);
        compilerOptions27.setTweakProcessing(tweakProcessing42);
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions27.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler47 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback48 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal49 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler47, callback48);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(40, node53, node56, node59, node62);
        java.lang.String str64 = node62.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.aliasKeywords = true;
        boolean boolean68 = compilerOptions65.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap69 = null;
        compilerOptions65.cssRenamingMap = cssRenamingMap69;
        compilerOptions65.setRemoveAbstractMethods(false);
        boolean boolean73 = compilerOptions65.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compilerOptions65.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType77 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray78 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError79 = nodeTraversal49.makeError(node62, checkLevel74, diagnosticType77, strArray78);
        loggerErrorManager25.report(checkLevel46, jSError79);
        compilerOptions0.checkGlobalThisLevel = checkLevel46;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(format38);
        org.junit.Assert.assertTrue("'" + tweakProcessing42 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing42.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + checkLevel74 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel74.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType77);
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertNotNull(jSError79);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(": WARNING - \n");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.flowSensitiveInlineVariables = true;
        compilerOptions0.setDefineToDoubleLiteral("Named type with empty name component", (double) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasableGlobals = "";
        compilerOptions0.checkEs5Strict = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap11 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable15 = node3.getAncestors();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(ancestorIterable15);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test062");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        context0.setCompileFunctionsWithDynamicScope(true);
//        java.lang.Object obj4 = context0.getDebuggerContextData();
//        java.lang.Object obj5 = context0.getDebuggerContextData();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions6.aliasKeywords = true;
//        compilerOptions6.markAsCompiled = false;
//        java.lang.Object obj11 = compilerOptions6.clone();
//        boolean boolean12 = compilerOptions6.inlineFunctions;
//        compilerOptions6.generatePseudoNames = false;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup15;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format18 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions17.sourceMapFormat = format18;
//        compilerOptions17.unaliasableGlobals = "";
//        boolean boolean22 = compilerOptions17.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet23 = compilerOptions17.stripTypePrefixes;
//        boolean boolean24 = compilerOptions17.devirtualizePrototypeMethods;
//        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap25 = null;
//        compilerOptions17.customPasses = customPassExecutionTimeMultimap25;
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions17.checkMissingGetCssNameLevel;
//        compilerOptions6.setWarningLevel(diagnosticGroup15, checkLevel27);
//        java.lang.Object obj29 = context0.getThreadLocal((java.lang.Object) compilerOptions6);
//        compilerOptions6.tightenTypes = false;
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(obj5);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup15);
//        org.junit.Assert.assertNotNull(format18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(strSet23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNull(obj29);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.lineLengthThreshold(0);
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean14 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setDefineToStringLiteral("eof", "hi!");
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention9);
        java.lang.String str11 = closureCodingConvention9.getDelegateSuperclassName();
        boolean boolean13 = closureCodingConvention9.isPrivate("Named type with empty name component");
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("error reporter");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.lineLengthThreshold(0);
        byte[] byteArray12 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(byteArray12);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        boolean boolean15 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format16 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions15.sourceMapFormat = format16;
        compilerOptions15.unaliasableGlobals = "";
        boolean boolean20 = compilerOptions15.disambiguateProperties;
        java.util.Set<java.lang.String> strSet21 = compilerOptions15.stripTypePrefixes;
        boolean boolean22 = compilerOptions15.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler23 = compilerOptions15.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler23);
        boolean boolean25 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean9 = compilerOptions0.removeDeadCode;
        boolean boolean10 = compilerOptions0.exportTestFunctions;
        compilerOptions0.generateExports = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.rhino.Node node15 = compiler1.parse(jSSourceFile12);
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler1.getWarnings();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        java.lang.String str31 = node29.getString();
        com.google.javascript.rhino.Node node32 = node29.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo33 = node29.getJSDocInfo();
        com.google.javascript.jscomp.NodeTraversal.Callback callback34 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node29, callback34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNull(jSDocInfo33);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        try {
            com.google.javascript.rhino.Context.reportWarning("DiagnosticGroup<missingProperties>(OFF)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        boolean boolean11 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = detailLevel0.apply(node10);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable16 = node10.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor17 = ancestorIterable16.iterator();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor18 = ancestorIterable16.iterator();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy19 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        java.lang.RuntimeException runtimeException20 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) ancestorIterable16, (java.lang.Object) anonymousFunctionNamingPolicy19);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(ancestorIterable16);
        org.junit.Assert.assertNotNull(nodeItor17);
        org.junit.Assert.assertNotNull(nodeItor18);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy19 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy19.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(runtimeException20);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test075");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("error reporter");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: error reporter");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter10 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter10, logger11);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean15 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("true");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(true)" + "'", str1.equals("(true)"));
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test079");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.nio.charset.Charset charset5 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset5);
//        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6, false);
//        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
//        context0.removeThreadLocal((java.lang.Object) jsAst9);
//        context0.addActivationName("instanceof");
//        java.lang.String str13 = context0.getImplementationVersion();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str13.equals("@IMPLEMENTATION.VERSION@"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup15;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.aliasKeywords = true;
        boolean boolean20 = compilerOptions17.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = null;
        compilerOptions17.cssRenamingMap = cssRenamingMap21;
        compilerOptions17.setRemoveAbstractMethods(false);
        boolean boolean25 = compilerOptions17.lineBreak;
        java.lang.Class<?> wildcardClass26 = compilerOptions17.getClass();
        boolean boolean27 = compilerOptions17.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.aliasKeywords = true;
        boolean boolean31 = compilerOptions28.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap32 = null;
        compilerOptions28.cssRenamingMap = cssRenamingMap32;
        compilerOptions28.setRemoveAbstractMethods(false);
        boolean boolean36 = compilerOptions28.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions28.aggressiveVarCheck;
        compilerOptions17.checkMethods = checkLevel37;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel37);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup40 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup40;
        boolean boolean42 = diagnosticGroupWarningsGuard39.enables(diagnosticGroup40);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) diagnosticGroupWarningsGuard39);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasableGlobals = "";
        compilerOptions0.checkEs5Strict = true;
        java.lang.String str10 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkFunctions;
        java.lang.String str12 = compilerOptions0.locale;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        boolean boolean12 = compiler1.hasErrors();
        com.google.javascript.rhino.Node node13 = compiler1.getRoot();
        try {
            com.google.javascript.jscomp.Region region16 = compiler1.getSourceRegion("(Named type with empty name component)", 46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput9.getModule();
        com.google.javascript.jscomp.SourceFile sourceFile14 = com.google.javascript.jscomp.SourceFile.fromCode("com.google.javascript.rhino.EcmaError: : ", "", "com.google.javascript.rhino.EcmaError: : ");
        sourceFile14.setOriginalPath("");
        try {
            compilerInput9.setSourceFile(sourceFile14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNotNull(sourceFile14);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        context0.setCompileFunctionsWithDynamicScope(true);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        java.lang.String str8 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.gatherCssNames = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        boolean boolean8 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("<No stack trace available>", "Unknown class name");
        jSSourceFile2.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("(false)");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.rhino.Node node33 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(40, node37, node40, node43, node46);
        node43.setType((int) '#');
        boolean boolean50 = node43.hasOneChild();
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = null;
        java.lang.String[] strArray52 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        try {
            com.google.javascript.jscomp.JSError jSError53 = nodeTraversal2.makeError(node43, diagnosticType51, strArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strArray52);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.aliasableStrings;
        compilerOptions0.setManageClosureDependencies(false);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap8 = compilerOptions0.customPasses;
        compilerOptions0.checkSuspiciousCode = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray12 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup7, diagnosticGroup8, diagnosticGroup9, diagnosticGroup10, diagnosticGroup11 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray12);
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray14 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup3, diagnosticGroup13 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray14);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray14);
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup16;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroupArray12);
        org.junit.Assert.assertNotNull(diagnosticGroupArray14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions5.checkRequires = checkLevel8;
        compilerOptions5.generateExports = false;
        boolean boolean12 = compilerOptions5.inferTypesInGlobalScope;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = compilerOptions5.variableRenaming;
        compilerOptions0.variableRenaming = variableRenamingPolicy13;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable15 = node14.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.aliasKeywords = true;
        boolean boolean19 = compilerOptions16.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap20 = null;
        compilerOptions16.cssRenamingMap = cssRenamingMap20;
        compilerOptions16.setRemoveAbstractMethods(false);
        boolean boolean24 = compilerOptions16.lineBreak;
        boolean boolean25 = compilerOptions16.markNoSideEffectCalls;
        boolean boolean26 = compilerOptions16.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format28 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions27.sourceMapFormat = format28;
        compilerOptions27.unaliasableGlobals = "";
        boolean boolean32 = compilerOptions27.disambiguateProperties;
        java.util.Set<java.lang.String> strSet33 = compilerOptions27.stripTypePrefixes;
        compilerOptions16.stripNameSuffixes = strSet33;
        node14.setDirectives(strSet33);
        java.util.Set<java.lang.String> strSet36 = node14.getDirectives();
        java.lang.String str37 = node14.getQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeIterable15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(format28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertNotNull(strSet36);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        compilerOptions0.ideMode = false;
        boolean boolean12 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.ideMode = true;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap9 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkFunctions;
        compilerOptions0.setDefineToBooleanLiteral("Not declared as a type name", false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        compilerOptions0.setGenerateExports(true);
        java.lang.String str16 = compilerOptions0.debugFunctionSideEffectsPath;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.aliasKeywords = true;
        compilerOptions17.markAsCompiled = false;
        compilerOptions17.setRemoveAbstractMethods(true);
        boolean boolean24 = compilerOptions17.checkTypedPropertyCalls;
        compilerOptions17.extractPrototypeMemberDeclarations = true;
        compilerOptions17.reserveRawExports = false;
        boolean boolean29 = compilerOptions17.inlineAnonymousFunctionExpressions;
        compilerOptions17.aliasExternals = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format33 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions32.sourceMapFormat = format33;
        compilerOptions17.sourceMapFormat = format33;
        compilerOptions0.sourceMapFormat = format33;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(format33);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.getErrorReporter();
//        boolean boolean5 = context0.isSealed();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
//        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType9 = null;
//        closureCodingConvention6.applySubclassRelationship(functionType7, functionType8, subclassType9);
//        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(": ");
//        java.lang.String str13 = closureCodingConvention6.identifyTypeDefAssign(node12);
//        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(40, node17, node20, node23, node26);
//        com.google.javascript.jscomp.AbstractCompiler abstractCompiler28 = null;
//        com.google.javascript.jscomp.NodeTraversal.Callback callback29 = null;
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal30 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler28, callback29);
//        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(40, node34, node37, node40, node43);
//        java.lang.String str45 = node43.getString();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions46.aliasKeywords = true;
//        boolean boolean49 = compilerOptions46.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap50 = null;
//        compilerOptions46.cssRenamingMap = cssRenamingMap50;
//        compilerOptions46.setRemoveAbstractMethods(false);
//        boolean boolean54 = compilerOptions46.rewriteFunctionExpressions;
//        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions46.aggressiveVarCheck;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("", "");
//        java.lang.String[] strArray59 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
//        com.google.javascript.jscomp.JSError jSError60 = nodeTraversal30.makeError(node43, checkLevel55, diagnosticType58, strArray59);
//        com.google.javascript.rhino.jstype.JSType jSType61 = node43.getJSType();
//        java.lang.String str62 = node20.checkTreeEquals(node43);
//        com.google.javascript.rhino.jstype.JSType jSType63 = node20.getJSType();
//        boolean boolean64 = closureCodingConvention6.isVarArgsParameter(node20);
//        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection65 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node20);
//        context0.removeThreadLocal((java.lang.Object) nodeCollection65);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(node12);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNotNull(node34);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertNotNull(node40);
//        org.junit.Assert.assertNotNull(node43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType58);
//        org.junit.Assert.assertNotNull(strArray59);
//        org.junit.Assert.assertNotNull(jSError60);
//        org.junit.Assert.assertNull(jSType61);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertNull(jSType63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(nodeCollection65);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        java.lang.String str33 = nodeTraversal2.getSourceName();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getErrors();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler1.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        loggerErrorManager15.generateReport();
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.CodingConvention codingConvention18 = compiler1.getCodingConvention();
        boolean boolean19 = compiler1.hasErrors();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(codingConvention18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setRemoveClosureAsserts(true);
        compilerOptions0.decomposeExpressions = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 34");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean12 = compilerOptions0.labelRenaming;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap13 = compilerOptions0.getTweakReplacements();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strMap13);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        boolean boolean30 = closureCodingConvention0.isConstant("DiagnosticGroup<accessControls>");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(40, node34, node37, node40, node43);
        com.google.javascript.rhino.Node node45 = node34.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable46 = node45.siblings();
        boolean boolean47 = closureCodingConvention0.isVarArgsParameter(node45);
        java.lang.String str48 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(40, node52, node55, node58, node61);
        boolean boolean63 = node52.isLocalResultCall();
        int int64 = node52.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection65 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node52);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder66 = node52.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node67 = node52.detachFromParent();
        boolean boolean68 = node52.isUnscopedQualifiedName();
        try {
            boolean boolean69 = closureCodingConvention0.isPropertyTestFunction(node52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeIterable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(nodeCollection65);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.setDefineToBooleanLiteral("instanceof", true);
        boolean boolean22 = compilerOptions0.isExternExportsEnabled();
        boolean boolean23 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = compilerOptions0.cssRenamingMap;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean9 = compilerOptions0.disambiguateProperties;
        boolean boolean10 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        node12.putBooleanProp(24, true);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler20 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler20, callback21);
        java.lang.String str23 = nodeTraversal22.getSourceName();
        node12.putProp((int) '4', (java.lang.Object) nodeTraversal22);
        com.google.javascript.rhino.Node node25 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int30 = diagnosticType28.compareTo(diagnosticType29);
        java.lang.String[] strArray33 = new java.lang.String[] { "(Unknown class name)", "Not declared as a type name" };
        try {
            nodeTraversal22.report(node25, diagnosticType28, strArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-23) + "'", int30 == (-23));
        org.junit.Assert.assertNotNull(strArray33);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        java.lang.String str25 = diagnosticGroupWarningsGuard24.toString();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler26 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler26, callback27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        java.lang.String str43 = node41.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.aliasKeywords = true;
        boolean boolean47 = compilerOptions44.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap48 = null;
        compilerOptions44.cssRenamingMap = cssRenamingMap48;
        compilerOptions44.setRemoveAbstractMethods(false);
        boolean boolean52 = compilerOptions44.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions44.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray57 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError58 = nodeTraversal28.makeError(node41, checkLevel53, diagnosticType56, strArray57);
        java.lang.String str59 = jSError58.description;
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.aliasKeywords = true;
        compilerOptions60.markAsCompiled = false;
        compilerOptions60.setRemoveAbstractMethods(true);
        boolean boolean67 = compilerOptions60.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions68.aliasKeywords = true;
        compilerOptions68.markAsCompiled = false;
        compilerOptions68.setRemoveAbstractMethods(true);
        compilerOptions68.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel77 = compilerOptions68.checkUndefinedProperties;
        compilerOptions60.checkGlobalThisLevel = checkLevel77;
        compilerOptions60.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions60.groupVariableDeclarations = true;
        boolean boolean84 = jSError58.equals((java.lang.Object) true);
        com.google.javascript.jscomp.CheckLevel checkLevel85 = diagnosticGroupWarningsGuard24.level(jSError58);
        java.lang.String str86 = jSError58.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DiagnosticGroup<missingProperties>(OFF)" + "'", str25.equals("DiagnosticGroup<missingProperties>(OFF)"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(checkLevel85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + ".  at (unknown source) line (unknown line) : (unknown column)" + "'", str86.equals(".  at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.checkMissingGetCssNameBlacklist = "Not declared as a type name";
        compilerOptions0.setTweakToNumberLiteral("goog.exportProperty", 0);
        compilerOptions0.exportTestFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        node14.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node18 = node14.getAncestor(39);
        boolean boolean19 = node14.hasOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        boolean boolean30 = closureCodingConvention0.isConstant("DiagnosticGroup<accessControls>");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(40, node34, node37, node40, node43);
        com.google.javascript.rhino.Node node45 = node34.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable46 = node45.siblings();
        boolean boolean47 = closureCodingConvention0.isVarArgsParameter(node45);
        boolean boolean49 = closureCodingConvention0.isExported("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeIterable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        node14.setWasEmptyNode(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node14.new FileLevelJsDocBuilder();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.checkSymbols = true;
        boolean boolean14 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        boolean boolean17 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node18 = node3.getParent();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean23 = node22.hasSideEffects();
        node22.setIsSyntheticBlock(false);
        boolean boolean26 = node18.isEquivalentToTyped(node22);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        byte[] byteArray13 = compilerOptions0.inputVariableMapSerialized;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap14 = compilerOptions0.getTweakReplacements();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(strMap14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.lang.Object obj1 = null;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) context0, obj1);
        java.util.Locale locale3 = context0.getLocale();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags5 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 1);
        java.lang.Object obj6 = context0.getThreadLocal((java.lang.Object) sideEffectFlags5);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertNotNull(locale3);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        java.lang.String str11 = compilerInput4.getLine((int) 'a');
        compilerInput4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node6.getParent();
        com.google.javascript.rhino.Node node15 = node14.getParent();
        try {
            java.lang.String str19 = node15.toString(false, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.rhino.Node node22 = node19.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node19.getJSDocInfo();
        node19.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention4.getDelegateRelationship(node19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node19, diagnosticType29, strArray30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = jSError31.getType();
        java.lang.String str33 = jSError31.description;
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        compilerOptions0.inlineFunctions = false;
        byte[] byteArray20 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray20;
        compilerOptions0.checkControlStructures = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node6.getParent();
        try {
            java.lang.String str15 = node14.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: String node not created with Node.newString");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = compilerInput4.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean9 = compilerOptions0.removeDeadCode;
        boolean boolean10 = compilerOptions0.exportTestFunctions;
        boolean boolean11 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = compilerOptions0.customPasses;
        compilerOptions0.specializeInitialModule = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap6);
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format7 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions6.sourceMapFormat = format7;
        compilerOptions6.unaliasableGlobals = "";
        compilerOptions6.collapseProperties = true;
        compilerOptions6.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str16 = compilerOptions6.appNameStr;
        compilerOptions6.nameReferenceReportPath = "<No stack trace available>";
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions6.checkUnreachableCode;
        java.lang.String[] strArray32 = new java.lang.String[] { "com.google.javascript.rhino.EcmaError: : ", "OR hi! [directives: []]", "(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", "(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", "hi!", "0", "Named type with empty name component", "false", "DiagnosticGroup<missingProperties>(OFF)", "error reporter", "DiagnosticGroup<accessControls>", "bitxor" };
        java.util.LinkedHashSet<java.lang.String> strSet33 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet33, strArray32);
        compilerOptions6.stripTypePrefixes = strSet33;
        com.google.javascript.jscomp.ErrorFormat errorFormat36 = compilerOptions6.errorFormat;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode37 = compilerOptions6.tracer;
        compilerOptions0.tracer = tracerMode37;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(errorFormat36);
        org.junit.Assert.assertTrue("'" + tracerMode37 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode37.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("STRING", "Unknown class name", "eof");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format13 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions12.sourceMapFormat = format13;
        compilerOptions12.unaliasableGlobals = "";
        boolean boolean17 = compilerOptions12.disambiguateProperties;
        java.util.Set<java.lang.String> strSet18 = compilerOptions12.stripTypePrefixes;
        compilerOptions12.devirtualizePrototypeMethods = false;
        compilerOptions12.deadAssignmentElimination = true;
        compilerOptions12.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.aliasKeywords = true;
        boolean boolean28 = compilerOptions25.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = null;
        compilerOptions25.cssRenamingMap = cssRenamingMap29;
        compilerOptions25.setRemoveAbstractMethods(false);
        boolean boolean33 = compilerOptions25.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions25.aggressiveVarCheck;
        compilerOptions12.checkUndefinedProperties = checkLevel34;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel34;
        compilerOptions0.renamePrefix = "false";
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.removeUnusedLocalVars = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        boolean boolean3 = node2.isSyntheticBlock();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        java.lang.String str18 = node16.getString();
        com.google.javascript.rhino.Node node19 = node16.getLastChild();
        node16.putBooleanProp(24, true);
        node16.setWasEmptyNode(false);
        int int25 = node16.getSideEffectFlags();
        java.lang.String str26 = node2.checkTreeEquals(node16);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput12 = compiler1.newExternInput("error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.aliasKeywords = true;
        boolean boolean12 = compilerOptions9.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap13 = null;
        compilerOptions9.cssRenamingMap = cssRenamingMap13;
        compilerOptions9.setRemoveAbstractMethods(false);
        compilerOptions9.aliasExternals = false;
        compilerOptions9.foldConstants = true;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions9.checkGlobalThisLevel;
        compilerOptions0.checkMethods = checkLevel21;
        java.lang.String str23 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format11 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions10.sourceMapFormat = format11;
        compilerOptions10.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing15 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean16 = tweakProcessing15.shouldStrip();
        compilerOptions10.setTweakProcessing(tweakProcessing15);
        compilerOptions0.setTweakProcessing(tweakProcessing15);
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(format11);
        org.junit.Assert.assertTrue("'" + tweakProcessing15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing15.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test135");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = context0.getErrorReporter();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNull(errorReporter15);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean7 = node6.hasSideEffects();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.lang.String str10 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(": ");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(40, node16, node19, node22, node25);
        com.google.javascript.rhino.Node node27 = node16.getLastSibling();
        node27.setWasEmptyNode(false);
        boolean boolean30 = node12.hasChild(node27);
        node27.setOptionalArg(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder33 = node27.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format35 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions34.sourceMapFormat = format35;
        compilerOptions34.unaliasableGlobals = "";
        boolean boolean39 = compilerOptions34.disambiguateProperties;
        java.util.Set<java.lang.String> strSet40 = compilerOptions34.stripTypePrefixes;
        boolean boolean41 = compilerOptions34.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler42 = compilerOptions34.getAliasTransformationHandler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention43 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean46 = closureCodingConvention43.isExported("DiagnosticGroup<accessControls>", false);
        compilerOptions34.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention43);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "DiagnosticGroup<missingProperties>", 46, 0);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(40, node56, node59, node62, node65);
        boolean boolean67 = node56.isLocalResultCall();
        int int68 = node56.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection69 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node56);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder70 = node56.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node71 = node56.detachFromParent();
        boolean boolean72 = node56.isUnscopedQualifiedName();
        java.lang.String str73 = closureCodingConvention43.extractClassNameIfProvide(node52, node56);
        java.lang.String str74 = closureCodingConvention0.extractClassNameIfProvide(node27, node56);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder33);
        org.junit.Assert.assertNotNull(format35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(strSet40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(nodeCollection69);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder70);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNull(str74);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter10 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker11 = null;
        compiler1.tracker = performanceTracker11;
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean12 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        compilerOptions13.markAsCompiled = false;
        java.lang.Object obj18 = compilerOptions13.clone();
        compilerOptions13.deadAssignmentElimination = true;
        compilerOptions13.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention24 = compilerOptions13.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig25 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions13);
        byte[] byteArray26 = compilerOptions13.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel27 = compilerOptions13.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format29 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions28.sourceMapFormat = format29;
        compilerOptions28.unaliasableGlobals = "";
        boolean boolean33 = compilerOptions28.disambiguateProperties;
        java.util.Set<java.lang.String> strSet34 = compilerOptions28.stripTypePrefixes;
        boolean boolean35 = compilerOptions28.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler36 = compilerOptions28.getAliasTransformationHandler();
        compilerOptions13.setAliasTransformationHandler(aliasTransformationHandler36);
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(codingConvention24);
        org.junit.Assert.assertNull(byteArray26);
        org.junit.Assert.assertNotNull(detailLevel27);
        org.junit.Assert.assertNotNull(format29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strSet34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler36);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkMissingReturn;
        compilerOptions0.reportPath = "false";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        java.lang.String str3 = closureCodingConvention1.getDelegateSuperclassName();
        boolean boolean5 = closureCodingConvention1.isSuperClassReference("goog.global");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(40, node9, node12, node15, node18);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder20 = node15.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(40, node24, node27, node30, node33);
        node30.setType((int) '#');
        com.google.javascript.rhino.Node node37 = node15.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node38 = node15.removeChildren();
        java.lang.String str39 = node15.toStringTree();
        boolean boolean40 = closureCodingConvention1.isVarArgsParameter(node15);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "OR hi!\n" + "'", str39.equals("OR hi!\n"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.rhino.Node node15 = compiler1.parse(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        compilerOptions0.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions0.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test143");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.nio.charset.Charset charset5 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset5);
//        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6, false);
//        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
//        context0.removeThreadLocal((java.lang.Object) jsAst9);
//        context0.addActivationName("instanceof");
//        context0.removeActivationName("Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
//        int int15 = context0.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test144");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.aliasKeywords = true;
//        boolean boolean3 = compilerOptions0.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
//        compilerOptions0.cssRenamingMap = cssRenamingMap4;
//        compilerOptions0.setRemoveAbstractMethods(false);
//        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
//        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
//        compilerOptions0.setCodingConvention(codingConvention9);
//        compilerOptions0.aliasAllStrings = true;
//        com.google.javascript.rhino.Context context13 = com.google.javascript.rhino.Context.enter();
//        long long14 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format16 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions15.sourceMapFormat = format16;
//        compilerOptions15.unaliasableGlobals = "";
//        boolean boolean20 = compilerOptions15.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet21 = compilerOptions15.stripTypePrefixes;
//        boolean boolean22 = compilerOptions15.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet23 = compilerOptions15.stripTypes;
//        context13.seal((java.lang.Object) compilerOptions15);
//        java.lang.String str25 = compilerOptions15.jsOutputFile;
//        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions15.checkRequires;
//        compilerOptions0.checkUndefinedProperties = checkLevel26;
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(context13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(format16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(strSet21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(strSet23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup18;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup18;
        boolean boolean21 = composeWarningsGuard16.disables(diagnosticGroup18);
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup18;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.ignoreCajaProperties = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        boolean boolean17 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node18 = node3.getParent();
        com.google.javascript.rhino.Node node19 = node3.removeFirstChild();
        try {
            node19.detachChildren();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node19);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.rewriteFunctionExpressions = false;
        boolean boolean17 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        compilerOptions14.markAsCompiled = false;
        compilerOptions14.setRemoveAbstractMethods(true);
        compilerOptions14.checkUnusedPropertiesEarly = false;
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.aliasKeywords = true;
        boolean boolean27 = compilerOptions24.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap28 = null;
        compilerOptions24.cssRenamingMap = cssRenamingMap28;
        compilerOptions24.setRemoveAbstractMethods(false);
        compilerOptions24.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray34 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard35 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray34);
        compilerOptions24.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard35);
        compilerOptions24.ambiguateProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions24.reportUnknownTypes;
        compilerOptions0.checkMethods = checkLevel39;
        compilerOptions0.setTweakToBooleanLiteral("", false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray34);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test151");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        boolean boolean4 = context0.isGeneratingSource();
//        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(40, node8, node11, node14, node17);
//        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node14.getJsDocBuilderForNode();
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
//        node29.setType((int) '#');
//        com.google.javascript.rhino.Node node36 = node14.clonePropsFrom(node29);
//        com.google.javascript.rhino.Node node37 = node14.removeChildren();
//        com.google.javascript.rhino.jstype.JSType jSType38 = null;
//        node14.setJSType(jSType38);
//        context0.putThreadLocal((java.lang.Object) node14, (java.lang.Object) "NAME  1\n");
//        int int42 = node14.getChildCount();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(node8);
//        org.junit.Assert.assertNotNull(node11);
//        org.junit.Assert.assertNotNull(node14);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder19);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNotNull(node32);
//        org.junit.Assert.assertNotNull(node36);
//        org.junit.Assert.assertNull(node37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        boolean boolean4 = compilerOptions0.rewriteFunctionExpressions;
        boolean boolean5 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        compilerOptions0.reserveRawExports = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray9 = anonymousFunctionNamingPolicy8.getReservedCharacters();
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy8;
        compilerOptions0.tightenTypes = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray9);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
//        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
//        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler1.getSourceMap();
//        com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter();
//        int int15 = context14.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = context14.getErrorReporter();
//        int int17 = context14.getInstructionObserverThreshold();
//        java.util.Locale locale18 = context14.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException20 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException20.initLineSource("Unknown class name");
//        int int23 = evaluatorException20.lineNumber();
//        context14.removeThreadLocal((java.lang.Object) int23);
//        java.io.PrintStream printStream25 = null;
//        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler(printStream25);
//        compiler26.disableThreads();
//        context14.removeThreadLocal((java.lang.Object) compiler26);
//        com.google.javascript.jscomp.Scope scope29 = compiler26.getTopScope();
//        java.nio.charset.Charset charset31 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset31);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format35 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions34.sourceMapFormat = format35;
//        compilerOptions34.unaliasableGlobals = "";
//        boolean boolean39 = compilerOptions34.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet40 = compilerOptions34.stripTypePrefixes;
//        boolean boolean41 = compilerOptions34.devirtualizePrototypeMethods;
//        boolean boolean42 = compilerOptions34.gatherCssNames;
//        boolean boolean43 = compilerOptions34.prettyPrint;
//        compilerOptions34.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result46 = compiler26.compile(jSSourceFile32, jSSourceFileArray33, compilerOptions34);
//        java.io.PrintStream printStream47 = null;
//        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler(printStream47);
//        compiler48.disableThreads();
//        java.nio.charset.Charset charset51 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset51);
//        java.lang.String str53 = jSSourceFile52.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst54 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile52);
//        com.google.javascript.rhino.Node node55 = compiler48.parse(jSSourceFile52);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray60 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile52, jSSourceFile57, jSSourceFile59 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions61.aliasKeywords = true;
//        boolean boolean64 = compilerOptions61.generateExports;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap65 = compilerOptions61.cssRenamingMap;
//        compiler1.init(jSSourceFileArray33, jSSourceFileArray60, compilerOptions61);
//        com.google.javascript.rhino.Node node67 = compiler1.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager68 = compiler1.getErrorManager();
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNull(node12);
//        org.junit.Assert.assertNull(sourceMap13);
//        org.junit.Assert.assertNotNull(context14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNull(errorReporter16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNull(scope29);
//        org.junit.Assert.assertNotNull(jSSourceFile32);
//        org.junit.Assert.assertNotNull(jSSourceFileArray33);
//        org.junit.Assert.assertNotNull(format35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(strSet40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(result46);
//        org.junit.Assert.assertNotNull(jSSourceFile52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
//        org.junit.Assert.assertNull(node55);
//        org.junit.Assert.assertNotNull(jSSourceFile57);
//        org.junit.Assert.assertNotNull(jSSourceFile59);
//        org.junit.Assert.assertNotNull(jSSourceFileArray60);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNull(cssRenamingMap65);
//        org.junit.Assert.assertNull(node67);
//        org.junit.Assert.assertNotNull(errorManager68);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<missingProperties>");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        boolean boolean10 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setTweakToNumberLiteral("(Named type with empty name component)", 0);
        compilerOptions0.setDefineToStringLiteral("goog.exportProperty", "0");
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        java.lang.String str11 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.setTweakToStringLiteral("goog.exportProperty", "(Named type with empty name component)");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        int int15 = node12.getCharno();
        boolean boolean16 = node12.hasSideEffects();
        node12.addSuppression("(Unknown class name)");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test160");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        boolean boolean4 = context0.isGeneratingSource();
//        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter();
//        int int6 = context5.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context5, 0L);
//        boolean boolean9 = context5.isGeneratingSource();
//        java.util.Locale locale10 = context5.getLocale();
//        java.util.Locale locale11 = context0.setLocale(locale10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions12.aliasKeywords = true;
//        compilerOptions12.markAsCompiled = false;
//        compilerOptions12.setRemoveAbstractMethods(true);
//        boolean boolean19 = compilerOptions12.checkTypedPropertyCalls;
//        compilerOptions12.extractPrototypeMemberDeclarations = true;
//        compilerOptions12.lineLengthThreshold(0);
//        compilerOptions12.removeTryCatchFinally = false;
//        context0.removeThreadLocal((java.lang.Object) false);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(context5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(locale10);
//        org.junit.Assert.assertNull(locale11);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        java.lang.String str36 = node34.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.aliasKeywords = true;
        boolean boolean40 = compilerOptions37.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap41 = null;
        compilerOptions37.cssRenamingMap = cssRenamingMap41;
        compilerOptions37.setRemoveAbstractMethods(false);
        boolean boolean45 = compilerOptions37.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions37.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray50 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError51 = nodeTraversal21.makeError(node34, checkLevel46, diagnosticType49, strArray50);
        compilerOptions0.checkGlobalNamesLevel = checkLevel46;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions55.aliasKeywords = true;
        boolean boolean58 = compilerOptions55.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap59 = null;
        compilerOptions55.cssRenamingMap = cssRenamingMap59;
        compilerOptions55.setRemoveAbstractMethods(false);
        boolean boolean63 = compilerOptions55.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention64 = null;
        compilerOptions55.setCodingConvention(codingConvention64);
        boolean boolean66 = compilerOptions55.optimizeCalls;
        compilerOptions55.enableExternExports(true);
        boolean boolean69 = compilerOptions55.checkDuplicateMessages;
        java.util.Set<java.lang.String> strSet70 = compilerOptions55.stripTypes;
        compilerOptions0.stripNameSuffixes = strSet70;
        com.google.javascript.jscomp.CheckLevel checkLevel72 = compilerOptions0.checkProvides;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = compilerOptions0.cssRenamingMap;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.setColorizeErrorOutput(false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(cssRenamingMap10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(": ");
        java.lang.String str7 = closureCodingConvention0.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(40, node11, node14, node17, node20);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler22 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler22, callback23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(40, node28, node31, node34, node37);
        java.lang.String str39 = node37.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.aliasKeywords = true;
        boolean boolean43 = compilerOptions40.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap44 = null;
        compilerOptions40.cssRenamingMap = cssRenamingMap44;
        compilerOptions40.setRemoveAbstractMethods(false);
        boolean boolean48 = compilerOptions40.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions40.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray53 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError54 = nodeTraversal24.makeError(node37, checkLevel49, diagnosticType52, strArray53);
        com.google.javascript.rhino.jstype.JSType jSType55 = node37.getJSType();
        java.lang.String str56 = node14.checkTreeEquals(node37);
        com.google.javascript.rhino.jstype.JSType jSType57 = node14.getJSType();
        boolean boolean58 = closureCodingConvention0.isVarArgsParameter(node14);
        java.lang.String str59 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "goog.exportSymbol" + "'", str59.equals("goog.exportSymbol"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("bitxor", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean7 = node6.hasSideEffects();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType12 = null;
        closureCodingConvention0.applySubclassRelationship(functionType10, functionType11, subclassType12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        boolean boolean12 = compiler1.hasErrors();
        com.google.javascript.rhino.Node node13 = compiler1.getRoot();
        com.google.javascript.jscomp.Scope scope14 = compiler1.getTopScope();
        boolean boolean15 = compiler1.acceptEcmaScript5();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNull(scope14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("OR hi! [directives: []]", "(Unknown class name)", "STRING");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getDelegateSuperclassName();
        java.lang.String str2 = closureCodingConvention0.getGlobalObject();
        boolean boolean4 = closureCodingConvention0.isConstant(": ");
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean9 = node8.hasSideEffects();
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(40, node14, node17, node20, node23);
        java.lang.String str25 = node23.getString();
        com.google.javascript.rhino.Node node26 = node23.getLastChild();
        java.lang.String str27 = closureCodingConvention0.extractClassNameIfRequire(node8, node23);
        java.lang.String str28 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.abstractMethod" + "'", str28.equals("goog.abstractMethod"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node6.setString("hi!");
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        boolean boolean16 = node3.hasOneChild();
        com.google.javascript.rhino.Node node17 = node3.getLastSibling();
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = node3.getJSDocInfo();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSDocInfo18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getErrors();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler1.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        loggerErrorManager15.generateReport();
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.CodingConvention codingConvention18 = compiler1.getCodingConvention();
        try {
            java.lang.String[] strArray19 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(codingConvention18);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.aliasableGlobals;
        compilerOptions0.allowLegacyJsMessages = true;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        com.google.javascript.rhino.Node node4 = node3.cloneNode();
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup2;
        boolean boolean4 = composeWarningsGuard1.enables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup2;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("DiagnosticGroup<accessControls>", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.lineLengthThreshold((-1));
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 1);
        sideEffectFlags1.setThrows();
        int int3 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node9.setType((int) '#');
        boolean boolean17 = node9.getBooleanProp((int) (short) -1);
        boolean boolean18 = node9.isSyntheticBlock();
        node9.putIntProp(8, 40);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = compilerOptions0.customPasses;
        compilerOptions0.optimizeArgumentsArray = false;
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node6.getParent();
        com.google.javascript.rhino.Node node15 = null;
        try {
            node6.addChildToBack(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        ecmaError2.initColumnNumber(16);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError2.getScriptStackTrace(filenameFilter6);
        java.lang.String str8 = ecmaError2.getErrorMessage();
        java.io.FilenameFilter filenameFilter9 = null;
        java.lang.String str10 = ecmaError2.getScriptStackTrace(filenameFilter9);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "<No stack trace available>" + "'", str10.equals("<No stack trace available>"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        boolean boolean4 = compilerOptions1.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions1.cssRenamingMap = cssRenamingMap5;
        compilerOptions1.setRemoveAbstractMethods(false);
        boolean boolean9 = compilerOptions1.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = null;
        compilerOptions1.setCodingConvention(codingConvention10);
        boolean boolean12 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        compilerOptions13.markAsCompiled = false;
        compilerOptions13.setRemoveAbstractMethods(true);
        compilerOptions13.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.checkUndefinedProperties;
        compilerOptions1.checkRequires = checkLevel22;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions1.reportMissingOverride;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.make("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", checkLevel24, "(false)");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType26);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput9.getModule();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromCode("<No stack trace available>", "Unknown class name");
        try {
            compilerInput9.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.Object obj15 = node9.getProp((-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler30 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback31 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal32 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler30, callback31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions48.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray61 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal32.makeError(node45, checkLevel57, diagnosticType60, strArray61);
        com.google.javascript.rhino.jstype.JSType jSType63 = node45.getJSType();
        java.lang.String str64 = node22.checkTreeEquals(node45);
        com.google.javascript.rhino.Node node65 = node9.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(40, node69, node72, node75, node78);
        boolean boolean80 = node69.isLocalResultCall();
        int int81 = node69.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection82 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node69);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder83 = node69.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node84 = node65.copyInformationFrom(node69);
        node84.setWasEmptyNode(false);
        boolean boolean87 = node84.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(nodeCollection82);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder83);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.enableExternExports(false);
        compilerOptions0.setTweakToNumberLiteral("0", (int) (byte) 1);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        java.lang.String str36 = node34.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.aliasKeywords = true;
        boolean boolean40 = compilerOptions37.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap41 = null;
        compilerOptions37.cssRenamingMap = cssRenamingMap41;
        compilerOptions37.setRemoveAbstractMethods(false);
        boolean boolean45 = compilerOptions37.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions37.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray50 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError51 = nodeTraversal21.makeError(node34, checkLevel46, diagnosticType49, strArray50);
        compilerOptions0.checkGlobalNamesLevel = checkLevel46;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions55.aliasKeywords = true;
        boolean boolean58 = compilerOptions55.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap59 = null;
        compilerOptions55.cssRenamingMap = cssRenamingMap59;
        compilerOptions55.setRemoveAbstractMethods(false);
        boolean boolean63 = compilerOptions55.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention64 = null;
        compilerOptions55.setCodingConvention(codingConvention64);
        boolean boolean66 = compilerOptions55.optimizeCalls;
        compilerOptions55.enableExternExports(true);
        boolean boolean69 = compilerOptions55.checkDuplicateMessages;
        java.util.Set<java.lang.String> strSet70 = compilerOptions55.stripTypes;
        compilerOptions0.stripNameSuffixes = strSet70;
        compilerOptions0.removeUnusedLocalVars = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(strSet70);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        boolean boolean12 = compiler1.hasErrors();
        com.google.javascript.rhino.Node node13 = compiler1.getRoot();
        com.google.javascript.jscomp.Scope scope14 = compiler1.getTopScope();
        boolean boolean15 = compiler1.hasErrors();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNull(scope14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test189");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
//        java.lang.String str6 = compilerInput4.getLine(120);
//        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
//        boolean boolean10 = compilerInput4.isExtern();
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        java.nio.charset.Charset charset15 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
//        java.lang.String str17 = jSSourceFile16.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst18 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
//        com.google.javascript.rhino.Node node19 = compiler12.parse(jSSourceFile16);
//        java.nio.charset.Charset charset21 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset21);
//        com.google.javascript.rhino.Node node23 = compiler12.parse(jSSourceFile22);
//        com.google.javascript.jscomp.SourceMap sourceMap24 = compiler12.getSourceMap();
//        com.google.javascript.rhino.Context context25 = com.google.javascript.rhino.Context.enter();
//        int int26 = context25.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter27 = context25.getErrorReporter();
//        int int28 = context25.getInstructionObserverThreshold();
//        java.util.Locale locale29 = context25.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException31 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException31.initLineSource("Unknown class name");
//        int int34 = evaluatorException31.lineNumber();
//        context25.removeThreadLocal((java.lang.Object) int34);
//        java.io.PrintStream printStream36 = null;
//        com.google.javascript.jscomp.Compiler compiler37 = new com.google.javascript.jscomp.Compiler(printStream36);
//        compiler37.disableThreads();
//        context25.removeThreadLocal((java.lang.Object) compiler37);
//        com.google.javascript.jscomp.Scope scope40 = compiler37.getTopScope();
//        java.nio.charset.Charset charset42 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset42);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray44 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format46 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions45.sourceMapFormat = format46;
//        compilerOptions45.unaliasableGlobals = "";
//        boolean boolean50 = compilerOptions45.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet51 = compilerOptions45.stripTypePrefixes;
//        boolean boolean52 = compilerOptions45.devirtualizePrototypeMethods;
//        boolean boolean53 = compilerOptions45.gatherCssNames;
//        boolean boolean54 = compilerOptions45.prettyPrint;
//        compilerOptions45.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result57 = compiler37.compile(jSSourceFile43, jSSourceFileArray44, compilerOptions45);
//        java.io.PrintStream printStream58 = null;
//        com.google.javascript.jscomp.Compiler compiler59 = new com.google.javascript.jscomp.Compiler(printStream58);
//        compiler59.disableThreads();
//        java.nio.charset.Charset charset62 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile63 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset62);
//        java.lang.String str64 = jSSourceFile63.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst65 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile63);
//        com.google.javascript.rhino.Node node66 = compiler59.parse(jSSourceFile63);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile70 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray71 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile63, jSSourceFile68, jSSourceFile70 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions72.aliasKeywords = true;
//        boolean boolean75 = compilerOptions72.generateExports;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap76 = compilerOptions72.cssRenamingMap;
//        compiler12.init(jSSourceFileArray44, jSSourceFileArray71, compilerOptions72);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker78 = null;
//        compiler12.tracker = performanceTracker78;
//        compiler12.parse();
//        com.google.javascript.rhino.Node node81 = compilerInput4.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler12);
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertNull(node19);
//        org.junit.Assert.assertNotNull(jSSourceFile22);
//        org.junit.Assert.assertNull(node23);
//        org.junit.Assert.assertNull(sourceMap24);
//        org.junit.Assert.assertNotNull(context25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNull(errorReporter27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(locale29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNull(scope40);
//        org.junit.Assert.assertNotNull(jSSourceFile43);
//        org.junit.Assert.assertNotNull(jSSourceFileArray44);
//        org.junit.Assert.assertNotNull(format46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(strSet51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(result57);
//        org.junit.Assert.assertNotNull(jSSourceFile63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
//        org.junit.Assert.assertNull(node66);
//        org.junit.Assert.assertNotNull(jSSourceFile68);
//        org.junit.Assert.assertNotNull(jSSourceFile70);
//        org.junit.Assert.assertNotNull(jSSourceFileArray71);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNull(cssRenamingMap76);
//        org.junit.Assert.assertNull(node81);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeTryCatchFinally = false;
        java.lang.String str4 = compilerOptions0.inputDelimiter;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 48);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "// Input %num%" + "'", str4.equals("// Input %num%"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
        compilerOptions0.generateExports = false;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = compilerOptions0.variableRenaming;
        compilerOptions0.ignoreCajaProperties = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        boolean boolean12 = compiler1.hasErrors();
        boolean boolean13 = compiler1.acceptConstKeyword();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.util.Locale locale1 = context0.getLocale();
        com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str5 = ecmaError4.toString();
        java.lang.String str6 = ecmaError4.lineSource();
        java.lang.Object obj7 = context0.getThreadLocal((java.lang.Object) ecmaError4);
        java.lang.String str8 = ecmaError4.sourceName();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertNotNull(ecmaError4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str5.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        boolean boolean75 = node52.hasMoreThanOneChild();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertNotNull(strSet10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str1 = diagnosticType0.key;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.crossModuleCodeMotion = true;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = detailLevel0.apply(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        java.lang.String str30 = node28.getString();
        com.google.javascript.rhino.Node node31 = node28.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = node28.getJSDocInfo();
        boolean boolean33 = detailLevel0.apply(node28);
        node28.putIntProp(0, 42);
        com.google.javascript.rhino.Node node37 = node28.getLastChild();
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.aliasKeywords = true;
        compilerOptions38.markAsCompiled = false;
        compilerOptions38.setRemoveAbstractMethods(true);
        boolean boolean45 = compilerOptions38.checkTypedPropertyCalls;
        compilerOptions38.extractPrototypeMemberDeclarations = true;
        java.lang.String str48 = compilerOptions38.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy49 = compilerOptions38.propertyRenaming;
        java.util.Set<java.lang.String> strSet50 = compilerOptions38.stripTypePrefixes;
        node28.setDirectives(strSet50);
        com.google.javascript.rhino.Node node52 = node28.cloneNode();
        int int53 = node28.getLineno();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(node37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy49 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy49.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        com.google.javascript.rhino.Node node18 = node7.getLastSibling();
        boolean boolean19 = node18.isQuotedString();
        java.lang.String str20 = node18.getString();
        boolean boolean21 = node3.isEquivalentToTyped(node18);
        boolean boolean22 = node18.hasSideEffects();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean13 = compilerOptions0.inlineConstantVars;
        boolean boolean14 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.enableExternExports(false);
        boolean boolean17 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        compilerOptions1.markAsCompiled = false;
        compilerOptions1.setRemoveAbstractMethods(true);
        boolean boolean8 = compilerOptions1.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.aliasKeywords = true;
        compilerOptions9.markAsCompiled = false;
        compilerOptions9.setRemoveAbstractMethods(true);
        compilerOptions9.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions9.checkUndefinedProperties;
        compilerOptions1.checkGlobalThisLevel = checkLevel18;
        compilerOptions1.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions1.groupVariableDeclarations = true;
        java.lang.Object obj26 = null;
        try {
            java.lang.String str27 = com.google.javascript.rhino.ScriptRuntime.getMessage3("goog.exportProperty", (java.lang.Object) true, (java.lang.Object) 12, obj26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test203");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        context0.setCompileFunctionsWithDynamicScope(true);
//        java.lang.Object obj4 = context0.getDebuggerContextData();
//        java.lang.Object obj5 = context0.getDebuggerContextData();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions6.aliasKeywords = true;
//        compilerOptions6.markAsCompiled = false;
//        java.lang.Object obj11 = compilerOptions6.clone();
//        boolean boolean12 = compilerOptions6.inlineFunctions;
//        compilerOptions6.generatePseudoNames = false;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup15;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format18 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions17.sourceMapFormat = format18;
//        compilerOptions17.unaliasableGlobals = "";
//        boolean boolean22 = compilerOptions17.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet23 = compilerOptions17.stripTypePrefixes;
//        boolean boolean24 = compilerOptions17.devirtualizePrototypeMethods;
//        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap25 = null;
//        compilerOptions17.customPasses = customPassExecutionTimeMultimap25;
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions17.checkMissingGetCssNameLevel;
//        compilerOptions6.setWarningLevel(diagnosticGroup15, checkLevel27);
//        java.lang.Object obj29 = context0.getThreadLocal((java.lang.Object) compilerOptions6);
//        java.lang.Object obj30 = compilerOptions6.clone();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(obj5);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup15);
//        org.junit.Assert.assertNotNull(format18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(strSet23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNull(obj29);
//        org.junit.Assert.assertNotNull(obj30);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 130, 7);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        boolean boolean18 = node7.isLocalResultCall();
        int int19 = node7.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection20 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node7);
        node7.setCharno(17);
        node7.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = node3.clonePropsFrom(node7);
        try {
            node7.setDouble((double) 4095);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR hi! is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(nodeCollection20);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags();
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 10L, (java.lang.Object) sideEffectFlags1);
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setAllFlags();
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        boolean boolean7 = compilerInput4.isExtern();
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        compilerInput4.setModule(jSModule8);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Unknown class name");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("eof", reader5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromReader("goog.abstractMethod", reader5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        compilerOptions0.aliasAllStrings = true;
        java.lang.String str13 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
        compilerOptions0.generateExports = false;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean8 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkFunctions;
        compilerOptions0.checkTypes = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.nameReferenceReportPath = "Unknown class name";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test211");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        int int4 = context0.getLanguageVersion();
//        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        boolean boolean14 = compilerOptions11.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap15 = null;
        compilerOptions11.cssRenamingMap = cssRenamingMap15;
        compilerOptions11.setRemoveAbstractMethods(false);
        boolean boolean19 = compilerOptions11.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.aggressiveVarCheck;
        compilerOptions0.checkMethods = checkLevel20;
        compilerOptions0.foldConstants = false;
        boolean boolean24 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap6 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strMap6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        try {
            com.google.javascript.rhino.Context.reportWarning("Node tree inequality:\nTree1:\nSTRING eof 24\n\n\nTree2:\nOR hi!\n\n\nSubtree1: STRING eof 24\n\n\nSubtree2: OR hi!\n", "instanceof", 30, "true", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 0.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        com.google.javascript.rhino.Node node15 = node4.getLastSibling();
        boolean boolean16 = node15.isQuotedString();
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node19 = node15.getAncestor(16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.aliasKeywords = true;
        compilerOptions20.markAsCompiled = false;
        java.lang.Object obj25 = compilerOptions20.clone();
        compilerOptions20.deadAssignmentElimination = true;
        compilerOptions20.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention31 = compilerOptions20.getCodingConvention();
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions20.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int37 = diagnosticType35.compareTo(diagnosticType36);
        java.lang.String[] strArray38 = null;
        try {
            com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("", node19, checkLevel32, diagnosticType36, strArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(codingConvention31);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-23) + "'", int37 == (-23));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        java.lang.String str36 = node34.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.aliasKeywords = true;
        boolean boolean40 = compilerOptions37.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap41 = null;
        compilerOptions37.cssRenamingMap = cssRenamingMap41;
        compilerOptions37.setRemoveAbstractMethods(false);
        boolean boolean45 = compilerOptions37.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions37.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray50 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError51 = nodeTraversal21.makeError(node34, checkLevel46, diagnosticType49, strArray50);
        compilerOptions0.checkGlobalNamesLevel = checkLevel46;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.checkTypedPropertyCalls = true;
        boolean boolean57 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        ecmaError2.initColumnNumber(16);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError2.getScriptStackTrace(filenameFilter6);
        java.lang.String str8 = ecmaError2.getErrorMessage();
        java.lang.String str9 = ecmaError2.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.aliasableStrings;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.printInputDelimiter = true;
        boolean boolean10 = compilerOptions0.removeUnusedPrototypeProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
        boolean boolean4 = context0.isGeneratingSource();
        java.util.Locale locale5 = context0.getLocale();
        com.google.javascript.rhino.ErrorReporter errorReporter6 = context0.getErrorReporter();
        boolean boolean8 = context0.isActivationNeeded("OR hi!");
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(locale5);
        org.junit.Assert.assertNull(errorReporter6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        boolean boolean23 = node15.isNoSideEffectsCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test222");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        java.lang.String str12 = compilerOptions2.jsOutputFile;
//        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions2.checkRequires;
//        compilerOptions2.convertToDottedProperties = false;
//        compilerOptions2.setPropertyAffinity(false);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.lineLengthThreshold(0);
        compilerOptions0.checkDuplicateMessages = true;
        java.lang.String str14 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0);
        com.google.javascript.rhino.Node node40 = node15.copyInformationFromForTree(node39);
        int int42 = node40.getIntProp(34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }
}

