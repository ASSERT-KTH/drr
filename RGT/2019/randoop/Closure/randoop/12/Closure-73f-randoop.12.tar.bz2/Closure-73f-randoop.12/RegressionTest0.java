import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) false, (java.lang.Object) "Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(runtimeException9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("Not declared as a type name", "Unknown class name", 0, "Unknown class name", (int) (short) 100);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        try {
            com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(100, node1, node2, node3, (-1), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eof" + "'", str1.equals("eof"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            com.google.javascript.rhino.Context.reportWarning("Not declared as a type name", "Unknown class name", (int) (short) 100, "eof", (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
        boolean boolean5 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) "Not declared as a type name", (java.lang.Object) true);
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.JSError jSError7 = null;
        try {
            boolean boolean8 = diagnosticGroup6.matches(jSError7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        try {
            ecmaError2.initLineNumber((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 36");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        compilerOptions2.markAsCompiled = false;
        compilerOptions2.setRemoveAbstractMethods(true);
        compilerOptions2.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions2.checkUndefinedProperties;
        com.google.javascript.jscomp.JSError jSError12 = null;
        try {
            loggerErrorManager1.report(checkLevel11, jSError12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node9.setType((int) '#');
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.rhino.Node node30 = node19.getLastSibling();
        com.google.javascript.rhino.Node node31 = null;
        try {
            node9.replaceChild(node19, node31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.aliasKeywords = true;
        compilerOptions3.markAsCompiled = false;
        compilerOptions3.setRemoveAbstractMethods(true);
        boolean boolean10 = compilerOptions3.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        compilerOptions11.markAsCompiled = false;
        compilerOptions11.setRemoveAbstractMethods(true);
        compilerOptions11.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.checkUndefinedProperties;
        compilerOptions3.checkGlobalThisLevel = checkLevel20;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = null;
        java.lang.String[] strArray23 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        try {
            com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 0, (int) '#', checkLevel20, diagnosticType22, strArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        com.google.javascript.jscomp.SourceMap.Format format11 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(format11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        int int15 = node10.getType();
        try {
            com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 0, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.aliasKeywords = true;
        compilerOptions3.markAsCompiled = false;
        compilerOptions3.setRemoveAbstractMethods(true);
        boolean boolean10 = compilerOptions3.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        compilerOptions11.markAsCompiled = false;
        compilerOptions11.setRemoveAbstractMethods(true);
        compilerOptions11.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.checkUndefinedProperties;
        compilerOptions3.checkGlobalThisLevel = checkLevel20;
        compilerOptions0.checkRequires = checkLevel20;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        int int15 = node12.getCharno();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        boolean boolean30 = node19.isLocalResultCall();
        boolean boolean31 = node19.isLocalResultCall();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel32 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        boolean boolean47 = detailLevel32.apply(node42);
        try {
            node12.replaceChild(node19, node42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node has siblings.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(detailLevel32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        int int15 = node12.getCharno();
        try {
            node12.setDouble((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR hi! is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        sourceFile1.setOriginalPath("Not declared as a type name");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        java.lang.String str15 = node13.getString();
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(2, node13, 100, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        boolean boolean7 = compilerOptions4.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = null;
        compilerOptions4.cssRenamingMap = cssRenamingMap8;
        compilerOptions4.setRemoveAbstractMethods(false);
        boolean boolean12 = compilerOptions4.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions4.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = null;
        java.lang.String[] strArray18 = new java.lang.String[] { ": ", "hi!", "Not declared as a type name" };
        try {
            com.google.javascript.jscomp.JSError jSError19 = nodeTraversal2.makeError(node3, checkLevel13, diagnosticType14, strArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setTweakToDoubleLiteral("error reporter", (double) 9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup6;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.unaliasableGlobals = "error reporter";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        int int15 = node12.getCharno();
        try {
            double double16 = node12.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR hi! is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo16 = node15.getJSDocInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        java.lang.Class<?> wildcardClass1 = variableRenamingPolicy0.getClass();
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        try {
            node15.detachChildren();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        boolean boolean13 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Unknown class name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((-1), node3, node13, 20, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            com.google.javascript.rhino.Context.reportWarning("error reporter", "error reporter", (int) (byte) 10, "error reporter", (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.enableExternExports(true);
        boolean boolean14 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("", "hi!");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray3 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray3);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticTypeArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("hi!", "Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.specializeInitialModule = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "Unknown class name", 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.Region region6 = jSSourceFile2.getRegion(41);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("com.google.javascript.rhino.EcmaError: : ", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        try {
            java.lang.String str5 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        int int15 = node12.getCharno();
        boolean boolean16 = node12.hasSideEffects();
        try {
            int int18 = node12.getExistingIntProp(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.generateExports = false;
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        boolean boolean10 = diagnosticGroup6.matches(diagnosticType9);
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup6;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.rhino.jstype.JSType jSType33 = node15.getJSType();
        node15.setVarArgs(true);
        com.google.javascript.rhino.Node node36 = node15.getNext();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNull(node36);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.setRemoveClosureAsserts(false);
        java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "false" + "'", str12.equals("false"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        boolean boolean4 = compilerOptions1.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions1.cssRenamingMap = cssRenamingMap5;
        compilerOptions1.setRemoveAbstractMethods(false);
        boolean boolean9 = compilerOptions1.lineBreak;
        java.lang.Class<?> wildcardClass10 = compilerOptions1.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions1.reportMissingOverride;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name", checkLevel11, "");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        try {
            int int16 = node15.getSideEffectFlags();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "instanceof" + "'", str1.equals("instanceof"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Not declared as a type name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        compilerOptions0.groupVariableDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(40, node17, node20, node23, node26);
        com.google.javascript.rhino.Node node28 = node17.getLastSibling();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        com.google.javascript.rhino.Node node43 = node35.getParent();
        try {
            node3.addChildBefore(node28, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.crossModuleCodeMotion = true;
        byte[] byteArray9 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertNull(byteArray9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean10 = compilerOptions0.prettyPrint;
        compilerOptions0.lineLengthThreshold((int) ' ');
        boolean boolean13 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.specializeInitialModule;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, false);
        java.lang.String str18 = compilerInput16.getLine(120);
        compilerInput16.clearAst();
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray20 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput4, compilerInput11, compilerInput16 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList21 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList21, dependencyInfoArray20);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies23 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(dependencyInfoArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler5 = null;
        try {
            compilerInput4.setCompiler(abstractCompiler5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        com.google.javascript.rhino.Node node47 = node36.getLastSibling();
        try {
            nodeTraversal2.traverse(node47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig5 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertNotNull(format1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
        evaluatorException1.initLineSource("Unknown class name");
        int int4 = evaluatorException1.lineNumber();
        java.lang.String str5 = evaluatorException1.sourceName();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray2 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray2);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard1, composeWarningsGuard3 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(warningsGuardArray2);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 2, "instanceof", 3);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.aliasableGlobals = "eof";
        boolean boolean12 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        java.lang.String str15 = node13.getString();
        com.google.javascript.rhino.Node node16 = node13.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node13.getJSDocInfo();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        com.google.javascript.rhino.Node node32 = node21.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.aliasKeywords = true;
        boolean boolean37 = compilerOptions34.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap38 = null;
        compilerOptions34.cssRenamingMap = cssRenamingMap38;
        compilerOptions34.setRemoveAbstractMethods(false);
        boolean boolean42 = compilerOptions34.lineBreak;
        boolean boolean43 = compilerOptions34.markNoSideEffectCalls;
        boolean boolean44 = compilerOptions34.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format46 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions45.sourceMapFormat = format46;
        compilerOptions45.unaliasableGlobals = "";
        boolean boolean50 = compilerOptions45.disambiguateProperties;
        java.util.Set<java.lang.String> strSet51 = compilerOptions45.stripTypePrefixes;
        compilerOptions34.stripNameSuffixes = strSet51;
        node32.setDirectives(strSet51);
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] { node13, node32 };
        try {
            com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(120, nodeArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(format46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strSet51);
        org.junit.Assert.assertNotNull(nodeArray54);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.getErrorReporter();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        try {
//            context0.addPropertyChangeListener(propertyChangeListener5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter4);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "instanceof", 44, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        node12.setType((int) '#');
        try {
            nodeTraversal2.traverse(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        compilerOptions0.computeFunctionSideEffects = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, ": ", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.WARNING;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler15 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler15, callback16);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        java.lang.String str32 = node30.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.aliasKeywords = true;
        boolean boolean36 = compilerOptions33.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap37 = null;
        compilerOptions33.cssRenamingMap = cssRenamingMap37;
        compilerOptions33.setRemoveAbstractMethods(false);
        boolean boolean41 = compilerOptions33.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions33.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray46 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError47 = nodeTraversal17.makeError(node30, checkLevel42, diagnosticType45, strArray46);
        com.google.javascript.rhino.jstype.JSType jSType48 = node30.getJSType();
        java.lang.String str49 = node7.checkTreeEquals(node30);
        com.google.javascript.rhino.jstype.JSType jSType50 = node7.getJSType();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(40, node54, node57, node60, node63);
        com.google.javascript.rhino.Node node65 = node54.getLastSibling();
        boolean boolean66 = node65.isQuotedString();
        boolean boolean67 = node65.isQualifiedName();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(40, node71, node74, node77, node80);
        boolean boolean82 = node71.isLocalResultCall();
        int int83 = node71.getSideEffectFlags();
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean88 = node87.hasSideEffects();
        node87.setIsSyntheticBlock(false);
        try {
            com.google.javascript.rhino.Node node93 = new com.google.javascript.rhino.Node(0, node7, node65, node71, node87, 49, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.aliasableGlobals = "eof";
        compilerOptions0.unaliasableGlobals = "instanceof";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType1, functionType2, objectType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags();
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 10L, (java.lang.Object) sideEffectFlags1);
        java.lang.Throwable[] throwableArray3 = runtimeException2.getSuppressed();
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.rhino.Node node0 = null;
        try {
            java.util.Collection<com.google.javascript.rhino.Node> nodeCollection1 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node16 = null;
        try {
            node14.replaceChild(node15, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        java.lang.String str15 = node13.getString();
        com.google.javascript.rhino.Node node16 = node13.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node13.getJSDocInfo();
        node13.setString("false");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel34 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(40, node38, node41, node44, node47);
        boolean boolean49 = detailLevel34.apply(node44);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable50 = node44.getAncestors();
        try {
            com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(5, node13, node23, node44, 18, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(detailLevel34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(ancestorIterable50);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        boolean boolean33 = nodeTraversal2.hasScope();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node9.setType((int) '#');
        java.lang.RuntimeException runtimeException16 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(runtimeException16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a type name", "com.google.javascript.rhino.EcmaError: : ", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.devirtualizePrototypeMethods = false;
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "com.google.javascript.rhino.EcmaError: : ", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean13 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("false");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        try {
            node12.setSideEffectFlags(42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearAllFlags();
        sideEffectFlags0.setAllFlags();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.rewriteFunctionExpressions = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy10;
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "com.google.javascript.rhino.EcmaError: : ");
        int int3 = ecmaError2.getLineNumber();
        java.lang.String str4 = ecmaError2.toString();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : " + "'", str4.equals("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : "));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention8);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
//        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("error reporter", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.collapseAnonymousFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        try {
            node6.setSideEffectFlags(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        java.lang.String str11 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.labelRenaming = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        com.google.javascript.rhino.Node node17 = node9.getParent();
        boolean boolean18 = node9.isNoSideEffectsCall();
        try {
            boolean boolean19 = closureCodingConvention0.isPropertyTestFunction(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node6.setString("hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.rhino.Node node30 = node19.getLastSibling();
        boolean boolean31 = node30.isQuotedString();
        boolean boolean32 = node30.isQualifiedName();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        com.google.javascript.rhino.Node node47 = node36.getLastSibling();
        boolean boolean48 = node47.isQuotedString();
        boolean boolean49 = node47.isQualifiedName();
        try {
            node6.replaceChildAfter(node30, node47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        java.lang.Class<?> wildcardClass1 = variableRenamingPolicy0.getClass();
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider6 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat4.toFormatter(sourceExcerptProvider6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        compilerInput4.clearAst();
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(logger8);
        loggerErrorManager9.generateReport();
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        boolean boolean10 = compilerInput9.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getCurrentNode();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a type name", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(40, node18, node21, node24, node27);
        java.lang.String str29 = node27.getString();
        com.google.javascript.rhino.Node node30 = node27.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = node27.getJSDocInfo();
        node27.setString("false");
        try {
            node3.addChildToFront(node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNull(jSDocInfo31);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1(".  at (unknown source) line (unknown line) : (unknown column)", (java.lang.Object) detailLevel1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property .  at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        int int3 = nodeTraversal2.getLineNumber();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, false);
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        java.lang.String str36 = node34.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.aliasKeywords = true;
        boolean boolean40 = compilerOptions37.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap41 = null;
        compilerOptions37.cssRenamingMap = cssRenamingMap41;
        compilerOptions37.setRemoveAbstractMethods(false);
        boolean boolean45 = compilerOptions37.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions37.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray50 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError51 = nodeTraversal21.makeError(node34, checkLevel46, diagnosticType49, strArray50);
        compilerOptions0.checkGlobalNamesLevel = checkLevel46;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.setTweakToBooleanLiteral("goog.exportProperty", false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        java.lang.String str13 = composeWarningsGuard11.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        try {
//            com.google.javascript.rhino.Context.reportError("instanceof", "<No stack trace available>", 3, "Not declared as a type name", 49);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: instanceof (<No stack trace available>#3)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        boolean boolean12 = compilerOptions2.inlineVariables;
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 29");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        try {
//            com.google.javascript.rhino.Context.reportError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        boolean boolean15 = node12.wasEmptyNode();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("false", ": ", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        com.google.javascript.rhino.Node node15 = null;
        try {
            node3.addChildToFront(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        java.lang.String str7 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(cssRenamingMap8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        jSSourceFile2.clearCachedSource();
        java.lang.String str6 = jSSourceFile2.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node18 = node3.detachFromParent();
        try {
            com.google.javascript.rhino.Node node19 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = node4.isLocalResultCall();
        int int16 = node4.getSideEffectFlags();
        com.google.javascript.jscomp.NodeTraversal.Callback callback17 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node4, callback17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.Region region6 = compilerInput4.getRegion(9);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup18;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup18;
        boolean boolean21 = composeWarningsGuard16.disables(diagnosticGroup18);
        java.lang.String str22 = composeWarningsGuard16.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.checkSymbols = true;
        java.lang.Class<?> wildcardClass14 = compilerOptions0.getClass();
        boolean boolean15 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 37);
        try {
            node1.setString("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 37.0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        try {
//            com.google.javascript.rhino.Context.reportError(".  at (unknown source) line (unknown line) : (unknown column)");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: .  at (unknown source) line (unknown line) : (unknown column)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 37);
        java.lang.Appendable appendable2 = null;
        try {
            node1.appendStringTree(appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        compilerOptions0.inputDelimiter = "eof";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("com.google.javascript.rhino.EcmaError: : ");
        try {
            ecmaError1.initColumnNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean3 = closureCodingConvention1.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        java.lang.String str18 = node16.getString();
        com.google.javascript.rhino.Node node19 = node16.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = node16.getJSDocInfo();
        node16.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = closureCodingConvention1.getDelegateRelationship(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(40, node27, node30, node33, node36);
        boolean boolean38 = node16.hasChild(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(40, node42, node45, node48, node51);
        java.lang.Object obj54 = node48.getProp((-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newNumber((double) 37);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(40, node60, node63, node66, node69);
        boolean boolean71 = node60.isLocalResultCall();
        boolean boolean72 = node60.isLocalResultCall();
        com.google.javascript.rhino.jstype.JSType jSType73 = node60.getJSType();
        try {
            com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(42, node16, node48, node56, node60, 7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNull(jSDocInfo20);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(obj54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNull(jSType73);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        compilerOptions0.setTweakToNumberLiteral("instanceof", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.setErrorReporter(errorReporter3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.Node node17 = null;
        try {
            com.google.javascript.rhino.Node node18 = node3.copyInformationFromForTree(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        boolean boolean15 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.aliasKeywords = true;
        boolean boolean19 = compilerOptions16.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap20 = null;
        compilerOptions16.cssRenamingMap = cssRenamingMap20;
        compilerOptions16.setRemoveAbstractMethods(false);
        boolean boolean24 = compilerOptions16.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention25 = null;
        compilerOptions16.setCodingConvention(codingConvention25);
        boolean boolean27 = compilerOptions16.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions16.reportUnknownTypes;
        compilerOptions0.aggressiveVarCheck = checkLevel28;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler23 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler23, callback24);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(40, node29, node32, node35, node38);
        java.lang.String str40 = node38.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.aliasKeywords = true;
        boolean boolean44 = compilerOptions41.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap45 = null;
        compilerOptions41.cssRenamingMap = cssRenamingMap45;
        compilerOptions41.setRemoveAbstractMethods(false);
        boolean boolean49 = compilerOptions41.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel50 = compilerOptions41.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray54 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError55 = nodeTraversal25.makeError(node38, checkLevel50, diagnosticType53, strArray54);
        com.google.javascript.rhino.jstype.JSType jSType56 = node38.getJSType();
        node38.setVarArgs(true);
        try {
            java.util.List<java.lang.String> strList59 = closureCodingConvention0.identifyTypeDeclarationCall(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + checkLevel50 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel50.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNull(jSType56);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(".  at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("error reporter", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        boolean boolean16 = detailLevel1.apply(node11);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node11.new FileLevelJsDocBuilder();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel18 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(40, node22, node25, node28, node31);
        boolean boolean33 = detailLevel18.apply(node28);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable34 = node28.getAncestors();
        try {
            com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(11, node11, node28, (int) (byte) 1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(detailLevel18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(ancestorIterable34);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = node4.isLocalResultCall();
        int int16 = node4.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean22 = node21.hasSideEffects();
        node21.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(40, node28, node31, node34, node37);
        java.lang.String str39 = node37.getString();
        com.google.javascript.rhino.Node node40 = node37.getLastChild();
        node37.putBooleanProp(24, true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention44 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean46 = closureCodingConvention44.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(40, node50, node53, node56, node59);
        java.lang.String str61 = node59.getString();
        com.google.javascript.rhino.Node node62 = node59.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo63 = node59.getJSDocInfo();
        node59.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship66 = closureCodingConvention44.getDelegateRelationship(node59);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(40, node70, node73, node76, node79);
        boolean boolean81 = node59.hasChild(node79);
        try {
            com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(13, node4, node21, node37, node59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNull(node40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertNull(node62);
        org.junit.Assert.assertNull(jSDocInfo63);
        org.junit.Assert.assertNull(delegateRelationship66);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.generatePseudoNames = false;
        java.lang.String str9 = compilerOptions0.locale;
        compilerOptions0.ambiguateProperties = true;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray6 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup4, diagnosticGroup5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = new com.google.javascript.jscomp.DiagnosticGroup("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", diagnosticGroupArray6);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroupArray6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        boolean boolean2 = context0.isGeneratingDebugChanged();
//        context0.setGeneratingSource(false);
//        context0.setInstructionObserverThreshold(8);
//        try {
//            context0.setLanguageVersion(21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 21");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.warning("", "hi!");
        int int4 = diagnosticType0.compareTo(diagnosticType3);
        java.text.MessageFormat messageFormat5 = diagnosticType0.format;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 23 + "'", int4 == 23);
        org.junit.Assert.assertNotNull(messageFormat5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        com.google.javascript.rhino.Node node15 = node4.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable16 = node15.siblings();
        try {
            com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(36, node15, (int) (short) 0, 4095);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeIterable16);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        try {
//            com.google.javascript.rhino.Context.reportError("Named type with empty name component");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Named type with empty name component");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("Unknown class name", "com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Unknown class name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node12.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("error reporter");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        try {
            node13.setDouble((double) 49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("com.google.javascript.rhino.EcmaError: : ", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel15 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        boolean boolean30 = detailLevel15.apply(node25);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable31 = node25.getAncestors();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node10, node25 };
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(7, nodeArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(detailLevel15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(ancestorIterable31);
        org.junit.Assert.assertNotNull(nodeArray32);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("hi!", "Not declared as a type name", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        java.lang.String str2 = sourceFile1.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 46");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        java.lang.String str33 = jSError32.sourceName;
        java.lang.String str34 = jSError32.description;
        java.lang.Object obj35 = null;
        boolean boolean36 = jSError32.equals(obj35);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        java.lang.String str15 = node13.getString();
        int int16 = node13.getCharno();
        boolean boolean17 = node13.hasSideEffects();
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, node13, (int) '4', 46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        try {
            java.lang.String str10 = compilerInput9.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean2 = context0.isGeneratingDebug();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("instanceof", "false");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("instanceof");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.reportPath = "<No stack trace available>";
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        int int15 = node12.getCharno();
        boolean boolean16 = node12.hasSideEffects();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
        java.lang.String str34 = node32.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.aliasKeywords = true;
        boolean boolean38 = compilerOptions35.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap39 = null;
        compilerOptions35.cssRenamingMap = cssRenamingMap39;
        compilerOptions35.setRemoveAbstractMethods(false);
        boolean boolean43 = compilerOptions35.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions35.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray48 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError49 = nodeTraversal19.makeError(node32, checkLevel44, diagnosticType47, strArray48);
        com.google.javascript.rhino.jstype.JSType jSType50 = node32.getJSType();
        node32.setCharno(0);
        try {
            com.google.javascript.rhino.Node node53 = node12.getChildBefore(node32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNull(jSType50);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        node35.setOptionalArg(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.checkSymbols = true;
        java.lang.Class<?> wildcardClass14 = compilerOptions0.getClass();
        java.lang.String str15 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy10;
        boolean boolean12 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        java.lang.String str15 = node3.getString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler28 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback29 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal30 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler28, callback29);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(40, node34, node37, node40, node43);
        java.lang.String str45 = node43.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions46.aliasKeywords = true;
        boolean boolean49 = compilerOptions46.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap50 = null;
        compilerOptions46.cssRenamingMap = cssRenamingMap50;
        compilerOptions46.setRemoveAbstractMethods(false);
        boolean boolean54 = compilerOptions46.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compilerOptions46.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray59 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError60 = nodeTraversal30.makeError(node43, checkLevel55, diagnosticType58, strArray59);
        com.google.javascript.rhino.jstype.JSType jSType61 = node43.getJSType();
        node43.setVarArgs(true);
        try {
            node26.addChildrenToFront(node43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNull(jSType61);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.collapseAnonymousFunctions = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions2.sourceMapFormat = format3;
        compilerOptions2.unaliasableGlobals = "";
        boolean boolean7 = compilerOptions2.disambiguateProperties;
        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
        boolean boolean9 = compilerOptions2.devirtualizePrototypeMethods;
        boolean boolean10 = compilerOptions2.gatherCssNames;
        boolean boolean11 = compilerOptions2.prettyPrint;
        boolean boolean12 = compilerOptions2.computeFunctionSideEffects;
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        com.google.javascript.rhino.Node node31 = node20.getLastSibling();
        boolean boolean32 = node31.isQuotedString();
        java.lang.String str33 = node31.getString();
        boolean boolean34 = node16.isEquivalentToTyped(node31);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(40, node38, node41, node44, node47);
        java.lang.String str49 = node47.getString();
        com.google.javascript.rhino.Node node50 = node47.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = node47.getJSDocInfo();
        try {
            java.lang.String str52 = com.google.javascript.rhino.ScriptRuntime.getMessage4("<No stack trace available>", (java.lang.Object) diagnosticGroup1, (java.lang.Object) boolean12, (java.lang.Object) boolean34, (java.lang.Object) jSDocInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <No stack trace available>");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertNull(jSDocInfo51);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.getErrorReporter();
//        try {
//            com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter4);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        compilerOptions0.reserveRawExports = false;
        boolean boolean8 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )" + "'", str1.equals("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("instanceof", "", 34, ": ", 13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        boolean boolean16 = node3.hasOneChild();
        node3.setOptionalArg(false);
        try {
            double double19 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR hi! is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap11 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap11;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        compilerOptions13.markAsCompiled = false;
        compilerOptions13.setRemoveAbstractMethods(true);
        boolean boolean20 = compilerOptions13.checkTypedPropertyCalls;
        compilerOptions13.extractPrototypeMemberDeclarations = true;
        boolean boolean23 = compilerOptions13.convertToDottedProperties;
        boolean boolean24 = compilerOptions13.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions13.brokenClosureRequiresLevel;
        compilerOptions0.checkFunctions = checkLevel25;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        char[] charArray2 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        boolean boolean10 = compilerInput4.isExtern();
        try {
            java.util.Collection<java.lang.String> strCollection11 = compilerInput4.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean13 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = node12.getJSDocInfo();
        node12.setString("false");
        try {
            node12.setSideEffectFlags((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(jSDocInfo16);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("com.google.javascript.rhino.EcmaError: : ", "", "com.google.javascript.rhino.EcmaError: : ");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(12);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bitxor" + "'", str1.equals("bitxor"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions0.checkUndefinedProperties = checkLevel22;
        boolean boolean24 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        compilerOptions2.markAsCompiled = false;
        compilerOptions2.setRemoveAbstractMethods(true);
        boolean boolean9 = compilerOptions2.checkTypedPropertyCalls;
        compilerOptions2.extractPrototypeMemberDeclarations = true;
        java.lang.String str12 = compilerOptions2.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy13 = compilerOptions2.propertyRenaming;
        java.lang.RuntimeException runtimeException14 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 31, obj1, (java.lang.Object) propertyRenamingPolicy13);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy13.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(runtimeException14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.setDefineToNumberLiteral("", 9);
        compilerOptions0.setPropertyAffinity(false);
        compilerOptions0.skipAllCompilerPasses();
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        node3.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        boolean boolean31 = node20.isLocalResultCall();
        int int32 = node20.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node20);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder34 = node20.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node35 = node20.detachFromParent();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        try {
            node3.replaceChildAfter(node35, node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags33 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags33.setThrows();
        sideEffectFlags33.setMutatesThis();
        try {
            node15.setSideEffectFlags(sideEffectFlags33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean4 = node3.hasSideEffects();
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        boolean boolean6 = node3.isQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean5 = node4.hasSideEffects();
        node4.setIsSyntheticBlock(false);
        boolean boolean8 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(40, node12, node15, node18, node21);
        java.lang.String str23 = node21.getString();
        int int24 = node21.getCharno();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel25 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(40, node29, node32, node35, node38);
        boolean boolean40 = detailLevel25.apply(node35);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder41 = node35.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(40, node45, node48, node51, node54);
        com.google.javascript.rhino.Node node56 = node48.getParent();
        try {
            com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(40, node4, node21, node35, node56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(detailLevel25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.setColorizeErrorOutput(false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setDefineToStringLiteral("", "DiagnosticGroup<accessControls>");
        org.junit.Assert.assertNotNull(format1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean4 = node3.hasSideEffects();
        node3.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) 37);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean11 = closureCodingConvention9.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(40, node15, node18, node21, node24);
        java.lang.String str26 = node24.getString();
        com.google.javascript.rhino.Node node27 = node24.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = node24.getJSDocInfo();
        node24.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship31 = closureCodingConvention9.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(40, node35, node38, node41, node44);
        boolean boolean46 = node24.hasChild(node44);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(40, node50, node53, node56, node59);
        com.google.javascript.rhino.Node node61 = node50.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable62 = node61.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions63.aliasKeywords = true;
        boolean boolean66 = compilerOptions63.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap67 = null;
        compilerOptions63.cssRenamingMap = cssRenamingMap67;
        compilerOptions63.setRemoveAbstractMethods(false);
        boolean boolean71 = compilerOptions63.lineBreak;
        boolean boolean72 = compilerOptions63.markNoSideEffectCalls;
        boolean boolean73 = compilerOptions63.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format75 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions74.sourceMapFormat = format75;
        compilerOptions74.unaliasableGlobals = "";
        boolean boolean79 = compilerOptions74.disambiguateProperties;
        java.util.Set<java.lang.String> strSet80 = compilerOptions74.stripTypePrefixes;
        compilerOptions63.stripNameSuffixes = strSet80;
        node61.setDirectives(strSet80);
        com.google.javascript.rhino.Node node83 = node44.copyInformationFromForTree(node61);
        try {
            node3.replaceChildAfter(node8, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertNull(delegateRelationship31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeIterable62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(format75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertNotNull(node83);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        int int17 = node3.getSourcePosition();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean15 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format16 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions15.sourceMapFormat = format16;
        compilerOptions15.unaliasableGlobals = "";
        boolean boolean20 = compilerOptions15.disambiguateProperties;
        java.util.Set<java.lang.String> strSet21 = compilerOptions15.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy23 = null;
        compilerOptions15.setRenamingPolicy(variableRenamingPolicy22, propertyRenamingPolicy23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format26 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions25.sourceMapFormat = format26;
        compilerOptions25.unaliasableGlobals = "";
        compilerOptions25.collapseProperties = true;
        compilerOptions25.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass34 = compilerOptions25.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy35 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions25.propertyRenaming = propertyRenamingPolicy35;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy22, propertyRenamingPolicy35);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy22.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertNotNull(format26);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy35 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy35.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        boolean boolean10 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        boolean boolean15 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 13");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.setTweakToDoubleLiteral("OR hi!\n", (-1.0d));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.jscomp.Compiler compiler33 = nodeTraversal2.getCompiler();
        try {
            com.google.javascript.rhino.Node node34 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNull(compiler33);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(40, node78, node81, node84, node87);
        node84.setType((int) '#');
        boolean boolean92 = node84.getBooleanProp((int) (short) -1);
        boolean boolean93 = node74.isEquivalentTo(node84);
        boolean boolean94 = node84.hasSideEffects();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        boolean boolean2 = context0.isGeneratingDebugChanged();
//        context0.setGeneratingSource(false);
//        try {
//            context0.setLanguageVersion(20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 20");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", "com.google.javascript.rhino.EcmaError: : ", "", "false");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkProvides;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setCharno(17);
        node3.putIntProp(18, 2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean8 = tweakProcessing7.isOn();
        compilerOptions0.setTweakProcessing(tweakProcessing7);
        boolean boolean10 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "hi!");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        jsAst4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        java.nio.charset.Charset charset2 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset2);
//        java.lang.String str4 = jSSourceFile3.getOriginalPath();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions5.aliasKeywords = true;
//        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
//        compilerOptions5.checkRequires = checkLevel8;
//        com.google.javascript.rhino.Context context10 = com.google.javascript.rhino.Context.enter();
//        long long11 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context10);
//        context10.setCompileFunctionsWithDynamicScope(true);
//        java.lang.Object obj14 = context10.getDebuggerContextData();
//        java.lang.Object obj15 = context10.getDebuggerContextData();
//        try {
//            java.lang.String str16 = com.google.javascript.rhino.ScriptRuntime.getMessage3("com.google.javascript.rhino.EcmaError: : ", (java.lang.Object) str4, (java.lang.Object) compilerOptions5, (java.lang.Object) context10);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: : ");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(context10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNull(obj14);
//        org.junit.Assert.assertNull(obj15);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError(".  at (unknown source) line (unknown line) : (unknown column)");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: .  at (unknown source) line (unknown line) : (unknown column)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = detailLevel0.apply(node10);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node10.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder16.append("");
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        context0.addActivationName("false");
//        int int6 = context0.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        com.google.javascript.rhino.Node node21 = node10.getLastSibling();
        boolean boolean22 = node21.isQuotedString();
        java.lang.String str23 = node21.getString();
        boolean boolean24 = node6.isEquivalentToTyped(node21);
        try {
            boolean boolean25 = closureCodingConvention1.isPropertyTestFunction(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.lang.Object obj1 = null;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) context0, obj1);
        boolean boolean3 = context0.isGeneratingDebug();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        boolean boolean4 = context0.isGeneratingSource();
//        java.util.Locale locale5 = context0.getLocale();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(locale5);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        try {
            java.lang.String str6 = compilerInput5.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.setAcceptConstKeyword(true);
        boolean boolean6 = compilerOptions0.exportTestFunctions;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        compilerOptions11.markAsCompiled = false;
        compilerOptions11.setRemoveAbstractMethods(true);
        boolean boolean18 = compilerOptions11.checkTypes;
        compilerOptions11.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy21 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy22 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions11.setRenamingPolicy(variableRenamingPolicy21, propertyRenamingPolicy22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format25 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions24.sourceMapFormat = format25;
        compilerOptions24.unaliasableGlobals = "";
        compilerOptions24.collapseProperties = true;
        compilerOptions24.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass33 = compilerOptions24.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy34 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions24.propertyRenaming = propertyRenamingPolicy34;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy21, propertyRenamingPolicy34);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(cssRenamingMap10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy21 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy21.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy22.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(format25);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy34 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy34.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        boolean boolean11 = compilerOptions0.deadAssignmentElimination;
        boolean boolean12 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(40, node17, node20, node23, node26);
        boolean boolean28 = node17.isLocalResultCall();
        int int29 = node17.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection30 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node17);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder31 = node17.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node32 = node17.detachFromParent();
        boolean boolean33 = node3.isEquivalentToTyped(node32);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(nodeCollection30);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        boolean boolean12 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        com.google.javascript.rhino.Node node15 = node7.getParent();
        boolean boolean16 = node7.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        com.google.javascript.rhino.Node node31 = node23.getParent();
        boolean boolean32 = node23.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        com.google.javascript.rhino.Node node47 = node39.getParent();
        java.lang.String str51 = node47.toString(true, true, true);
        try {
            com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(150, node7, node23, node47, 10, 140);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "STRING" + "'", str51.equals("STRING"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions0.checkUndefinedProperties = checkLevel22;
        compilerOptions0.instrumentForCoverage = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "", (int) (byte) 1, (int) '#');
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(40, node35, node38, node41, node44);
        com.google.javascript.rhino.Node node46 = node35.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable47 = node46.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.lineBreak;
        boolean boolean57 = compilerOptions48.markNoSideEffectCalls;
        boolean boolean58 = compilerOptions48.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format60 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions59.sourceMapFormat = format60;
        compilerOptions59.unaliasableGlobals = "";
        boolean boolean64 = compilerOptions59.disambiguateProperties;
        java.util.Set<java.lang.String> strSet65 = compilerOptions59.stripTypePrefixes;
        compilerOptions48.stripNameSuffixes = strSet65;
        node46.setDirectives(strSet65);
        boolean boolean68 = closureCodingConvention0.isVarArgsParameter(node46);
        java.lang.String str69 = node46.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeIterable47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(format60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(strSet65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "OR hi! [directives: []]" + "'", str69.equals("OR hi! [directives: []]"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node12.getLastChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(cssRenamingMap8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        java.lang.String str23 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType25 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType26 = null;
        closureCodingConvention0.applySubclassRelationship(functionType24, functionType25, subclassType26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.exportProperty" + "'", str23.equals("goog.exportProperty"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("OR hi!\n", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkGlobalNamesLevel;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Unknown class name", "Not declared as a type name", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        node10.setType((int) '#');
        boolean boolean18 = node10.getBooleanProp((int) (short) -1);
        com.google.javascript.rhino.Node node19 = null;
        try {
            com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(25, node10, node19, 24, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        node9.setType((int) '#');
        boolean boolean17 = node9.getBooleanProp((int) (short) -1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        java.lang.String str32 = node30.getString();
        com.google.javascript.rhino.Node node33 = node30.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo34 = node30.getJSDocInfo();
        node30.setString("false");
        try {
            node9.addChildToBack(node30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNull(jSDocInfo34);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        boolean boolean15 = node3.isLocalResultCall();
        node3.addSuppression("Unknown class name");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler15 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler15, callback16);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        java.lang.String str32 = node30.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.aliasKeywords = true;
        boolean boolean36 = compilerOptions33.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap37 = null;
        compilerOptions33.cssRenamingMap = cssRenamingMap37;
        compilerOptions33.setRemoveAbstractMethods(false);
        boolean boolean41 = compilerOptions33.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions33.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray46 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError47 = nodeTraversal17.makeError(node30, checkLevel42, diagnosticType45, strArray46);
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("false", 0, 38, diagnosticType14, strArray46);
        try {
            nodeTraversal2.report(node7, diagnosticType10, strArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(jSError48);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.syntheticBlockEndMarker = "Not declared as a type name";
        boolean boolean17 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler2 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler2, callback3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(40, node8, node11, node14, node17);
        java.lang.String str19 = node17.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.aliasKeywords = true;
        boolean boolean23 = compilerOptions20.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap24 = null;
        compilerOptions20.cssRenamingMap = cssRenamingMap24;
        compilerOptions20.setRemoveAbstractMethods(false);
        boolean boolean28 = compilerOptions20.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions20.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray33 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError34 = nodeTraversal4.makeError(node17, checkLevel29, diagnosticType32, strArray33);
        java.lang.String str35 = jSError34.sourceName;
        java.lang.String str36 = jSError34.description;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel37 = compiler1.getErrorLevel(jSError34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 40");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = node10.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        node25.setType((int) '#');
        com.google.javascript.rhino.Node node32 = node10.clonePropsFrom(node25);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(40, node50, node53, node56, node59);
        node56.setType((int) '#');
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel63 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node(40, node67, node70, node73, node76);
        boolean boolean78 = detailLevel63.apply(node73);
        boolean boolean79 = node73.hasChildren();
        try {
            com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(26, node25, node36, node56, node73, 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(detailLevel63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("Named type with empty name component", "com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.inputDelimiter = "error reporter";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap1 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap1;
        compilerOptions0.inferTypesInGlobalScope = false;
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean7 = compilerOptions0.optimizeReturns;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node3.getJsDocBuilderForNode();
        java.lang.String str18 = node3.toStringTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "OR hi!\n" + "'", str18.equals("OR hi!\n"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.removeUnusedVars = true;
        boolean boolean9 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        boolean boolean26 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup25);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup27;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup27;
        boolean boolean30 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup27);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup27;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "com.google.javascript.rhino.EcmaError: : ");
        int int3 = ecmaError2.getColumnNumber();
        java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) int3);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 130, 7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeCollection4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("DiagnosticGroup<missingProperties>(OFF)", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.checkMissingGetCssNameBlacklist = "Not declared as a type name";
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean6 = tweakProcessing5.shouldStrip();
        compilerOptions0.setTweakProcessing(tweakProcessing5);
        boolean boolean8 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node75 = node52.getParent();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getName();
        java.lang.String str4 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup18;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup18;
        boolean boolean21 = composeWarningsGuard16.disables(diagnosticGroup18);
        com.google.javascript.jscomp.JSError jSError22 = null;
        try {
            boolean boolean23 = diagnosticGroup18.matches(jSError22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.computeFunctionSideEffects = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.rhino.Node node22 = node19.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node19.getJSDocInfo();
        node19.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention4.getDelegateRelationship(node19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node19, diagnosticType29, strArray30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = jSError31.getType();
        java.lang.String str33 = diagnosticType32.key;
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getDelegateSuperclassName();
        java.lang.String str2 = closureCodingConvention0.getGlobalObject();
        boolean boolean4 = closureCodingConvention0.isConstant(": ");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(40, node8, node11, node14, node17);
        boolean boolean19 = node8.isLocalResultCall();
        int int20 = node8.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection21 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node8);
        node8.setCharno(17);
        com.google.javascript.rhino.Node node24 = null;
        try {
            java.lang.String str25 = closureCodingConvention0.extractClassNameIfRequire(node8, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(nodeCollection21);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "OR hi!\n", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("com.google.javascript.rhino.EcmaError: : ");
        int int2 = ecmaError1.getLineNumber();
        java.lang.String str3 = ecmaError1.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        boolean boolean15 = node14.isQuotedString();
        java.lang.String str16 = node14.getString();
        try {
            com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.JSModule jSModule13 = null;
        try {
            java.lang.String str14 = compiler1.toSource(jSModule13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        try {
            com.google.javascript.jscomp.Region region11 = compiler1.getSourceRegion("<No stack trace available>", 37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format16 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions15.sourceMapFormat = format16;
        compilerOptions0.sourceMapFormat = format16;
        compilerOptions0.checkSymbols = false;
        compilerOptions0.checkDuplicateMessages = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(format16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean7 = node6.hasSideEffects();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        boolean boolean11 = closureCodingConvention0.isExported("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.checkTypes;
        boolean boolean11 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        com.google.javascript.rhino.Node node18 = node10.getParent();
        boolean boolean19 = node10.isNoSideEffectsCall();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler20 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler20, callback21);
        com.google.javascript.jscomp.Compiler compiler23 = nodeTraversal22.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean26 = closureCodingConvention24.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        java.lang.String str41 = node39.getString();
        com.google.javascript.rhino.Node node42 = node39.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = node39.getJSDocInfo();
        node39.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = closureCodingConvention24.getDelegateRelationship(node39);
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray50 = null;
        com.google.javascript.jscomp.JSError jSError51 = nodeTraversal22.makeError(node39, diagnosticType49, strArray50);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", 130, 7);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(40, node59, node62, node65, node68);
        boolean boolean70 = node59.isLocalResultCall();
        int int71 = node59.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection72 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node59);
        node59.setCharno(17);
        node59.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node77 = node55.clonePropsFrom(node59);
        com.google.javascript.rhino.Node[] nodeArray78 = new com.google.javascript.rhino.Node[] { node3, node10, node39, node77 };
        try {
            com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(16, nodeArray78, 0, 160);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(compiler23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNull(node42);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNull(delegateRelationship46);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(nodeCollection72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(nodeArray78);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean7 = node6.hasSideEffects();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.lang.String str10 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(40, node14, node17, node20, node23);
        java.lang.Object obj26 = node20.getProp((-1));
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler41 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback42 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal43 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler41, callback42);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(40, node47, node50, node53, node56);
        java.lang.String str58 = node56.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions59.aliasKeywords = true;
        boolean boolean62 = compilerOptions59.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap63 = null;
        compilerOptions59.cssRenamingMap = cssRenamingMap63;
        compilerOptions59.setRemoveAbstractMethods(false);
        boolean boolean67 = compilerOptions59.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions59.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray72 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError73 = nodeTraversal43.makeError(node56, checkLevel68, diagnosticType71, strArray72);
        com.google.javascript.rhino.jstype.JSType jSType74 = node56.getJSType();
        java.lang.String str75 = node33.checkTreeEquals(node56);
        com.google.javascript.rhino.Node node76 = node20.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node89 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node(40, node80, node83, node86, node89);
        boolean boolean91 = node80.isLocalResultCall();
        int int92 = node80.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection93 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node80);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder94 = node80.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node95 = node76.copyInformationFrom(node80);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship96 = closureCodingConvention0.getClassesDefinedByCall(node80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNotNull(nodeCollection93);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder94);
        org.junit.Assert.assertNotNull(node95);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        compilerOptions0.tightenTypes = false;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        boolean boolean19 = compilerOptions0.disambiguateProperties;
        boolean boolean20 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "instanceof");
        ecmaError2.initLineNumber(24);
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "", (int) (byte) 1, (int) '#');
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(40, node35, node38, node41, node44);
        com.google.javascript.rhino.Node node46 = node35.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable47 = node46.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.lineBreak;
        boolean boolean57 = compilerOptions48.markNoSideEffectCalls;
        boolean boolean58 = compilerOptions48.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format60 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions59.sourceMapFormat = format60;
        compilerOptions59.unaliasableGlobals = "";
        boolean boolean64 = compilerOptions59.disambiguateProperties;
        java.util.Set<java.lang.String> strSet65 = compilerOptions59.stripTypePrefixes;
        compilerOptions48.stripNameSuffixes = strSet65;
        node46.setDirectives(strSet65);
        boolean boolean68 = closureCodingConvention0.isVarArgsParameter(node46);
        node46.setWasEmptyNode(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeIterable47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(format60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(strSet65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format16 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions15.sourceMapFormat = format16;
        compilerOptions15.unaliasableGlobals = "";
        boolean boolean20 = compilerOptions15.disambiguateProperties;
        java.util.Set<java.lang.String> strSet21 = compilerOptions15.stripTypePrefixes;
        boolean boolean22 = compilerOptions15.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler23 = compilerOptions15.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler23);
        java.util.Set<java.lang.String> strSet25 = null;
        compilerOptions0.stripTypePrefixes = strSet25;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler23);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkRequires;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        context0.addActivationName("false");
//        java.lang.Object obj6 = null;
//        context0.removeThreadLocal(obj6);
//        int int8 = context0.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile8 = compilerInput4.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(sourceFile8);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        byte[] byteArray13 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.instrumentForCoverageOnly = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(byteArray13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 130, 7);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        com.google.javascript.rhino.Node node18 = node7.getLastSibling();
        boolean boolean19 = node18.isQuotedString();
        java.lang.String str20 = node18.getString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray27 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup22, diagnosticGroup23, diagnosticGroup24, diagnosticGroup25, diagnosticGroup26 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray27);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup28;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup28;
        node18.putProp(22, (java.lang.Object) diagnosticGroup28);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(40, node35, node38, node41, node44);
        java.lang.Object obj47 = node41.getProp((-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(40, node51, node54, node57, node60);
        com.google.javascript.rhino.Node node62 = node51.getLastSibling();
        boolean boolean63 = node62.isQuotedString();
        java.lang.String str64 = node41.checkTreeEquals(node62);
        try {
            node3.replaceChildAfter(node18, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticGroup26);
        org.junit.Assert.assertNotNull(diagnosticGroupArray27);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str64);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.reportUnknownTypes;
        boolean boolean13 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup2;
        boolean boolean4 = composeWarningsGuard1.enables(diagnosticGroup2);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        try {
            com.google.javascript.rhino.Node node3 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("com.google.javascript.rhino.EcmaError: : ", "hi!", "DiagnosticGroup<accessControls>");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        compilerOptions0.inferTypesInGlobalScope = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.debugFunctionSideEffectsPath = "";
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean3 = closureCodingConvention0.isExported("DiagnosticGroup<accessControls>", false);
        boolean boolean5 = closureCodingConvention0.isConstantKey("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        boolean boolean19 = compilerOptions0.disambiguateProperties;
        compilerOptions0.inlineConstantVars = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.aliasKeywords = true;
        compilerOptions12.markAsCompiled = false;
        compilerOptions12.setRemoveAbstractMethods(true);
        compilerOptions12.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions12.checkUndefinedProperties;
        compilerOptions0.checkRequires = checkLevel21;
        java.lang.String str23 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = null;
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset4);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        jSSourceFile5.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a type name");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile10, jSSourceFile12 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format15 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions14.sourceMapFormat = format15;
        compilerOptions14.unaliasableGlobals = "";
        boolean boolean19 = compilerOptions14.disambiguateProperties;
        java.util.Set<java.lang.String> strSet20 = compilerOptions14.stripTypePrefixes;
        boolean boolean21 = compilerOptions14.devirtualizePrototypeMethods;
        try {
            compiler1.init(jSSourceFileArray2, jSSourceFileArray13, compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strSet20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        long long2 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        boolean boolean3 = context0.isGeneratingSource();
        int int4 = context0.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.flowSensitiveInlineVariables;
        compilerOptions12.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions12.checkMissingGetCssNameLevel;
        compilerOptions0.checkGlobalNamesLevel = checkLevel16;
        compilerOptions0.checkControlStructures = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11, false);
        com.google.javascript.jscomp.JsAst jsAst14 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset16);
        java.lang.String str18 = jSSourceFile17.getName();
        jsAst14.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.io.PrintStream printStream22 = null;
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler(printStream22);
        compiler23.disableThreads();
        java.nio.charset.Charset charset26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset26);
        java.lang.String str28 = jSSourceFile27.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst29 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile27);
        com.google.javascript.rhino.Node node30 = compiler23.parse(jSSourceFile27);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        java.lang.String str35 = jSSourceFile34.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray36 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile17, jSSourceFile21, jSSourceFile27, jSSourceFile34 };
        com.google.javascript.jscomp.JSModule jSModule37 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray38 = new com.google.javascript.jscomp.JSModule[] { jSModule37 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions39.aliasKeywords = true;
        boolean boolean42 = compilerOptions39.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap43 = null;
        compilerOptions39.cssRenamingMap = cssRenamingMap43;
        compilerOptions39.setRemoveAbstractMethods(false);
        boolean boolean47 = compilerOptions39.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention48 = null;
        compilerOptions39.setCodingConvention(codingConvention48);
        boolean boolean50 = compilerOptions39.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format52 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions51.sourceMapFormat = format52;
        compilerOptions51.unaliasableGlobals = "";
        boolean boolean56 = compilerOptions51.disambiguateProperties;
        java.util.Set<java.lang.String> strSet57 = compilerOptions51.stripTypePrefixes;
        compilerOptions51.devirtualizePrototypeMethods = false;
        compilerOptions51.deadAssignmentElimination = true;
        compilerOptions51.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions64.aliasKeywords = true;
        boolean boolean67 = compilerOptions64.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap68 = null;
        compilerOptions64.cssRenamingMap = cssRenamingMap68;
        compilerOptions64.setRemoveAbstractMethods(false);
        boolean boolean72 = compilerOptions64.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel73 = compilerOptions64.aggressiveVarCheck;
        compilerOptions51.checkUndefinedProperties = checkLevel73;
        compilerOptions39.brokenClosureRequiresLevel = checkLevel73;
        try {
            compiler1.init(jSSourceFileArray36, jSModuleArray38, compilerOptions39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray36);
        org.junit.Assert.assertNotNull(jSModuleArray38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(format52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strSet57);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + checkLevel73 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel73.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        compilerOptions0.checkSymbols = false;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JsAst jsAst5 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        jsAst5.clearAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        try {
            com.google.javascript.rhino.Node node8 = jsAst5.getAstRoot(abstractCompiler7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy14 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy14 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy14.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format6 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions5.sourceMapFormat = format6;
//        compilerOptions5.groupVariableDeclarations = true;
//        context0.removeThreadLocal((java.lang.Object) true);
//        java.lang.Object obj11 = context0.getDebuggerContextData();
//        context0.setInstructionObserverThreshold(2);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions14.aliasKeywords = true;
//        boolean boolean17 = compilerOptions14.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
//        compilerOptions14.cssRenamingMap = cssRenamingMap18;
//        compilerOptions14.setRemoveAbstractMethods(false);
//        boolean boolean22 = compilerOptions14.lineBreak;
//        java.lang.Class<?> wildcardClass23 = compilerOptions14.getClass();
//        boolean boolean24 = compilerOptions14.ambiguateProperties;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions25.aliasKeywords = true;
//        boolean boolean28 = compilerOptions25.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = null;
//        compilerOptions25.cssRenamingMap = cssRenamingMap29;
//        compilerOptions25.setRemoveAbstractMethods(false);
//        boolean boolean33 = compilerOptions25.rewriteFunctionExpressions;
//        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions25.aggressiveVarCheck;
//        compilerOptions14.checkMethods = checkLevel34;
//        try {
//            context0.unseal((java.lang.Object) checkLevel34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(format6);
//        org.junit.Assert.assertNull(obj11);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        java.lang.String str15 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.ErrorManager errorManager10 = null;
        try {
            compiler1.setErrorManager(errorManager10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        boolean boolean4 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean12 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMissingReturn;
        boolean boolean14 = compilerOptions0.lineBreak;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int5 = diagnosticType3.compareTo(diagnosticType4);
        boolean boolean6 = diagnosticGroup0.matches(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-23) + "'", int5 == (-23));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler14, callback15);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        java.lang.String str31 = node29.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.aliasKeywords = true;
        boolean boolean35 = compilerOptions32.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap36 = null;
        compilerOptions32.cssRenamingMap = cssRenamingMap36;
        compilerOptions32.setRemoveAbstractMethods(false);
        boolean boolean40 = compilerOptions32.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions32.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray45 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError46 = nodeTraversal16.makeError(node29, checkLevel41, diagnosticType44, strArray45);
        com.google.javascript.rhino.jstype.JSType jSType47 = node29.getJSType();
        java.lang.String str48 = node6.checkTreeEquals(node29);
        com.google.javascript.rhino.jstype.JSType jSType49 = node6.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(40, node53, node56, node59, node62);
        boolean boolean64 = node53.isLocalResultCall();
        node53.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node67 = node6.clonePropsFrom(node53);
        node53.setSourcePositionForTree((int) (byte) 100);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        compilerOptions4.markAsCompiled = false;
        compilerOptions4.setRemoveAbstractMethods(true);
        boolean boolean11 = compilerOptions4.checkTypedPropertyCalls;
        compilerOptions4.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format15 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions14.sourceMapFormat = format15;
        compilerOptions14.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing19 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean20 = tweakProcessing19.shouldStrip();
        compilerOptions14.setTweakProcessing(tweakProcessing19);
        compilerOptions4.setTweakProcessing(tweakProcessing19);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler24 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler24, callback25);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        java.lang.String str41 = node39.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.aliasKeywords = true;
        boolean boolean45 = compilerOptions42.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap46 = null;
        compilerOptions42.cssRenamingMap = cssRenamingMap46;
        compilerOptions42.setRemoveAbstractMethods(false);
        boolean boolean50 = compilerOptions42.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions42.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray55 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal26.makeError(node39, checkLevel51, diagnosticType54, strArray55);
        loggerErrorManager2.report(checkLevel23, jSError56);
        java.lang.String str58 = jSError56.description;
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertTrue("'" + tweakProcessing19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing19.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.checkTypes = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.children();
        int int5 = node3.getSideEffectFlags();
        try {
            node3.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.Object obj15 = node9.getProp((-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler30 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback31 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal32 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler30, callback31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions48.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray61 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal32.makeError(node45, checkLevel57, diagnosticType60, strArray61);
        com.google.javascript.rhino.jstype.JSType jSType63 = node45.getJSType();
        java.lang.String str64 = node22.checkTreeEquals(node45);
        com.google.javascript.rhino.Node node65 = node9.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(40, node69, node72, node75, node78);
        boolean boolean80 = node69.isLocalResultCall();
        int int81 = node69.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection82 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node69);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder83 = node69.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node84 = node65.copyInformationFrom(node69);
        com.google.javascript.rhino.Node node85 = node69.detachFromParent();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(nodeCollection82);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder83);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node85);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
        int int4 = context0.getLanguageVersion();
        java.util.Locale locale5 = context0.getLocale();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(locale5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("com.google.javascript.rhino.EcmaError: : ", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Object obj0 = null;
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean7 = compilerOptions0.optimizeReturns;
        compilerOptions0.syntheticBlockEndMarker = ": ";
        boolean boolean10 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.aliasableStrings;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.printInputDelimiter = true;
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format16 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions15.sourceMapFormat = format16;
        compilerOptions15.unaliasableGlobals = "";
        boolean boolean20 = compilerOptions15.disambiguateProperties;
        java.util.Set<java.lang.String> strSet21 = compilerOptions15.stripTypePrefixes;
        boolean boolean22 = compilerOptions15.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler23 = compilerOptions15.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler23);
        boolean boolean25 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(detailLevel14);
        org.junit.Assert.assertNotNull(format16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions12.aliasKeywords = true;
//        boolean boolean15 = compilerOptions12.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap16 = null;
//        compilerOptions12.cssRenamingMap = cssRenamingMap16;
//        compilerOptions12.setRemoveAbstractMethods(false);
//        compilerOptions12.aliasExternals = false;
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard23 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray22);
//        compilerOptions12.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard23);
//        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard23);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray22);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JsAst jsAst5 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset7);
        java.lang.String str9 = jSSourceFile8.getName();
        jsAst5.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.Region region12 = jSSourceFile8.getRegion((-23));
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNull(region12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasableGlobals = "";
        compilerOptions0.setDefineToDoubleLiteral("eof", 0.0d);
        boolean boolean11 = compilerOptions0.checkTypes;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        boolean boolean15 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.aliasKeywords = true;
        boolean boolean19 = compilerOptions16.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap20 = null;
        compilerOptions16.cssRenamingMap = cssRenamingMap20;
        compilerOptions16.setRemoveAbstractMethods(false);
        boolean boolean24 = compilerOptions16.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention25 = null;
        compilerOptions16.setCodingConvention(codingConvention25);
        boolean boolean27 = compilerOptions16.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions16.reportUnknownTypes;
        compilerOptions0.aggressiveVarCheck = checkLevel28;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        boolean boolean14 = compilerOptions11.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap15 = null;
        compilerOptions11.cssRenamingMap = cssRenamingMap15;
        compilerOptions11.setRemoveAbstractMethods(false);
        boolean boolean19 = compilerOptions11.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.aggressiveVarCheck;
        compilerOptions0.checkMethods = checkLevel20;
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        com.google.javascript.rhino.Node node36 = node25.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable37 = node36.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.aliasKeywords = true;
        boolean boolean41 = compilerOptions38.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap42 = null;
        compilerOptions38.cssRenamingMap = cssRenamingMap42;
        compilerOptions38.setRemoveAbstractMethods(false);
        boolean boolean46 = compilerOptions38.lineBreak;
        boolean boolean47 = compilerOptions38.markNoSideEffectCalls;
        boolean boolean48 = compilerOptions38.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format50 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions49.sourceMapFormat = format50;
        compilerOptions49.unaliasableGlobals = "";
        boolean boolean54 = compilerOptions49.disambiguateProperties;
        java.util.Set<java.lang.String> strSet55 = compilerOptions49.stripTypePrefixes;
        compilerOptions38.stripNameSuffixes = strSet55;
        node36.setDirectives(strSet55);
        compilerOptions0.stripNamePrefixes = strSet55;
        compilerOptions0.unaliasableGlobals = "Named type with empty name component";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeIterable37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(format50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(strSet55);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        boolean boolean12 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.coalesceVariableNames = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = null;
        compilerOptions0.messageBundle = messageBundle15;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        ecmaError2.initColumnNumber(16);
        java.lang.String str6 = ecmaError2.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getDelegateSuperclassName();
        java.lang.String str2 = closureCodingConvention0.getGlobalObject();
        boolean boolean4 = closureCodingConvention0.isConstant(": ");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal29 = null;
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable34 = node33.children();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast35 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal29, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(nodeIterable34);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("TypeError");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: TypeError");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        boolean boolean4 = compilerOptions1.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions1.cssRenamingMap = cssRenamingMap5;
        compilerOptions1.setRemoveAbstractMethods(false);
        boolean boolean9 = compilerOptions1.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = null;
        compilerOptions1.setCodingConvention(codingConvention10);
        boolean boolean12 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        compilerOptions13.markAsCompiled = false;
        compilerOptions13.setRemoveAbstractMethods(true);
        compilerOptions13.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.checkUndefinedProperties;
        compilerOptions1.checkRequires = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        com.google.javascript.jscomp.Scope scope15 = compiler12.getTopScope();
//        java.nio.charset.Charset charset17 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset17);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format21 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions20.sourceMapFormat = format21;
//        compilerOptions20.unaliasableGlobals = "";
//        boolean boolean25 = compilerOptions20.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions20.stripTypePrefixes;
//        boolean boolean27 = compilerOptions20.devirtualizePrototypeMethods;
//        boolean boolean28 = compilerOptions20.gatherCssNames;
//        boolean boolean29 = compilerOptions20.prettyPrint;
//        compilerOptions20.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result32 = compiler12.compile(jSSourceFile18, jSSourceFileArray19, compilerOptions20);
//        com.google.javascript.rhino.Node node33 = compiler12.getRoot();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNull(scope15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertNotNull(jSSourceFileArray19);
//        org.junit.Assert.assertNotNull(format21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(result32);
//        org.junit.Assert.assertNotNull(node33);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
        java.io.FilenameFilter filenameFilter2 = null;
        java.lang.String str3 = evaluatorException1.getScriptStackTrace(filenameFilter2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = node4.isLocalResultCall();
        int int16 = node4.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node4.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format20 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions19.sourceMapFormat = format20;
        compilerOptions19.unaliasableGlobals = "";
        boolean boolean24 = compilerOptions19.deadAssignmentElimination;
        java.lang.RuntimeException runtimeException25 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 14, (java.lang.Object) fileLevelJsDocBuilder18, (java.lang.Object) compilerOptions19);
        java.lang.String str26 = compilerOptions19.instrumentationTemplate;
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertNotNull(format20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(runtimeException25);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        boolean boolean9 = compilerOptions0.prettyPrint;
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        byte[] byteArray11 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(byteArray11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.rhino.Node node22 = node19.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node19.getJSDocInfo();
        node19.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention4.getDelegateRelationship(node19);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        boolean boolean41 = node19.hasChild(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(40, node45, node48, node51, node54);
        com.google.javascript.rhino.Node node56 = node45.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable57 = node56.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions58.aliasKeywords = true;
        boolean boolean61 = compilerOptions58.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap62 = null;
        compilerOptions58.cssRenamingMap = cssRenamingMap62;
        compilerOptions58.setRemoveAbstractMethods(false);
        boolean boolean66 = compilerOptions58.lineBreak;
        boolean boolean67 = compilerOptions58.markNoSideEffectCalls;
        boolean boolean68 = compilerOptions58.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions69 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format70 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions69.sourceMapFormat = format70;
        compilerOptions69.unaliasableGlobals = "";
        boolean boolean74 = compilerOptions69.disambiguateProperties;
        java.util.Set<java.lang.String> strSet75 = compilerOptions69.stripTypePrefixes;
        compilerOptions58.stripNameSuffixes = strSet75;
        node56.setDirectives(strSet75);
        com.google.javascript.rhino.Node node78 = node39.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node91 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node(40, node82, node85, node88, node91);
        node88.setType((int) '#');
        boolean boolean96 = node88.getBooleanProp((int) (short) -1);
        boolean boolean97 = node78.isEquivalentTo(node88);
        com.google.javascript.rhino.Node node98 = node78.getParent();
        java.lang.String str99 = node3.checkTreeEquals(node78);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeIterable57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(format70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(strSet75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertNotNull(node98);
        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "Node tree inequality:\nTree1:\nSTRING eof 24\n\n\nTree2:\nOR hi!\n\n\nSubtree1: STRING eof 24\n\n\nSubtree2: OR hi!\n" + "'", str99.equals("Node tree inequality:\nTree1:\nSTRING eof 24\n\n\nTree2:\nOR hi!\n\n\nSubtree1: STRING eof 24\n\n\nSubtree2: OR hi!\n"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        boolean boolean17 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node18 = node3.getParent();
        com.google.javascript.rhino.Node node19 = node18.removeFirstChild();
        try {
            node18.setString("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: String node not created with Node.newString");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(": ");
        java.lang.String str7 = closureCodingConvention0.identifyTypeDefAssign(node6);
        com.google.javascript.rhino.Node node9 = node6.getAncestor(35);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", "instanceof");
        java.lang.String str3 = jSSourceFile2.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : " + "'", str3.equals("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : "));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(32);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 37);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        node1.setJSType(jSType2);
        org.junit.Assert.assertNotNull(node1);
    }
}

