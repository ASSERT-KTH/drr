import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.reportPath = "<No stack trace available>";
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("com.google.javascript.rhino.EcmaError: : ", "OR hi! [directives: []]", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = detailLevel0.apply(node10);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node10.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean21 = node20.hasSideEffects();
        node10.addChildToFront(node20);
        try {
            java.lang.String str23 = node20.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: GT 1 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler4 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler4, callback5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.aliasKeywords = true;
        boolean boolean25 = compilerOptions22.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap26 = null;
        compilerOptions22.cssRenamingMap = cssRenamingMap26;
        compilerOptions22.setRemoveAbstractMethods(false);
        boolean boolean30 = compilerOptions22.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions22.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray35 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError36 = nodeTraversal6.makeError(node19, checkLevel31, diagnosticType34, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("false", 0, 38, diagnosticType3, strArray35);
        com.google.javascript.jscomp.CheckLevel checkLevel38 = diagnosticType3.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
        int int3 = context0.getInstructionObserverThreshold();
        java.util.Locale locale4 = context0.getLocale();
        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
        evaluatorException6.initLineSource("Unknown class name");
        int int9 = evaluatorException6.lineNumber();
        context0.removeThreadLocal((java.lang.Object) int9);
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        compiler12.disableThreads();
        context0.removeThreadLocal((java.lang.Object) compiler12);
        com.google.javascript.jscomp.Scope scope15 = compiler12.getTopScope();
        try {
            compiler12.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(errorReporter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(locale4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(scope15);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions0.errorFormat;
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(errorFormat15);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
        int int3 = context0.getInstructionObserverThreshold();
        java.util.Locale locale4 = context0.getLocale();
        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
        evaluatorException6.initLineSource("Unknown class name");
        int int9 = evaluatorException6.lineNumber();
        context0.removeThreadLocal((java.lang.Object) int9);
        boolean boolean11 = context0.hasCompileFunctionsWithDynamicScope();
        boolean boolean12 = context0.hasCompileFunctionsWithDynamicScope();
        int int13 = context0.getLanguageVersion();
        context0.setGeneratingSource(true);
        int int16 = context0.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(errorReporter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(locale4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.lang.String str2 = jSSourceFile1.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "error reporter" + "'", str2.equals("error reporter"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        java.lang.String str33 = jSError32.sourceName;
        java.lang.String str34 = jSError32.description;
        java.lang.String str35 = jSError32.description;
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(46);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset10);
//        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11, false);
//        jSSourceFile11.clearCachedSource();
//        java.nio.charset.Charset charset16 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset16);
//        java.lang.String str18 = jSSourceFile17.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst19 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions20.aliasKeywords = true;
//        compilerOptions20.markAsCompiled = false;
//        compilerOptions20.setRemoveAbstractMethods(true);
//        boolean boolean27 = compilerOptions20.checkTypes;
//        compilerOptions20.aliasKeywords = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy31 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
//        compilerOptions20.setRenamingPolicy(variableRenamingPolicy30, propertyRenamingPolicy31);
//        compilerOptions20.lineBreak = false;
//        com.google.javascript.jscomp.Result result35 = compiler1.compile(jSSourceFile11, jSSourceFile17, compilerOptions20);
//        try {
//            compiler1.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNotNull(jSSourceFile17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy30.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy31 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy31.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
//        org.junit.Assert.assertNotNull(result35);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler1.tracker;
        try {
            java.lang.String str13 = compiler1.getSourceLine("<No stack trace available>", 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNull(performanceTracker10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = compilerOptions0.customPasses;
        compilerOptions0.specializeInitialModule = true;
        com.google.javascript.jscomp.MessageBundle messageBundle9 = null;
        compilerOptions0.messageBundle = messageBundle9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format12 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions11.sourceMapFormat = format12;
        compilerOptions11.unaliasableGlobals = "";
        boolean boolean16 = compilerOptions11.disambiguateProperties;
        byte[] byteArray19 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions11.inputPropertyMapSerialized = byteArray19;
        compilerOptions0.inputVariableMapSerialized = byteArray19;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap6);
        org.junit.Assert.assertNotNull(format12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray19);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkSymbols;
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        compilerOptions0.setGenerateExports(true);
        java.lang.String str16 = compilerOptions0.debugFunctionSideEffectsPath;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.aliasKeywords = true;
        compilerOptions17.markAsCompiled = false;
        java.lang.Object obj22 = compilerOptions17.clone();
        compilerOptions17.deadAssignmentElimination = true;
        compilerOptions17.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention28 = compilerOptions17.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig29 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions17);
        byte[] byteArray30 = compilerOptions17.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel31 = compilerOptions17.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format33 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions32.sourceMapFormat = format33;
        compilerOptions32.unaliasableGlobals = "";
        boolean boolean37 = compilerOptions32.disambiguateProperties;
        java.util.Set<java.lang.String> strSet38 = compilerOptions32.stripTypePrefixes;
        boolean boolean39 = compilerOptions32.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler40 = compilerOptions32.getAliasTransformationHandler();
        compilerOptions17.setAliasTransformationHandler(aliasTransformationHandler40);
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler40);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(codingConvention28);
        org.junit.Assert.assertNull(byteArray30);
        org.junit.Assert.assertNotNull(detailLevel31);
        org.junit.Assert.assertNotNull(format33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler40);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean12 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMissingReturn;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap14 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setDefineToDoubleLiteral("", (double) 9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap14);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        context0.addActivationName("hi!");
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        boolean boolean16 = detailLevel1.apply(node11);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable17 = node11.getAncestors();
        try {
            java.lang.String str18 = com.google.javascript.rhino.ScriptRuntime.getMessage1(".  at (unknown source) line (unknown line) : (unknown column)", (java.lang.Object) node11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property .  at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(ancestorIterable17);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.checkSymbols = true;
        java.lang.Class<?> wildcardClass14 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.aliasKeywords = true;
        compilerOptions15.markAsCompiled = false;
        compilerOptions15.setRemoveAbstractMethods(true);
        compilerOptions15.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions15.checkUndefinedProperties;
        compilerOptions0.checkShadowVars = checkLevel24;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy26 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions0.variableRenaming = variableRenamingPolicy26;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy26 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy26.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        boolean boolean9 = compilerOptions0.prettyPrint;
        boolean boolean10 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        compilerOptions11.markAsCompiled = false;
        java.lang.Object obj16 = compilerOptions11.clone();
        compilerOptions11.deadAssignmentElimination = true;
        compilerOptions11.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention22 = compilerOptions11.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig23 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions11);
        byte[] byteArray24 = compilerOptions11.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel25 = compilerOptions11.sourceMapDetailLevel;
        compilerOptions0.sourceMapDetailLevel = detailLevel25;
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        boolean boolean41 = node30.isLocalResultCall();
        node30.setSourcePositionForTree(0);
        boolean boolean44 = detailLevel25.apply(node30);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel45 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(40, node49, node52, node55, node58);
        boolean boolean60 = detailLevel45.apply(node55);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder61 = node55.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean66 = node65.hasSideEffects();
        node55.addChildToFront(node65);
        boolean boolean68 = detailLevel25.apply(node55);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(codingConvention22);
        org.junit.Assert.assertNull(byteArray24);
        org.junit.Assert.assertNotNull(detailLevel25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(detailLevel45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(": ");
        java.lang.String str7 = closureCodingConvention0.identifyTypeDefAssign(node6);
        boolean boolean8 = node6.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.enableExternExports(true);
        boolean boolean14 = compilerOptions0.checkDuplicateMessages;
        boolean boolean15 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.setTweakToBooleanLiteral(".  at (unknown source) line (unknown line) : (unknown column)", false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setCharno(17);
        node3.setIsSyntheticBlock(false);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node3.siblings();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertNotNull(nodeIterable21);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.syntheticBlockStartMarker = "Unknown class name";
        compilerOptions0.rewriteFunctionExpressions = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean7 = node6.hasSideEffects();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.lang.String str10 = closureCodingConvention0.getAbstractMethodName();
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        compiler12.disableThreads();
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        java.lang.String str17 = jSSourceFile16.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst18 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        com.google.javascript.rhino.Node node19 = compiler12.parse(jSSourceFile16);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = compiler12.getTypeRegistry();
        com.google.javascript.jscomp.Scope scope21 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray22 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23, objectTypeArray22);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry20, scope21, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(jSTypeRegistry20);
        org.junit.Assert.assertNotNull(objectTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("com.google.javascript.rhino.EcmaError: : ", "", "com.google.javascript.rhino.EcmaError: : ");
        java.io.Reader reader4 = sourceFile3.getCodeReader();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(reader4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        try {
            com.google.javascript.rhino.Context.reportWarning("TypeError", "OR hi! [directives: []]", 46, "goog.global", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy10;
        boolean boolean12 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags();
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 10L, (java.lang.Object) sideEffectFlags1);
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setReturnsTainted();
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        boolean boolean2 = node1.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(40, node78, node81, node84, node87);
        node84.setType((int) '#');
        boolean boolean92 = node84.getBooleanProp((int) (short) -1);
        boolean boolean93 = node74.isEquivalentTo(node84);
        com.google.javascript.rhino.Node node94 = node74.getParent();
        node94.setVarArgs(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(node94);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        boolean boolean9 = compilerOptions0.prettyPrint;
        compilerOptions0.checkSymbols = false;
        boolean boolean12 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkRequires;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "", (int) (byte) 1, (int) '#');
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler32 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback33 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal34 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler32, callback33);
        int int35 = nodeTraversal34.getLineNumber();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(40, node39, node42, node45, node48);
        com.google.javascript.rhino.Node node50 = node39.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable51 = node50.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.aliasKeywords = true;
        boolean boolean55 = compilerOptions52.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap56 = null;
        compilerOptions52.cssRenamingMap = cssRenamingMap56;
        compilerOptions52.setRemoveAbstractMethods(false);
        boolean boolean60 = compilerOptions52.lineBreak;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        boolean boolean62 = compilerOptions52.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format64 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions63.sourceMapFormat = format64;
        compilerOptions63.unaliasableGlobals = "";
        boolean boolean68 = compilerOptions63.disambiguateProperties;
        java.util.Set<java.lang.String> strSet69 = compilerOptions63.stripTypePrefixes;
        compilerOptions52.stripNameSuffixes = strSet69;
        node50.setDirectives(strSet69);
        boolean boolean72 = node50.hasOneChild();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast73 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal34, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeIterable51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(format64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(strSet69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        boolean boolean15 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.devirtualizePrototypeMethods = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        boolean boolean19 = compilerOptions0.inlineFunctions;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean9 = compilerOptions0.removeDeadCode;
        boolean boolean10 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format6 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions5.sourceMapFormat = format6;
//        compilerOptions5.groupVariableDeclarations = true;
//        context0.removeThreadLocal((java.lang.Object) true);
//        java.lang.Object obj11 = context0.getDebuggerContextData();
//        context0.setInstructionObserverThreshold(2);
//        try {
//            com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(format6);
//        org.junit.Assert.assertNull(obj11);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkRequires;
        compilerOptions0.setAcceptConstKeyword(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 37);
        boolean boolean2 = node1.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        java.lang.String str15 = node3.toStringTree();
        node3.setLineno(160);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "OR hi!\n" + "'", str15.equals("OR hi!\n"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        int int4 = ecmaError2.getColumnNumber();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup18;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup18;
        boolean boolean21 = composeWarningsGuard16.disables(diagnosticGroup18);
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup18;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.instrumentForCoverageOnly = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format11 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions10.sourceMapFormat = format11;
        compilerOptions10.unaliasableGlobals = "";
        boolean boolean15 = compilerOptions10.disambiguateProperties;
        java.util.Set<java.lang.String> strSet16 = compilerOptions10.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy17 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = null;
        compilerOptions10.setRenamingPolicy(variableRenamingPolicy17, propertyRenamingPolicy18);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions10.checkRequires;
        compilerOptions0.checkGlobalThisLevel = checkLevel20;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap22;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(format11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy17.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        boolean boolean11 = context0.hasCompileFunctionsWithDynamicScope();
//        java.lang.Object obj12 = context0.getDebuggerContextData();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(obj12);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        compilerInput4.clearAst();
        java.lang.String str8 = compilerInput4.getName();
        try {
            java.lang.String str9 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.ErrorManager errorManager9 = compiler1.getErrorManager();
        try {
            com.google.javascript.jscomp.Region region12 = compiler1.getSourceRegion("", 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(errorManager9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.rhino.Node node15 = compiler1.parse(jSSourceFile12);
        com.google.javascript.jscomp.ErrorManager errorManager16 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(errorManager16);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
        boolean boolean5 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.rhino.Node node22 = node19.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node19.getJSDocInfo();
        node19.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention4.getDelegateRelationship(node19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node19, diagnosticType29, strArray30);
        java.lang.String str32 = nodeTraversal2.getSourceName();
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node3.getJsDocBuilderForNode();
        boolean boolean18 = node3.isOptionalArg();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter9.setColorize(false);
        lightweightMessageFormatter9.setColorize(true);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JsAst jsAst5 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = jsAst5.getSourceFile();
        com.google.javascript.jscomp.SourceFile sourceFile7 = jsAst5.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "goog.abstractMethod", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        com.google.javascript.jscomp.SourceMap sourceMap9 = compiler1.getSourceMap();
//        try {
//            compiler1.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNull(sourceMap9);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 48");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeTryCatchFinally = false;
        java.lang.String str4 = compilerOptions0.inputDelimiter;
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "// Input %num%" + "'", str4.equals("// Input %num%"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "DiagnosticGroup<missingProperties>(OFF)", true);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceAst7);
        java.lang.Class<?> wildcardClass12 = sourceAst7.getClass();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = node4.isLocalResultCall();
        node4.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        boolean boolean32 = node21.isLocalResultCall();
        int int33 = node21.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection34 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node21);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder35 = node21.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node36 = node21.detachFromParent();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(40, node40, node43, node46, node49);
        java.lang.String str51 = node49.getString();
        com.google.javascript.rhino.Node node52 = node49.getLastChild();
        node49.setOptionalArg(false);
        com.google.javascript.rhino.Node node55 = node49.detachFromParent();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder56 = node49.new FileLevelJsDocBuilder();
        try {
            com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (byte) 10, node4, node21, node49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodeCollection34);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNull(node52);
        org.junit.Assert.assertNotNull(node55);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        context0.setCompileFunctionsWithDynamicScope(true);
        java.lang.Object obj4 = context0.getDebuggerContextData();
        java.lang.Object obj5 = context0.getDebuggerContextData();
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter7 = context0.setErrorReporter(errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        java.lang.String str15 = node3.toStringTree();
        node3.setVarArgs(true);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        java.lang.String str32 = node30.getString();
        com.google.javascript.rhino.Node node33 = node30.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo34 = node30.getJSDocInfo();
        node30.setString("false");
        boolean boolean37 = node3.hasChild(node30);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "OR hi!\n" + "'", str15.equals("OR hi!\n"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNull(jSDocInfo34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        boolean boolean18 = compilerOptions0.disambiguateProperties;
        boolean boolean19 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        int int3 = nodeTraversal2.getLineNumber();
        try {
            com.google.javascript.jscomp.JSModule jSModule4 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        try {
            int int3 = compiler1.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap6;
        java.lang.String str8 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.Region region7 = compilerInput4.getRegion(0);
        com.google.javascript.jscomp.Region region9 = compilerInput4.getRegion(11);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNull(region7);
        org.junit.Assert.assertNull(region9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        byte[] byteArray13 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        boolean boolean17 = compilerOptions14.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions14.cssRenamingMap = cssRenamingMap18;
        compilerOptions14.setRemoveAbstractMethods(false);
        boolean boolean22 = compilerOptions14.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention23 = null;
        compilerOptions14.setCodingConvention(codingConvention23);
        boolean boolean25 = compilerOptions14.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions14.reportUnknownTypes;
        compilerOptions0.reportMissingOverride = checkLevel26;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput13 = compiler1.newExternInput("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker14 = compiler1.tracker;
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(performanceTracker14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler8 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler8, callback9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(40, node14, node17, node20, node23);
        java.lang.String str25 = node23.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.aliasKeywords = true;
        boolean boolean29 = compilerOptions26.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap30 = null;
        compilerOptions26.cssRenamingMap = cssRenamingMap30;
        compilerOptions26.setRemoveAbstractMethods(false);
        boolean boolean34 = compilerOptions26.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions26.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray39 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError40 = nodeTraversal10.makeError(node23, checkLevel35, diagnosticType38, strArray39);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("false", 0, 38, diagnosticType7, strArray39);
        try {
            com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", (int) (short) 100, 33, diagnosticType3, strArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
        compilerOptions0.generateExports = false;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean8 = compilerOptions0.coalesceVariableNames;
        java.lang.String str9 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Unknown class name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Unknown class name)" + "'", str1.equals("(Unknown class name)"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions1.sourceMapFormat = format2;
        compilerOptions1.unaliasableGlobals = "";
        boolean boolean6 = compilerOptions1.disambiguateProperties;
        java.util.Set<java.lang.String> strSet7 = compilerOptions1.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy9 = null;
        compilerOptions1.setRenamingPolicy(variableRenamingPolicy8, propertyRenamingPolicy9);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions1.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions1.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel12, "(Unknown class name)");
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType14);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        int int3 = nodeTraversal2.getLineNumber();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(scope4);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.nio.charset.Charset charset5 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset5);
//        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6, false);
//        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
//        context0.removeThreadLocal((java.lang.Object) jsAst9);
//        jsAst9.clearAst();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions2.sourceMapFormat = format3;
        compilerOptions2.unaliasableGlobals = "";
        boolean boolean7 = compilerOptions2.disambiguateProperties;
        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
        boolean boolean9 = compilerOptions2.strictMessageReplacement;
        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
        context0.seal((java.lang.Object) compilerOptions2);
        java.lang.String str12 = compilerOptions2.jsOutputFile;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions2.checkRequires;
        compilerOptions2.convertToDottedProperties = false;
        java.lang.String str16 = compilerOptions2.inputDelimiter;
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "// Input %num%" + "'", str16.equals("// Input %num%"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = node4.isLocalResultCall();
        int int16 = node4.getSideEffectFlags();
        boolean boolean17 = node4.hasOneChild();
        node4.setOptionalArg(false);
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(49, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        boolean boolean24 = closureCodingConvention0.isSuperClassReference("instanceof");
        java.lang.String str25 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(40, node29, node32, node35, node38);
        java.lang.String str40 = node38.getString();
        com.google.javascript.rhino.Node node41 = node38.getLastChild();
        node38.setOptionalArg(false);
        com.google.javascript.rhino.Node node44 = node38.detachFromParent();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node38.new FileLevelJsDocBuilder();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention46 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean48 = closureCodingConvention46.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(40, node52, node55, node58, node61);
        java.lang.String str63 = node61.getString();
        com.google.javascript.rhino.Node node64 = node61.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo65 = node61.getJSDocInfo();
        node61.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship68 = closureCodingConvention46.getDelegateRelationship(node61);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(40, node72, node75, node78, node81);
        boolean boolean83 = node61.hasChild(node81);
        java.lang.String str84 = closureCodingConvention0.extractClassNameIfProvide(node38, node61);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "goog.abstractMethod" + "'", str25.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
        org.junit.Assert.assertNull(node64);
        org.junit.Assert.assertNull(jSDocInfo65);
        org.junit.Assert.assertNull(delegateRelationship68);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(str84);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        compilerOptions0.setGenerateExports(true);
        java.lang.String str16 = compilerOptions0.debugFunctionSideEffectsPath;
        boolean boolean17 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            com.google.javascript.rhino.Context.reportWarning("(Unknown class name)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.lang.String str5 = compiler1.getSourceLine("Not declared as a type name", (int) (short) -1);
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = compiler1.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup2;
        boolean boolean5 = composeWarningsGuard1.enables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = null;
        boolean boolean7 = diagnosticGroup2.matches(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup2;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType5 = null;
        closureCodingConvention1.applySubclassRelationship(functionType3, functionType4, subclassType5);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean9 = closureCodingConvention7.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(40, node13, node16, node19, node22);
        java.lang.String str24 = node22.getString();
        com.google.javascript.rhino.Node node25 = node22.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = node22.getJSDocInfo();
        node22.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship29 = closureCodingConvention7.getDelegateRelationship(node22);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(40, node33, node36, node39, node42);
        boolean boolean44 = node22.hasChild(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(40, node48, node51, node54, node57);
        com.google.javascript.rhino.Node node59 = node48.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable60 = node59.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions61.aliasKeywords = true;
        boolean boolean64 = compilerOptions61.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap65 = null;
        compilerOptions61.cssRenamingMap = cssRenamingMap65;
        compilerOptions61.setRemoveAbstractMethods(false);
        boolean boolean69 = compilerOptions61.lineBreak;
        boolean boolean70 = compilerOptions61.markNoSideEffectCalls;
        boolean boolean71 = compilerOptions61.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format73 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions72.sourceMapFormat = format73;
        compilerOptions72.unaliasableGlobals = "";
        boolean boolean77 = compilerOptions72.disambiguateProperties;
        java.util.Set<java.lang.String> strSet78 = compilerOptions72.stripTypePrefixes;
        compilerOptions61.stripNameSuffixes = strSet78;
        node59.setDirectives(strSet78);
        com.google.javascript.rhino.Node node81 = node42.copyInformationFromForTree(node59);
        boolean boolean82 = closureCodingConvention1.isOptionalParameter(node81);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertNull(delegateRelationship29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeIterable60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(format73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(strSet78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a type name");
        java.lang.String str2 = jSSourceFile1.toString();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Not declared as a type name" + "'", str2.equals("Not declared as a type name"));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        java.lang.String str12 = compilerOptions2.jsOutputFile;
//        boolean boolean13 = compilerOptions2.optimizeArgumentsArray;
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        compilerInput7.setModule(jSModule8);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        compiler7.disableThreads();
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.lang.String str12 = jSSourceFile11.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst13 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.rhino.Node node14 = compiler7.parse(jSSourceFile11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter15 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        boolean boolean16 = compiler7.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray17 = compiler7.getWarnings();
        boolean boolean18 = compiler7.isTypeCheckingEnabled();
        compilerInput5.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSErrorArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler1, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        java.lang.String str18 = node16.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.aliasKeywords = true;
        boolean boolean22 = compilerOptions19.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap23 = null;
        compilerOptions19.cssRenamingMap = cssRenamingMap23;
        compilerOptions19.setRemoveAbstractMethods(false);
        boolean boolean27 = compilerOptions19.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions19.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray32 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal3.makeError(node16, checkLevel28, diagnosticType31, strArray32);
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) 150, (java.lang.Object) strArray32);
        java.lang.String str35 = runtimeException34.toString();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(runtimeException34);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        com.google.javascript.jscomp.Scope scope15 = compiler12.getTopScope();
//        java.nio.charset.Charset charset17 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset17);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format21 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions20.sourceMapFormat = format21;
//        compilerOptions20.unaliasableGlobals = "";
//        boolean boolean25 = compilerOptions20.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions20.stripTypePrefixes;
//        boolean boolean27 = compilerOptions20.devirtualizePrototypeMethods;
//        boolean boolean28 = compilerOptions20.gatherCssNames;
//        boolean boolean29 = compilerOptions20.prettyPrint;
//        compilerOptions20.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result32 = compiler12.compile(jSSourceFile18, jSSourceFileArray19, compilerOptions20);
//        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile18, false);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNull(scope15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertNotNull(jSSourceFileArray19);
//        org.junit.Assert.assertNotNull(format21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(result32);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard2 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node6.getParent();
        com.google.javascript.rhino.Node node15 = null;
        try {
            com.google.javascript.rhino.Node node16 = node14.copyInformationFrom(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format11 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions10.sourceMapFormat = format11;
        compilerOptions10.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing15 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean16 = tweakProcessing15.shouldStrip();
        compilerOptions10.setTweakProcessing(tweakProcessing15);
        compilerOptions0.setTweakProcessing(tweakProcessing15);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(format11);
        org.junit.Assert.assertTrue("'" + tweakProcessing15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing15.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean7 = compilerOptions0.optimizeReturns;
        compilerOptions0.syntheticBlockEndMarker = ": ";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = compilerOptions0.propertyRenaming;
        compilerOptions0.aliasableGlobals = "DiagnosticGroup<missingProperties>(OFF)";
        boolean boolean13 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.aliasKeywords = true;
//        boolean boolean5 = compilerOptions2.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
//        compilerOptions2.cssRenamingMap = cssRenamingMap6;
//        compilerOptions2.setRemoveAbstractMethods(false);
//        boolean boolean10 = compilerOptions2.lineBreak;
//        com.google.javascript.jscomp.CodingConvention codingConvention11 = null;
//        compilerOptions2.setCodingConvention(codingConvention11);
//        boolean boolean13 = compilerOptions2.optimizeCalls;
//        compilerOptions2.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray17 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard18 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray17);
//        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard18);
//        java.lang.Object obj20 = context0.getThreadLocal((java.lang.Object) compilerOptions2);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions21.aliasKeywords = true;
//        compilerOptions21.markAsCompiled = false;
//        compilerOptions21.setRemoveAbstractMethods(true);
//        boolean boolean28 = compilerOptions21.checkTypedPropertyCalls;
//        compilerOptions21.extractPrototypeMemberDeclarations = true;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format32 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions31.sourceMapFormat = format32;
//        compilerOptions31.groupVariableDeclarations = true;
//        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing36 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
//        boolean boolean37 = tweakProcessing36.shouldStrip();
//        compilerOptions31.setTweakProcessing(tweakProcessing36);
//        compilerOptions21.setTweakProcessing(tweakProcessing36);
//        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions21.checkMissingGetCssNameLevel;
//        context0.seal((java.lang.Object) compilerOptions21);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray17);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(format32);
//        org.junit.Assert.assertTrue("'" + tweakProcessing36 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing36.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean7 = node6.hasSideEffects();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        boolean boolean10 = node8.isNoSideEffectsCall();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection11 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node8);
        boolean boolean12 = node8.isLocalResultCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeCollection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Object obj0 = null;
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy10;
        compilerOptions0.setTweakToDoubleLiteral("instanceof", (double) 39);
        boolean boolean15 = compilerOptions0.checkControlStructures;
        compilerOptions0.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format19 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions18.sourceMapFormat = format19;
        compilerOptions18.unaliasableGlobals = "";
        boolean boolean23 = compilerOptions18.disambiguateProperties;
        java.util.Set<java.lang.String> strSet24 = compilerOptions18.stripTypePrefixes;
        compilerOptions18.devirtualizePrototypeMethods = false;
        compilerOptions18.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format30 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions29.sourceMapFormat = format30;
        compilerOptions29.unaliasableGlobals = "";
        boolean boolean34 = compilerOptions29.disambiguateProperties;
        java.util.Set<java.lang.String> strSet35 = compilerOptions29.stripTypePrefixes;
        compilerOptions29.devirtualizePrototypeMethods = false;
        boolean boolean38 = compilerOptions29.inlineLocalVariables;
        compilerOptions29.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions29.checkMethods;
        compilerOptions18.checkFunctions = checkLevel41;
        compilerOptions0.checkShadowVars = checkLevel41;
        boolean boolean44 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(format19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertNotNull(format30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strSet35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        boolean boolean17 = compilerOptions14.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions14.cssRenamingMap = cssRenamingMap18;
        compilerOptions14.setRemoveAbstractMethods(false);
        boolean boolean22 = compilerOptions14.lineBreak;
        java.lang.Class<?> wildcardClass23 = compilerOptions14.getClass();
        boolean boolean24 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.aliasKeywords = true;
        boolean boolean28 = compilerOptions25.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = null;
        compilerOptions25.cssRenamingMap = cssRenamingMap29;
        compilerOptions25.setRemoveAbstractMethods(false);
        boolean boolean33 = compilerOptions25.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions25.aggressiveVarCheck;
        compilerOptions14.checkMethods = checkLevel34;
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(40, node39, node42, node45, node48);
        com.google.javascript.rhino.Node node50 = node39.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable51 = node50.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.aliasKeywords = true;
        boolean boolean55 = compilerOptions52.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap56 = null;
        compilerOptions52.cssRenamingMap = cssRenamingMap56;
        compilerOptions52.setRemoveAbstractMethods(false);
        boolean boolean60 = compilerOptions52.lineBreak;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        boolean boolean62 = compilerOptions52.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format64 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions63.sourceMapFormat = format64;
        compilerOptions63.unaliasableGlobals = "";
        boolean boolean68 = compilerOptions63.disambiguateProperties;
        java.util.Set<java.lang.String> strSet69 = compilerOptions63.stripTypePrefixes;
        compilerOptions52.stripNameSuffixes = strSet69;
        node50.setDirectives(strSet69);
        compilerOptions14.stripNamePrefixes = strSet69;
        compilerOptions0.stripTypePrefixes = strSet69;
        compilerOptions0.optimizeParameters = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeIterable51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(format64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(strSet69);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        compilerOptions1.markAsCompiled = false;
        compilerOptions1.setRemoveAbstractMethods(true);
        compilerOptions1.inputDelimiter = "Not declared as a type name";
        compilerOptions1.removeTryCatchFinally = false;
        compilerOptions1.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions1.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.aliasKeywords = true;
        compilerOptions15.markAsCompiled = false;
        compilerOptions15.setRemoveAbstractMethods(true);
        compilerOptions15.checkUnusedPropertiesEarly = false;
        java.lang.RuntimeException runtimeException24 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions1, (java.lang.Object) false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.aliasKeywords = true;
        boolean boolean28 = compilerOptions25.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = null;
        compilerOptions25.cssRenamingMap = cssRenamingMap29;
        compilerOptions25.setRemoveAbstractMethods(false);
        compilerOptions25.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray35 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard36 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray35);
        compilerOptions25.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard36);
        compilerOptions25.ambiguateProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions25.reportUnknownTypes;
        compilerOptions1.checkMethods = checkLevel40;
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.make("STRING", checkLevel40, "eof");
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray35);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType43);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        boolean boolean8 = compilerOptions0.lineBreak;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.toString();
        ecmaError2.initColumnNumber(26);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str3.equals("com.google.javascript.rhino.EcmaError: : "));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        boolean boolean19 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode20 = compilerOptions0.tracer;
        compilerOptions0.checkControlStructures = true;
        boolean boolean23 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + tracerMode20 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode20.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.SourceMap sourceMap9 = compiler1.getSourceMap();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler1.tracker;
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNull(sourceMap9);
        org.junit.Assert.assertNull(performanceTracker10);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("");
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        boolean boolean30 = closureCodingConvention0.isExported("(Unknown class name)");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.Object obj15 = node9.getProp((-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler30 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback31 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal32 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler30, callback31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions48.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray61 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal32.makeError(node45, checkLevel57, diagnosticType60, strArray61);
        com.google.javascript.rhino.jstype.JSType jSType63 = node45.getJSType();
        java.lang.String str64 = node22.checkTreeEquals(node45);
        com.google.javascript.rhino.Node node65 = node9.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(40, node69, node72, node75, node78);
        boolean boolean80 = node69.isLocalResultCall();
        int int81 = node69.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection82 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node69);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder83 = node69.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node84 = node65.copyInformationFrom(node69);
        node84.setWasEmptyNode(false);
        boolean boolean87 = node84.wasEmptyNode();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(nodeCollection82);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder83);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.aliasableGlobals;
        compilerOptions0.removeTryCatchFinally = true;
        boolean boolean13 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
        boolean boolean4 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        java.lang.String str12 = compilerOptions2.jsOutputFile;
//        compilerOptions2.checkTypedPropertyCalls = true;
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setSummaryDetailLevel(29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        context0.addActivationName("false");
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter7 = context0.setErrorReporter(errorReporter6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        try {
            com.google.javascript.rhino.Context.reportWarning("OR hi!\n", "OR hi!\n", 100, "DiagnosticGroup<missingProperties>", 29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.reportPath = "<No stack trace available>";
        boolean boolean21 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        boolean boolean16 = detailLevel1.apply(node11);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node11.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(40, node21, node24, node27, node30);
        int int32 = node27.getType();
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] { node11, node27 };
        try {
            com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(0, nodeArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(nodeArray33);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11, false);
        jSSourceFile11.clearCachedSource();
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset16);
        java.lang.String str18 = jSSourceFile17.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst19 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.aliasKeywords = true;
        compilerOptions20.markAsCompiled = false;
        compilerOptions20.setRemoveAbstractMethods(true);
        boolean boolean27 = compilerOptions20.checkTypes;
        compilerOptions20.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy31 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions20.setRenamingPolicy(variableRenamingPolicy30, propertyRenamingPolicy31);
        compilerOptions20.lineBreak = false;
        com.google.javascript.jscomp.Result result35 = compiler1.compile(jSSourceFile11, jSSourceFile17, compilerOptions20);
        com.google.javascript.jscomp.JSError[] jSErrorArray36 = compiler1.getWarnings();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy30.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy31 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy31.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(result35);
        org.junit.Assert.assertNotNull(jSErrorArray36);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeTryCatchFinally = false;
        java.lang.String str4 = compilerOptions0.inputDelimiter;
        compilerOptions0.nameReferenceReportPath = "DiagnosticGroup<missingProperties>";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "// Input %num%" + "'", str4.equals("// Input %num%"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.jscomp.Compiler compiler33 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node34 = nodeTraversal2.getCurrentNode();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput35 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNull(compiler33);
        org.junit.Assert.assertNull(node34);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.coalesceVariableNames = false;
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        com.google.javascript.rhino.Node node18 = node7.getLastSibling();
        boolean boolean19 = node18.isQuotedString();
        java.lang.String str20 = node18.getString();
        boolean boolean21 = node3.isEquivalentToTyped(node18);
        com.google.javascript.rhino.Node node22 = node3.getLastChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.lang.String str5 = compiler1.getSourceLine("Not declared as a type name", (int) (short) -1);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState6 = null;
        try {
            compiler1.setState(intermediateState6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(40, node18, node21, node24, node27);
        node24.setType((int) '#');
        com.google.javascript.rhino.Node node31 = node9.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node32 = node9.removeChildren();
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        node9.setJSType(jSType33);
        int int35 = node9.getSourcePosition();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(40, node39, node42, node45, node48);
        boolean boolean50 = node39.isLocalResultCall();
        int int51 = node39.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection52 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node39);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder53 = node39.getJsDocBuilderForNode();
        try {
            node9.addChildToBack(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(nodeCollection52);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder53);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Object obj0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", 130, 7);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(40, node8, node11, node14, node17);
        boolean boolean19 = node8.isLocalResultCall();
        int int20 = node8.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection21 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node8);
        node8.setCharno(17);
        node8.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node26 = node4.clonePropsFrom(node8);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0, (java.lang.Object) node8);
        java.lang.Throwable[] throwableArray28 = runtimeException27.getSuppressed();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(nodeCollection21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.lineBreak;
        boolean boolean22 = compilerOptions13.markNoSideEffectCalls;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler23 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler23, callback24);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(40, node29, node32, node35, node38);
        java.lang.String str40 = node38.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.aliasKeywords = true;
        boolean boolean44 = compilerOptions41.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap45 = null;
        compilerOptions41.cssRenamingMap = cssRenamingMap45;
        compilerOptions41.setRemoveAbstractMethods(false);
        boolean boolean49 = compilerOptions41.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel50 = compilerOptions41.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray54 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError55 = nodeTraversal25.makeError(node38, checkLevel50, diagnosticType53, strArray54);
        compilerOptions13.checkFunctions = checkLevel50;
        compilerOptions0.checkRequires = checkLevel50;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + checkLevel50 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel50.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(jSError55);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler1.getSourceMap();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput15 = compiler1.getInput("STRING");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(sourceMap13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("", "goog.global");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler1.tracker;
        com.google.javascript.jscomp.Scope scope11 = compiler1.getTopScope();
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertNull(scope11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("goog.abstractMethod");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.abstractMethod");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getErrors();
        try {
            com.google.javascript.jscomp.Region region14 = compiler1.getSourceRegion("", 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.checkSuspiciousCode = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
//        boolean boolean10 = compiler1.isTypeCheckingEnabled();
//        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
//        boolean boolean12 = compiler1.isTypeCheckingEnabled();
//        try {
//            compiler1.check();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(jSErrorArray11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Unknown class name");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("eof", reader5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromReader(": WARNING - \n", reader5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        compilerOptions0.foldConstants = true;
        boolean boolean12 = compilerOptions0.instrumentForCoverage;
        boolean boolean13 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        compilerOptions4.markAsCompiled = false;
        compilerOptions4.setRemoveAbstractMethods(true);
        boolean boolean11 = compilerOptions4.checkTypedPropertyCalls;
        compilerOptions4.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format15 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions14.sourceMapFormat = format15;
        compilerOptions14.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing19 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean20 = tweakProcessing19.shouldStrip();
        compilerOptions14.setTweakProcessing(tweakProcessing19);
        compilerOptions4.setTweakProcessing(tweakProcessing19);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler24 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler24, callback25);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        java.lang.String str41 = node39.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.aliasKeywords = true;
        boolean boolean45 = compilerOptions42.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap46 = null;
        compilerOptions42.cssRenamingMap = cssRenamingMap46;
        compilerOptions42.setRemoveAbstractMethods(false);
        boolean boolean50 = compilerOptions42.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions42.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray55 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal26.makeError(node39, checkLevel51, diagnosticType54, strArray55);
        loggerErrorManager2.report(checkLevel23, jSError56);
        com.google.javascript.jscomp.Compiler compiler58 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.JSError[] jSErrorArray59 = compiler58.getMessages();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertTrue("'" + tweakProcessing19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing19.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertNotNull(jSErrorArray59);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        com.google.javascript.jscomp.Scope scope15 = compiler12.getTopScope();
//        java.nio.charset.Charset charset17 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset17);
//        java.nio.charset.Charset charset20 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset20);
//        java.nio.charset.Charset charset23 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset23);
//        java.lang.String str25 = jSSourceFile24.getName();
//        com.google.javascript.rhino.Context context26 = com.google.javascript.rhino.Context.enter();
//        int int27 = context26.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = context26.getErrorReporter();
//        int int29 = context26.getInstructionObserverThreshold();
//        java.util.Locale locale30 = context26.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException32 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException32.initLineSource("Unknown class name");
//        int int35 = evaluatorException32.lineNumber();
//        context26.removeThreadLocal((java.lang.Object) int35);
//        java.io.PrintStream printStream37 = null;
//        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
//        compiler38.disableThreads();
//        context26.removeThreadLocal((java.lang.Object) compiler38);
//        com.google.javascript.jscomp.Scope scope41 = compiler38.getTopScope();
//        java.nio.charset.Charset charset43 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset43);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format47 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions46.sourceMapFormat = format47;
//        compilerOptions46.unaliasableGlobals = "";
//        boolean boolean51 = compilerOptions46.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet52 = compilerOptions46.stripTypePrefixes;
//        boolean boolean53 = compilerOptions46.devirtualizePrototypeMethods;
//        boolean boolean54 = compilerOptions46.gatherCssNames;
//        boolean boolean55 = compilerOptions46.prettyPrint;
//        compilerOptions46.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result58 = compiler38.compile(jSSourceFile44, jSSourceFileArray45, compilerOptions46);
//        com.google.javascript.jscomp.CompilerInput compilerInput60 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44, false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a type name");
//        java.lang.String str63 = jSSourceFile62.toString();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray64 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile21, jSSourceFile24, jSSourceFile44, jSSourceFile62 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray65 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions66.aliasKeywords = true;
//        boolean boolean69 = compilerOptions66.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap70 = null;
//        compilerOptions66.cssRenamingMap = cssRenamingMap70;
//        compilerOptions66.setRemoveAbstractMethods(false);
//        boolean boolean74 = compilerOptions66.lineBreak;
//        java.lang.String str75 = compilerOptions66.aliasStringsBlacklist;
//        com.google.javascript.jscomp.Result result76 = compiler12.compile(jSSourceFileArray64, jSModuleArray65, compilerOptions66);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNull(scope15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertNotNull(jSSourceFile21);
//        org.junit.Assert.assertNotNull(jSSourceFile24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
//        org.junit.Assert.assertNotNull(context26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNull(errorReporter28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNull(scope41);
//        org.junit.Assert.assertNotNull(jSSourceFile44);
//        org.junit.Assert.assertNotNull(jSSourceFileArray45);
//        org.junit.Assert.assertNotNull(format47);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(strSet52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(result58);
//        org.junit.Assert.assertNotNull(jSSourceFile62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Not declared as a type name" + "'", str63.equals("Not declared as a type name"));
//        org.junit.Assert.assertNotNull(jSSourceFileArray64);
//        org.junit.Assert.assertNotNull(jSModuleArray65);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
//        org.junit.Assert.assertNotNull(result76);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format5 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions4.sourceMapFormat = format5;
        compilerOptions4.unaliasableGlobals = "";
        boolean boolean9 = compilerOptions4.disambiguateProperties;
        java.util.Set<java.lang.String> strSet10 = compilerOptions4.stripTypePrefixes;
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.deadAssignmentElimination = true;
        compilerOptions4.debugFunctionSideEffectsPath = "";
        java.lang.RuntimeException runtimeException17 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) jSModuleGraph3, (java.lang.Object) compilerOptions4);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList20 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList20, jSModuleArray19);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph22 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList20);
        try {
            com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList20);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(format5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNotNull(runtimeException17);
        org.junit.Assert.assertNotNull(jSModuleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        boolean boolean12 = compilerOptions0.ideMode;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.aliasKeywords = true;
        compilerOptions3.markAsCompiled = false;
        compilerOptions3.setRemoveAbstractMethods(true);
        compilerOptions3.inputDelimiter = "Not declared as a type name";
        compilerOptions3.removeTryCatchFinally = false;
        compilerOptions3.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions3.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalNamesLevel = checkLevel16;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        boolean boolean10 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.instrumentForCoverageOnly = true;
        boolean boolean15 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("Unknown class name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Unknown class name" + "'", str1.equals("Unknown class name"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        int int4 = node3.getLineno();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node3.siblings();
        boolean boolean6 = node3.isLocalResultCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
        org.junit.Assert.assertNotNull(nodeIterable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.ideMode = false;
        compilerOptions0.instrumentationTemplate = "// Input %num%";
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter5 = context0.setErrorReporter(errorReporter4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean10 = compilerOptions0.prettyPrint;
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        int int4 = ecmaError2.getColumnNumber();
        java.lang.String str5 = ecmaError2.sourceName();
        java.lang.String str6 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.setTweakToStringLiteral("DiagnosticGroup<missingProperties>", "OR hi! [directives: []]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(0);
        int int2 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        boolean boolean12 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.tightenTypes = false;
        compilerOptions0.setDefineToDoubleLiteral("DiagnosticGroup<accessControls>", (double) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("0");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 0");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 0, "", (int) (short) 0, 3);
        node4.detachChildren();
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("DiagnosticGroup<missingProperties>", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.lang.String str5 = compiler1.getSourceLine("Not declared as a type name", (int) (short) -1);
        try {
            boolean boolean6 = compiler1.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setOutputCharset("com.google.javascript.rhino.EcmaError: : ");
        compilerOptions0.flowSensitiveInlineVariables = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.aliasKeywords = true;
        compilerOptions12.markAsCompiled = false;
        compilerOptions12.setRemoveAbstractMethods(true);
        boolean boolean19 = compilerOptions12.checkTypes;
        compilerOptions12.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy23 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions12.setRenamingPolicy(variableRenamingPolicy22, propertyRenamingPolicy23);
        compilerOptions0.variableRenaming = variableRenamingPolicy22;
        compilerOptions0.setDefineToDoubleLiteral(".  at (unknown source) line (unknown line) : (unknown column)", (double) (short) 100);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy22.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy23 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy23.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup2;
        boolean boolean5 = composeWarningsGuard1.enables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = null;
        boolean boolean7 = diagnosticGroup2.matches(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup2;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        boolean boolean15 = node14.isQuotedString();
        java.lang.String str16 = node14.getString();
        boolean boolean17 = node14.isQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions0.checkUndefinedProperties = checkLevel22;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format25 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions24.sourceMapFormat = format25;
        compilerOptions24.unaliasableGlobals = "";
        compilerOptions24.collapseProperties = true;
        compilerOptions24.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass33 = compilerOptions24.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy34 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions24.propertyRenaming = propertyRenamingPolicy34;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy34;
        boolean boolean37 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions0.reportUnknownTypes;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format25);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy34 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy34.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.aliasableStrings;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.printInputDelimiter = true;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        compilerOptions0.foldConstants = true;
        boolean boolean12 = compilerOptions0.instrumentForCoverage;
        boolean boolean13 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        boolean boolean7 = compilerOptions4.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = null;
        compilerOptions4.cssRenamingMap = cssRenamingMap8;
        compilerOptions4.setRemoveAbstractMethods(false);
        boolean boolean12 = compilerOptions4.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention13 = null;
        compilerOptions4.setCodingConvention(codingConvention13);
        boolean boolean15 = compilerOptions4.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions4.reportUnknownTypes;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
        java.lang.String str34 = node32.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.aliasKeywords = true;
        boolean boolean38 = compilerOptions35.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap39 = null;
        compilerOptions35.cssRenamingMap = cssRenamingMap39;
        compilerOptions35.setRemoveAbstractMethods(false);
        boolean boolean43 = compilerOptions35.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions35.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray48 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError49 = nodeTraversal19.makeError(node32, checkLevel44, diagnosticType47, strArray48);
        java.lang.String str50 = jSError49.description;
        loggerErrorManager1.println(checkLevel16, jSError49);
        loggerErrorManager1.setTypedPercent((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean4 = node3.hasSideEffects();
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node5.getAncestors();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(ancestorIterable6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(34, "(Unknown class name)");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        java.lang.String str7 = compilerOptions0.syntheticBlockStartMarker;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        boolean boolean18 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        ecmaError2.initColumnNumber(16);
        try {
            ecmaError2.initLineNumber((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        compilerOptions4.markAsCompiled = false;
        compilerOptions4.setRemoveAbstractMethods(true);
        boolean boolean11 = compilerOptions4.checkTypedPropertyCalls;
        compilerOptions4.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format15 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions14.sourceMapFormat = format15;
        compilerOptions14.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing19 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean20 = tweakProcessing19.shouldStrip();
        compilerOptions14.setTweakProcessing(tweakProcessing19);
        compilerOptions4.setTweakProcessing(tweakProcessing19);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray24);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler26 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler26, callback27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        java.lang.String str43 = node41.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.aliasKeywords = true;
        boolean boolean47 = compilerOptions44.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap48 = null;
        compilerOptions44.cssRenamingMap = cssRenamingMap48;
        compilerOptions44.setRemoveAbstractMethods(false);
        boolean boolean52 = compilerOptions44.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions44.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray57 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError58 = nodeTraversal28.makeError(node41, checkLevel53, diagnosticType56, strArray57);
        java.lang.String str59 = jSError58.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel60 = composeWarningsGuard25.level(jSError58);
        loggerErrorManager2.println(checkLevel23, jSError58);
        int int62 = loggerErrorManager2.getWarningCount();
        loggerErrorManager2.setTypedPercent((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertTrue("'" + tweakProcessing19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing19.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertNull(checkLevel60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.reportPath = "<No stack trace available>";
        com.google.javascript.jscomp.CodingConvention codingConvention21 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(codingConvention21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        compilerOptions0.instrumentForCoverage = false;
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean12 = closureCodingConvention9.isExported("DiagnosticGroup<accessControls>", false);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention9);
        boolean boolean15 = closureCodingConvention9.isPrivate("com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format11 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions10.sourceMapFormat = format11;
        compilerOptions10.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing15 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean16 = tweakProcessing15.shouldStrip();
        compilerOptions10.setTweakProcessing(tweakProcessing15);
        compilerOptions0.setTweakProcessing(tweakProcessing15);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.enableRuntimeTypeCheck("STRING");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(format11);
        org.junit.Assert.assertTrue("'" + tweakProcessing15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing15.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        compilerOptions13.markAsCompiled = false;
        compilerOptions13.setRemoveAbstractMethods(true);
        boolean boolean20 = compilerOptions13.checkTypedPropertyCalls;
        compilerOptions13.extractPrototypeMemberDeclarations = true;
        java.lang.String str23 = compilerOptions13.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy24 = compilerOptions13.propertyRenaming;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy24;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy24 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy24.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.unaliasableGlobals = ".  at (unknown source) line (unknown line) : (unknown column)";
        compilerOptions0.setColorizeErrorOutput(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format6 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions5.sourceMapFormat = format6;
//        compilerOptions5.groupVariableDeclarations = true;
//        context0.removeThreadLocal((java.lang.Object) true);
//        java.lang.Object obj11 = context0.getDebuggerContextData();
//        context0.setInstructionObserverThreshold(2);
//        boolean boolean14 = context0.isSealed();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(format6);
//        org.junit.Assert.assertNull(obj11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        int int75 = node74.getChildCount();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable76 = node74.children();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(nodeIterable76);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        com.google.javascript.rhino.Node node16 = node5.getLastSibling();
        node16.setWasEmptyNode(false);
        boolean boolean19 = node1.hasChild(node16);
        node16.setOptionalArg(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder22 = node16.getJsDocBuilderForNode();
        node16.detachChildren();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder22);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.enableExternExports(false);
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean12 = compilerOptions0.checkCaja;
        compilerOptions0.computeFunctionSideEffects = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(40, node78, node81, node84, node87);
        node84.setType((int) '#');
        boolean boolean92 = node84.getBooleanProp((int) (short) -1);
        boolean boolean93 = node74.isEquivalentTo(node84);
        com.google.javascript.rhino.Node node94 = node74.getParent();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags96 = new com.google.javascript.rhino.Node.SideEffectFlags(0);
        sideEffectFlags96.setMutatesGlobalState();
        try {
            node94.setSideEffectFlags(sideEffectFlags96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(node94);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString(0.0d, 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("com.google.javascript.rhino.EcmaError: : ", "false", ".  at (unknown source) line (unknown line) : (unknown column)", 20, ".  at (unknown source) line (unknown line) : (unknown column)", 32);
        java.lang.Throwable[] throwableArray7 = ecmaError6.getSuppressed();
        java.lang.String str8 = ecmaError6.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<No stack trace available>" + "'", str8.equals("<No stack trace available>"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        boolean boolean16 = detailLevel1.apply(node11);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        node11.setJSType(jSType17);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean21 = closureCodingConvention19.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        java.lang.String str36 = node34.getString();
        com.google.javascript.rhino.Node node37 = node34.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = node34.getJSDocInfo();
        node34.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship41 = closureCodingConvention19.getDelegateRelationship(node34);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(40, node45, node48, node51, node54);
        boolean boolean56 = node34.hasChild(node54);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention57 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean59 = closureCodingConvention57.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node(40, node63, node66, node69, node72);
        java.lang.String str74 = node72.getString();
        com.google.javascript.rhino.Node node75 = node72.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo76 = node72.getJSDocInfo();
        node72.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship79 = closureCodingConvention57.getDelegateRelationship(node72);
        com.google.javascript.rhino.Node node80 = node72.getLastChild();
        com.google.javascript.rhino.Node node81 = null;
        try {
            com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node(2, node11, node54, node72, node81, 49, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNull(node37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(delegateRelationship41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertNull(node75);
        org.junit.Assert.assertNull(jSDocInfo76);
        org.junit.Assert.assertNull(delegateRelationship79);
        org.junit.Assert.assertNull(node80);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter();
//        long long2 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format4 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions3.sourceMapFormat = format4;
//        compilerOptions3.unaliasableGlobals = "";
//        boolean boolean8 = compilerOptions3.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet9 = compilerOptions3.stripTypePrefixes;
//        boolean boolean10 = compilerOptions3.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet11 = compilerOptions3.stripTypes;
//        context1.seal((java.lang.Object) compilerOptions3);
//        java.lang.String str13 = compilerOptions3.jsOutputFile;
//        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions3.checkRequires;
//        compilerOptions3.setChainCalls(false);
//        java.nio.charset.Charset charset18 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset18);
//        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19, false);
//        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput21, ": WARNING - \n", false);
//        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(40, node28, node31, node34, node37);
//        java.lang.String str39 = node37.getString();
//        try {
//            java.lang.String str40 = com.google.javascript.rhino.ScriptRuntime.getMessage3("Not declared as a type name", (java.lang.Object) false, (java.lang.Object) compilerInput21, (java.lang.Object) node37);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a type name");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertNotNull(format4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(strSet9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(strSet11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(jSSourceFile19);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertNotNull(node31);
//        org.junit.Assert.assertNotNull(node34);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        byte[] byteArray15 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setDefineToBooleanLiteral("Named type with empty name component", false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(byteArray15);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        compilerOptions0.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean24 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "com.google.javascript.rhino.EcmaError: : ");
        int int3 = ecmaError2.getColumnNumber();
        ecmaError2.initColumnNumber(21);
        ecmaError2.initLineNumber(150);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setDefineToStringLiteral("eof", "hi!");
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        compilerOptions0.checkShadowVars = checkLevel9;
        java.lang.String str11 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        java.lang.String str29 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(40, node33, node36, node39, node42);
        java.lang.Object obj45 = node39.getProp((-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(40, node49, node52, node55, node58);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler60 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal62 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler60, callback61);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(40, node66, node69, node72, node75);
        java.lang.String str77 = node75.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions78.aliasKeywords = true;
        boolean boolean81 = compilerOptions78.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap82 = null;
        compilerOptions78.cssRenamingMap = cssRenamingMap82;
        compilerOptions78.setRemoveAbstractMethods(false);
        boolean boolean86 = compilerOptions78.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel87 = compilerOptions78.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType90 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray91 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError92 = nodeTraversal62.makeError(node75, checkLevel87, diagnosticType90, strArray91);
        com.google.javascript.rhino.jstype.JSType jSType93 = node75.getJSType();
        java.lang.String str94 = node52.checkTreeEquals(node75);
        com.google.javascript.rhino.Node node95 = node39.copyInformationFromForTree(node75);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship96 = closureCodingConvention0.getDelegateRelationship(node95);
        boolean boolean97 = node95.isQuotedString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + checkLevel87 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel87.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType90);
        org.junit.Assert.assertNotNull(strArray91);
        org.junit.Assert.assertNotNull(jSError92);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNull(delegateRelationship96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        compilerOptions0.removeUnusedPrototypeProperties = true;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap15 = compilerOptions0.cssRenamingMap;
        compilerOptions0.aliasStringsBlacklist = "bitxor";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertNull(cssRenamingMap15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.generatePseudoNames = false;
        java.lang.String str9 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockEndMarker = "goog.global";
        compilerOptions0.ignoreCajaProperties = false;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        boolean boolean4 = compilerOptions1.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions1.cssRenamingMap = cssRenamingMap5;
        compilerOptions1.setRemoveAbstractMethods(false);
        boolean boolean9 = compilerOptions1.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = null;
        compilerOptions1.setCodingConvention(codingConvention10);
        boolean boolean12 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format14 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions13.sourceMapFormat = format14;
        compilerOptions13.unaliasableGlobals = "";
        boolean boolean18 = compilerOptions13.disambiguateProperties;
        java.util.Set<java.lang.String> strSet19 = compilerOptions13.stripTypePrefixes;
        compilerOptions13.devirtualizePrototypeMethods = false;
        compilerOptions13.deadAssignmentElimination = true;
        compilerOptions13.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.aliasKeywords = true;
        boolean boolean29 = compilerOptions26.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap30 = null;
        compilerOptions26.cssRenamingMap = cssRenamingMap30;
        compilerOptions26.setRemoveAbstractMethods(false);
        boolean boolean34 = compilerOptions26.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions26.aggressiveVarCheck;
        compilerOptions13.checkUndefinedProperties = checkLevel35;
        compilerOptions1.brokenClosureRequiresLevel = checkLevel35;
        try {
            java.lang.String str38 = com.google.javascript.rhino.ScriptRuntime.getMessage1("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(format14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = compilerOptions0.customPasses;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        boolean boolean4 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        compilerOptions0.inlineFunctions = false;
        boolean boolean6 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        boolean boolean4 = node3.hasSideEffects();
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(40, node9, node12, node15, node18);
        java.lang.String str20 = node18.getString();
        com.google.javascript.rhino.Node node21 = node18.getLastChild();
        node18.setOptionalArg(false);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(40, node27, node30, node33, node36);
        boolean boolean38 = node27.isLocalResultCall();
        int int39 = node27.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection40 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node27);
        node27.setCharno(17);
        int int43 = node27.getCharno();
        try {
            node3.replaceChildAfter(node18, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeCollection40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType5 = null;
        closureCodingConvention1.applySubclassRelationship(functionType3, functionType4, subclassType5);
        boolean boolean8 = closureCodingConvention1.isPrivate("");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        node3.setLineno((int) (short) -1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup7;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        boolean boolean12 = compilerOptions0.aliasKeywords;
        compilerOptions0.sourceMapOutputPath = "TypeError";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 22);
        com.google.javascript.rhino.Node node2 = node1.getLastSibling();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions12.aliasKeywords = true;
//        compilerOptions12.markAsCompiled = false;
//        compilerOptions12.setRemoveAbstractMethods(true);
//        boolean boolean19 = compilerOptions12.checkTypes;
//        compilerOptions12.aliasKeywords = false;
//        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy22 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy23 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
//        compilerOptions12.setRenamingPolicy(variableRenamingPolicy22, propertyRenamingPolicy23);
//        compilerOptions12.lineBreak = false;
//        compilerOptions12.recordFunctionInformation = false;
//        compilerOptions12.instrumentForCoverageOnly = false;
//        boolean boolean31 = compilerOptions12.disambiguateProperties;
//        try {
//            context0.removeThreadLocal((java.lang.Object) boolean31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + variableRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy22.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy23 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy23.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.collapseAnonymousFunctions = true;
        compilerOptions0.optimizeParameters = true;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        boolean boolean11 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.brokenClosureRequiresLevel;
        java.lang.String str13 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) checkLevel12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR" + "'", str13.equals("ERROR"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler1.getSourceMap();
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(sourceMap13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.instrumentForCoverage = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.aliasKeywords = true;
        boolean boolean15 = compilerOptions12.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap16 = null;
        compilerOptions12.cssRenamingMap = cssRenamingMap16;
        compilerOptions12.setRemoveAbstractMethods(false);
        compilerOptions12.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard23 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray22);
        compilerOptions12.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard23);
        compilerOptions12.ambiguateProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions12.reportUnknownTypes;
        compilerOptions0.checkRequires = checkLevel27;
        boolean boolean29 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 130);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        int int16 = node3.getLineno();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        boolean boolean17 = compilerOptions14.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions14.cssRenamingMap = cssRenamingMap18;
        compilerOptions14.setRemoveAbstractMethods(false);
        boolean boolean22 = compilerOptions14.lineBreak;
        java.lang.Class<?> wildcardClass23 = compilerOptions14.getClass();
        boolean boolean24 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.aliasKeywords = true;
        boolean boolean28 = compilerOptions25.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = null;
        compilerOptions25.cssRenamingMap = cssRenamingMap29;
        compilerOptions25.setRemoveAbstractMethods(false);
        boolean boolean33 = compilerOptions25.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions25.aggressiveVarCheck;
        compilerOptions14.checkMethods = checkLevel34;
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(40, node39, node42, node45, node48);
        com.google.javascript.rhino.Node node50 = node39.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable51 = node50.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.aliasKeywords = true;
        boolean boolean55 = compilerOptions52.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap56 = null;
        compilerOptions52.cssRenamingMap = cssRenamingMap56;
        compilerOptions52.setRemoveAbstractMethods(false);
        boolean boolean60 = compilerOptions52.lineBreak;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        boolean boolean62 = compilerOptions52.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format64 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions63.sourceMapFormat = format64;
        compilerOptions63.unaliasableGlobals = "";
        boolean boolean68 = compilerOptions63.disambiguateProperties;
        java.util.Set<java.lang.String> strSet69 = compilerOptions63.stripTypePrefixes;
        compilerOptions52.stripNameSuffixes = strSet69;
        node50.setDirectives(strSet69);
        compilerOptions14.stripNamePrefixes = strSet69;
        compilerOptions0.stripTypePrefixes = strSet69;
        boolean boolean74 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeIterable51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(format64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(strSet69);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("error reporter", "STRING", ": ");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.toString();
        java.lang.String str4 = ecmaError2.getSourceName();
        java.lang.String str5 = ecmaError2.getLineSource();
        java.lang.String str6 = ecmaError2.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str3.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        java.lang.String str25 = diagnosticGroupWarningsGuard24.toString();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler26 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler26, callback27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        java.lang.String str43 = node41.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.aliasKeywords = true;
        boolean boolean47 = compilerOptions44.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap48 = null;
        compilerOptions44.cssRenamingMap = cssRenamingMap48;
        compilerOptions44.setRemoveAbstractMethods(false);
        boolean boolean52 = compilerOptions44.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions44.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray57 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError58 = nodeTraversal28.makeError(node41, checkLevel53, diagnosticType56, strArray57);
        java.lang.String str59 = jSError58.description;
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.aliasKeywords = true;
        compilerOptions60.markAsCompiled = false;
        compilerOptions60.setRemoveAbstractMethods(true);
        boolean boolean67 = compilerOptions60.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions68.aliasKeywords = true;
        compilerOptions68.markAsCompiled = false;
        compilerOptions68.setRemoveAbstractMethods(true);
        compilerOptions68.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel77 = compilerOptions68.checkUndefinedProperties;
        compilerOptions60.checkGlobalThisLevel = checkLevel77;
        compilerOptions60.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions60.groupVariableDeclarations = true;
        boolean boolean84 = jSError58.equals((java.lang.Object) true);
        com.google.javascript.jscomp.CheckLevel checkLevel85 = diagnosticGroupWarningsGuard24.level(jSError58);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup86 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup87 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup88 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup89 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup90 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray91 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup86, diagnosticGroup87, diagnosticGroup88, diagnosticGroup89, diagnosticGroup90 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup92 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray91);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup92;
        boolean boolean94 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup92);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup92;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DiagnosticGroup<missingProperties>(OFF)" + "'", str25.equals("DiagnosticGroup<missingProperties>(OFF)"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(checkLevel85);
        org.junit.Assert.assertNotNull(diagnosticGroup86);
        org.junit.Assert.assertNotNull(diagnosticGroup87);
        org.junit.Assert.assertNotNull(diagnosticGroup88);
        org.junit.Assert.assertNotNull(diagnosticGroup89);
        org.junit.Assert.assertNotNull(diagnosticGroup90);
        org.junit.Assert.assertNotNull(diagnosticGroupArray91);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format12 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions11.sourceMapFormat = format12;
        compilerOptions11.unaliasableGlobals = "";
        boolean boolean16 = compilerOptions11.disambiguateProperties;
        java.util.Set<java.lang.String> strSet17 = compilerOptions11.stripTypePrefixes;
        compilerOptions11.devirtualizePrototypeMethods = false;
        boolean boolean20 = compilerOptions11.inlineLocalVariables;
        compilerOptions11.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions11.checkMethods;
        compilerOptions0.checkFunctions = checkLevel23;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy25 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(format12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy25.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.checkMissingGetCssNameBlacklist = "Node tree inequality:\nTree1:\nSTRING eof 24\n\n\nTree2:\nOR hi!\n\n\nSubtree1: STRING eof 24\n\n\nSubtree2: OR hi!\n";
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("STRING", "Not declared as a type name", "eof", 38, "eof", 42);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.setManageClosureDependencies(true);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean10 = compilerOptions0.prettyPrint;
        boolean boolean11 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap6;
        boolean boolean8 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.ignoreCajaProperties = false;
        boolean boolean11 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("0", "", (int) (short) 0);
        java.lang.String str4 = evaluatorException3.details();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType1, functionType2, objectType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.setDefineToStringLiteral("0", "0");
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("false");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(false)" + "'", str1.equals("(false)"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean7 = compilerOptions0.tightenTypes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node6.isLocalResultCall();
        com.google.javascript.rhino.Node node16 = node6.getChildAtIndex(0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(node16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        node12.putBooleanProp(24, true);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler20 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler20, callback21);
        java.lang.String str23 = nodeTraversal22.getSourceName();
        node12.putProp((int) '4', (java.lang.Object) nodeTraversal22);
        node12.setString(": ");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.setOutputCharset("hi!");
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(detailLevel14);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        com.google.javascript.jscomp.Scope scope15 = compiler12.getTopScope();
//        java.nio.charset.Charset charset17 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset17);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format21 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions20.sourceMapFormat = format21;
//        compilerOptions20.unaliasableGlobals = "";
//        boolean boolean25 = compilerOptions20.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet26 = compilerOptions20.stripTypePrefixes;
//        boolean boolean27 = compilerOptions20.devirtualizePrototypeMethods;
//        boolean boolean28 = compilerOptions20.gatherCssNames;
//        boolean boolean29 = compilerOptions20.prettyPrint;
//        compilerOptions20.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result32 = compiler12.compile(jSSourceFile18, jSSourceFileArray19, compilerOptions20);
//        compilerOptions20.setRemoveAbstractMethods(true);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNull(scope15);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertNotNull(jSSourceFileArray19);
//        org.junit.Assert.assertNotNull(format21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(strSet26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(result32);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.skipAllCompilerPasses();
        com.google.javascript.jscomp.SourceMap.Format format8 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format8;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(format8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.ideMode = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean13 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        compilerOptions0.foldConstants = true;
        java.lang.String str12 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkMissingReturn;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean17 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Named type with empty name component)" + "'", str1.equals("(Named type with empty name component)"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        boolean boolean15 = node3.isLocalResultCall();
        com.google.javascript.rhino.jstype.JSType jSType16 = node3.getJSType();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable17 = node3.getAncestors();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(ancestorIterable17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11, false);
        jSSourceFile11.clearCachedSource();
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset16);
        java.lang.String str18 = jSSourceFile17.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst19 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.aliasKeywords = true;
        compilerOptions20.markAsCompiled = false;
        compilerOptions20.setRemoveAbstractMethods(true);
        boolean boolean27 = compilerOptions20.checkTypes;
        compilerOptions20.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy30 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy31 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions20.setRenamingPolicy(variableRenamingPolicy30, propertyRenamingPolicy31);
        compilerOptions20.lineBreak = false;
        com.google.javascript.jscomp.Result result35 = compiler1.compile(jSSourceFile11, jSSourceFile17, compilerOptions20);
        jSSourceFile17.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy30.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy31 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy31.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(result35);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        java.lang.String str9 = compilerOptions0.reportPath;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        compilerOptions0.foldConstants = true;
        compilerOptions0.enableRuntimeTypeCheck("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        boolean boolean12 = compiler1.isTypeCheckingEnabled();
        compiler1.disableThreads();
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        int int16 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format18 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions17.sourceMapFormat = format18;
        compilerOptions17.unaliasableGlobals = "";
        boolean boolean22 = compilerOptions17.disambiguateProperties;
        java.util.Set<java.lang.String> strSet23 = compilerOptions17.stripTypePrefixes;
        boolean boolean24 = compilerOptions17.devirtualizePrototypeMethods;
        compilerOptions17.instrumentForCoverageOnly = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format28 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions27.sourceMapFormat = format28;
        compilerOptions27.unaliasableGlobals = "";
        boolean boolean32 = compilerOptions27.disambiguateProperties;
        java.util.Set<java.lang.String> strSet33 = compilerOptions27.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy34 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy35 = null;
        compilerOptions27.setRenamingPolicy(variableRenamingPolicy34, propertyRenamingPolicy35);
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions27.checkRequires;
        compilerOptions17.checkGlobalThisLevel = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(40, node45, node48, node51, node54);
        java.lang.String str56 = node54.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.aliasKeywords = true;
        boolean boolean60 = compilerOptions57.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap61 = null;
        compilerOptions57.cssRenamingMap = cssRenamingMap61;
        compilerOptions57.setRemoveAbstractMethods(false);
        boolean boolean65 = compilerOptions57.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel66 = compilerOptions57.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray70 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError71 = nodeTraversal41.makeError(node54, checkLevel66, diagnosticType69, strArray70);
        java.lang.String str72 = jSError71.sourceName;
        loggerErrorManager15.report(checkLevel37, jSError71);
        compiler1.report(jSError71);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(format18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(strSet23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(format28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy34 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy34.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + checkLevel66 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel66.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "" + "'", str72.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        com.google.javascript.jscomp.CodingConvention codingConvention12 = compiler1.getCodingConvention();
        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(codingConvention12);
        org.junit.Assert.assertNotNull(errorManager13);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
        compilerOptions0.generateExports = false;
        boolean boolean7 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.decomposeExpressions = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.aliasKeywords = true;
        boolean boolean14 = compilerOptions11.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap15 = null;
        compilerOptions11.cssRenamingMap = cssRenamingMap15;
        compilerOptions11.setRemoveAbstractMethods(false);
        boolean boolean19 = compilerOptions11.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.aggressiveVarCheck;
        compilerOptions0.checkMethods = checkLevel20;
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        com.google.javascript.rhino.Node node36 = node25.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable37 = node36.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.aliasKeywords = true;
        boolean boolean41 = compilerOptions38.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap42 = null;
        compilerOptions38.cssRenamingMap = cssRenamingMap42;
        compilerOptions38.setRemoveAbstractMethods(false);
        boolean boolean46 = compilerOptions38.lineBreak;
        boolean boolean47 = compilerOptions38.markNoSideEffectCalls;
        boolean boolean48 = compilerOptions38.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format50 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions49.sourceMapFormat = format50;
        compilerOptions49.unaliasableGlobals = "";
        boolean boolean54 = compilerOptions49.disambiguateProperties;
        java.util.Set<java.lang.String> strSet55 = compilerOptions49.stripTypePrefixes;
        compilerOptions38.stripNameSuffixes = strSet55;
        node36.setDirectives(strSet55);
        compilerOptions0.stripNamePrefixes = strSet55;
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeIterable37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(format50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(strSet55);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasableGlobals = "";
        compilerOptions0.checkEs5Strict = true;
        java.lang.String str10 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkFunctions;
        compilerOptions0.setManageClosureDependencies(true);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean7 = compilerOptions0.optimizeReturns;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.unaliasableGlobals = "com.google.javascript.rhino.EcmaError: : ";
        boolean boolean11 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config6 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false);
        com.google.javascript.jscomp.parsing.Config config8 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode4, true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter9 = null;
        java.util.logging.Logger logger10 = null;
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.parsing.ParserRunner.parse("STRING", "goog.abstractMethod", config8, errorReporter9, logger10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode4 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode4.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config6);
        org.junit.Assert.assertNotNull(config8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format11 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions10.sourceMapFormat = format11;
        compilerOptions10.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing15 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean16 = tweakProcessing15.shouldStrip();
        compilerOptions10.setTweakProcessing(tweakProcessing15);
        compilerOptions0.setTweakProcessing(tweakProcessing15);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.aliasKeywords = true;
        compilerOptions20.markAsCompiled = false;
        compilerOptions20.setRemoveAbstractMethods(true);
        boolean boolean27 = compilerOptions20.checkTypedPropertyCalls;
        compilerOptions20.extractPrototypeMemberDeclarations = true;
        compilerOptions20.reserveRawExports = false;
        boolean boolean32 = compilerOptions20.inlineLocalFunctions;
        compilerOptions20.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat35 = compilerOptions20.errorFormat;
        java.io.PrintStream printStream36 = null;
        com.google.javascript.jscomp.Compiler compiler37 = new com.google.javascript.jscomp.Compiler(printStream36);
        compiler37.disableThreads();
        java.nio.charset.Charset charset40 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset40);
        java.lang.String str42 = jSSourceFile41.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst43 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.rhino.Node node44 = compiler37.parse(jSSourceFile41);
        com.google.javascript.jscomp.SourceMap sourceMap45 = compiler37.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter47 = errorFormat35.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler37, true);
        compilerOptions0.errorFormat = errorFormat35;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(format11);
        org.junit.Assert.assertTrue("'" + tweakProcessing15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing15.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(errorFormat35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNull(sourceMap45);
        org.junit.Assert.assertNotNull(messageFormatter47);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions0.errorFormat;
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        compiler17.disableThreads();
        java.nio.charset.Charset charset20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset20);
        java.lang.String str22 = jSSourceFile21.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst23 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile21);
        com.google.javascript.rhino.Node node24 = compiler17.parse(jSSourceFile21);
        com.google.javascript.jscomp.SourceMap sourceMap25 = compiler17.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter27 = errorFormat15.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler17, true);
        com.google.javascript.jscomp.NodeTraversal.Callback callback28 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal29 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler17, callback28);
        boolean boolean30 = nodeTraversal29.hasScope();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(sourceMap25);
        org.junit.Assert.assertNotNull(messageFormatter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "com.google.javascript.rhino.EcmaError: : ");
        int int3 = ecmaError2.getLineNumber();
        java.lang.String str4 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Not declared as a type name: com.google.javascript.rhino.EcmaError: : " + "'", str4.equals("Not declared as a type name: com.google.javascript.rhino.EcmaError: : "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        boolean boolean3 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.jsOutputFile = ": WARNING - \n";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("eof", 24, 28);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        node3.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap8 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap8;
        java.lang.String str10 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.appNameStr = "OR hi!\n";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter9.setColorize(true);
        lightweightMessageFormatter9.setColorize(true);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.aliasExternals = false;
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean12 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        boolean boolean12 = compiler1.isTypeCheckingEnabled();
        compiler1.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState14 = null;
        try {
            compiler1.setState(intermediateState14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.instrumentForCoverageOnly = false;
        boolean boolean10 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        compilerInput7.clearAst();
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput7.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
        org.junit.Assert.assertNotNull(sourceAst9);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.Object obj15 = node9.getProp((-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler30 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback31 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal32 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler30, callback31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions48.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray61 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal32.makeError(node45, checkLevel57, diagnosticType60, strArray61);
        com.google.javascript.rhino.jstype.JSType jSType63 = node45.getJSType();
        java.lang.String str64 = node22.checkTreeEquals(node45);
        com.google.javascript.rhino.Node node65 = node9.copyInformationFromForTree(node45);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler66 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback67 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal68 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler66, callback67);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(40, node72, node75, node78, node81);
        java.lang.String str83 = node81.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions84 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions84.aliasKeywords = true;
        boolean boolean87 = compilerOptions84.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap88 = null;
        compilerOptions84.cssRenamingMap = cssRenamingMap88;
        compilerOptions84.setRemoveAbstractMethods(false);
        boolean boolean92 = compilerOptions84.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel93 = compilerOptions84.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType96 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray97 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError98 = nodeTraversal68.makeError(node81, checkLevel93, diagnosticType96, strArray97);
        try {
            node65.addChildToFront(node81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "hi!" + "'", str83.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + checkLevel93 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel93.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType96);
        org.junit.Assert.assertNotNull(strArray97);
        org.junit.Assert.assertNotNull(jSError98);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean6 = closureCodingConvention4.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(40, node10, node13, node16, node19);
        java.lang.String str21 = node19.getString();
        com.google.javascript.rhino.Node node22 = node19.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = node19.getJSDocInfo();
        node19.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = closureCodingConvention4.getDelegateRelationship(node19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal2.makeError(node19, diagnosticType29, strArray30);
        com.google.javascript.rhino.Node node32 = nodeTraversal2.getCurrentNode();
        boolean boolean33 = nodeTraversal2.hasScope();
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        boolean boolean11 = compilerOptions0.specializeInitialModule;
        java.lang.String str12 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        boolean boolean17 = compilerOptions14.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions14.cssRenamingMap = cssRenamingMap18;
        compilerOptions14.setRemoveAbstractMethods(false);
        boolean boolean22 = compilerOptions14.lineBreak;
        java.lang.Class<?> wildcardClass23 = compilerOptions14.getClass();
        boolean boolean24 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.aliasKeywords = true;
        boolean boolean28 = compilerOptions25.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = null;
        compilerOptions25.cssRenamingMap = cssRenamingMap29;
        compilerOptions25.setRemoveAbstractMethods(false);
        boolean boolean33 = compilerOptions25.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions25.aggressiveVarCheck;
        compilerOptions14.checkMethods = checkLevel34;
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(40, node39, node42, node45, node48);
        com.google.javascript.rhino.Node node50 = node39.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable51 = node50.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.aliasKeywords = true;
        boolean boolean55 = compilerOptions52.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap56 = null;
        compilerOptions52.cssRenamingMap = cssRenamingMap56;
        compilerOptions52.setRemoveAbstractMethods(false);
        boolean boolean60 = compilerOptions52.lineBreak;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        boolean boolean62 = compilerOptions52.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format64 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions63.sourceMapFormat = format64;
        compilerOptions63.unaliasableGlobals = "";
        boolean boolean68 = compilerOptions63.disambiguateProperties;
        java.util.Set<java.lang.String> strSet69 = compilerOptions63.stripTypePrefixes;
        compilerOptions52.stripNameSuffixes = strSet69;
        node50.setDirectives(strSet69);
        compilerOptions14.stripNamePrefixes = strSet69;
        compilerOptions0.stripTypePrefixes = strSet69;
        compilerOptions0.checkEs5Strict = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeIterable51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(format64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(strSet69);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.ideMode = false;
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "eof", false);
        java.lang.String str11 = compilerInput4.getLine((int) 'a');
        boolean boolean12 = compilerInput4.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst13 = compilerInput4.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(sourceAst13);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        int int3 = nodeTraversal2.getLineNumber();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getCurrentNode();
        com.google.javascript.jscomp.Scope scope5 = nodeTraversal2.getScope();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(scope5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        java.lang.String str11 = compilerOptions0.checkMissingGetCssNameBlacklist;
        boolean boolean12 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        compilerOptions0.foldConstants = true;
        boolean boolean12 = compilerOptions0.instrumentForCoverage;
        boolean boolean13 = compilerOptions0.lineBreak;
        boolean boolean14 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap6;
        boolean boolean8 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.syntheticBlockEndMarker = "goog.exportProperty";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.OFF;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        boolean boolean10 = diagnosticGroup6.matches(diagnosticType9);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup6;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setCharno(17);
        int int19 = node3.getCharno();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node3.siblings();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(nodeIterable20);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        compilerOptions0.setColorizeErrorOutput(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler14, callback15);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        java.lang.String str31 = node29.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.aliasKeywords = true;
        boolean boolean35 = compilerOptions32.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap36 = null;
        compilerOptions32.cssRenamingMap = cssRenamingMap36;
        compilerOptions32.setRemoveAbstractMethods(false);
        boolean boolean40 = compilerOptions32.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions32.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray45 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError46 = nodeTraversal16.makeError(node29, checkLevel41, diagnosticType44, strArray45);
        com.google.javascript.rhino.jstype.JSType jSType47 = node29.getJSType();
        java.lang.String str48 = node6.checkTreeEquals(node29);
        com.google.javascript.rhino.jstype.JSType jSType49 = node6.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(40, node53, node56, node59, node62);
        boolean boolean64 = node53.isLocalResultCall();
        node53.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node67 = node6.clonePropsFrom(node53);
        int int68 = node6.getChildCount();
        com.google.javascript.rhino.Node node69 = node6.detachFromParent();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(node69);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        java.lang.Class<?> wildcardClass9 = compilerOptions0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        compilerOptions0.tightenTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format15 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions14.sourceMapFormat = format15;
        compilerOptions14.unaliasableGlobals = "";
        compilerOptions14.collapseProperties = true;
        compilerOptions14.checkTypedPropertyCalls = false;
        java.lang.Class<?> wildcardClass23 = compilerOptions14.getClass();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy24 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions14.propertyRenaming = propertyRenamingPolicy24;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy24;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy24 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy24.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
//        java.io.PrintStream printStream10 = null;
//        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
//        compiler11.disableThreads();
//        java.nio.charset.Charset charset14 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset14);
//        java.lang.String str16 = jSSourceFile15.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst17 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile15);
//        com.google.javascript.rhino.Node node18 = compiler11.parse(jSSourceFile15);
//        java.nio.charset.Charset charset20 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset20);
//        com.google.javascript.rhino.Node node22 = compiler11.parse(jSSourceFile21);
//        com.google.javascript.jscomp.SourceMap sourceMap23 = compiler11.getSourceMap();
//        com.google.javascript.rhino.Context context24 = com.google.javascript.rhino.Context.enter();
//        int int25 = context24.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = context24.getErrorReporter();
//        int int27 = context24.getInstructionObserverThreshold();
//        java.util.Locale locale28 = context24.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException30 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException30.initLineSource("Unknown class name");
//        int int33 = evaluatorException30.lineNumber();
//        context24.removeThreadLocal((java.lang.Object) int33);
//        java.io.PrintStream printStream35 = null;
//        com.google.javascript.jscomp.Compiler compiler36 = new com.google.javascript.jscomp.Compiler(printStream35);
//        compiler36.disableThreads();
//        context24.removeThreadLocal((java.lang.Object) compiler36);
//        com.google.javascript.jscomp.Scope scope39 = compiler36.getTopScope();
//        java.nio.charset.Charset charset41 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset41);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format45 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions44.sourceMapFormat = format45;
//        compilerOptions44.unaliasableGlobals = "";
//        boolean boolean49 = compilerOptions44.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet50 = compilerOptions44.stripTypePrefixes;
//        boolean boolean51 = compilerOptions44.devirtualizePrototypeMethods;
//        boolean boolean52 = compilerOptions44.gatherCssNames;
//        boolean boolean53 = compilerOptions44.prettyPrint;
//        compilerOptions44.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result56 = compiler36.compile(jSSourceFile42, jSSourceFileArray43, compilerOptions44);
//        java.io.PrintStream printStream57 = null;
//        com.google.javascript.jscomp.Compiler compiler58 = new com.google.javascript.jscomp.Compiler(printStream57);
//        compiler58.disableThreads();
//        java.nio.charset.Charset charset61 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset61);
//        java.lang.String str63 = jSSourceFile62.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst64 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile62);
//        com.google.javascript.rhino.Node node65 = compiler58.parse(jSSourceFile62);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile67 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray70 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile62, jSSourceFile67, jSSourceFile69 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions71.aliasKeywords = true;
//        boolean boolean74 = compilerOptions71.generateExports;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap75 = compilerOptions71.cssRenamingMap;
//        compiler11.init(jSSourceFileArray43, jSSourceFileArray70, compilerOptions71);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray77 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions78.aliasKeywords = true;
//        compilerOptions78.markAsCompiled = false;
//        java.lang.Object obj83 = compilerOptions78.clone();
//        compilerOptions78.deadAssignmentElimination = true;
//        boolean boolean86 = compilerOptions78.markNoSideEffectCalls;
//        try {
//            compiler1.init(jSSourceFileArray43, jSSourceFileArray77, compilerOptions78);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSTypeRegistry9);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertNull(node18);
//        org.junit.Assert.assertNotNull(jSSourceFile21);
//        org.junit.Assert.assertNull(node22);
//        org.junit.Assert.assertNull(sourceMap23);
//        org.junit.Assert.assertNotNull(context24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNull(errorReporter26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNull(scope39);
//        org.junit.Assert.assertNotNull(jSSourceFile42);
//        org.junit.Assert.assertNotNull(jSSourceFileArray43);
//        org.junit.Assert.assertNotNull(format45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(strSet50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(result56);
//        org.junit.Assert.assertNotNull(jSSourceFile62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
//        org.junit.Assert.assertNull(node65);
//        org.junit.Assert.assertNotNull(jSSourceFile67);
//        org.junit.Assert.assertNotNull(jSSourceFile69);
//        org.junit.Assert.assertNotNull(jSSourceFileArray70);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNull(cssRenamingMap75);
//        org.junit.Assert.assertNotNull(obj83);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule5 = compilerInput4.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        compilerInput7.clearAst();
        try {
            java.lang.String str9 = compilerInput7.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler1, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        java.lang.String str18 = node16.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.aliasKeywords = true;
        boolean boolean22 = compilerOptions19.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap23 = null;
        compilerOptions19.cssRenamingMap = cssRenamingMap23;
        compilerOptions19.setRemoveAbstractMethods(false);
        boolean boolean27 = compilerOptions19.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions19.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray32 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal3.makeError(node16, checkLevel28, diagnosticType31, strArray32);
        try {
            com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        try {
            java.lang.String[] strArray3 = compiler1.toSourceArray(jSModule2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("OR hi! [directives: []]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        int int15 = context0.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("(Named type with empty name component)", "Named type with empty name component");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("bitxor", "null", "Named type with empty name component", 0, ": WARNING - \n", (int) (short) 0);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean10 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        compilerOptions0.setManageClosureDependencies(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.lineLengthThreshold(37);
        boolean boolean13 = compilerOptions0.markAsCompiled;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.reportUnknownTypes;
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        java.lang.Class<?> wildcardClass8 = sourceAst7.getClass();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getErrors();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler1.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        loggerErrorManager15.generateReport();
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format19 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions18.sourceMapFormat = format19;
        compilerOptions18.unaliasableGlobals = "";
        boolean boolean23 = compilerOptions18.disambiguateProperties;
        java.util.Set<java.lang.String> strSet24 = compilerOptions18.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy25 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy26 = null;
        compilerOptions18.setRenamingPolicy(variableRenamingPolicy25, propertyRenamingPolicy26);
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions18.checkRequires;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler29 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback30 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal31 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler29, callback30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(40, node35, node38, node41, node44);
        java.lang.String str46 = node44.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.aliasKeywords = true;
        boolean boolean50 = compilerOptions47.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap51 = null;
        compilerOptions47.cssRenamingMap = cssRenamingMap51;
        compilerOptions47.setRemoveAbstractMethods(false);
        boolean boolean55 = compilerOptions47.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel56 = compilerOptions47.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray60 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError61 = nodeTraversal31.makeError(node44, checkLevel56, diagnosticType59, strArray60);
        java.lang.String str62 = jSError61.toString();
        java.lang.String str63 = jSError61.toString();
        java.lang.String str64 = jSError61.description;
        loggerErrorManager15.report(checkLevel28, jSError61);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(format19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy25.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + checkLevel56 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel56.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + ".  at (unknown source) line (unknown line) : (unknown column)" + "'", str62.equals(".  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + ".  at (unknown source) line (unknown line) : (unknown column)" + "'", str63.equals(".  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        context0.setLanguageVersion(0);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        java.lang.Throwable[] throwableArray4 = ecmaError2.getSuppressed();
        java.lang.String str5 = ecmaError2.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0);
        com.google.javascript.rhino.Node node40 = node15.copyInformationFromForTree(node39);
        boolean boolean41 = node39.isNoSideEffectsCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("null", "instanceof");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        compilerOptions14.markAsCompiled = false;
        compilerOptions14.setRemoveAbstractMethods(true);
        compilerOptions14.checkUnusedPropertiesEarly = false;
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.aliasKeywords = true;
        boolean boolean27 = compilerOptions24.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap28 = null;
        compilerOptions24.cssRenamingMap = cssRenamingMap28;
        compilerOptions24.setRemoveAbstractMethods(false);
        compilerOptions24.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray34 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard35 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray34);
        compilerOptions24.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard35);
        compilerOptions24.ambiguateProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions24.reportUnknownTypes;
        compilerOptions0.checkMethods = checkLevel39;
        java.lang.Class<?> wildcardClass41 = compilerOptions0.getClass();
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray34);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions1.sourceMapFormat = format2;
        compilerOptions1.unaliasableGlobals = "";
        compilerOptions1.collapseProperties = true;
        compilerOptions1.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str11 = compilerOptions1.appNameStr;
        compilerOptions1.nameReferenceReportPath = "<No stack trace available>";
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions1.checkUnreachableCode;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard15 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel14);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.lang.String str5 = compiler1.getSourceLine("Not declared as a type name", (int) (short) -1);
        try {
            java.lang.String str8 = compiler1.getSourceLine("false", 25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType30 = null;
        closureCodingConvention0.applySubclassRelationship(functionType28, functionType29, subclassType30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        java.lang.String str1 = diagnosticGroup0.toString();
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<missingProperties>" + "'", str1.equals("DiagnosticGroup<missingProperties>"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.instrumentForCoverage = true;
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format12 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions11.sourceMapFormat = format12;
        compilerOptions11.groupVariableDeclarations = true;
        compilerOptions11.setDefineToStringLiteral("eof", "hi!");
        byte[] byteArray19 = compilerOptions11.inputVariableMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(40, node24, node27, node30, node33);
        boolean boolean35 = detailLevel20.apply(node30);
        compilerOptions11.sourceMapDetailLevel = detailLevel20;
        compilerOptions0.sourceMapDetailLevel = detailLevel20;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(format12);
        org.junit.Assert.assertNull(byteArray19);
        org.junit.Assert.assertNotNull(detailLevel20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        java.lang.String str29 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(40, node34, node37, node40, node43);
        boolean boolean45 = node34.isLocalResultCall();
        int int46 = node34.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection47 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node34);
        boolean boolean48 = node34.isSyntheticBlock();
        com.google.javascript.rhino.Node node49 = node34.getParent();
        com.google.javascript.rhino.Node node50 = node49.removeFirstChild();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(0, node49);
        com.google.javascript.rhino.Node node52 = node49.cloneNode();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel53 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel54 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(40, node58, node61, node64, node67);
        boolean boolean69 = detailLevel54.apply(node64);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable70 = node64.getAncestors();
        boolean boolean71 = detailLevel53.apply(node64);
        java.lang.String str72 = closureCodingConvention0.extractClassNameIfRequire(node52, node64);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(nodeCollection47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(detailLevel53);
        org.junit.Assert.assertNotNull(detailLevel54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(ancestorIterable70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNull(str72);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        boolean boolean6 = compilerOptions0.inlineFunctions;
        compilerOptions0.generatePseudoNames = false;
        java.lang.String str9 = compilerOptions0.locale;
        boolean boolean10 = compilerOptions0.decomposeExpressions;
        compilerOptions0.generateExports = false;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean9 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(codingConvention10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0);
        com.google.javascript.rhino.Node node40 = node15.copyInformationFromForTree(node39);
        com.google.javascript.rhino.Node node41 = node39.removeChildren();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node41);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.rhino.Node node15 = compiler1.parse(jSSourceFile12);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        boolean boolean10 = compilerOptions0.inlineVariables;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.enableRuntimeTypeCheck("eof");
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.reserveRawExports = false;
        boolean boolean12 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.collapseVariableDeclarations = false;
        boolean boolean15 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.aliasKeywords = true;
        boolean boolean19 = compilerOptions16.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap20 = null;
        compilerOptions16.cssRenamingMap = cssRenamingMap20;
        compilerOptions16.setRemoveAbstractMethods(false);
        boolean boolean24 = compilerOptions16.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention25 = null;
        compilerOptions16.setCodingConvention(codingConvention25);
        boolean boolean27 = compilerOptions16.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions16.reportUnknownTypes;
        compilerOptions0.aggressiveVarCheck = checkLevel28;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = null;
        compilerOptions0.checkRequires = checkLevel30;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.rhino.Node node15 = compiler1.parse(jSSourceFile12);
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler1.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format18 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions17.sourceMapFormat = format18;
        compilerOptions17.unaliasableGlobals = "";
        compilerOptions17.collapseProperties = true;
        compilerOptions17.ideMode = true;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap26 = null;
        compilerOptions17.cssRenamingMap = cssRenamingMap26;
        compiler1.initOptions(compilerOptions17);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(format18);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        compilerOptions0.coalesceVariableNames = true;
        java.lang.String str8 = compilerOptions0.appNameStr;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        compilerOptions0.coalesceVariableNames = true;
        java.lang.String[] strArray39 = new java.lang.String[] { "error reporter", "null", "(false)", "Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", "com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", "DiagnosticGroup<accessControls>", "DiagnosticGroup<missingProperties>", "null", "goog.global", "", "// Input %num%", ": WARNING - \n", "eof", "goog.global", "false", ": ", "goog.abstractMethod", "bitxor", "(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", "goog.global", "eof", "OR hi!\n", "NAME  1\n", "com.google.javascript.rhino.EcmaError: : ", "DiagnosticGroup<missingProperties>", "NAME  1\n", "Not declared as a type name", "(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", "(Unknown class name)", "error reporter", "false" };
        java.util.ArrayList<java.lang.String> strList40 = new java.util.ArrayList<java.lang.String>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList40, strArray39);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList40);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        java.lang.String str10 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = compilerOptions0.propertyRenaming;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean14 = compilerOptions0.aliasKeywords;
        compilerOptions0.collapseProperties = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.aggressiveVarCheck;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap12 = compilerOptions0.getTweakReplacements();
        boolean boolean13 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap11 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap11;
        boolean boolean13 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("Not declared as a type name", "(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )", (int) (byte) 10, "bitxor", (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -3");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput4.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.sourceMapOutputPath = "0";
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("(Named type with empty name component)", "", 37, "OR hi!\n", 11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        ecmaError2.initColumnNumber(16);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError2.getScriptStackTrace(filenameFilter6);
        ecmaError2.initLineSource(".  at (unknown source) line (unknown line) : (unknown column)");
        int int10 = ecmaError2.getLineNumber();
        java.lang.String str11 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ": " + "'", str11.equals(": "));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        boolean boolean11 = context0.hasCompileFunctionsWithDynamicScope();
//        boolean boolean12 = context0.hasCompileFunctionsWithDynamicScope();
//        int int13 = context0.getLanguageVersion();
//        context0.setGeneratingSource(true);
//        int int16 = context0.getLanguageVersion();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkRequires;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.setTweakToNumberLiteral("(false)", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.NodeUtil.newExpr(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(40, node78, node81, node84, node87);
        node84.setType((int) '#');
        boolean boolean92 = node84.getBooleanProp((int) (short) -1);
        boolean boolean93 = node74.isEquivalentTo(node84);
        com.google.javascript.rhino.Node node94 = node74.getParent();
        com.google.javascript.rhino.jstype.JSType jSType95 = null;
        node94.setJSType(jSType95);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(node94);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        compilerOptions14.markAsCompiled = false;
        compilerOptions14.setRemoveAbstractMethods(true);
        compilerOptions14.checkUnusedPropertiesEarly = false;
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.aliasKeywords = true;
        boolean boolean27 = compilerOptions24.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap28 = null;
        compilerOptions24.cssRenamingMap = cssRenamingMap28;
        compilerOptions24.setRemoveAbstractMethods(false);
        compilerOptions24.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray34 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard35 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray34);
        compilerOptions24.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard35);
        compilerOptions24.ambiguateProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions24.reportUnknownTypes;
        compilerOptions0.checkMethods = checkLevel39;
        boolean boolean41 = compilerOptions0.groupVariableDeclarations;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray34);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        compilerOptions1.markAsCompiled = false;
        compilerOptions1.setRemoveAbstractMethods(true);
        compilerOptions1.inputDelimiter = "Not declared as a type name";
        compilerOptions1.removeTryCatchFinally = false;
        compilerOptions1.removeTryCatchFinally = false;
        boolean boolean14 = compilerOptions1.inlineConstantVars;
        boolean boolean15 = compilerOptions1.optimizeArgumentsArray;
        compilerOptions1.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        compilerOptions18.markAsCompiled = false;
        compilerOptions18.setRemoveAbstractMethods(true);
        compilerOptions18.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.checkUndefinedProperties;
        java.lang.String str28 = compilerOptions18.debugFunctionSideEffectsPath;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions18.checkFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.aliasKeywords = true;
        boolean boolean33 = compilerOptions30.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap34 = null;
        compilerOptions30.cssRenamingMap = cssRenamingMap34;
        compilerOptions30.setRemoveAbstractMethods(false);
        boolean boolean38 = compilerOptions30.lineBreak;
        java.lang.Class<?> wildcardClass39 = compilerOptions30.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions30.reportMissingOverride;
        boolean boolean41 = compilerOptions30.specializeInitialModule;
        java.lang.String str42 = compilerOptions30.aliasableGlobals;
        compilerOptions30.inlineAnonymousFunctionExpressions = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat45 = compilerOptions30.errorFormat;
        try {
            java.lang.String str46 = com.google.javascript.rhino.ScriptRuntime.getMessage3("0", (java.lang.Object) compilerOptions1, (java.lang.Object) compilerOptions18, (java.lang.Object) compilerOptions30);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 0");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(errorFormat45);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
//        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
//        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler1.getSourceMap();
//        com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter();
//        int int15 = context14.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = context14.getErrorReporter();
//        int int17 = context14.getInstructionObserverThreshold();
//        java.util.Locale locale18 = context14.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException20 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException20.initLineSource("Unknown class name");
//        int int23 = evaluatorException20.lineNumber();
//        context14.removeThreadLocal((java.lang.Object) int23);
//        java.io.PrintStream printStream25 = null;
//        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler(printStream25);
//        compiler26.disableThreads();
//        context14.removeThreadLocal((java.lang.Object) compiler26);
//        com.google.javascript.jscomp.Scope scope29 = compiler26.getTopScope();
//        java.nio.charset.Charset charset31 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset31);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format35 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions34.sourceMapFormat = format35;
//        compilerOptions34.unaliasableGlobals = "";
//        boolean boolean39 = compilerOptions34.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet40 = compilerOptions34.stripTypePrefixes;
//        boolean boolean41 = compilerOptions34.devirtualizePrototypeMethods;
//        boolean boolean42 = compilerOptions34.gatherCssNames;
//        boolean boolean43 = compilerOptions34.prettyPrint;
//        compilerOptions34.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result46 = compiler26.compile(jSSourceFile32, jSSourceFileArray33, compilerOptions34);
//        java.io.PrintStream printStream47 = null;
//        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler(printStream47);
//        compiler48.disableThreads();
//        java.nio.charset.Charset charset51 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset51);
//        java.lang.String str53 = jSSourceFile52.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst54 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile52);
//        com.google.javascript.rhino.Node node55 = compiler48.parse(jSSourceFile52);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray60 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile52, jSSourceFile57, jSSourceFile59 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions61.aliasKeywords = true;
//        boolean boolean64 = compilerOptions61.generateExports;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap65 = compilerOptions61.cssRenamingMap;
//        compiler1.init(jSSourceFileArray33, jSSourceFileArray60, compilerOptions61);
//        com.google.javascript.rhino.Node node67 = compiler1.getRoot();
//        try {
//            java.lang.String[] strArray68 = compiler1.toSourceArray();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.RuntimeException: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNull(node12);
//        org.junit.Assert.assertNull(sourceMap13);
//        org.junit.Assert.assertNotNull(context14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNull(errorReporter16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNull(scope29);
//        org.junit.Assert.assertNotNull(jSSourceFile32);
//        org.junit.Assert.assertNotNull(jSSourceFileArray33);
//        org.junit.Assert.assertNotNull(format35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(strSet40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(result46);
//        org.junit.Assert.assertNotNull(jSSourceFile52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
//        org.junit.Assert.assertNull(node55);
//        org.junit.Assert.assertNotNull(jSSourceFile57);
//        org.junit.Assert.assertNotNull(jSSourceFile59);
//        org.junit.Assert.assertNotNull(jSSourceFileArray60);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNull(cssRenamingMap65);
//        org.junit.Assert.assertNull(node67);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        try {
//            com.google.javascript.rhino.Context.reportError("com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format5 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions4.sourceMapFormat = format5;
        compilerOptions4.unaliasableGlobals = "";
        boolean boolean9 = compilerOptions4.disambiguateProperties;
        java.util.Set<java.lang.String> strSet10 = compilerOptions4.stripTypePrefixes;
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.deadAssignmentElimination = true;
        compilerOptions4.debugFunctionSideEffectsPath = "";
        java.lang.RuntimeException runtimeException17 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) jSModuleGraph3, (java.lang.Object) compilerOptions4);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule19 = null;
        com.google.javascript.jscomp.JSModule jSModule20 = null;
        com.google.javascript.jscomp.JSModule jSModule21 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule19, jSModule20);
        com.google.javascript.jscomp.JSModule jSModule22 = null;
        com.google.javascript.jscomp.JSModule jSModule23 = null;
        try {
            boolean boolean24 = jSModuleGraph3.dependsOn(jSModule22, jSModule23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(format5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNotNull(runtimeException17);
        org.junit.Assert.assertNull(jSModule21);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.aliasKeywords = true;
        compilerOptions34.markAsCompiled = false;
        compilerOptions34.setRemoveAbstractMethods(true);
        compilerOptions34.inputDelimiter = "Not declared as a type name";
        compilerOptions34.removeTryCatchFinally = false;
        compilerOptions34.removeTryCatchFinally = false;
        boolean boolean47 = compilerOptions34.inlineConstantVars;
        node15.putProp(9, (java.lang.Object) compilerOptions34);
        compilerOptions34.optimizeParameters = true;
        java.lang.String str51 = compilerOptions34.reportPath;
        boolean boolean52 = compilerOptions34.inlineConstantVars;
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        long long2 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNull(errorReporter3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker14 = compiler1.tracker;
        try {
            java.lang.String[] strArray15 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(performanceTracker14);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        java.lang.String str15 = node13.getString();
        com.google.javascript.rhino.Node node16 = node13.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node13.getJSDocInfo();
        node13.setString("false");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
        java.lang.Object obj35 = node29.getProp((-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(40, node39, node42, node45, node48);
        com.google.javascript.rhino.Node node50 = node39.getLastSibling();
        boolean boolean51 = node50.isQuotedString();
        java.lang.String str52 = node29.checkTreeEquals(node50);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable57 = node56.children();
        try {
            com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (byte) 10, node13, node29, node56, 160, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(nodeIterable57);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setDefineToStringLiteral("eof", "hi!");
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(40, node13, node16, node19, node22);
        boolean boolean24 = detailLevel9.apply(node19);
        compilerOptions0.sourceMapDetailLevel = detailLevel9;
        boolean boolean26 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.enableExternExports(false);
        java.lang.String str29 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        boolean boolean10 = compilerOptions0.inlineVariables;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkGlobalNamesLevel;
        java.lang.String str12 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions2.aliasKeywords = true;
//        boolean boolean5 = compilerOptions2.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
//        compilerOptions2.cssRenamingMap = cssRenamingMap6;
//        compilerOptions2.setRemoveAbstractMethods(false);
//        boolean boolean10 = compilerOptions2.lineBreak;
//        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
//        boolean boolean12 = compilerOptions2.ambiguateProperties;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions13.aliasKeywords = true;
//        boolean boolean16 = compilerOptions13.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
//        compilerOptions13.cssRenamingMap = cssRenamingMap17;
//        compilerOptions13.setRemoveAbstractMethods(false);
//        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
//        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
//        compilerOptions2.checkMethods = checkLevel22;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup25;
//        boolean boolean27 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup25);
//        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup25;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap6;
        compilerOptions0.setRemoveAbstractMethods(true);
        com.google.javascript.jscomp.CodingConvention codingConvention10 = compilerOptions0.getCodingConvention();
        compilerOptions0.optimizeCalls = true;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, false);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config3);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        java.lang.String str12 = compilerOptions2.jsOutputFile;
//        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions2.checkRequires;
//        boolean boolean14 = compilerOptions2.moveFunctionDeclarations;
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.aliasKeywords = true;
        compilerOptions12.markAsCompiled = false;
        compilerOptions12.setRemoveAbstractMethods(true);
        compilerOptions12.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions12.checkUndefinedProperties;
        compilerOptions0.checkRequires = checkLevel21;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions0.reportMissingOverride;
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        boolean boolean2 = context0.isGeneratingDebugChanged();
//        context0.setGeneratingSource(false);
//        context0.setInstructionObserverThreshold(8);
//        java.util.Locale locale7 = context0.getLocale();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(locale7);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler14, callback15);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        java.lang.String str31 = node29.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.aliasKeywords = true;
        boolean boolean35 = compilerOptions32.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap36 = null;
        compilerOptions32.cssRenamingMap = cssRenamingMap36;
        compilerOptions32.setRemoveAbstractMethods(false);
        boolean boolean40 = compilerOptions32.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions32.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray45 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError46 = nodeTraversal16.makeError(node29, checkLevel41, diagnosticType44, strArray45);
        com.google.javascript.rhino.jstype.JSType jSType47 = node29.getJSType();
        java.lang.String str48 = node6.checkTreeEquals(node29);
        com.google.javascript.rhino.jstype.JSType jSType49 = node6.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(40, node53, node56, node59, node62);
        boolean boolean64 = node53.isLocalResultCall();
        node53.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node67 = node6.clonePropsFrom(node53);
        node6.setVarArgs(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(40, node18, node21, node24, node27);
        node24.setType((int) '#');
        com.google.javascript.rhino.Node node31 = node9.clonePropsFrom(node24);
        boolean boolean32 = node24.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.deadAssignmentElimination = true;
        boolean boolean11 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.setDefineToNumberLiteral("", 8);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripNameSuffixes;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        boolean boolean4 = compilerOptions0.checkSymbols;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format6 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions5.sourceMapFormat = format6;
        compilerOptions5.groupVariableDeclarations = true;
        boolean boolean10 = compilerOptions5.foldConstants;
        java.lang.String str11 = compilerOptions5.aliasStringsBlacklist;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.aliasKeywords = true;
        boolean boolean15 = compilerOptions12.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap16 = null;
        compilerOptions12.cssRenamingMap = cssRenamingMap16;
        compilerOptions12.setRemoveAbstractMethods(false);
        boolean boolean20 = compilerOptions12.lineBreak;
        boolean boolean21 = compilerOptions12.markNoSideEffectCalls;
        boolean boolean22 = compilerOptions12.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format24 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions23.sourceMapFormat = format24;
        compilerOptions23.unaliasableGlobals = "";
        boolean boolean28 = compilerOptions23.disambiguateProperties;
        java.util.Set<java.lang.String> strSet29 = compilerOptions23.stripTypePrefixes;
        compilerOptions12.stripNameSuffixes = strSet29;
        compilerOptions5.setIdGenerators(strSet29);
        compilerOptions0.aliasableStrings = strSet29;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(format24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet29);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.aliasKeywords = true;
        compilerOptions16.markAsCompiled = false;
        compilerOptions16.setRemoveAbstractMethods(true);
        boolean boolean23 = compilerOptions16.checkTypedPropertyCalls;
        compilerOptions16.extractPrototypeMemberDeclarations = true;
        java.lang.String str26 = compilerOptions16.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions16.propertyRenaming;
        java.util.Set<java.lang.String> strSet28 = compilerOptions16.stripTypePrefixes;
        compilerOptions0.stripTypePrefixes = strSet28;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet28);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setDefineToStringLiteral("eof", "hi!");
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(40, node13, node16, node19, node22);
        boolean boolean24 = detailLevel9.apply(node19);
        compilerOptions0.sourceMapDetailLevel = detailLevel9;
        boolean boolean26 = compilerOptions0.generateExports;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        context0.addActivationName("false");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions6.aliasKeywords = true;
//        compilerOptions6.markAsCompiled = false;
//        java.lang.Object obj11 = compilerOptions6.clone();
//        compilerOptions6.deadAssignmentElimination = true;
//        compilerOptions6.setTweakToDoubleLiteral("error reporter", 0.0d);
//        com.google.javascript.jscomp.CodingConvention codingConvention17 = compilerOptions6.getCodingConvention();
//        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig18 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions6);
//        byte[] byteArray19 = compilerOptions6.inputPropertyMapSerialized;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = compilerOptions6.sourceMapDetailLevel;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format22 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions21.sourceMapFormat = format22;
//        compilerOptions21.unaliasableGlobals = "";
//        boolean boolean26 = compilerOptions21.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet27 = compilerOptions21.stripTypePrefixes;
//        boolean boolean28 = compilerOptions21.strictMessageReplacement;
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler29 = compilerOptions21.getAliasTransformationHandler();
//        compilerOptions6.setAliasTransformationHandler(aliasTransformationHandler29);
//        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions6.checkMethods;
//        try {
//            context0.unseal((java.lang.Object) compilerOptions6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNull(codingConvention17);
//        org.junit.Assert.assertNull(byteArray19);
//        org.junit.Assert.assertNotNull(detailLevel20);
//        org.junit.Assert.assertNotNull(format22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(strSet27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(aliasTransformationHandler29);
//        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format9 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions8.sourceMapFormat = format9;
        compilerOptions8.unaliasableGlobals = "";
        boolean boolean13 = compilerOptions8.disambiguateProperties;
        java.util.Set<java.lang.String> strSet14 = compilerOptions8.stripTypePrefixes;
        boolean boolean15 = compilerOptions8.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler16 = compilerOptions8.getAliasTransformationHandler();
        boolean boolean17 = compilerOptions8.removeDeadCode;
        boolean boolean18 = compilerOptions8.inlineAnonymousFunctionExpressions;
        boolean boolean19 = compilerOptions8.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions8.checkProvides;
        compilerOptions0.checkGlobalThisLevel = checkLevel20;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        java.lang.String str15 = node13.getString();
        com.google.javascript.rhino.Node node16 = node13.getLastChild();
        node13.setOptionalArg(false);
        com.google.javascript.rhino.Node node19 = node13.detachFromParent();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder20 = node13.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node21 = null;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler22 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler22, callback23);
        com.google.javascript.jscomp.Compiler compiler25 = nodeTraversal24.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention26 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean28 = closureCodingConvention26.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        java.lang.String str43 = node41.getString();
        com.google.javascript.rhino.Node node44 = node41.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = node41.getJSDocInfo();
        node41.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship48 = closureCodingConvention26.getDelegateRelationship(node41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray52 = null;
        com.google.javascript.jscomp.JSError jSError53 = nodeTraversal24.makeError(node41, diagnosticType51, strArray52);
        try {
            com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(7, node13, node21, node41, 110, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(compiler25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertNull(delegateRelationship48);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(jSError53);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(40, node18, node21, node24, node27);
        node24.setType((int) '#');
        com.google.javascript.rhino.Node node31 = node9.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node32 = node9.removeChildren();
        try {
            boolean boolean33 = node32.hasChildren();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(node32);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap6;
        boolean boolean8 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.setRemoveAbstractMethods(false);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat4;
        compilerOptions0.reserveRawExports = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray9 = anonymousFunctionNamingPolicy8.getReservedCharacters();
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy8;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap11;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.instrumentForCoverageOnly = false;
        boolean boolean19 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode20 = compilerOptions0.tracer;
        compilerOptions0.checkControlStructures = true;
        compilerOptions0.ideMode = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + tracerMode20 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode20.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.enableExternExports(true);
        boolean boolean14 = compilerOptions0.checkDuplicateMessages;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.aliasKeywords = true;
        compilerOptions16.markAsCompiled = false;
        compilerOptions16.setRemoveAbstractMethods(true);
        boolean boolean23 = compilerOptions16.checkTypedPropertyCalls;
        compilerOptions16.extractPrototypeMemberDeclarations = true;
        java.lang.String str26 = compilerOptions16.renamePrefix;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions16.propertyRenaming;
        java.util.Set<java.lang.String> strSet28 = compilerOptions16.stripTypePrefixes;
        java.lang.RuntimeException runtimeException29 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) strSet15, (java.lang.Object) strSet28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertNotNull(runtimeException29);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        java.lang.String str3 = closureCodingConvention1.getDelegateSuperclassName();
        boolean boolean5 = closureCodingConvention1.isSuperClassReference("goog.global");
        java.lang.String str6 = closureCodingConvention1.getExportSymbolFunction();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.aliasableGlobals = "";
        compilerOptions0.checkEs5Strict = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportMissingOverride;
        compilerOptions0.inlineVariables = true;
        java.lang.String str13 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        boolean boolean11 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.removeEmptyFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        java.lang.String str14 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) true);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "true" + "'", str14.equals("true"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions0.cssRenamingMap;
        boolean boolean5 = compilerOptions0.aliasKeywords;
        boolean boolean6 = compilerOptions0.generateExports;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap9 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap9;
        boolean boolean11 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 1);
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setReturnsTainted();
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.lang.String str5 = compiler1.getSourceLine("Not declared as a type name", (int) (short) -1);
//        java.io.PrintStream printStream6 = null;
//        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
//        compiler7.disableThreads();
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
//        java.lang.String str12 = jSSourceFile11.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst13 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
//        com.google.javascript.rhino.Node node14 = compiler7.parse(jSSourceFile11);
//        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
//        com.google.javascript.rhino.Context context16 = com.google.javascript.rhino.Context.enter();
//        int int17 = context16.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = context16.getErrorReporter();
//        int int19 = context16.getInstructionObserverThreshold();
//        java.util.Locale locale20 = context16.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException22 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException22.initLineSource("Unknown class name");
//        int int25 = evaluatorException22.lineNumber();
//        context16.removeThreadLocal((java.lang.Object) int25);
//        java.io.PrintStream printStream27 = null;
//        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler(printStream27);
//        compiler28.disableThreads();
//        context16.removeThreadLocal((java.lang.Object) compiler28);
//        com.google.javascript.jscomp.Scope scope31 = compiler28.getTopScope();
//        java.nio.charset.Charset charset33 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset33);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray35 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format37 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions36.sourceMapFormat = format37;
//        compilerOptions36.unaliasableGlobals = "";
//        boolean boolean41 = compilerOptions36.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet42 = compilerOptions36.stripTypePrefixes;
//        boolean boolean43 = compilerOptions36.devirtualizePrototypeMethods;
//        boolean boolean44 = compilerOptions36.gatherCssNames;
//        boolean boolean45 = compilerOptions36.prettyPrint;
//        compilerOptions36.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result48 = compiler28.compile(jSSourceFile34, jSSourceFileArray35, compilerOptions36);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format50 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions49.sourceMapFormat = format50;
//        compilerOptions49.unaliasableGlobals = "";
//        compilerOptions49.collapseProperties = true;
//        compilerOptions49.checkTypedPropertyCalls = false;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel58 = compilerOptions49.sourceMapDetailLevel;
//        com.google.javascript.jscomp.Result result59 = compiler1.compile(jSSourceFile11, jSSourceFileArray35, compilerOptions49);
//        java.lang.String str60 = compiler1.toSource();
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNull(node14);
//        org.junit.Assert.assertNotNull(context16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNull(errorReporter18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(locale20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNull(scope31);
//        org.junit.Assert.assertNotNull(jSSourceFile34);
//        org.junit.Assert.assertNotNull(jSSourceFileArray35);
//        org.junit.Assert.assertNotNull(format37);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(strSet42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(result48);
//        org.junit.Assert.assertNotNull(format50);
//        org.junit.Assert.assertNotNull(detailLevel58);
//        org.junit.Assert.assertNotNull(result59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setCharno(17);
        int int19 = node3.getCharno();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection20 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        java.lang.Object obj22 = node3.getProp((int) (byte) -1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(nodeCollection20);
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("instanceof", "goog.exportProperty");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler14, callback15);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        java.lang.String str31 = node29.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.aliasKeywords = true;
        boolean boolean35 = compilerOptions32.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap36 = null;
        compilerOptions32.cssRenamingMap = cssRenamingMap36;
        compilerOptions32.setRemoveAbstractMethods(false);
        boolean boolean40 = compilerOptions32.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions32.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray45 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError46 = nodeTraversal16.makeError(node29, checkLevel41, diagnosticType44, strArray45);
        com.google.javascript.rhino.jstype.JSType jSType47 = node29.getJSType();
        java.lang.String str48 = node6.checkTreeEquals(node29);
        com.google.javascript.rhino.jstype.JSType jSType49 = node6.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(40, node53, node56, node59, node62);
        boolean boolean64 = node53.isLocalResultCall();
        node53.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node67 = node6.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node68 = node67.cloneNode();
        com.google.javascript.rhino.Node node70 = node68.getChildAtIndex((-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(node70);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.lang.String str5 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Unknown class name");
        java.io.Reader reader3 = sourceFile2.getCodeReader();
        java.lang.String str4 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(reader3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Not declared as a type name" + "'", str4.equals("Not declared as a type name"));
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test412");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
//        boolean boolean4 = context0.isGeneratingSource();
//        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter();
//        int int6 = context5.getLanguageVersion();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context5, 0L);
//        boolean boolean9 = context5.isGeneratingSource();
//        java.util.Locale locale10 = context5.getLocale();
//        java.util.Locale locale11 = context0.setLocale(locale10);
//        boolean boolean12 = context0.isGeneratingSource();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(context5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(locale10);
//        org.junit.Assert.assertNull(locale11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("<No stack trace available>", "com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : ");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test415");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.util.Locale locale1 = context0.getLocale();
//        try {
//            com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(locale1);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean13 = compilerOptions0.inlineConstantVars;
        boolean boolean14 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.generateExports = false;
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.setLooseTypes(true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.aliasKeywords = true;
        compilerOptions1.markAsCompiled = false;
        compilerOptions1.setRemoveAbstractMethods(true);
        boolean boolean8 = compilerOptions1.checkTypedPropertyCalls;
        compilerOptions1.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format12 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions11.sourceMapFormat = format12;
        compilerOptions11.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing16 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean17 = tweakProcessing16.shouldStrip();
        compilerOptions11.setTweakProcessing(tweakProcessing16);
        compilerOptions1.setTweakProcessing(tweakProcessing16);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions1.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name: com.google.javascript.rhino.EcmaError: : ", checkLevel20, "(false)");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(format12);
        org.junit.Assert.assertTrue("'" + tweakProcessing16 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing16.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType22);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(6, nodeArray2, 41, 34);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(11, nodeArray2);
        org.junit.Assert.assertNotNull(nodeArray2);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test423");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        context0.setCompileFunctionsWithDynamicScope(true);
//        java.lang.Object obj4 = context0.getDebuggerContextData();
//        java.lang.Object obj5 = context0.getDebuggerContextData();
//        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(40, node9, node12, node15, node18);
//        com.google.javascript.jscomp.AbstractCompiler abstractCompiler20 = null;
//        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler20, callback21);
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
//        java.lang.String str37 = node35.getString();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions38.aliasKeywords = true;
//        boolean boolean41 = compilerOptions38.strictMessageReplacement;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap42 = null;
//        compilerOptions38.cssRenamingMap = cssRenamingMap42;
//        compilerOptions38.setRemoveAbstractMethods(false);
//        boolean boolean46 = compilerOptions38.rewriteFunctionExpressions;
//        com.google.javascript.jscomp.CheckLevel checkLevel47 = compilerOptions38.aggressiveVarCheck;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.error("", "");
//        java.lang.String[] strArray51 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
//        com.google.javascript.jscomp.JSError jSError52 = nodeTraversal22.makeError(node35, checkLevel47, diagnosticType50, strArray51);
//        com.google.javascript.rhino.jstype.JSType jSType53 = node35.getJSType();
//        java.lang.String str54 = node12.checkTreeEquals(node35);
//        com.google.javascript.rhino.jstype.JSType jSType55 = node12.getJSType();
//        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
//        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(40, node59, node62, node65, node68);
//        boolean boolean70 = node59.isLocalResultCall();
//        node59.setSourcePositionForTree(0);
//        com.google.javascript.rhino.Node node73 = node12.clonePropsFrom(node59);
//        try {
//            context0.unseal((java.lang.Object) node59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(obj5);
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNotNull(node12);
//        org.junit.Assert.assertNotNull(node15);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNotNull(node32);
//        org.junit.Assert.assertNotNull(node35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType50);
//        org.junit.Assert.assertNotNull(strArray51);
//        org.junit.Assert.assertNotNull(jSError52);
//        org.junit.Assert.assertNull(jSType53);
//        org.junit.Assert.assertNull(str54);
//        org.junit.Assert.assertNull(jSType55);
//        org.junit.Assert.assertNotNull(node59);
//        org.junit.Assert.assertNotNull(node62);
//        org.junit.Assert.assertNotNull(node65);
//        org.junit.Assert.assertNotNull(node68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(node73);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention1);
        java.lang.String str3 = compilerOptions0.jsOutputFile;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        boolean boolean11 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.setManageClosureDependencies(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test426");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format3 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions2.sourceMapFormat = format3;
//        compilerOptions2.unaliasableGlobals = "";
//        boolean boolean7 = compilerOptions2.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet8 = compilerOptions2.stripTypePrefixes;
//        boolean boolean9 = compilerOptions2.strictMessageReplacement;
//        java.util.Set<java.lang.String> strSet10 = compilerOptions2.stripTypes;
//        context0.seal((java.lang.Object) compilerOptions2);
//        try {
//            context0.setCompileFunctionsWithDynamicScope(true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(format3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(strSet8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(strSet10);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap4 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap4;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setOutputCharset("com.google.javascript.rhino.EcmaError: : ");
        compilerOptions0.checkUnusedPropertiesEarly = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        int int75 = node74.getChildCount();
        com.google.javascript.rhino.Node node77 = node74.getAncestor((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(node77);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(16, 1, (int) (byte) 100);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<missingProperties>", 8, 0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean10 = closureCodingConvention8.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(40, node14, node17, node20, node23);
        java.lang.String str25 = node23.getString();
        com.google.javascript.rhino.Node node26 = node23.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo27 = node23.getJSDocInfo();
        node23.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship30 = closureCodingConvention8.getDelegateRelationship(node23);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(40, node34, node37, node40, node43);
        boolean boolean45 = node23.hasChild(node43);
        try {
            node3.replaceChild(node7, node43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNull(jSDocInfo27);
        org.junit.Assert.assertNull(delegateRelationship30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        long long2 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(40, node26, node29, node32, node35);
        boolean boolean37 = node15.hasChild(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(40, node41, node44, node47, node50);
        com.google.javascript.rhino.Node node52 = node41.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions54.aliasKeywords = true;
        boolean boolean57 = compilerOptions54.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap58 = null;
        compilerOptions54.cssRenamingMap = cssRenamingMap58;
        compilerOptions54.setRemoveAbstractMethods(false);
        boolean boolean62 = compilerOptions54.lineBreak;
        boolean boolean63 = compilerOptions54.markNoSideEffectCalls;
        boolean boolean64 = compilerOptions54.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format66 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions65.sourceMapFormat = format66;
        compilerOptions65.unaliasableGlobals = "";
        boolean boolean70 = compilerOptions65.disambiguateProperties;
        java.util.Set<java.lang.String> strSet71 = compilerOptions65.stripTypePrefixes;
        compilerOptions54.stripNameSuffixes = strSet71;
        node52.setDirectives(strSet71);
        com.google.javascript.rhino.Node node74 = node35.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(40, node78, node81, node84, node87);
        node84.setType((int) '#');
        boolean boolean92 = node84.getBooleanProp((int) (short) -1);
        boolean boolean93 = node74.isEquivalentTo(node84);
        node74.setVarArgs(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        compilerOptions0.lineBreak = false;
        compilerOptions0.setGenerateExports(false);
        java.util.Set<java.lang.String> strSet17 = null;
        compilerOptions0.stripTypes = strSet17;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        boolean boolean26 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup25);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup27;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup27;
        boolean boolean30 = diagnosticGroupWarningsGuard24.disables(diagnosticGroup27);
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup27;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter9.setColorize(false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler12 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler12, callback13);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(40, node18, node21, node24, node27);
        java.lang.String str29 = node27.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.aliasKeywords = true;
        boolean boolean33 = compilerOptions30.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap34 = null;
        compilerOptions30.cssRenamingMap = cssRenamingMap34;
        compilerOptions30.setRemoveAbstractMethods(false);
        boolean boolean38 = compilerOptions30.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions30.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray43 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError44 = nodeTraversal14.makeError(node27, checkLevel39, diagnosticType42, strArray43);
        java.lang.String str45 = lightweightMessageFormatter9.formatWarning(jSError44);
        int int46 = jSError44.getCharno();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jSError44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + ": WARNING - \n" + "'", str45.equals(": WARNING - \n"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap8 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap8;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        ecmaError2.initColumnNumber(16);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError2.getScriptStackTrace(filenameFilter6);
        java.lang.String str8 = ecmaError2.getErrorMessage();
        java.lang.String str9 = ecmaError2.toString();
        java.lang.String str10 = ecmaError2.details();
        java.lang.String str11 = ecmaError2.sourceName();
        int int12 = ecmaError2.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str9.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup25;
        boolean boolean27 = diagnosticGroupWarningsGuard24.enables(diagnosticGroup25);
        com.google.javascript.jscomp.JSError jSError28 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel29 = diagnosticGroupWarningsGuard24.level(jSError28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        boolean boolean14 = node3.isLocalResultCall();
        int int15 = node3.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        boolean boolean17 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node18 = node3.getParent();
        com.google.javascript.rhino.Node node19 = node18.removeFirstChild();
        node18.setVarArgs(false);
        boolean boolean22 = node18.isVarArgs();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 0L);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context0.getErrorReporter();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(errorReporter4);
        org.junit.Assert.assertNull(errorReporter5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray10);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard11);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy13 = compilerOptions0.propertyRenaming;
        compilerOptions0.ambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy13.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Unknown class name");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("eof", reader5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromReader("hi!", reader5);
        com.google.javascript.jscomp.Region region9 = sourceFile7.getRegion(5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNull(region9);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        com.google.javascript.rhino.Node node16 = node5.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node16.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.lineBreak;
        boolean boolean27 = compilerOptions18.markNoSideEffectCalls;
        boolean boolean28 = compilerOptions18.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format30 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions29.sourceMapFormat = format30;
        compilerOptions29.unaliasableGlobals = "";
        boolean boolean34 = compilerOptions29.disambiguateProperties;
        java.util.Set<java.lang.String> strSet35 = compilerOptions29.stripTypePrefixes;
        compilerOptions18.stripNameSuffixes = strSet35;
        node16.setDirectives(strSet35);
        compilerOptions0.stripTypePrefixes = strSet35;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(format30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strSet35);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = context0.getErrorReporter();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNull(errorReporter15);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.aliasKeywords = true;
        compilerOptions12.markAsCompiled = false;
        compilerOptions12.setRemoveAbstractMethods(true);
        compilerOptions12.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions12.checkUndefinedProperties;
        compilerOptions0.checkRequires = checkLevel21;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler1.getSourceMap();
        com.google.javascript.jscomp.JSError[] jSErrorArray14 = compiler1.getWarnings();
        try {
            java.lang.String str17 = compiler1.getSourceLine("", 49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(sourceMap13);
        org.junit.Assert.assertNotNull(jSErrorArray14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        boolean boolean5 = compilerOptions2.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions2.cssRenamingMap = cssRenamingMap6;
        compilerOptions2.setRemoveAbstractMethods(false);
        boolean boolean10 = compilerOptions2.lineBreak;
        java.lang.Class<?> wildcardClass11 = compilerOptions2.getClass();
        boolean boolean12 = compilerOptions2.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.aliasKeywords = true;
        boolean boolean16 = compilerOptions13.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap17 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap17;
        compilerOptions13.setRemoveAbstractMethods(false);
        boolean boolean21 = compilerOptions13.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.aggressiveVarCheck;
        compilerOptions2.checkMethods = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel22);
        java.lang.String str25 = diagnosticGroupWarningsGuard24.toString();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler26 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler26, callback27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(40, node32, node35, node38, node41);
        java.lang.String str43 = node41.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.aliasKeywords = true;
        boolean boolean47 = compilerOptions44.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap48 = null;
        compilerOptions44.cssRenamingMap = cssRenamingMap48;
        compilerOptions44.setRemoveAbstractMethods(false);
        boolean boolean52 = compilerOptions44.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions44.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray57 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError58 = nodeTraversal28.makeError(node41, checkLevel53, diagnosticType56, strArray57);
        java.lang.String str59 = jSError58.description;
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.aliasKeywords = true;
        compilerOptions60.markAsCompiled = false;
        compilerOptions60.setRemoveAbstractMethods(true);
        boolean boolean67 = compilerOptions60.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions68.aliasKeywords = true;
        compilerOptions68.markAsCompiled = false;
        compilerOptions68.setRemoveAbstractMethods(true);
        compilerOptions68.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel77 = compilerOptions68.checkUndefinedProperties;
        compilerOptions60.checkGlobalThisLevel = checkLevel77;
        compilerOptions60.setDefineToBooleanLiteral("error reporter", true);
        compilerOptions60.groupVariableDeclarations = true;
        boolean boolean84 = jSError58.equals((java.lang.Object) true);
        com.google.javascript.jscomp.CheckLevel checkLevel85 = diagnosticGroupWarningsGuard24.level(jSError58);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray86 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard87 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray86);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup88 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup88;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup88;
        boolean boolean91 = composeWarningsGuard87.enables(diagnosticGroup88);
        com.google.javascript.jscomp.DiagnosticType diagnosticType92 = null;
        boolean boolean93 = diagnosticGroup88.matches(diagnosticType92);
        boolean boolean94 = diagnosticGroupWarningsGuard24.enables(diagnosticGroup88);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DiagnosticGroup<missingProperties>(OFF)" + "'", str25.equals("DiagnosticGroup<missingProperties>(OFF)"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(checkLevel85);
        org.junit.Assert.assertNotNull(warningsGuardArray86);
        org.junit.Assert.assertNotNull(diagnosticGroup88);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.columnNumber();
        java.lang.String str4 = ecmaError2.details();
        java.lang.String str5 = ecmaError2.toString();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str5.equals("com.google.javascript.rhino.EcmaError: : "));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean12 = closureCodingConvention9.isExported("DiagnosticGroup<accessControls>", false);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention9);
        java.lang.String str14 = closureCodingConvention9.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean18 = closureCodingConvention16.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(40, node22, node25, node28, node31);
        java.lang.String str33 = node31.getString();
        com.google.javascript.rhino.Node node34 = node31.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo35 = node31.getJSDocInfo();
        node31.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = closureCodingConvention16.getDelegateRelationship(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean43 = closureCodingConvention16.isOptionalParameter(node42);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention16, "", (int) (byte) 1, (int) '#');
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(40, node51, node54, node57, node60);
        com.google.javascript.rhino.Node node62 = node51.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable63 = node62.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions64.aliasKeywords = true;
        boolean boolean67 = compilerOptions64.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap68 = null;
        compilerOptions64.cssRenamingMap = cssRenamingMap68;
        compilerOptions64.setRemoveAbstractMethods(false);
        boolean boolean72 = compilerOptions64.lineBreak;
        boolean boolean73 = compilerOptions64.markNoSideEffectCalls;
        boolean boolean74 = compilerOptions64.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions75 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format76 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions75.sourceMapFormat = format76;
        compilerOptions75.unaliasableGlobals = "";
        boolean boolean80 = compilerOptions75.disambiguateProperties;
        java.util.Set<java.lang.String> strSet81 = compilerOptions75.stripTypePrefixes;
        compilerOptions64.stripNameSuffixes = strSet81;
        node62.setDirectives(strSet81);
        boolean boolean84 = closureCodingConvention16.isVarArgsParameter(node62);
        java.lang.String str85 = closureCodingConvention9.extractClassNameIfProvide(node15, node62);
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNull(jSDocInfo35);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeIterable63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(format76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(strSet81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(str85);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        compilerOptions0.collapseProperties = true;
        compilerOptions0.setTweakToBooleanLiteral("Unknown class name", false);
        java.lang.String str10 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceReportPath = "<No stack trace available>";
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.Object obj15 = node9.getProp((-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(40, node19, node22, node25, node28);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler30 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback31 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal32 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler30, callback31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(40, node36, node39, node42, node45);
        java.lang.String str47 = node45.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.aliasKeywords = true;
        boolean boolean51 = compilerOptions48.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap52 = null;
        compilerOptions48.cssRenamingMap = cssRenamingMap52;
        compilerOptions48.setRemoveAbstractMethods(false);
        boolean boolean56 = compilerOptions48.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions48.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray61 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal32.makeError(node45, checkLevel57, diagnosticType60, strArray61);
        com.google.javascript.rhino.jstype.JSType jSType63 = node45.getJSType();
        java.lang.String str64 = node22.checkTreeEquals(node45);
        com.google.javascript.rhino.Node node65 = node9.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(40, node69, node72, node75, node78);
        boolean boolean80 = node69.isLocalResultCall();
        int int81 = node69.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection82 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node69);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder83 = node69.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node84 = node65.copyInformationFrom(node69);
        java.lang.String str85 = node69.toStringTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(nodeCollection82);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder83);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "OR hi!\n" + "'", str85.equals("OR hi!\n"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 130, 7);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(40, node7, node10, node13, node16);
        boolean boolean18 = node7.isLocalResultCall();
        int int19 = node7.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection20 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node7);
        node7.setCharno(17);
        node7.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = node3.clonePropsFrom(node7);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(nodeCollection20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        compilerOptions4.markAsCompiled = false;
        compilerOptions4.setRemoveAbstractMethods(true);
        boolean boolean11 = compilerOptions4.checkTypedPropertyCalls;
        compilerOptions4.extractPrototypeMemberDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format15 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions14.sourceMapFormat = format15;
        compilerOptions14.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing19 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean20 = tweakProcessing19.shouldStrip();
        compilerOptions14.setTweakProcessing(tweakProcessing19);
        compilerOptions4.setTweakProcessing(tweakProcessing19);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler24 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler24, callback25);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        java.lang.String str41 = node39.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.aliasKeywords = true;
        boolean boolean45 = compilerOptions42.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap46 = null;
        compilerOptions42.cssRenamingMap = cssRenamingMap46;
        compilerOptions42.setRemoveAbstractMethods(false);
        boolean boolean50 = compilerOptions42.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions42.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray55 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal26.makeError(node39, checkLevel51, diagnosticType54, strArray55);
        loggerErrorManager2.report(checkLevel23, jSError56);
        int int58 = loggerErrorManager2.getErrorCount();
        loggerErrorManager2.setTypedPercent(100.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertTrue("'" + tweakProcessing19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing19.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        java.lang.String str14 = node12.getString();
        com.google.javascript.rhino.Node node15 = node12.getLastChild();
        node12.setOptionalArg(false);
        com.google.javascript.rhino.Node node18 = node12.detachFromParent();
        int int19 = node12.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Unknown class name");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("eof", reader5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromReader("(Unknown class name)", reader5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = jSSourceFile2.toString();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        com.google.javascript.rhino.Node node16 = node5.getLastSibling();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node16.siblings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.lineBreak;
        boolean boolean27 = compilerOptions18.markNoSideEffectCalls;
        boolean boolean28 = compilerOptions18.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format30 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions29.sourceMapFormat = format30;
        compilerOptions29.unaliasableGlobals = "";
        boolean boolean34 = compilerOptions29.disambiguateProperties;
        java.util.Set<java.lang.String> strSet35 = compilerOptions29.stripTypePrefixes;
        compilerOptions18.stripNameSuffixes = strSet35;
        node16.setDirectives(strSet35);
        compilerOptions0.stripTypePrefixes = strSet35;
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format40 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions39.sourceMapFormat = format40;
        compilerOptions39.unaliasableGlobals = "";
        boolean boolean44 = compilerOptions39.disambiguateProperties;
        java.util.Set<java.lang.String> strSet45 = compilerOptions39.stripTypePrefixes;
        boolean boolean46 = compilerOptions39.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler47 = compilerOptions39.getAliasTransformationHandler();
        boolean boolean48 = compilerOptions39.removeDeadCode;
        boolean boolean49 = compilerOptions39.inlineAnonymousFunctionExpressions;
        boolean boolean50 = compilerOptions39.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions39.checkProvides;
        compilerOptions0.checkMissingReturn = checkLevel51;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(format30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strSet35);
        org.junit.Assert.assertNotNull(format40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(strSet45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format2 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions1.sourceMapFormat = format2;
        compilerOptions1.unaliasableGlobals = "";
        boolean boolean6 = compilerOptions1.disambiguateProperties;
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) 100 };
        compilerOptions1.inputPropertyMapSerialized = byteArray9;
        compilerOptions1.setTweakToNumberLiteral("", (int) ' ');
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.aliasKeywords = true;
        boolean boolean17 = compilerOptions14.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions14.cssRenamingMap = cssRenamingMap18;
        compilerOptions14.setRemoveAbstractMethods(false);
        boolean boolean22 = compilerOptions14.lineBreak;
        boolean boolean23 = compilerOptions14.markNoSideEffectCalls;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler24 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler24, callback25);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(40, node30, node33, node36, node39);
        java.lang.String str41 = node39.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.aliasKeywords = true;
        boolean boolean45 = compilerOptions42.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap46 = null;
        compilerOptions42.cssRenamingMap = cssRenamingMap46;
        compilerOptions42.setRemoveAbstractMethods(false);
        boolean boolean50 = compilerOptions42.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions42.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray55 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal26.makeError(node39, checkLevel51, diagnosticType54, strArray55);
        compilerOptions14.checkFunctions = checkLevel51;
        compilerOptions1.checkGlobalThisLevel = checkLevel51;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard59 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler64 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback65 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal66 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler64, callback65);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(40, node70, node73, node76, node79);
        java.lang.String str81 = node79.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions82 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions82.aliasKeywords = true;
        boolean boolean85 = compilerOptions82.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap86 = null;
        compilerOptions82.cssRenamingMap = cssRenamingMap86;
        compilerOptions82.setRemoveAbstractMethods(false);
        boolean boolean90 = compilerOptions82.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel91 = compilerOptions82.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType94 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray95 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError96 = nodeTraversal66.makeError(node79, checkLevel91, diagnosticType94, strArray95);
        com.google.javascript.jscomp.JSError jSError97 = com.google.javascript.jscomp.JSError.make("false", 0, 38, diagnosticType63, strArray95);
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel98 = diagnosticGroupWarningsGuard59.level(jSError97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(format2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + checkLevel91 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel91.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType94);
        org.junit.Assert.assertNotNull(strArray95);
        org.junit.Assert.assertNotNull(jSError96);
        org.junit.Assert.assertNotNull(jSError97);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Unknown class name");
        java.io.Reader reader4 = sourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromReader("0", reader4);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.unaliasableGlobals = "";
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = null;
        compilerOptions0.messageBundle = messageBundle7;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy10;
        compilerOptions0.setTweakToDoubleLiteral("instanceof", (double) 39);
        boolean boolean15 = compilerOptions0.checkControlStructures;
        compilerOptions0.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format19 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions18.sourceMapFormat = format19;
        compilerOptions18.unaliasableGlobals = "";
        boolean boolean23 = compilerOptions18.disambiguateProperties;
        java.util.Set<java.lang.String> strSet24 = compilerOptions18.stripTypePrefixes;
        compilerOptions18.devirtualizePrototypeMethods = false;
        compilerOptions18.deadAssignmentElimination = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format30 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions29.sourceMapFormat = format30;
        compilerOptions29.unaliasableGlobals = "";
        boolean boolean34 = compilerOptions29.disambiguateProperties;
        java.util.Set<java.lang.String> strSet35 = compilerOptions29.stripTypePrefixes;
        compilerOptions29.devirtualizePrototypeMethods = false;
        boolean boolean38 = compilerOptions29.inlineLocalVariables;
        compilerOptions29.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions29.checkMethods;
        compilerOptions18.checkFunctions = checkLevel41;
        compilerOptions0.checkShadowVars = checkLevel41;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap44 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap44;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(format19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertNotNull(format30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strSet35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        boolean boolean24 = closureCodingConvention0.isSuperClassReference("instanceof");
        java.lang.String str25 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean27 = closureCodingConvention0.isPrivate("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )");
        java.lang.String str28 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "goog.abstractMethod" + "'", str25.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportSymbol" + "'", str28.equals("goog.exportSymbol"));
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test464");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
//        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
//        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker14 = compiler1.tracker;
//        com.google.javascript.jscomp.SourceMap sourceMap15 = compiler1.getSourceMap();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = null;
//        java.io.PrintStream printStream17 = null;
//        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler(printStream17);
//        compiler18.disableThreads();
//        java.lang.String str22 = compiler18.getSourceLine("Not declared as a type name", (int) (short) -1);
//        java.io.PrintStream printStream23 = null;
//        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
//        compiler24.disableThreads();
//        java.nio.charset.Charset charset27 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset27);
//        java.lang.String str29 = jSSourceFile28.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst30 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile28);
//        com.google.javascript.rhino.Node node31 = compiler24.parse(jSSourceFile28);
//        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
//        com.google.javascript.rhino.Context context33 = com.google.javascript.rhino.Context.enter();
//        int int34 = context33.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter35 = context33.getErrorReporter();
//        int int36 = context33.getInstructionObserverThreshold();
//        java.util.Locale locale37 = context33.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException39 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException39.initLineSource("Unknown class name");
//        int int42 = evaluatorException39.lineNumber();
//        context33.removeThreadLocal((java.lang.Object) int42);
//        java.io.PrintStream printStream44 = null;
//        com.google.javascript.jscomp.Compiler compiler45 = new com.google.javascript.jscomp.Compiler(printStream44);
//        compiler45.disableThreads();
//        context33.removeThreadLocal((java.lang.Object) compiler45);
//        com.google.javascript.jscomp.Scope scope48 = compiler45.getTopScope();
//        java.nio.charset.Charset charset50 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset50);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format54 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions53.sourceMapFormat = format54;
//        compilerOptions53.unaliasableGlobals = "";
//        boolean boolean58 = compilerOptions53.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet59 = compilerOptions53.stripTypePrefixes;
//        boolean boolean60 = compilerOptions53.devirtualizePrototypeMethods;
//        boolean boolean61 = compilerOptions53.gatherCssNames;
//        boolean boolean62 = compilerOptions53.prettyPrint;
//        compilerOptions53.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result65 = compiler45.compile(jSSourceFile51, jSSourceFileArray52, compilerOptions53);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format67 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions66.sourceMapFormat = format67;
//        compilerOptions66.unaliasableGlobals = "";
//        compilerOptions66.collapseProperties = true;
//        compilerOptions66.checkTypedPropertyCalls = false;
//        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel75 = compilerOptions66.sourceMapDetailLevel;
//        com.google.javascript.jscomp.Result result76 = compiler18.compile(jSSourceFile28, jSSourceFileArray52, compilerOptions66);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format78 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions77.sourceMapFormat = format78;
//        compilerOptions77.unaliasableGlobals = "";
//        boolean boolean82 = compilerOptions77.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet83 = compilerOptions77.stripTypePrefixes;
//        compilerOptions77.devirtualizePrototypeMethods = false;
//        compilerOptions77.syntheticBlockStartMarker = "Unknown class name";
//        compilerOptions77.collapseVariableDeclarations = true;
//        try {
//            com.google.javascript.jscomp.Result result90 = compiler1.compile(jSSourceFile16, jSSourceFileArray52, compilerOptions77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNull(node12);
//        org.junit.Assert.assertNull(performanceTracker14);
//        org.junit.Assert.assertNull(sourceMap15);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertNotNull(jSSourceFile28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertNull(node31);
//        org.junit.Assert.assertNotNull(context33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNull(errorReporter35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(locale37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNull(scope48);
//        org.junit.Assert.assertNotNull(jSSourceFile51);
//        org.junit.Assert.assertNotNull(jSSourceFileArray52);
//        org.junit.Assert.assertNotNull(format54);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(strSet59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(result65);
//        org.junit.Assert.assertNotNull(format67);
//        org.junit.Assert.assertNotNull(detailLevel75);
//        org.junit.Assert.assertNotNull(result76);
//        org.junit.Assert.assertNotNull(format78);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(strSet83);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.toString();
        java.lang.String str4 = ecmaError2.getSourceName();
        java.lang.String str5 = ecmaError2.details();
        java.lang.String str6 = ecmaError2.lineSource();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: : " + "'", str3.equals("com.google.javascript.rhino.EcmaError: : "));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ": " + "'", str5.equals(": "));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("(Unknown class name)");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.setDefineToStringLiteral("eof", "hi!");
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention9);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing11 = compilerOptions0.getTweakProcessing();
        boolean boolean12 = tweakProcessing11.shouldStrip();
        boolean boolean13 = tweakProcessing11.shouldStrip();
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + tweakProcessing11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing11.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        java.lang.String str2 = composeWarningsGuard1.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup3;
        boolean boolean5 = composeWarningsGuard1.enables(diagnosticGroup3);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.aliasExternals = false;
        compilerOptions0.foldConstants = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.generateExports = false;
        boolean boolean15 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
        int int13 = compiler1.getErrorCount();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst4.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler14, callback15);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(40, node20, node23, node26, node29);
        java.lang.String str31 = node29.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.aliasKeywords = true;
        boolean boolean35 = compilerOptions32.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap36 = null;
        compilerOptions32.cssRenamingMap = cssRenamingMap36;
        compilerOptions32.setRemoveAbstractMethods(false);
        boolean boolean40 = compilerOptions32.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions32.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray45 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError46 = nodeTraversal16.makeError(node29, checkLevel41, diagnosticType44, strArray45);
        com.google.javascript.rhino.jstype.JSType jSType47 = node29.getJSType();
        java.lang.String str48 = node6.checkTreeEquals(node29);
        java.lang.String str49 = node6.toString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "OR hi!" + "'", str49.equals("OR hi!"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.aliasKeywords = true;
        boolean boolean21 = compilerOptions18.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap22 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap22;
        compilerOptions18.setRemoveAbstractMethods(false);
        boolean boolean26 = compilerOptions18.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray31 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError32 = nodeTraversal2.makeError(node15, checkLevel27, diagnosticType30, strArray31);
        java.lang.String str33 = jSError32.sourceName;
        java.lang.String str34 = jSError32.description;
        java.lang.String str35 = jSError32.sourceName;
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test475");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        int int1 = context0.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        int int3 = context0.getInstructionObserverThreshold();
//        java.util.Locale locale4 = context0.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException6.initLineSource("Unknown class name");
//        int int9 = evaluatorException6.lineNumber();
//        context0.removeThreadLocal((java.lang.Object) int9);
//        java.io.PrintStream printStream11 = null;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
//        compiler12.disableThreads();
//        context0.removeThreadLocal((java.lang.Object) compiler12);
//        try {
//            compiler12.normalize();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType25 = null;
        closureCodingConvention0.applySubclassRelationship(functionType23, functionType24, subclassType25);
        boolean boolean28 = closureCodingConvention0.isConstant("Named type with empty name component");
        java.lang.String str29 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean31 = closureCodingConvention0.isSuperClassReference("TypeError");
        boolean boolean33 = closureCodingConvention0.isConstant("(com.google.javascript.rhino.EcmaError: Not declared as a type name: com.google.javascript.rhino.EcmaError: : )");
        java.lang.String str34 = closureCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("0", "", (int) (short) 0);
        try {
            evaluatorException3.initColumnNumber((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node9.getJsDocBuilderForNode();
        fileLevelJsDocBuilder14.append("(Named type with empty name component)");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setThrows();
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        boolean boolean9 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.aliasableGlobals = "eof";
        boolean boolean12 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.setTweakToStringLiteral("eof", "(Named type with empty name component)");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(40, node3, node6, node9, node12);
        com.google.javascript.rhino.Node node14 = node3.getLastSibling();
        node14.setWasEmptyNode(false);
        java.lang.Object obj18 = node14.getProp(31);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler1.getTypeRegistry();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler1.tracker;
        com.google.javascript.jscomp.Scope scope11 = compiler1.getTopScope();
        com.google.javascript.jscomp.CodingConvention codingConvention12 = compiler1.getCodingConvention();
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertNull(scope11);
        org.junit.Assert.assertNotNull(codingConvention12);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.SourceMap.Format format1 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        compilerOptions0.sourceMapFormat = format1;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean5 = compilerOptions0.foldConstants;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap6;
        boolean boolean8 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        org.junit.Assert.assertNotNull(format1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags();
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 10L, (java.lang.Object) sideEffectFlags1);
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.allowLegacyJsMessages = true;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str6 = compilerInput4.getLine(120);
        boolean boolean7 = compilerInput4.isExtern();
        java.lang.String str8 = compilerInput4.getName();
        com.google.javascript.jscomp.SourceFile sourceFile9 = compilerInput4.getSourceFile();
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput4.getModule();
        java.lang.String str11 = compilerInput4.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.aliasKeywords = true;
        compilerOptions2.markAsCompiled = false;
        java.lang.Object obj7 = compilerOptions2.clone();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        compilerOptions8.removeTryCatchFinally = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy19 = compilerOptions8.anonymousFunctionNaming;
        try {
            java.lang.String str20 = com.google.javascript.rhino.ScriptRuntime.getMessage3("OR hi! [directives: []]", obj1, obj7, (java.lang.Object) compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property OR hi! [directives: []]");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy19 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy19.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.aliasKeywords = true;
        compilerOptions8.markAsCompiled = false;
        compilerOptions8.setRemoveAbstractMethods(true);
        compilerOptions8.inputDelimiter = "Not declared as a type name";
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.checkUndefinedProperties;
        compilerOptions0.checkGlobalThisLevel = checkLevel17;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(40, node25, node28, node31, node34);
        java.lang.String str36 = node34.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.aliasKeywords = true;
        boolean boolean40 = compilerOptions37.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap41 = null;
        compilerOptions37.cssRenamingMap = cssRenamingMap41;
        compilerOptions37.setRemoveAbstractMethods(false);
        boolean boolean45 = compilerOptions37.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions37.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray50 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError51 = nodeTraversal21.makeError(node34, checkLevel46, diagnosticType49, strArray50);
        compilerOptions0.checkGlobalNamesLevel = checkLevel46;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean54 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler55 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler55);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 1.0d);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray15);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard16);
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node18 = node15.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node15.getJSDocInfo();
        node15.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = closureCodingConvention0.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 100.0f, 23, 26);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "", (int) (byte) 1, (int) '#');
        boolean boolean33 = closureCodingConvention0.isSuperClassReference("DiagnosticGroup<missingProperties>");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention34 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean36 = closureCodingConvention34.isSuperClassReference("Not declared as a type name");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(40, node40, node43, node46, node49);
        java.lang.String str51 = node49.getString();
        com.google.javascript.rhino.Node node52 = node49.getLastChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = node49.getJSDocInfo();
        node49.setString("false");
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship56 = closureCodingConvention34.getDelegateRelationship(node49);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(40, node60, node63, node66, node69);
        boolean boolean71 = node49.hasChild(node69);
        java.lang.String str72 = closureCodingConvention0.identifyTypeDefAssign(node49);
        boolean boolean73 = node49.isVarArgs();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNull(node52);
        org.junit.Assert.assertNull(jSDocInfo53);
        org.junit.Assert.assertNull(delegateRelationship56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        java.lang.String str3 = ecmaError2.getName();
        java.lang.String str4 = ecmaError2.sourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test493");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        compiler1.disableThreads();
//        java.nio.charset.Charset charset4 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
//        java.lang.String str6 = jSSourceFile5.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
//        com.google.javascript.rhino.Node node8 = compiler1.parse(jSSourceFile5);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod", charset10);
//        com.google.javascript.rhino.Node node12 = compiler1.parse(jSSourceFile11);
//        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler1.getSourceMap();
//        com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter();
//        int int15 = context14.getLanguageVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = context14.getErrorReporter();
//        int int17 = context14.getInstructionObserverThreshold();
//        java.util.Locale locale18 = context14.getLocale();
//        com.google.javascript.rhino.EvaluatorException evaluatorException20 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: : ");
//        evaluatorException20.initLineSource("Unknown class name");
//        int int23 = evaluatorException20.lineNumber();
//        context14.removeThreadLocal((java.lang.Object) int23);
//        java.io.PrintStream printStream25 = null;
//        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler(printStream25);
//        compiler26.disableThreads();
//        context14.removeThreadLocal((java.lang.Object) compiler26);
//        com.google.javascript.jscomp.Scope scope29 = compiler26.getTopScope();
//        java.nio.charset.Charset charset31 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset31);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.SourceMap.Format format35 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
//        compilerOptions34.sourceMapFormat = format35;
//        compilerOptions34.unaliasableGlobals = "";
//        boolean boolean39 = compilerOptions34.disambiguateProperties;
//        java.util.Set<java.lang.String> strSet40 = compilerOptions34.stripTypePrefixes;
//        boolean boolean41 = compilerOptions34.devirtualizePrototypeMethods;
//        boolean boolean42 = compilerOptions34.gatherCssNames;
//        boolean boolean43 = compilerOptions34.prettyPrint;
//        compilerOptions34.setGenerateExports(false);
//        com.google.javascript.jscomp.Result result46 = compiler26.compile(jSSourceFile32, jSSourceFileArray33, compilerOptions34);
//        java.io.PrintStream printStream47 = null;
//        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler(printStream47);
//        compiler48.disableThreads();
//        java.nio.charset.Charset charset51 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset51);
//        java.lang.String str53 = jSSourceFile52.getOriginalPath();
//        com.google.javascript.jscomp.JsAst jsAst54 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile52);
//        com.google.javascript.rhino.Node node55 = compiler48.parse(jSSourceFile52);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray60 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile52, jSSourceFile57, jSSourceFile59 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions61.aliasKeywords = true;
//        boolean boolean64 = compilerOptions61.generateExports;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap65 = compilerOptions61.cssRenamingMap;
//        compiler1.init(jSSourceFileArray33, jSSourceFileArray60, compilerOptions61);
//        int int67 = compiler1.getErrorCount();
//        org.junit.Assert.assertNotNull(jSSourceFile5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNull(node12);
//        org.junit.Assert.assertNull(sourceMap13);
//        org.junit.Assert.assertNotNull(context14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNull(errorReporter16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNull(scope29);
//        org.junit.Assert.assertNotNull(jSSourceFile32);
//        org.junit.Assert.assertNotNull(jSSourceFileArray33);
//        org.junit.Assert.assertNotNull(format35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(strSet40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(result46);
//        org.junit.Assert.assertNotNull(jSSourceFile52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
//        org.junit.Assert.assertNull(node55);
//        org.junit.Assert.assertNotNull(jSSourceFile57);
//        org.junit.Assert.assertNotNull(jSSourceFile59);
//        org.junit.Assert.assertNotNull(jSSourceFileArray60);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNull(cssRenamingMap65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(40, node4, node7, node10, node13);
        boolean boolean15 = node4.isLocalResultCall();
        boolean boolean16 = node4.isLocalResultCall();
        try {
            com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-3), node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.markAsCompiled = false;
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", 0.0d);
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig12 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        byte[] byteArray13 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.inlineLocalVariables = true;
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertNull(byteArray13);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) 4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.aliasKeywords = true;
        boolean boolean7 = compilerOptions4.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = null;
        compilerOptions4.cssRenamingMap = cssRenamingMap8;
        compilerOptions4.setRemoveAbstractMethods(false);
        boolean boolean12 = compilerOptions4.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention13 = null;
        compilerOptions4.setCodingConvention(codingConvention13);
        boolean boolean15 = compilerOptions4.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions4.reportUnknownTypes;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
        java.lang.String str34 = node32.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.aliasKeywords = true;
        boolean boolean38 = compilerOptions35.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap39 = null;
        compilerOptions35.cssRenamingMap = cssRenamingMap39;
        compilerOptions35.setRemoveAbstractMethods(false);
        boolean boolean43 = compilerOptions35.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions35.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray48 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError49 = nodeTraversal19.makeError(node32, checkLevel44, diagnosticType47, strArray48);
        java.lang.String str50 = jSError49.description;
        loggerErrorManager1.println(checkLevel16, jSError49);
        int int52 = jSError49.getCharno();
        int int53 = jSError49.getCharno();
        com.google.javascript.jscomp.CheckLevel checkLevel54 = jSError49.level;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(40, node5, node8, node11, node14);
        boolean boolean16 = node5.isLocalResultCall();
        int int17 = node5.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection18 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node5);
        node5.setCharno(17);
        int int21 = node5.getCharno();
        com.google.javascript.rhino.Node node22 = null;
        try {
            node1.replaceChild(node5, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(nodeCollection18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getDelegateSuperclassName();
        java.lang.String str2 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(40, node6, node9, node12, node15);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(40, node23, node26, node29, node32);
        java.lang.String str34 = node32.getString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.aliasKeywords = true;
        boolean boolean38 = compilerOptions35.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap39 = null;
        compilerOptions35.cssRenamingMap = cssRenamingMap39;
        compilerOptions35.setRemoveAbstractMethods(false);
        boolean boolean43 = compilerOptions35.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions35.aggressiveVarCheck;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String[] strArray48 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError49 = nodeTraversal19.makeError(node32, checkLevel44, diagnosticType47, strArray48);
        com.google.javascript.rhino.jstype.JSType jSType50 = node32.getJSType();
        java.lang.String str51 = node9.checkTreeEquals(node32);
        com.google.javascript.rhino.jstype.JSType jSType52 = node9.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!");
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(40, node56, node59, node62, node65);
        boolean boolean67 = node56.isLocalResultCall();
        node56.setSourcePositionForTree(0);
        com.google.javascript.rhino.Node node70 = node9.clonePropsFrom(node56);
        java.lang.String str71 = closureCodingConvention0.identifyTypeDefAssign(node56);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(str71);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.aliasKeywords = true;
        boolean boolean3 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = null;
        compilerOptions0.setCodingConvention(codingConvention9);
        boolean boolean11 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean12 = compilerOptions0.foldConstants;
        compilerOptions0.setDefineToNumberLiteral("", 7);
        compilerOptions0.removeUnusedPrototypeProperties = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }
}

