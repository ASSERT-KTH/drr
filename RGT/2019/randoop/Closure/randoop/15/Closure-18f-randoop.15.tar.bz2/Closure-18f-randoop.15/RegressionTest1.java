import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        boolean boolean29 = functionType28.isFunctionPrototypeType();
        boolean boolean30 = functionType28.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = functionType28.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        boolean boolean40 = functionType39.isFunctionPrototypeType();
        boolean boolean41 = functionType39.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType16, functionType28, functionType39 };
        com.google.javascript.rhino.Node node43 = jSTypeRegistry12.createParametersWithVarArgs(jSTypeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList49 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList49, jSTypeArray48);
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createFunctionTypeWithVarArgs(jSType47, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList49);
        boolean boolean52 = functionType51.isFunctionPrototypeType();
        boolean boolean53 = functionType51.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry12.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType51, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        boolean boolean67 = functionType66.isFunctionPrototypeType();
        boolean boolean68 = functionType66.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType69 = functionType66.getOwnerFunction();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType70 = jSTypeRegistry3.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType51, (com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean71 = parameterizedType70.isNativeObjectType();
        com.google.javascript.rhino.jstype.EnumType enumType72 = parameterizedType70.toMaybeEnumType();
        com.google.javascript.rhino.jstype.TemplateType templateType73 = parameterizedType70.toMaybeTemplateType();
        boolean boolean75 = parameterizedType70.isPropertyInExterns("");
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(functionType31);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(functionType69);
        org.junit.Assert.assertNotNull(parameterizedType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(enumType72);
        org.junit.Assert.assertNull(templateType73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isFunctionPrototypeType();
        boolean boolean9 = functionType7.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType10 = functionType7.getConstructor();
        try {
            java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType10.getExtendedInterfaces();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(functionType10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isConstructor();
        boolean boolean10 = functionType7.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        java.util.Set<java.lang.String> strSet11 = functionType7.getPropertyNames();
        com.google.javascript.rhino.jstype.JSType jSType12 = functionType7.unboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertNull(jSType12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.setCheckProvides(checkLevel4);
        java.lang.String str6 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean7 = compilerOptions0.isRemoveUnusedClassProperties();
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setDebugFunctionSideEffectsPath("hi!");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping15 = new com.google.javascript.jscomp.SourceMap.LocationMapping("module$hi!", "hi!");
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray16 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] { locationMapping15 };
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList17 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList17, locationMappingArray16);
        compilerOptions0.sourceMapLocationMappings = locationMappingList17;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(locationMappingArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        java.lang.Object obj6 = node3.getProp((int) (byte) 0);
        int int7 = node3.getLineno();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.NodeUtil.getRootOfQualifiedName(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.lang.String[] strArray7 = new java.lang.String[] { "module$hi!", "(Not declared as a type name)", "DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)" };
//        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("", (int) '4', 0, diagnosticType3, strArray7);
//        com.google.javascript.jscomp.CheckLevel checkLevel9 = jSError8.getDefaultLevel();
//        int int10 = jSError8.getLineNumber();
//        int int11 = jSError8.getNodeSourceOffset();
//        com.google.javascript.jscomp.CheckLevel checkLevel12 = jSError8.getDefaultLevel();
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertNotNull(strArray7);
//        org.junit.Assert.assertNotNull(jSError8);
//        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceFile1, false);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceFile10, false);
        java.lang.String str13 = sourceFile10.getName();
        com.google.javascript.rhino.Node node14 = compiler8.parse(sourceFile10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler8);
        com.google.javascript.jscomp.JsAst jsAst16 = null;
        try {
            compiler8.addNewScript(jsAst16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "module$hi!" + "'", str13.equals("module$hi!"));
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        boolean boolean11 = functionType10.isFunctionPrototypeType();
        boolean boolean12 = functionType10.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType13 = functionType10.getOwnerFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType14 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType10);
        com.google.javascript.rhino.jstype.EnumType enumType15 = functionType10.toMaybeEnumType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isFunctionPrototypeType();
        boolean boolean25 = functionType23.isOrdinaryFunction();
        boolean boolean26 = functionType23.matchesNumberContext();
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType23.collapseUnion();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, false);
        jSTypeRegistry30.identifyNonNullableName("Not declared as a type name");
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList38 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList38, jSTypeArray37);
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry35.createFunctionTypeWithVarArgs(jSType36, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList38);
        boolean boolean41 = functionType40.isConstructor();
        boolean boolean43 = functionType40.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.rhino.jstype.ObjectType objectType44 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType40);
        boolean boolean46 = jSTypeRegistry30.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) objectType44, "");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, false);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList53 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList53, jSTypeArray52);
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry50.createFunctionTypeWithVarArgs(jSType51, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList53);
        boolean boolean56 = functionType55.isConstructor();
        boolean boolean58 = functionType55.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.rhino.jstype.ObjectType objectType59 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType55);
        boolean boolean60 = functionType55.matchesStringContext();
        boolean boolean61 = jSTypeRegistry30.declareType("()", (com.google.javascript.rhino.jstype.JSType) functionType55);
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry64.createFunctionTypeWithVarArgs(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        boolean boolean70 = functionType69.isFunctionPrototypeType();
        boolean boolean71 = functionType69.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { functionType23, functionType55, functionType69 };
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType10, jSTypeArray72);
        com.google.javascript.rhino.JSDocInfo jSDocInfo75 = functionType73.getOwnPropertyJSDocInfo("");
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(functionType13);
        org.junit.Assert.assertNotNull(objectType14);
        org.junit.Assert.assertNull(enumType15);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertNull(jSDocInfo75);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
//        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
//        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
//        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
//        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
//        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
//        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
//        com.google.javascript.rhino.jstype.JSType jSType24 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
//        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
//        boolean boolean29 = functionType28.isFunctionPrototypeType();
//        boolean boolean30 = functionType28.isTemplateType();
//        com.google.javascript.rhino.jstype.FunctionType functionType31 = functionType28.getOwnerFunction();
//        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
//        com.google.javascript.rhino.jstype.JSType jSType35 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
//        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
//        boolean boolean40 = functionType39.isFunctionPrototypeType();
//        boolean boolean41 = functionType39.isTemplateType();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType16, functionType28, functionType39 };
//        com.google.javascript.rhino.Node node43 = jSTypeRegistry12.createParametersWithVarArgs(jSTypeArray42);
//        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
//        com.google.javascript.rhino.jstype.JSType jSType47 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList49 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList49, jSTypeArray48);
//        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createFunctionTypeWithVarArgs(jSType47, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList49);
//        boolean boolean52 = functionType51.isFunctionPrototypeType();
//        boolean boolean53 = functionType51.hasDisplayName();
//        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry12.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType51, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
//        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
//        com.google.javascript.rhino.jstype.JSType jSType62 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
//        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
//        boolean boolean67 = functionType66.isFunctionPrototypeType();
//        boolean boolean68 = functionType66.isTemplateType();
//        com.google.javascript.rhino.jstype.FunctionType functionType69 = functionType66.getOwnerFunction();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType70 = jSTypeRegistry3.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType51, (com.google.javascript.rhino.jstype.JSType) functionType66);
//        boolean boolean71 = parameterizedType70.canBeCalled();
//        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, false);
//        com.google.javascript.rhino.jstype.JSType jSType75 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList77 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList77, jSTypeArray76);
//        com.google.javascript.rhino.jstype.FunctionType functionType79 = jSTypeRegistry74.createFunctionTypeWithVarArgs(jSType75, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList77);
//        parameterizedType70.matchConstraint((com.google.javascript.rhino.jstype.ObjectType) functionType79);
//        java.lang.String str81 = parameterizedType70.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.ObjectType.Property property83 = parameterizedType70.getSlot("{proxy:function (): {1053557690}}");
//        boolean boolean84 = parameterizedType70.isAllType();
//        org.junit.Assert.assertNotNull(objectTypeArray5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(functionType20);
//        org.junit.Assert.assertNotNull(jSTypeArray25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(functionType28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(functionType31);
//        org.junit.Assert.assertNotNull(jSTypeArray36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(functionType39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray42);
//        org.junit.Assert.assertNotNull(node43);
//        org.junit.Assert.assertNotNull(jSTypeArray48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(functionType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(jSType58);
//        org.junit.Assert.assertNotNull(jSTypeArray63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(functionType66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNull(functionType69);
//        org.junit.Assert.assertNotNull(parameterizedType70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertNotNull(jSTypeArray76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(functionType79);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "{proxy:function (): {849721762}}" + "'", str81.equals("{proxy:function (): {849721762}}"));
//        org.junit.Assert.assertNull(property83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.setRenamePrefixNamespace("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        boolean boolean12 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode14 = compilerOptions13.getLanguageOut();
        compilerOptions13.setInlineVariables(false);
        compilerOptions13.inputDelimiter = "hi!";
        java.util.Set<java.lang.String> strSet19 = compilerOptions13.stripNamePrefixes;
        compilerOptions0.setReplaceStringsReservedStrings(strSet19);
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel23);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(languageMode14);
        org.junit.Assert.assertNotNull(strSet19);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node3.setOptionalArg(true);
        boolean boolean6 = node3.isCase();
        node3.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setCommonJSModulePathPrefix("(Not declared as a type name)");
        compilerOptions0.moveFunctionDeclarations = true;
        boolean boolean13 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel14 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.setCrossModuleMethodMotion(false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(detailLevel14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean2 = node1.isOptionalArg();
        boolean boolean3 = node1.isAnd();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        java.io.InputStream inputStream4 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromInputStream("module$(Not declared as a type name)", inputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceFile1, false);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        com.google.javascript.jscomp.Region region8 = compilerInput4.getRegion(1);
        com.google.javascript.jscomp.SourceFile.Builder builder9 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile11 = builder9.buildFromFile("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.jscomp.SourceFile sourceFile13 = builder9.buildFromFile("./");
        try {
            compilerInput4.setSourceFile(sourceFile13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertNotNull(sourceFile13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("module$(Not declared as a type name)");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        java.lang.String str6 = sourceFile3.getName();
        com.google.javascript.rhino.Node node7 = compiler1.parse(sourceFile3);
        boolean boolean8 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.ErrorManager errorManager9 = compiler1.getErrorManager();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput11 = compiler1.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "module$hi!" + "'", str6.equals("module$hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(errorManager9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        boolean boolean29 = functionType28.isFunctionPrototypeType();
        boolean boolean30 = functionType28.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = functionType28.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        boolean boolean40 = functionType39.isFunctionPrototypeType();
        boolean boolean41 = functionType39.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType16, functionType28, functionType39 };
        com.google.javascript.rhino.Node node43 = jSTypeRegistry12.createParametersWithVarArgs(jSTypeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList49 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList49, jSTypeArray48);
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createFunctionTypeWithVarArgs(jSType47, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList49);
        boolean boolean52 = functionType51.isFunctionPrototypeType();
        boolean boolean53 = functionType51.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry12.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType51, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        boolean boolean67 = functionType66.isFunctionPrototypeType();
        boolean boolean68 = functionType66.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType69 = functionType66.getOwnerFunction();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType70 = jSTypeRegistry3.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType51, (com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean71 = functionType51.matchesInt32Context();
        boolean boolean72 = functionType51.isEmptyType();
        boolean boolean73 = functionType51.hasReferenceName();
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(functionType31);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(functionType69);
        org.junit.Assert.assertNotNull(parameterizedType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.lang.String[] strArray7 = new java.lang.String[] { "module$hi!", "(Not declared as a type name)", "DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)" };
//        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("", (int) '4', 0, diagnosticType3, strArray7);
//        com.google.javascript.jscomp.CheckLevel checkLevel9 = jSError8.getDefaultLevel();
//        int int10 = jSError8.getLineNumber();
//        int int11 = jSError8.getNodeSourceOffset();
//        int int12 = jSError8.getNodeSourceOffset();
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertNotNull(strArray7);
//        org.junit.Assert.assertNotNull(jSError8);
//        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean2 = node1.isTrue();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList19, jSTypeArray18);
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createFunctionTypeWithVarArgs(jSType17, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList19);
        boolean boolean22 = functionType21.isFunctionPrototypeType();
        boolean boolean23 = functionType21.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType24 = functionType21.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        boolean boolean33 = functionType32.isFunctionPrototypeType();
        boolean boolean34 = functionType32.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] { jSType9, functionType21, functionType32 };
        com.google.javascript.rhino.Node node36 = jSTypeRegistry5.createParametersWithVarArgs(jSTypeArray35);
        com.google.javascript.rhino.Node node37 = node1.useSourceInfoIfMissingFromForTree(node36);
        com.google.javascript.rhino.Node node38 = null;
        com.google.javascript.rhino.Node node39 = null;
        try {
            node37.addChildBefore(node38, node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(functionType24);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setDebugFunctionSideEffectsPath("hi!");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy13 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode15 = compilerOptions14.getLanguageOut();
        compilerOptions14.setReserveRawExports(true);
        compilerOptions14.setCheckSymbols(false);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions14.aggressiveVarCheck;
        compilerOptions0.setCheckMissingGetCssNameLevel(checkLevel20);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy13 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy13.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(languageMode15);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.removeUnusedVars = false;
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setSyntheticBlockStartMarker("JSC_OPTIMIZE_LOOP_ERROR");
        compilerOptions0.setExtractPrototypeMemberDeclarations(false);
        compilerOptions0.generateExports = true;
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node13.setOptionalArg(true);
        boolean boolean16 = closureCodingConvention0.isPrototypeAlias(node13);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        int int19 = node18.getSideEffectFlags();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship20 = closureCodingConvention0.getDelegateRelationship(node18);
        boolean boolean22 = closureCodingConvention0.isPrivate("()");
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship24 = closureCodingConvention0.getDelegateRelationship(node23);
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(delegateRelationship20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(delegateRelationship24);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceFile1, false);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, true);
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceFile10, false);
        java.lang.String str13 = sourceFile10.getName();
        com.google.javascript.rhino.Node node14 = compiler8.parse(sourceFile10);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler8);
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(logger16);
        loggerErrorManager17.setTypedPercent((double) (short) -1);
        compiler8.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        try {
            java.lang.String[] strArray21 = compiler8.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "module$hi!" + "'", str13.equals("module$hi!"));
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.SourceMap.Format format4 = com.google.javascript.jscomp.SourceMap.Format.V1;
        compilerOptions0.setSourceMapFormat(format4);
        compilerOptions0.moveFunctionDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = compilerOptions0.getTracerMode();
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertTrue("'" + tracerMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode8.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) (short) -1);
        loggerErrorManager1.generateReport();
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setCommonJSModulePathPrefix("(Not declared as a type name)");
        boolean boolean11 = compilerOptions0.printInputDelimiter;
        boolean boolean12 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.ambiguateProperties = true;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long0 = com.google.javascript.rhino.InputId.serialVersionUID;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setCommonJSModulePathPrefix("(Not declared as a type name)");
        boolean boolean11 = compilerOptions0.printInputDelimiter;
        boolean boolean12 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.ambiguateProperties = true;
        boolean boolean15 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        com.google.javascript.rhino.Node node6 = compiler1.parse(sourceFile3);
        int int7 = compiler1.getWarningCount();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setSyntheticBlockStartMarker("JSC_OPTIMIZE_LOOP_ERROR");
        boolean boolean4 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            boolean boolean4 = diagnosticGroup0.matches(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler1.getSourceMap();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode4 = compilerOptions3.getLanguageOut();
        compilerOptions3.setReserveRawExports(true);
        compilerOptions3.setCheckSymbols(false);
        compiler1.initOptions(compilerOptions3);
        compilerOptions3.collapseAnonymousFunctions = false;
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNull(languageMode4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        java.lang.Object obj6 = node3.getProp((int) (byte) 0);
        node3.setSourceEncodedPosition(50);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable9 = node3.getAncestors();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean12 = node11.isNull();
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFromForTree(node11);
        boolean boolean14 = node3.isFromExterns();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(ancestorIterable9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile4 = builder0.buildFromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setDebugFunctionSideEffectsPath("hi!");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy13 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode15 = compilerOptions14.getLanguageOut();
        compilerOptions14.setInlineVariables(false);
        compilerOptions14.inputDelimiter = "hi!";
        java.util.Set<java.lang.String> strSet20 = compilerOptions14.stripNamePrefixes;
        compilerOptions0.setStripTypePrefixes(strSet20);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy13 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy13.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(languageMode15);
        org.junit.Assert.assertNotNull(strSet20);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        boolean boolean6 = compilerOptions0.aliasExternals;
        compilerOptions0.removeUnusedVars = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setCheckSuspiciousCode(true);
        boolean boolean12 = compilerOptions9.closurePass;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode13 = compilerOptions9.getTracerMode();
        compilerOptions0.setTracerMode(tracerMode13);
        compilerOptions0.lineBreak = true;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + tracerMode13 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode13.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setCollapseObjectLiterals(true);
        compilerOptions0.enableExternExports(true);
        compilerOptions0.setDeadAssignmentElimination(false);
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node6 = node3.useSourceInfoIfMissingFromForTree(node5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node11 = node8.useSourceInfoIfMissingFromForTree(node10);
        boolean boolean12 = node11.isSetterDef();
        boolean boolean13 = node11.isString();
        com.google.javascript.rhino.Node node14 = node3.useSourceInfoIfMissingFrom(node11);
        java.lang.String str15 = closureCodingConvention0.extractClassNameIfRequire(node1, node14);
        java.lang.String str16 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str17 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.exportProperty" + "'", str16.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.global" + "'", str17.equals("goog.global"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setRenamePrefix("function (): {58344744}");
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.enableExternExports(false);
        compilerOptions0.setDevirtualizePrototypeMethods(true);
        boolean boolean15 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node14 = node11.useSourceInfoIfMissingFromForTree(node13);
        java.lang.Object obj16 = node13.getProp((int) (byte) 0);
        node13.setCharno(0);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean21 = node20.isOptionalArg();
        node20.setVarArgs(false);
        boolean boolean24 = node20.isParamList();
        boolean boolean25 = node13.isEquivalentToTyped(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        com.google.javascript.rhino.Node node28 = node26.cloneTree();
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = node28.getJSDocInfo();
        try {
            com.google.javascript.rhino.Node node30 = node28.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSDocInfo29);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode1, false);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createFunctionTypeWithVarArgs(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean12 = node11.isOptionalArg();
        node11.setVarArgs(false);
        boolean boolean15 = node11.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        boolean boolean24 = functionType23.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList30 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList30, jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry27.createFunctionTypeWithVarArgs(jSType28, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList30);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue33 = functionType23.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType32);
        boolean boolean34 = functionType32.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry3.createObjectType("goog.exportProperty", node11, (com.google.javascript.rhino.jstype.ObjectType) functionType32);
        com.google.javascript.rhino.jstype.ObjectType objectType36 = functionType32.dereference();
        functionType32.clearResolved();
        try {
            java.lang.String str38 = com.google.javascript.rhino.ScriptRuntime.getMessage1("{proxy:function (): {1565557195}}", (java.lang.Object) functionType32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property {proxy:function (): {1565557195}}");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(ternaryValue33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertNotNull(objectType36);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.preferLineBreakAtEndOfFile = true;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setRenamePrefixNamespace("module$hi!");
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        boolean boolean5 = node3.isOr();
        node3.setWasEmptyNode(false);
        boolean boolean8 = node3.isDefaultCase();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.throwNode(node3);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node14 = node11.useSourceInfoIfMissingFromForTree(node13);
        boolean boolean15 = node14.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node16 = node9.useSourceInfoFromForTree(node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block(node16);
        boolean boolean18 = node16.isNot();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList14, jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry11.createFunctionTypeWithVarArgs(jSType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList14);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue17 = functionType7.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType16);
        boolean boolean18 = functionType16.isNativeObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertNotNull(ternaryValue17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isFunctionPrototypeType();
        boolean boolean20 = functionType18.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionType18.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        boolean boolean30 = functionType29.isFunctionPrototypeType();
        boolean boolean31 = functionType29.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType6, functionType18, functionType29 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray32);
        boolean boolean34 = node33.isString();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        boolean boolean6 = compilerOptions0.aliasExternals;
        compilerOptions0.removeUnusedVars = true;
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        boolean boolean28 = functionType27.isFunctionPrototypeType();
        boolean boolean29 = functionType27.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType30 = functionType27.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList36 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList36, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry33.createFunctionTypeWithVarArgs(jSType34, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList36);
        boolean boolean39 = functionType38.isFunctionPrototypeType();
        boolean boolean40 = functionType38.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { jSType15, functionType27, functionType38 };
        com.google.javascript.rhino.Node node42 = jSTypeRegistry11.createParametersWithVarArgs(jSTypeArray41);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry11.getNativeObjectType(jSTypeNative43);
        java.util.Set<java.lang.String> strSet45 = objectType44.getPropertyNames();
        compilerOptions0.aliasableStrings = strSet45;
        compilerOptions0.setTransformAMDToCJSModules(true);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(functionType30);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(strSet45);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node6 = node3.useSourceInfoIfMissingFromForTree(node5);
        node3.removeProp(16);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean11 = node10.isOptionalArg();
        node10.setVarArgs(false);
        boolean boolean14 = node10.isParamList();
        node10.putProp(43, (java.lang.Object) 43);
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(37, node1, node3, node10, 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node2);
        boolean boolean4 = node2.isReturn();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script(nodeArray5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.newNode(node2, nodeArray5);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray5);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node14 = node11.useSourceInfoIfMissingFromForTree(node13);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray20 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList21, objectTypeArray20);
        java.util.Map<java.lang.String, java.lang.String> strMap23 = null;
        closureCodingConvention15.defineDelegateProxyPrototypeProperties(jSTypeRegistry18, jSTypeStaticScope19, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList21, strMap23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node28.setOptionalArg(true);
        boolean boolean31 = closureCodingConvention15.isPrototypeAlias(node28);
        node14.addChildToFront(node28);
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.script(nodeArray33);
        java.lang.String str35 = closureCodingConvention0.extractClassNameIfProvide(node28, node34);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean38 = node37.isOptionalArg();
        node37.setVarArgs(false);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node45 = node42.useSourceInfoIfMissingFromForTree(node44);
        java.lang.Object obj47 = node44.getProp((int) (byte) 0);
        node44.setCharno(0);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean52 = node51.isOptionalArg();
        node51.setVarArgs(false);
        boolean boolean55 = node51.isParamList();
        boolean boolean56 = node44.isEquivalentToTyped(node51);
        node37.addChildrenToFront(node51);
        boolean boolean58 = node37.isGetterDef();
        boolean boolean59 = closureCodingConvention0.isVarArgsParameter(node37);
        java.lang.String str60 = node37.toString();
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(objectTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(nodeArray33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "NUMBER 0.0" + "'", str60.equals("NUMBER 0.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        java.lang.Object obj6 = node3.getProp((int) (byte) 0);
        node3.setCharno(0);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = node10.useSourceInfoIfMissingFromForTree(node12);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray19 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList20, objectTypeArray19);
        java.util.Map<java.lang.String, java.lang.String> strMap22 = null;
        closureCodingConvention14.defineDelegateProxyPrototypeProperties(jSTypeRegistry17, jSTypeStaticScope18, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList20, strMap22);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node27.setOptionalArg(true);
        boolean boolean30 = closureCodingConvention14.isPrototypeAlias(node27);
        node13.addChildToFront(node27);
        node3.addChildrenToFront(node13);
        boolean boolean33 = node13.isBreak();
        com.google.javascript.rhino.JSDocInfo jSDocInfo34 = null;
        node13.setJSDocInfo(jSDocInfo34);
        boolean boolean36 = node13.isHook();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(objectTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile4, false);
        java.lang.String str7 = sourceFile4.getName();
        com.google.javascript.rhino.Node node8 = compiler2.parse(sourceFile4);
        boolean boolean9 = node8.isLabelName();
        java.lang.String str10 = node0.checkTreeEquals(node8);
        node8.setVarArgs(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node8.getJSType();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "module$hi!" + "'", str7.equals("module$hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nSCRIPT [source_file: module$hi!] [input_id: InputId: module$hi!]\n\n\nSubtree1: BREAK\n\n\nSubtree2: SCRIPT [source_file: module$hi!] [input_id: InputId: module$hi!]\n" + "'", str10.equals("Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nSCRIPT [source_file: module$hi!] [input_id: InputId: module$hi!]\n\n\nSubtree1: BREAK\n\n\nSubtree2: SCRIPT [source_file: module$hi!] [input_id: InputId: module$hi!]\n"));
        org.junit.Assert.assertNull(jSType13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.labelName("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        int int5 = node3.getLength();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope10 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray11 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList12, objectTypeArray11);
        java.util.Map<java.lang.String, java.lang.String> strMap14 = null;
        closureCodingConvention6.defineDelegateProxyPrototypeProperties(jSTypeRegistry9, jSTypeStaticScope10, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList12, strMap14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node20 = node17.useSourceInfoIfMissingFromForTree(node19);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope25 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray26 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList27, objectTypeArray26);
        java.util.Map<java.lang.String, java.lang.String> strMap29 = null;
        closureCodingConvention21.defineDelegateProxyPrototypeProperties(jSTypeRegistry24, jSTypeStaticScope25, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList27, strMap29);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node34.setOptionalArg(true);
        boolean boolean37 = closureCodingConvention21.isPrototypeAlias(node34);
        node20.addChildToFront(node34);
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.script(nodeArray39);
        java.lang.String str41 = closureCodingConvention6.extractClassNameIfProvide(node34, node40);
        com.google.javascript.rhino.InputId inputId42 = com.google.javascript.jscomp.NodeUtil.getInputId(node40);
        com.google.javascript.rhino.Node node43 = node3.copyInformationFrom(node40);
        boolean boolean44 = node40.isFunction();
        try {
            node1.removeChild(node40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeCollection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(objectTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(objectTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(inputId42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        boolean boolean29 = functionType28.isFunctionPrototypeType();
        boolean boolean30 = functionType28.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = functionType28.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        boolean boolean40 = functionType39.isFunctionPrototypeType();
        boolean boolean41 = functionType39.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType16, functionType28, functionType39 };
        com.google.javascript.rhino.Node node43 = jSTypeRegistry12.createParametersWithVarArgs(jSTypeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList49 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList49, jSTypeArray48);
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createFunctionTypeWithVarArgs(jSType47, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList49);
        boolean boolean52 = functionType51.isFunctionPrototypeType();
        boolean boolean53 = functionType51.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry12.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType51, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        boolean boolean67 = functionType66.isFunctionPrototypeType();
        boolean boolean68 = functionType66.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType69 = functionType66.getOwnerFunction();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType70 = jSTypeRegistry3.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType51, (com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean71 = parameterizedType70.isNativeObjectType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo73 = null;
        parameterizedType70.setPropertyJSDocInfo("", jSDocInfo73);
        boolean boolean75 = parameterizedType70.isCheckedUnknownType();
        boolean boolean76 = parameterizedType70.canBeCalled();
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(functionType31);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(functionType69);
        org.junit.Assert.assertNotNull(parameterizedType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean11 = node10.isOptionalArg();
        node10.setVarArgs(false);
        boolean boolean14 = node10.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createFunctionTypeWithVarArgs(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        boolean boolean23 = functionType22.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList29 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList29, jSTypeArray28);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createFunctionTypeWithVarArgs(jSType27, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList29);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue32 = functionType22.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType31);
        boolean boolean33 = functionType31.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry2.createObjectType("goog.exportProperty", node10, (com.google.javascript.rhino.jstype.ObjectType) functionType31);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        boolean boolean43 = functionType42.isFunctionPrototypeType();
        boolean boolean44 = functionType42.isOrdinaryFunction();
        boolean boolean45 = functionType42.matchesNumberContext();
        com.google.javascript.rhino.jstype.JSType jSType46 = functionType42.collapseUnion();
        boolean boolean47 = functionType42.isInterface();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry2.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType42, jSTypeArray48);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNotNull(ternaryValue32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertNotNull(functionType49);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean11 = node10.isOptionalArg();
        node10.setVarArgs(false);
        boolean boolean14 = node10.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createFunctionTypeWithVarArgs(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        boolean boolean23 = functionType22.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, false);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList29 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList29, jSTypeArray28);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createFunctionTypeWithVarArgs(jSType27, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList29);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue32 = functionType22.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType31);
        boolean boolean33 = functionType31.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry2.createObjectType("goog.exportProperty", node10, (com.google.javascript.rhino.jstype.ObjectType) functionType31);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention35 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node41 = node38.useSourceInfoIfMissingFromForTree(node40);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node46 = node43.useSourceInfoIfMissingFromForTree(node45);
        boolean boolean47 = node46.isSetterDef();
        boolean boolean48 = node46.isString();
        com.google.javascript.rhino.Node node49 = node38.useSourceInfoIfMissingFrom(node46);
        java.lang.String str50 = closureCodingConvention35.extractClassNameIfRequire(node36, node49);
        java.lang.String str51 = closureCodingConvention35.getExportPropertyFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList57, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createFunctionTypeWithVarArgs(jSType55, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList57);
        boolean boolean60 = functionType59.isConstructor();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList61 = functionType59.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry64.createFunctionTypeWithVarArgs(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        boolean boolean70 = functionType69.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, false);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList76 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean77 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList76, jSTypeArray75);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createFunctionTypeWithVarArgs(jSType74, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList76);
        boolean boolean79 = functionType78.isFunctionPrototypeType();
        boolean boolean80 = functionType78.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair81 = functionType69.getTypesUnderEquality((com.google.javascript.rhino.jstype.JSType) functionType78);
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType82 = null;
        closureCodingConvention35.applySubclassRelationship(functionType59, functionType78, subclassType82);
        com.google.javascript.rhino.Node node85 = functionType78.getPropertyNode("JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.rhino.jstype.ObjectType objectType86 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType78, objectType86);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative88 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative88);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.InstanceObjectType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNotNull(ternaryValue32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "goog.exportProperty" + "'", str51.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(functionTypeList61);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(typePair81);
        org.junit.Assert.assertNull(node85);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertTrue("'" + jSTypeNative88 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE + "'", jSTypeNative88.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setOutputCharset("module$");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.setRenamePrefixNamespace("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.aggressiveVarCheck;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        com.google.javascript.rhino.Node node6 = compiler1.parse(sourceFile3);
        java.lang.String str7 = compiler1.toSource();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.syntheticBlockEndMarker = "./";
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node14 = node11.useSourceInfoIfMissingFromForTree(node13);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray20 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList21, objectTypeArray20);
        java.util.Map<java.lang.String, java.lang.String> strMap23 = null;
        closureCodingConvention15.defineDelegateProxyPrototypeProperties(jSTypeRegistry18, jSTypeStaticScope19, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList21, strMap23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node28.setOptionalArg(true);
        boolean boolean31 = closureCodingConvention15.isPrototypeAlias(node28);
        node14.addChildToFront(node28);
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.script(nodeArray33);
        java.lang.String str35 = closureCodingConvention0.extractClassNameIfProvide(node28, node34);
        boolean boolean36 = node28.isNew();
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(objectTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(nodeArray33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstantKey("// Input %num%");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setInlineFunctions(false);
        boolean boolean3 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode5 = compilerOptions4.getLanguageOut();
        compilerOptions4.setMarkAsCompiled(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        compilerOptions4.variableRenaming = variableRenamingPolicy8;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy8);
        compilerOptions0.locale = "module${proxy:function (): {1307325090}}";
        compilerOptions0.optimizeCalls = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList16 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList16, warningsGuardArray15);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard18 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str22 = diagnosticType21.key;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray23 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType19, diagnosticType20, diagnosticType21 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray23);
        boolean boolean25 = composeWarningsGuard18.enables(diagnosticGroup24);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard18);
        compilerOptions0.instrumentationTemplate = "module$(Not declared as a type name)";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(languageMode5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str22.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(diagnosticTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("module$hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        int int4 = node3.getSideEffectFlags();
        boolean boolean5 = node3.isHook();
        com.google.javascript.rhino.Node node6 = assertInstanceofSpec1.getAssertedParam(node3);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList12, jSTypeArray11);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createFunctionTypeWithVarArgs(jSType10, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList12);
        boolean boolean15 = functionType14.isConstructor();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = null;
        functionType14.setPropertyJSDocInfo("", jSDocInfo17);
        boolean boolean19 = functionType14.matchesObjectContext();
        com.google.javascript.rhino.Node node20 = functionType14.getParametersNode();
        node20.setLineno(43);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection25 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.throwNode(node24);
        boolean boolean28 = node26.getBooleanProp(100);
        boolean boolean29 = node26.isFor();
        try {
            com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.tryCatchFinally(node6, node20, node26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeCollection25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckSuspiciousCode(true);
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode4 = compilerOptions0.getTracerMode();
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + tracerMode4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode4.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean10 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        com.google.javascript.rhino.Node node6 = compiler1.parse(sourceFile3);
        double double7 = compiler1.getProgress();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
//        boolean boolean3 = node2.isOptionalArg();
//        node2.setVarArgs(false);
//        com.google.javascript.rhino.JSTypeExpression jSTypeExpression7 = new com.google.javascript.rhino.JSTypeExpression(node2, "");
//        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression7);
//        com.google.javascript.rhino.Node node9 = jSTypeExpression7.getRoot();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.lang.String[] strArray13 = new java.lang.String[] { "module${proxy:function (): {1307325090}}", "module$hi!" };
//        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("", node9, diagnosticType10, strArray13);
//        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType10.level;
//        org.junit.Assert.assertNotNull(node2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(jSTypeExpression8);
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNotNull(diagnosticType10);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertNotNull(jSError14);
//        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node13.setOptionalArg(true);
        boolean boolean16 = closureCodingConvention0.isPrototypeAlias(node13);
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        boolean boolean19 = closureCodingConvention0.isSuperClassReference("JSC_OPTIMIZE_LOOP_ERROR");
        boolean boolean21 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node26 = node23.useSourceInfoIfMissingFromForTree(node25);
        java.lang.Object obj28 = node25.getProp((int) (byte) 0);
        node25.setCharno(0);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node35 = node32.useSourceInfoIfMissingFromForTree(node34);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention36 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope40 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray41 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList42 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList42, objectTypeArray41);
        java.util.Map<java.lang.String, java.lang.String> strMap44 = null;
        closureCodingConvention36.defineDelegateProxyPrototypeProperties(jSTypeRegistry39, jSTypeStaticScope40, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList42, strMap44);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node49.setOptionalArg(true);
        boolean boolean52 = closureCodingConvention36.isPrototypeAlias(node49);
        node35.addChildToFront(node49);
        node25.addChildrenToFront(node35);
        int int56 = node25.getIntProp((int) (byte) 1);
        java.util.Map<java.lang.String, java.lang.String> strMap57 = null;
        closureCodingConvention0.checkForCallingConventionDefiningCalls(node25, strMap57);
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(objectTypeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isFunctionPrototypeType();
        boolean boolean20 = functionType18.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionType18.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        boolean boolean30 = functionType29.isFunctionPrototypeType();
        boolean boolean31 = functionType29.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType6, functionType18, functionType29 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean42 = functionType41.isFunctionPrototypeType();
        boolean boolean43 = functionType41.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry2.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList54, jSTypeArray53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry51.createFunctionTypeWithVarArgs(jSType52, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList54);
        boolean boolean57 = functionType56.isConstructor();
        boolean boolean59 = functionType56.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.rhino.jstype.ObjectType objectType60 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType56);
        com.google.javascript.rhino.jstype.StaticSlot staticSlot62 = functionType56.getSlot("()");
        boolean boolean63 = functionType41.hasEqualCallType(functionType56);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertNull(staticSlot62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        boolean boolean6 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.disambiguateProperties = false;
        java.lang.String[] strArray21 = new java.lang.String[] { "Unversioned directory", "DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)", "hi!", "module$Not declared as a type name", "JSC_OPTIMIZE_LOOP_ERROR", "JSC_OPTIMIZE_LOOP_ERROR", "function (): {58344744}", "./", "", "", "goog.exportProperty", "function (): {58344744}" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        compilerOptions0.setExtraAnnotationNames((java.util.Set<java.lang.String>) strSet22);
        java.lang.String str25 = compilerOptions0.inputDelimiter;
        compilerOptions0.setFoldConstants(true);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "// Input %num%" + "'", str25.equals("// Input %num%"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean4 = node3.isOptionalArg();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean7 = node6.isOptionalArg();
        try {
            node1.addChildrenAfter(node3, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.setCheckProvides(checkLevel4);
        compilerOptions0.inlineFunctions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkMissingReturn;
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList14, jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry11.createFunctionTypeWithVarArgs(jSType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList14);
        boolean boolean17 = functionType16.isConstructor();
        boolean boolean19 = functionType16.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        java.util.Set<java.lang.String> strSet20 = functionType16.getPropertyNames();
        compilerOptions0.setStripNamePrefixes(strSet20);
        boolean boolean22 = compilerOptions0.jqueryPass;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strSet20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node14 = node11.useSourceInfoIfMissingFromForTree(node13);
        java.lang.Object obj16 = node13.getProp((int) (byte) 0);
        node13.setCharno(0);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean21 = node20.isOptionalArg();
        node20.setVarArgs(false);
        boolean boolean24 = node20.isParamList();
        boolean boolean25 = node13.isEquivalentToTyped(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node26);
        java.util.Collection<java.lang.String> strCollection28 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node30 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "function (): ?");
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strCollection28);
        org.junit.Assert.assertNotNull(node30);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.setRemoveDeadCode(false);
//        compilerOptions0.setClosurePass(false);
//        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
//        compilerOptions0.setMessageBundle(messageBundle5);
//        compilerOptions0.setGenerateExports(true);
//        compilerOptions0.setCommonJSModulePathPrefix("(Not declared as a type name)");
//        compilerOptions0.moveFunctionDeclarations = true;
//        boolean boolean13 = compilerOptions0.disambiguateProperties;
//        boolean boolean14 = compilerOptions0.foldConstants;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode16 = compilerOptions15.getLanguageOut();
//        compilerOptions15.setInlineVariables(false);
//        boolean boolean19 = compilerOptions15.aliasAllStrings;
//        compilerOptions15.setRuntimeTypeCheck(true);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode23 = compilerOptions22.getLanguageOut();
//        compilerOptions22.setReserveRawExports(true);
//        compilerOptions22.setCheckSymbols(false);
//        boolean boolean28 = compilerOptions22.removeUnusedLocalVars;
//        com.google.javascript.jscomp.ErrorFormat errorFormat29 = compilerOptions22.errorFormat;
//        compilerOptions15.errorFormat = errorFormat29;
//        compilerOptions0.errorFormat = errorFormat29;
//        com.google.javascript.jscomp.MessageBundle messageBundle32 = compilerOptions0.messageBundle;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.lang.String[] strArray40 = new java.lang.String[] { "module$hi!", "(Not declared as a type name)", "DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)" };
//        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("", (int) '4', 0, diagnosticType36, strArray40);
//        com.google.javascript.jscomp.CheckLevel checkLevel42 = jSError41.getDefaultLevel();
//        com.google.javascript.jscomp.CheckLevel checkLevel43 = jSError41.level;
//        com.google.javascript.jscomp.CheckLevel checkLevel44 = jSError41.getDefaultLevel();
//        compilerOptions0.checkMissingReturn = checkLevel44;
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(languageMode16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(languageMode23);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(errorFormat29);
//        org.junit.Assert.assertNull(messageBundle32);
//        org.junit.Assert.assertNotNull(diagnosticType36);
//        org.junit.Assert.assertNotNull(strArray40);
//        org.junit.Assert.assertNotNull(jSError41);
//        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("{proxy:function (): {1672076576}}", "goog.global", "NUMBER 0.0");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList14, jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry11.createFunctionTypeWithVarArgs(jSType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList14);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue17 = functionType7.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, false);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList23, jSTypeArray22);
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createFunctionTypeWithVarArgs(jSType21, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList23);
        boolean boolean26 = functionType25.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue35 = functionType25.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean36 = functionType34.isReturnTypeInferred();
        boolean boolean37 = functionType16.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.jstype.ObjectType objectType38 = functionType34.getImplicitPrototype();
        com.google.javascript.rhino.jstype.JSType jSType39 = functionType34.autoboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertNotNull(ternaryValue17);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNotNull(ternaryValue35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertNull(jSType39);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isConstructor();
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = null;
        functionType7.setPropertyJSDocInfo("", jSDocInfo10);
        boolean boolean12 = functionType7.matchesObjectContext();
        com.google.javascript.rhino.Node node13 = functionType7.getParametersNode();
        boolean boolean14 = functionType7.isStringObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection2 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        boolean boolean3 = node1.isReturn();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script(nodeArray4);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.newNode(node1, nodeArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.objectlit(nodeArray4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.objectlit(nodeArray4);
        com.google.javascript.rhino.Node node9 = node8.getFirstChild();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.defaultCase(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkUnreachableCode = checkLevel6;
        boolean boolean8 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy4.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        int int1 = typePosition0.getStartLine();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean4 = node3.isTrue();
        typePosition0.setItem(node3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isFunctionPrototypeType();
        boolean boolean20 = functionType18.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionType18.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        boolean boolean30 = functionType29.isFunctionPrototypeType();
        boolean boolean31 = functionType29.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType6, functionType18, functionType29 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean42 = functionType41.isFunctionPrototypeType();
        boolean boolean43 = functionType41.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry2.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.jstype.UnionType unionType49 = functionType41.toMaybeUnionType();
        boolean boolean50 = functionType41.isRegexpType();
        boolean boolean51 = functionType41.isBooleanValueType();
        functionType41.clearCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSType jSType56 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList58 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList58, jSTypeArray57);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry55.createFunctionTypeWithVarArgs(jSType56, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList58);
        boolean boolean61 = functionType60.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry64.createFunctionTypeWithVarArgs(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue70 = functionType60.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType69);
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, false);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList76 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean77 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList76, jSTypeArray75);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createFunctionTypeWithVarArgs(jSType74, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList76);
        boolean boolean79 = functionType78.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry82 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter80, false);
        com.google.javascript.rhino.jstype.JSType jSType83 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList85 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean86 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList85, jSTypeArray84);
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry82.createFunctionTypeWithVarArgs(jSType83, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList85);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue88 = functionType78.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType87);
        boolean boolean89 = functionType87.isReturnTypeInferred();
        boolean boolean90 = functionType69.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType87);
        com.google.javascript.rhino.jstype.ObjectType objectType91 = functionType87.getImplicitPrototype();
        java.util.Set<java.lang.String> strSet92 = functionType87.getPropertyNames();
        boolean boolean93 = functionType41.equals((java.lang.Object) functionType87);
        com.google.common.collect.ImmutableList<java.lang.String> strList94 = functionType41.getTemplateTypeNames();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNull(unionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSTypeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNotNull(ternaryValue70);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(jSTypeArray84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNotNull(ternaryValue88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(objectType91);
        org.junit.Assert.assertNotNull(strSet92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(strList94);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineVariables(false);
        compilerOptions0.inputDelimiter = "hi!";
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNamePrefixes;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing8 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        compilerOptions0.setTweakProcessing(tweakProcessing8);
        compilerOptions0.preferLineBreakAtEndOfFile = false;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + tweakProcessing8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing8.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isFunctionPrototypeType();
        boolean boolean20 = functionType18.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionType18.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        boolean boolean30 = functionType29.isFunctionPrototypeType();
        boolean boolean31 = functionType29.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType6, functionType18, functionType29 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean42 = functionType41.isFunctionPrototypeType();
        boolean boolean43 = functionType41.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry2.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.jstype.UnionType unionType49 = functionType41.toMaybeUnionType();
        boolean boolean50 = functionType41.hasAnyTemplateInternal();
        boolean boolean51 = functionType41.isInterface();
        boolean boolean52 = functionType41.isStringValueType();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNull(unionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node13.setOptionalArg(true);
        boolean boolean16 = closureCodingConvention0.isPrototypeAlias(node13);
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        boolean boolean19 = closureCodingConvention0.isConstantKey("{proxy:function (): {1307325090}}");
        boolean boolean21 = closureCodingConvention0.isSuperClassReference("module$(Not declared as a type name)");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node26 = node23.useSourceInfoIfMissingFromForTree(node25);
        boolean boolean27 = node25.isOr();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(31, "Not declared as a type name", (int) (byte) 1, 43);
        com.google.javascript.rhino.Node node33 = node25.copyInformationFrom(node32);
        try {
            java.lang.String str34 = closureCodingConvention0.getSingletonGetterClassName(node33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.lang.String[] strArray7 = new java.lang.String[] { "module$hi!", "(Not declared as a type name)", "DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)" };
//        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("", (int) '4', 0, diagnosticType3, strArray7);
//        com.google.javascript.jscomp.CheckLevel checkLevel9 = jSError8.getDefaultLevel();
//        int int10 = jSError8.getLineNumber();
//        int int11 = jSError8.getNodeSourceOffset();
//        int int12 = jSError8.getLineNumber();
//        int int13 = jSError8.getLineNumber();
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertNotNull(strArray7);
//        org.junit.Assert.assertNotNull(jSError8);
//        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        compilerOptions0.removeDeadCode = true;
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.removeUnusedClassProperties = true;
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isConstructor();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList9 = functionType7.getSubTypes();
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = functionType7.getOwnPropertyJSDocInfo("");
        boolean boolean12 = functionType7.matchesObjectContext();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(functionTypeList9);
        org.junit.Assert.assertNull(jSDocInfo11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        java.lang.Object obj6 = node3.getProp((int) (byte) 0);
        node3.setCharno(0);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean11 = node10.isOptionalArg();
        node10.setVarArgs(false);
        boolean boolean14 = node10.isParamList();
        boolean boolean15 = node3.isEquivalentToTyped(node10);
        boolean boolean16 = node3.isIn();
        boolean boolean17 = node3.isBlock();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isFunctionPrototypeType();
        boolean boolean20 = functionType18.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionType18.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        boolean boolean30 = functionType29.isFunctionPrototypeType();
        boolean boolean31 = functionType29.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType6, functionType18, functionType29 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry36.createFunctionTypeWithVarArgs(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        boolean boolean42 = functionType41.isFunctionPrototypeType();
        boolean boolean43 = functionType41.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry2.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.jstype.UnionType unionType49 = functionType41.toMaybeUnionType();
        boolean boolean50 = functionType41.isRegexpType();
        java.lang.Iterable iterable51 = functionType41.getCtorImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNull(unionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(iterable51);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setDebugFunctionSideEffectsPath("hi!");
        compilerOptions0.renamePrefixNamespace = "";
        com.google.javascript.jscomp.CheckLevel checkLevel15 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setReportMissingOverride(checkLevel15);
        boolean boolean17 = compilerOptions0.checkTypes;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.collapseProperties = true;
        compilerOptions0.preferLineBreakAtEndOfFile = false;
        compilerOptions0.gatherCssNames = true;
        boolean boolean10 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.setSmartNameRemoval(false);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.identifyNonNullableName("Not declared as a type name");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createFunctionTypeWithVarArgs(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        boolean boolean13 = functionType12.isConstructor();
        boolean boolean15 = functionType12.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.rhino.jstype.ObjectType objectType16 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType12);
        boolean boolean18 = jSTypeRegistry2.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) objectType16, "");
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry2.createNamedType("", "", 8, 0);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSType23);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.SourceMap.Format format4 = com.google.javascript.jscomp.SourceMap.Format.V1;
        compilerOptions0.setSourceMapFormat(format4);
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.aliasStringsBlacklist = "";
        java.lang.Object obj10 = compilerOptions0.clone();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy11);
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setCommonJSModulePathPrefix("(Not declared as a type name)");
        boolean boolean11 = compilerOptions0.printInputDelimiter;
        boolean boolean12 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.ambiguateProperties = true;
        compilerOptions0.setFoldConstants(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceFile1, false);
        java.lang.String str5 = compilerInput3.getLine(0);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, false);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.SourceMap.Format format4 = com.google.javascript.jscomp.SourceMap.Format.V1;
        compilerOptions0.setSourceMapFormat(format4);
        compilerOptions0.moveFunctionDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode9 = compilerOptions8.getLanguageOut();
        compilerOptions8.setReserveRawExports(true);
        compilerOptions8.setCheckSymbols(false);
        compilerOptions8.setOutputJsStringUsage(true);
        compilerOptions8.setRemoveClosureAsserts(true);
        boolean boolean18 = compilerOptions8.shouldColorizeErrorOutput();
        compilerOptions8.setDebugFunctionSideEffectsPath("hi!");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy21 = compilerOptions8.anonymousFunctionNaming;
        compilerOptions0.setAnonymousFunctionNaming(anonymousFunctionNamingPolicy21);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertNull(languageMode9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy21 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy21.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection2 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        boolean boolean3 = node1.isReturn();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node9 = node6.useSourceInfoIfMissingFromForTree(node8);
        boolean boolean10 = node8.isOr();
        node8.setWasEmptyNode(false);
        boolean boolean13 = node8.isDefaultCase();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.throwNode(node8);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node19 = node16.useSourceInfoIfMissingFromForTree(node18);
        boolean boolean20 = node19.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node21 = node14.useSourceInfoFromForTree(node19);
        node4.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node23 = null;
        try {
            com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.sheq(node4, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkTypes;
        boolean boolean2 = compilerOptions0.reserveRawExports;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createFunctionTypeWithVarArgs(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean17 = node16.isOptionalArg();
        node16.setVarArgs(false);
        boolean boolean20 = node16.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        boolean boolean29 = functionType28.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry32.createFunctionTypeWithVarArgs(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue38 = functionType28.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType37);
        boolean boolean39 = functionType37.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry8.createObjectType("goog.exportProperty", node16, (com.google.javascript.rhino.jstype.ObjectType) functionType37);
        java.util.Set<java.lang.String> strSet41 = functionType37.getPropertyNames();
        compilerOptions0.stripTypePrefixes = strSet41;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(ternaryValue38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(strSet41);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.rhino.Node node0 = null;
        try {
            boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList8, jSTypeArray7);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createFunctionTypeWithVarArgs(jSType6, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList8);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createFunctionTypeWithVarArgs(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
        boolean boolean19 = functionType18.isFunctionPrototypeType();
        boolean boolean20 = functionType18.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType21 = functionType18.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        boolean boolean30 = functionType29.isFunctionPrototypeType();
        boolean boolean31 = functionType29.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType6, functionType18, functionType29 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray32);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope34 = null;
        jSTypeRegistry2.resolveTypesInScope(jSTypeStaticScope34);
        jSTypeRegistry2.setLastGeneration(false);
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isConstructor();
        boolean boolean10 = functionType7.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        java.util.Set<java.lang.String> strSet11 = functionType7.getPropertyNames();
        boolean boolean12 = functionType7.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.ObjectType.Property property14 = functionType7.getOwnSlot("Not declared as a type name");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(property14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        node1.removeProp(16);
        boolean boolean7 = node1.isDefaultCase();
        boolean boolean8 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node1);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("Not declared as a type name", "./");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$Not declared as a type name" + "'", str2.equals("module$Not declared as a type name"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!" };
        java.util.ArrayList<java.lang.String> strList10 = new java.util.ArrayList<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList10, strArray9);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo12 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "", (java.util.List<java.lang.String>) strList6, (java.util.List<java.lang.String>) strList10);
        java.lang.String str13 = simpleDependencyInfo12.getPathRelativeToClosureBase();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node6 = node3.useSourceInfoIfMissingFromForTree(node5);
        boolean boolean7 = node6.isSetterDef();
        boolean boolean8 = node6.isString();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (byte) 1, node6);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node6);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection13 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node12);
        boolean boolean14 = node12.isNot();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean17 = node16.isOptionalArg();
        node16.setVarArgs(false);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node24 = node21.useSourceInfoIfMissingFromForTree(node23);
        java.lang.Object obj26 = node23.getProp((int) (byte) 0);
        node23.setCharno(0);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean31 = node30.isOptionalArg();
        node30.setVarArgs(false);
        boolean boolean34 = node30.isParamList();
        boolean boolean35 = node23.isEquivalentToTyped(node30);
        node16.addChildrenToFront(node30);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection39 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node38);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.throwNode(node38);
        boolean boolean41 = node30.isEquivalentTo(node38);
        com.google.javascript.rhino.Node node42 = node12.useSourceInfoIfMissingFromForTree(node38);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile43 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node12);
        java.lang.String str44 = node0.checkTreeEquals(node12);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeCollection39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(staticSourceFile43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nNUMBER 0.0\n\n\nSubtree1: BREAK\n\n\nSubtree2: NUMBER 0.0\n" + "'", str44.equals("Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nNUMBER 0.0\n\n\nSubtree1: BREAK\n\n\nSubtree2: NUMBER 0.0\n"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention1.getAssertionFunctions();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.trueNode();
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention1.checkForCallingConventionDefiningCalls(node3, strMap4);
        try {
            boolean boolean6 = googleCodingConvention0.isOptionalParameter(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: TRUE is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        int int1 = typePosition0.getStartLine();
        typePosition0.setPositionInformation((-1), 0, 39, (int) (short) 0);
        boolean boolean7 = typePosition0.hasBrackets();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] { "module$hi!", "(Not declared as a type name)", "DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", (int) '4', 0, diagnosticType14, strArray18);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType14.level = checkLevel20;
        compilerOptions0.setCheckMissingGetCssNameLevel(checkLevel20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setRemoveDeadCode(false);
        compilerOptions23.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle28 = null;
        compilerOptions23.setMessageBundle(messageBundle28);
        compilerOptions23.setGenerateExports(true);
        compilerOptions23.setCommonJSModulePathPrefix("(Not declared as a type name)");
        compilerOptions23.exportTestFunctions = true;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode36 = compilerOptions23.getLanguageIn();
        compilerOptions0.setLanguageOut(languageMode36);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing38 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy39 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        compilerOptions0.variableRenaming = variableRenamingPolicy39;
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.setRemoveDeadCode(false);
        compilerOptions41.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle46 = null;
        compilerOptions41.setMessageBundle(messageBundle46);
        compilerOptions41.setGenerateExports(true);
        compilerOptions41.setCommonJSModulePathPrefix("(Not declared as a type name)");
        compilerOptions41.moveFunctionDeclarations = true;
        boolean boolean54 = compilerOptions41.disambiguateProperties;
        boolean boolean55 = compilerOptions41.foldConstants;
        com.google.javascript.jscomp.CompilerOptions compilerOptions56 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode57 = compilerOptions56.getLanguageOut();
        compilerOptions56.setInlineVariables(false);
        boolean boolean60 = compilerOptions56.aliasAllStrings;
        compilerOptions56.setRuntimeTypeCheck(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode64 = compilerOptions63.getLanguageOut();
        compilerOptions63.setReserveRawExports(true);
        compilerOptions63.setCheckSymbols(false);
        boolean boolean69 = compilerOptions63.removeUnusedLocalVars;
        com.google.javascript.jscomp.ErrorFormat errorFormat70 = compilerOptions63.errorFormat;
        compilerOptions56.errorFormat = errorFormat70;
        compilerOptions41.errorFormat = errorFormat70;
        compilerOptions0.setErrorFormat(errorFormat70);
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + languageMode36 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode36.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertTrue("'" + tweakProcessing38 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing38.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy39 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy39.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(languageMode57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(languageMode64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(errorFormat70);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setCollapseObjectLiterals(true);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel8;
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveDeadCode(false);
        compilerOptions0.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = null;
        compilerOptions0.setMessageBundle(messageBundle5);
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setCommonJSModulePathPrefix("(Not declared as a type name)");
        compilerOptions0.moveFunctionDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode13 = compilerOptions0.getLanguageOut();
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap14 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertNull(languageMode13);
        org.junit.Assert.assertNull(cssRenamingMap14);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isFunctionPrototypeType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList14, jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry11.createFunctionTypeWithVarArgs(jSType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList14);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue17 = functionType7.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType16);
        boolean boolean18 = functionType16.isReturnTypeInferred();
        boolean boolean19 = functionType16.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertNotNull(ternaryValue17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection2 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        boolean boolean3 = node1.isNot();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean6 = node5.isOptionalArg();
        node5.setVarArgs(false);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node13 = node10.useSourceInfoIfMissingFromForTree(node12);
        java.lang.Object obj15 = node12.getProp((int) (byte) 0);
        node12.setCharno(0);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean20 = node19.isOptionalArg();
        node19.setVarArgs(false);
        boolean boolean23 = node19.isParamList();
        boolean boolean24 = node12.isEquivalentToTyped(node19);
        node5.addChildrenToFront(node19);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection28 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.throwNode(node27);
        boolean boolean30 = node19.isEquivalentTo(node27);
        com.google.javascript.rhino.Node node31 = node1.useSourceInfoIfMissingFromForTree(node27);
        com.google.javascript.rhino.Node node32 = node1.removeFirstChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeCollection28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(node32);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("module$hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        com.google.javascript.rhino.Node node6 = compiler1.parse(sourceFile3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        boolean boolean9 = node8.isTrue();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, false);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        boolean boolean29 = functionType28.isFunctionPrototypeType();
        boolean boolean30 = functionType28.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = functionType28.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        boolean boolean40 = functionType39.isFunctionPrototypeType();
        boolean boolean41 = functionType39.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { jSType16, functionType28, functionType39 };
        com.google.javascript.rhino.Node node43 = jSTypeRegistry12.createParametersWithVarArgs(jSTypeArray42);
        com.google.javascript.rhino.Node node44 = node8.useSourceInfoIfMissingFromForTree(node43);
        com.google.javascript.rhino.Node node45 = node6.useSourceInfoIfMissingFrom(node43);
        try {
            com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.defaultCase(node43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(functionType31);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node13.setOptionalArg(true);
        boolean boolean16 = closureCodingConvention0.isPrototypeAlias(node13);
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        boolean boolean19 = closureCodingConvention0.isSuperClassReference("JSC_OPTIMIZE_LOOP_ERROR");
        boolean boolean21 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node22 = null;
        try {
            java.lang.String str23 = closureCodingConvention0.getSingletonGetterClassName(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.collapseProperties = true;
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        compilerOptions0.setAnonymousFunctionNaming(anonymousFunctionNamingPolicy8);
        char[] charArray10 = anonymousFunctionNamingPolicy8.getReservedCharacters();
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("module$hi!", (int) (byte) 1, 0);
        node13.setOptionalArg(true);
        boolean boolean16 = closureCodingConvention0.isPrototypeAlias(node13);
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        boolean boolean19 = closureCodingConvention0.isSuperClassReference("JSC_OPTIMIZE_LOOP_ERROR");
        boolean boolean21 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection24 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node23);
        int int25 = node23.getLength();
        int int26 = node23.getSourceOffset();
        boolean boolean27 = closureCodingConvention0.isOptionalParameter(node23);
        java.lang.String str28 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node33 = node30.useSourceInfoIfMissingFromForTree(node32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node38 = node35.useSourceInfoIfMissingFromForTree(node37);
        boolean boolean39 = node38.isSetterDef();
        boolean boolean40 = node38.isString();
        com.google.javascript.rhino.Node node41 = node30.useSourceInfoIfMissingFrom(node38);
        node30.setSourceEncodedPositionForTree((int) (short) 100);
        boolean boolean44 = node30.hasOneChild();
        try {
            java.lang.String str45 = closureCodingConvention0.getSingletonGetterClassName(node30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeCollection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportSymbol" + "'", str28.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node4 = node1.useSourceInfoIfMissingFromForTree(node3);
        boolean boolean5 = node4.isSetterDef();
        boolean boolean6 = node4.isScript();
        boolean boolean7 = node4.isBreak();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node12 = node9.useSourceInfoIfMissingFromForTree(node11);
        node9.removeProp(16);
        boolean boolean15 = node9.isDefaultCase();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.var(node4, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = compilerOptions0.getLanguageOut();
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.setRenamePrefixNamespace("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        compilerOptions0.setManageClosureDependencies(true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node20 = node17.useSourceInfoIfMissingFromForTree(node19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 0.0f);
        com.google.javascript.rhino.Node node25 = node22.useSourceInfoIfMissingFromForTree(node24);
        boolean boolean26 = node25.isSetterDef();
        boolean boolean27 = node25.isString();
        com.google.javascript.rhino.Node node28 = node17.useSourceInfoIfMissingFrom(node25);
        java.lang.String str29 = closureCodingConvention14.extractClassNameIfRequire(node15, node28);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setRemoveDeadCode(false);
        compilerOptions31.setClosurePass(false);
        com.google.javascript.jscomp.MessageBundle messageBundle36 = null;
        compilerOptions31.setMessageBundle(messageBundle36);
        compilerOptions31.setGenerateExports(true);
        compilerOptions31.setCommonJSModulePathPrefix("(Not declared as a type name)");
        compilerOptions31.moveFunctionDeclarations = true;
        boolean boolean44 = compilerOptions31.disambiguateProperties;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel45 = compilerOptions31.sourceMapDetailLevel;
        compilerOptions0.sourceMapDetailLevel = detailLevel45;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel47 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean48 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertNull(languageMode1);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(detailLevel45);
        org.junit.Assert.assertNotNull(detailLevel47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        boolean boolean8 = functionType7.isConstructor();
        boolean boolean10 = functionType7.isPropertyTypeInferred("DependencyInfo(relativePath='', path='JSC_OPTIMIZE_LOOP_ERROR', provides=[hi!], requires=null)");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = null;
        functionType7.setPropertyJSDocInfo("{proxy:function (): {1565557195}}", jSDocInfo13);
        com.google.javascript.rhino.jstype.ObjectType.Property property16 = functionType7.getOwnSlot("{proxy:function (): {1307325090}}");
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNull(property16);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard4 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, jSTypeStaticScope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, strMap8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope14 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray15 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16, objectTypeArray15);
        java.util.Map<java.lang.String, java.lang.String> strMap18 = null;
        closureCodingConvention10.defineDelegateProxyPrototypeProperties(jSTypeRegistry13, jSTypeStaticScope14, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList16, strMap18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, false);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createFunctionTypeWithVarArgs(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList36 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList36, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry33.createFunctionTypeWithVarArgs(jSType34, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList36);
        boolean boolean39 = functionType38.isFunctionPrototypeType();
        boolean boolean40 = functionType38.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType41 = functionType38.getOwnerFunction();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createFunctionTypeWithVarArgs(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        boolean boolean50 = functionType49.isFunctionPrototypeType();
        boolean boolean51 = functionType49.isTemplateType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] { jSType26, functionType38, functionType49 };
        com.google.javascript.rhino.Node node53 = jSTypeRegistry22.createParametersWithVarArgs(jSTypeArray52);
        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54, false);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList59 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList59, jSTypeArray58);
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry56.createFunctionTypeWithVarArgs(jSType57, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList59);
        boolean boolean62 = functionType61.isFunctionPrototypeType();
        boolean boolean63 = functionType61.hasDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry22.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType61, "Not declared as a type name", "module$hi!", (int) (short) 1, (int) ' ');
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69, false);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList74 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList74, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry71.createFunctionTypeWithVarArgs(jSType72, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList74);
        boolean boolean77 = functionType76.isFunctionPrototypeType();
        boolean boolean78 = functionType76.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType79 = functionType76.getOwnerFunction();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType80 = jSTypeRegistry13.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType61, (com.google.javascript.rhino.jstype.JSType) functionType76);
        int int81 = parameterizedType80.getPropertiesCount();
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry3.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) parameterizedType80);
        boolean boolean83 = parameterizedType80.isBooleanValueType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = parameterizedType80.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.TemplateType templateType86 = parameterizedType80.toMaybeTemplateType();
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objectTypeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(functionType41);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(functionType79);
        org.junit.Assert.assertNotNull(parameterizedType80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(jSDocInfo85);
        org.junit.Assert.assertNull(templateType86);
    }
}

